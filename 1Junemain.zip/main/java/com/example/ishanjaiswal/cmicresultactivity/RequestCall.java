package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.preference.PreferenceManager;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

import java.util.ArrayList;

public class RequestCall {
    private final String TAG = RequestCall.class.getSimpleName();
    private String baseURL;
    public RequestCall(Context context){
        SharedPreferences defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(context);
        String serverUrl = defaultSharedPreference.getString(context.getString(R.string.settings_key_server),context.getString(R.string.settings_server_default));
        //String environment = defaultSharedPreference.getString(context.getString(R.string.settings_key_environment),context.getString(R.string.settings_environment_default));
        //baseURL = serverUrl.concat("/").concat(environment);
        baseURL = serverUrl;
    }

    public String requestAuthenticate(Context context, String auth)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.url_Login));
            Log.d(TAG,"Login URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Login(url, auth);
            Log.d(TAG, "Login Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public String requestJobData(Context context)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(WebConstants.jobDataEndPoint);
            Log.d(TAG,"Job Data URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Job Data Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d(TAG, "Job Data Error: "+ e.toString());
            return null;
        }
    }
    public String personData(Context context,String employeeOraseq ,String date)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.person_webservice)).concat("responsibleEmpOraseq=").concat(employeeOraseq).concat("&timesheetDate=").concat(date);
            Log.d(TAG,"Person Data URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Person Data Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.e(TAG,"Person Data Exception: "+ e.toString());
            return e.toString();
        }
    }

    public String personDashboardMembers(Context context,String crewCode,String date)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.dashboard_fetching_members_person) + "crewCode=" + crewCode + "&timesheetDate=" + date);
            Log.d(TAG,"Dashboard 1 URL:"+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Dashboard 1 Response:"+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Dashboard 1 Exception:"+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }

    public String getAllEmployees(Context context)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.employee_data));
            Log.d(TAG,"Get Employees URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Get Employees Response: "+url);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Get Employees Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String insertCrew( Context context,String parameters)
    {
        String url;
        try
        {
            url= baseURL.concat("/").concat(context.getResources().getString(R.string.insert_crew));
            Log.d(TAG,"Inserting Crew URL: "+url);
            Log.d(TAG,"Inserting Crew Request: "+parameters);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.insertCrewNameCrewCode(url, parameters);
            Log.d(TAG,"Inserting Crew Response: "+strResponse);
            return strResponse;

        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Inserting Crew Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }

    public String selectCrewOnCrewCodeBasis( Context context,String crewcode)
    {
        String url;
        try
        {

            url= baseURL.concat("/").concat(context.getResources().getString(R.string.select_inserted_crew_on_crewcode)+"?crewCode="+crewcode);
            Log.d(TAG,"Select Crew On Code Basis URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Select Crew On Code Basis Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Select Crew On Code Basis Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }
    public String selectCrewList( Context context)
    {
        String url;
        try
        {
            url= baseURL.concat("/").concat(context.getResources().getString(R.string.crew_list));
            Log.d(TAG,"Select Crew List URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Select Crew List Response: "+strResponse);
            return strResponse;

        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Select Crew List Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }

    public String linkEmployeeWithCrew(Context context, String crewOraseqForNewCrewInserted, ArrayList<User> selectedEmployees)
    {
        String url;
        try {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.insert_crew_employee));
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.connectionPutEmployee(url, crewOraseqForNewCrewInserted, selectedEmployees);
            Log.d(TAG, "Linking Employee with Crew URL: " + url);
            Log.d(TAG, "Linking Employee with Crew RESPONSE: " + strResponse);
            return strResponse;
        }
        catch (Exception e){
            e.printStackTrace();
            Log.d(TAG,"Linking Employee with Crew Exception "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String retrievingTimeSheet(Context context,String crewCode,String workDate, String jobCode)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.retrieve_time_sheet)+"?crewCode="+crewCode+"&workDate="+workDate+"&jobCode="+jobCode);
            Log.d(TAG,"Retrieve TimeSheet URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve TimeSheet Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.d(TAG,"Retrieve TimeSheet Exception "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String fetchCrewEmployee(Context context, String crewcode ){
        String url;
        try {
            url = baseURL.concat("/").concat(context.getString(R.string.fetch_emp)+"crewCode="+crewcode);
            Log.d(TAG,"Fetch Crew Employee URL: "+url);
            ServerConnection serverConnection = new ServerConnection(context);
            String response = serverConnection.Connection(url);
            Log.d(TAG,"Fetch Crew Employee Response: "+response);
            return response;
        }
        catch (Exception ex){
            Log.e(TAG,"Fetch Crew Employee Error: "+ex.toString());
            return  context.getString(R.string.internal_server_error);
        }
    }
    public String deleteCrewMember(Context context, String pyceOraSeq){
        String url;
        try {
            url = baseURL.concat("/").concat(context.getString(R.string.delete_crew_member_url)+"?pyceOraseq="+pyceOraSeq);
            Log.d(TAG,"Delete Crew Member URL: "+url);
            ServerConnection serverConnection = new ServerConnection(context);
            String response = serverConnection.DeleteConnection(url);
            Log.d(TAG,"Delete Crew Member Response: "+response);
            return response;
        }
        catch (Exception ex){
            ex.printStackTrace();
            Log.e(TAG,"Delete Crew Member Error: "+ex.toString());
            return  context.getString(R.string.internal_server_error);
        }
    }

    public String requestHourData(Context context, String header)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.job_data);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            return e.toString();
        }
    }
    public String phaseWithChild(Context context,String compcode,String jobcode)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.Phase_with_child)+"etimeCompCode="+compcode+"&etimeJobCode="+jobcode+"&childViews=EtimeJcjobcatView");
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Phase With Child URL: "+url);
            Log.d(TAG,"Phase With Child Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Phase With Child Exception: "+e.getMessage());
            return e.toString();
        }
    }

    public String submitTask(Context context, String requestString)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.crew_sheet_updation));
            Log.d(TAG,"Submit Time Sheet URL: "+url);
            Log.d(TAG,"Submit Time Sheet Request: "+requestString);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.submitTimeSheet(url, requestString);
            Log.d(TAG,"Submit Time Sheet Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.d(TAG,"Submit Time Sheet Error: "+e.toString());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String pciTask(Context context,String phaseCode,String categoryCode,String jobCode ,String compcode)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.pci_webservice)+"compCode="+compcode+"&jobCode="+jobCode+"&phsCode="+phaseCode+"&catCode="+categoryCode);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Submit Time Sheet URL: "+url);
            Log.d(TAG,"Submit Time Sheet Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.d(TAG,"PCI TASK Exception: "+e.toString());
            return context.getString(R.string.internal_server_error);
        }
    }

    public String updateResponsiblePerson(Context context, String crewCode, String requestJson){
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.update_responsible_person_webservice)+"crewCode="+crewCode);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.putRequestConnection(url, requestJson);
            Log.d(TAG,"UpdateResponsiblePerson URL: "+url);
            Log.d(TAG,"UpdateResponsiblePerson Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"UpdateResponsiblePerson: Exception - " + e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String deleteAllTask(Context context ,String crewCode,String workDate,String jobCode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.delete_entire_timesheet)+"?crewCode="+crewCode+"&workDate=" +workDate+"&jobCode="+jobCode;
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.DeleteConnection(url);
            Log.d("deleteAllTask",strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("Deleteerror","Caught");
            return null;
        }

    }
    public String dashboardTask(Context context ,String compCode,String jobCode,String workDate)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.dashboard)+"?compCode="+compCode+"&jobCode=" +jobCode+"&timesheetDate="+workDate);
            Log.d(TAG,"Retrieve Dashboard 1 URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve Dashboard 1 Response: "+strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Dashboard 1 Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }
    public String dashboardMembers(Context context ,String compCode,String jobCode,String workDate,String selectedcrewCode)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.dashboard_fetching_members)+"?compCode="+compCode+"&jobCode=" +jobCode+"&timesheetDate="+workDate+"&crewCode="+selectedcrewCode);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve Dashboard 2 URL: "+url);
            Log.d(TAG,"Retrieve Dashboard 2 Response: "+strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Dashboard 2 Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }
    public String dashboardCrewMemberDetails(Context context ,String empNumber,String workDate)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.dashboard_fetching_members_details)+"?empNo="+empNumber+"&timesheetDate="+workDate);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve Dashboard 3 URL: "+url);
            Log.d(TAG,"Retrieve Dashboard 3 Response: "+strResponse);
            return strResponse;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Dashboard 3 Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }

    public String uploadSignatureEmployee(Context context , String empOraseq , String fromDate , String toDate, Signature enumSignature, String encodedImage)
    {
        String fileName = "";
        String url;
        try
        {
            if (enumSignature.equals(Signature.EMPLOYEE)) {
                url = baseURL.concat("/") + context.getResources().getString(R.string.upload_signature_employee) + "empOraseq=" + empOraseq + "&tshFromDate=" + fromDate + "&tshToDate=" + toDate;
                fileName = "signature1.jpg";
            }
            else {
                url = baseURL.concat("/") + context.getResources().getString(R.string.upload_signature_foreman) + "empOraseq=" + empOraseq + "&tshFromDate=" + fromDate + "&tshToDate=" + toDate;
                fileName = "signature2.jpg";
            }
            Log.d(TAG,"Post Signature URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.putSignature(url,fileName,encodedImage );
            Log.d(TAG,"Post Signature Response: "+strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("DashboardMemberDetails",e.toString());
            return null;
        }

    }

    public String getSignatureOraSeq(Context context , String empOraSeq, String fromDate, String toDate)
    {
        String url;
        try
        {
            url = baseURL.concat("/").concat(context.getResources().getString(R.string.get_signature_ora_seq)+"empOraseq="+empOraSeq+"&tshFromDate="+fromDate+"&tshToDate="+toDate);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve Signature OraSeq URL: "+url);
            Log.d(TAG,"Retrieve Signature OraSeq Response: "+strResponse);
            return strResponse;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Signature OraSeq Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }

    public Bitmap getSignature(Context context , String signOraSeq, GetSignature enumSignature){
        String url;
        Bitmap imageSignature;
        try
        {
            if (enumSignature.equals(GetSignature.CREWTIME_FOREMAN_SIGNATURE))
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.get_signature)+"objOraseq="+signOraSeq+"&&objFileType=CREWTIME_FOREMAN_SIGNATURE");
            else
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.get_signature)+"objOraseq="+signOraSeq+"&&objFileType=CREWTIME_EMPLOYEE_SIGNATURE");
            ServerConnection createServerConnection = new ServerConnection(context);
            imageSignature = createServerConnection.loadImage(url);
            Log.d(TAG,"Retrieve Signature URL: "+url);
            Log.d(TAG,"Retrieve Signature Success: ");
            return imageSignature;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Signature Exception: "+e.getMessage());
            return null;
        }
    }

    public String postSignature(Context context , String empOraSeq, String fromDate, String toDate, Signature signatureEnum)
    {
        String url;
        try
        {
            if (signatureEnum == Signature.EMPLOYEE)
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.upload_signature_employee)+"empOraseq="+empOraSeq+"&tshFromDate="+fromDate+"&tshToDate="+toDate);
            else
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.upload_signature_foreman)+"empOraseq="+empOraSeq+"&tshFromDate="+fromDate+"&tshToDate="+toDate);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            if (signatureEnum == Signature.EMPLOYEE) {
                Log.d(TAG, "Upload Signature Employee URL: " + url);
                Log.d(TAG, "Upload Signature Employee Response: " + strResponse);
            }
            else {
                Log.d(TAG, "Upload Signature Foreman URL: " + url);
                Log.d(TAG, "Upload Signature Foreman Response: " + strResponse);
            }
            return strResponse;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Signature OraSeq Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }

    }


    public String deleteSignature(Context context, String empOraSeq, String tshFromDate, String tshToDate, Signature enumSignature) {
        String url;
        try
        {
            if (enumSignature == Signature.EMPLOYEE)
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.delete_signature_employee)+"empOraseq="+empOraSeq+"&tshFromDate="+tshFromDate+"&tshToDate="+tshToDate);
            else
                url = baseURL.concat("/").concat(context.getResources().getString(R.string.delete_signature_foreman)+"empOraseq="+empOraSeq+"&tshFromDate="+tshFromDate+"&tshToDate="+tshToDate);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.DeleteConnection(url);
            if (enumSignature == Signature.EMPLOYEE) {
                Log.d(TAG, "Delete Signature Employee URL: " + url);
                Log.d(TAG, "Delete Signature Employee Response: " + strResponse);
            }
            else {
                Log.d(TAG, "Delete Signature Foreman URL: " + url);
                Log.d(TAG, "Delete Signature Foreman Response: " + strResponse);
            }
            return strResponse;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"Retrieve Signature OraSeq Exception: "+e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
}

