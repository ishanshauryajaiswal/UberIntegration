package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CrewMemberDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard3;
import com.example.ishanjaiswal.cmicresultactivity.Model.SignatureOraSeqModel;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;
import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;
import com.example.ishanjaiswal.cmicresultactivity.parsers.Dashboard2Parser;
import com.example.ishanjaiswal.cmicresultactivity.parsers.Dashboard3Parser;
import com.example.ishanjaiswal.cmicresultactivity.parsers.DashboardParser;
import com.example.ishanjaiswal.cmicresultactivity.parsers.GetSignatureOraSeqParser;

import java.util.HashMap;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class DashboardActivity extends AppCompatActivity implements FragmentClickListener,DashboardTaskListener,JobDataListener,CrewMemberDataListener {

    private RelativeLayout rl,rlHome, rlDashboard;private TextView tvHome, tvDashboard;private ImageView ivHome,ivDashboard;
    FragmentManager fragmentManager;
    private FragmentOne fragmentOne;
    private FragmentTwo fragmentTwo;
    private FragmentThree fragmentThree;
    private HeadlessFragment1 headlessFragment1;
    private ProgressDialog progressDialog;
    private String jobCode, jobName, jobCompCode, crewCode, crewName, date, empOraseq, empNameFromDashboard1, empNumber;
    private boolean flagJobSelected = true;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        rlHome = (RelativeLayout)findViewById(R.id.rlHome);
        rlDashboard = (RelativeLayout)findViewById(R.id.rlDashboard);
        tvHome = (TextView)findViewById(R.id.tvHome);
        tvDashboard = (TextView)findViewById(R.id.tvDashboard);
        ivDashboard = (ImageView)findViewById(R.id.btnDashboard);
        ivHome = (ImageView)findViewById(R.id.btnHome);
        ivHome.setColorFilter(getResources().getColor(R.color.colorBlack));
        tvDashboard.setTextColor(getResources().getColor(R.color.colorLightBlue));
        ivDashboard.setColorFilter(getResources().getColor(R.color.colorLightBlue));
        tvHome.setTextColor(getResources().getColor(R.color.colorBlack));
        rlHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivDashboard.setColorFilter(getResources().getColor(R.color.colorBlack));
                tvDashboard.setTextColor(getResources().getColor(R.color.colorBlack));
                ivHome.setColorFilter(getResources().getColor(R.color.colorLightBlue));
                tvHome.setTextColor(getResources().getColor(R.color.colorLightBlue));
                for(int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                    fragmentManager.popBackStack();
                }
                onBackPressed();
            }
        });
        getValuesFromSharedPreference();
        fragmentManager = getSupportFragmentManager();
        fragmentOne = FragmentOne.getInstance();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer,fragmentOne,FragmentOne.class.getSimpleName())
                .commit();
    }



    @Override
    public void retrieveDashboardData(String date) {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting){
            if (flagJobSelected)
                headlessFragment1.getDashboardData(DashboardActivity.this,jobCompCode, jobCode, date,DashboardActivity.this);
            else
                headlessFragment1.getDashboardData(DashboardActivity.this,empOraseq, date,DashboardActivity.this);
        }
    }

    @Override
    public void retrieveCrewMemberData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.cancelAllRunningTasks();
        if (headlessFragment1.getCrewMemberList()!=null&& headlessFragment1.getCrewMemberList().size()>0)
            fragmentOne.populateCrewMemberList(headlessFragment1.getCrewMemberList());
        else
            headlessFragment1.getCrewMemberData(DashboardActivity.this);
    }

    @Override
    public void retrieveJobData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.cancelAllRunningTasks();
        if (headlessFragment1.getJobDataList()!=null&& headlessFragment1.getJobDataList().size()>0)
            fragmentOne.populateJobData(headlessFragment1.getJobDataList());
        else
            headlessFragment1.getJobData(DashboardActivity.this);
    }

    @Override
    public void retrieveDashboard2Data() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting) {
            if (flagJobSelected)
                headlessFragment1.getDashboard2Data(DashboardActivity.this, jobCompCode, jobCode, crewCode, date, this);
            else
                headlessFragment1.getDashboard2Data(DashboardActivity.this, crewCode, date, DashboardActivity.this);
        }
    }

    @Override
    public void retrieveDashboard3Data() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting) {
            headlessFragment1.getDashboard3Data(DashboardActivity.this, empNumber, date, DashboardActivity.this);
        }
    }

    @Override
    public void retrieveSignatures( String empOraSeq, String startDate, String endDate){
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting) {
            headlessFragment1.getSignatureOraSeq(DashboardActivity.this, DashboardActivity.this, empOraSeq, startDate, endDate);
        }
    }

    @Override
    public void beforeDashboardTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        showProgressDialog(displayMessage);
    }

    @Override
    public void onDashboardTaskComplete(String response) {
        headlessFragment1.isTaskExecuting = false;
        hideProgressDialog();
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            DashboardParser dashboardParser = new DashboardParser();
            List<Dashboard> dashboardList = dashboardParser.parseDashboardData(response);
            if (fragmentOne != null)
                fragmentOne.setUpUI(dashboardList);
        }
        else
            makeAlertErrorOccurred(response);
    }

    @Override
    public void onTaskCancelled() {
        hideProgressDialog();
        makeAlertErrorOccurred("Some Error Occurred While Fetching Details");
    }

    @Override
    public void onDashboard2TaskComplete(String response) {
        headlessFragment1.isTaskExecuting = false;
        hideProgressDialog();
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            Dashboard2Parser parser = new Dashboard2Parser(flagJobSelected);
            List<Dashboard2> dashboard2List = parser.parseDashboard2Data(response);
            fragmentTwo.setUpDashboard(dashboard2List);
        }
        else
            makeAlertErrorOccurred(response);

    }

    @Override
    public void onDashboard3TaskComplete(String response) {
        headlessFragment1.isTaskExecuting = false;
        hideProgressDialog();
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            Dashboard3Parser parser = new Dashboard3Parser();
            List<Dashboard3> dashboard3List = parser.parseDashboard3(response);
            fragmentThree.setUpDashboard(dashboard3List);
        }
        else
            makeAlertErrorOccurred(response);
    }

    @Override
    public void onGetSignatureOraSeqStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        showProgressDialog(displayMessage);
    }

    @Override
    public void onGetSignatureOraSeqCompleted(String response) {
        headlessFragment1.isTaskExecuting = false;
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            GetSignatureOraSeqParser parser = new GetSignatureOraSeqParser();
            SignatureOraSeqModel signatureOraSeqModel = parser.parseSignatureOraSeq(response);
            if (signatureOraSeqModel!=null){
                String signatureOraSeq = signatureOraSeqModel.getSignOraSeq();
                headlessFragment1.getSignature(this,this,signatureOraSeq);
            }
            //If parsed signature oraseq is null load emoty signatures
            else {
                hideProgressDialog();
                fragmentThree.loadDownloadedSignatures(null,null);
            }
        }
        else {
            hideProgressDialog();
            makeAlertErrorOccurred(response);
        }
    }

    @Override
    public void onGetSignatureStarted() {

    }

    HashMap<GetSignature,Bitmap> hashMapSignatureBitmap = new HashMap<>();
    @Override
    public synchronized void onGetSignatureCompleted(Bitmap bitmap, GetSignature enumSignature) {
        if (hashMapSignatureBitmap.size() == 1) {
            hashMapSignatureBitmap.put(enumSignature, bitmap);
            headlessFragment1.isTaskExecuting = false;
            hideProgressDialog();
            fragmentThree.loadDownloadedSignatures(hashMapSignatureBitmap.get(GetSignature.CREWTIME_FOREMAN_SIGNATURE)
                                                    ,hashMapSignatureBitmap.get(GetSignature.CREWTIME_EMPLOYEE_SIGNATURE));
            hashMapSignatureBitmap = new HashMap<>();
        }
        else
            hashMapSignatureBitmap.put(enumSignature,bitmap);
    }

    @Override
    public void postSignature(String empOraSeq, String startDate, String endDate, String encodedImage, Signature signatureEnum){
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting) {
            headlessFragment1.postSignature(DashboardActivity.this, DashboardActivity.this, empOraSeq, startDate, endDate, encodedImage, signatureEnum);
        }
    }

    @Override
    public void onPostSignatureTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        showProgressDialog(displayMessage);
    }

    @Override
    public void onPostSignatureTaskCompleted(String response, Signature enumSignature) {
        headlessFragment1.isTaskExecuting = false;
        hideProgressDialog();
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            fragmentThree.onSignatureSavedSuccess(enumSignature);
        }
        else
            fragmentThree.onSignatureSaveFailure();
    }

    @Override
    public void deleteSignature(String empOraSeq, String startDate, String endDate, Signature signatureEnum){
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting) {
            headlessFragment1.deleteSignature(DashboardActivity.this, DashboardActivity.this, empOraSeq, startDate, endDate, signatureEnum);
        }
    }

    @Override
    public void onDeleteSignatureTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        showProgressDialog(displayMessage);
    }

    @Override
    public void onDeleteSignatureTaskCompleted(String response, Signature enumSignature) {
        headlessFragment1.isTaskExecuting = false;
        hideProgressDialog();
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            fragmentThree.onSignatureDeleteSuccess(enumSignature);
        }
        else
            fragmentThree.onSignatureDeleteFailure();
    }

    @Override
    public void beforeJobDataTaskStarted(String displayMessage) {
        fragmentOne.showPopUpProgressbar();
        headlessFragment1.isTaskExecuting = true;
    }

    @Override
    public void onJobDataTaskComplete(String response) {
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.isTaskExecuting = false;
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            headlessFragment1.setJobDataList(new JobDataParser().parseJobData(response));
            fragmentOne.populateJobData(headlessFragment1.getJobDataList());
        }
        else
            makeAlertErrorOccurred(response);
    }

    @Override
    public void onJobDataTaskCancelled() {
        fragmentOne.hidePopUpProgressbar();
    }

    @Override
    public void onCrewMemberDataTaskStarted() {
        fragmentOne.showPopUpProgressbar();
        headlessFragment1.isTaskExecuting = true;
    }

    @Override
    public void onCrewMemberDataTaskCompleted(String response) {
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.isTaskExecuting = false;
        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
            headlessFragment1.setCrewMemberList(new EmployeeDataParser().parseEmployeeData(response, DashboardActivity.this));
            fragmentOne.populateCrewMemberList(headlessFragment1.getCrewMemberList());
        }
        else
            makeAlertErrorOccurred(response);
    }

    @Override
    public void onCrewMemberDataTaskCancelled() {
        fragmentOne.hidePopUpProgressbar();
    }


    @Override
    public void onCrewMemberSelected(String crewCode, String crewName, String date) {
        this.date = date;
        this.crewName = crewName;
        this.crewCode = crewCode;
        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.cmic_fragment_extras_date_from_dashboard),date);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_comp_code_from_dashboard),jobCode);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_code_from_dashboard),jobCompCode);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_name_from_dashboard),jobName);
        bundle.putString(getString(R.string.cmic_fragment_extras_crew_name_from_dashboard),crewName);
        bundle.putString(getString(R.string.cmic_fragment_extras_employee_number_from_dashboard),empNumber);
        bundle.putString(getString(R.string.cmic_fragment_extras_employee_name_from_dashboard), empNameFromDashboard1);
        bundle.putBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),flagJobSelected);
        fragmentTwo = FragmentTwo.getInstance(bundle);
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,fragmentTwo,FragmentTwo.class.getSimpleName())
                .addToBackStack(FragmentTwo.class.getSimpleName())
                .commit();
    }

    @Override
    public void onCrewMemberSelectedDashboard2(String empNumber, String empNameFromFragment2) {
        this.empNumber = empNumber;
        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.cmic_fragment_extras_date_from_dashboard),date);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_comp_code_from_dashboard),jobCode);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_code_from_dashboard),jobCompCode);
        bundle.putString(getString(R.string.cmic_fragment_extras_job_name_from_dashboard),jobName);
        bundle.putString(getString(R.string.cmic_fragment_extras_employee_number_from_dashboard),empNumber);
        bundle.putString(getString(R.string.cmic_fragment_extras_employee_name_from_dashboard),empNameFromFragment2);
        bundle.putBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),flagJobSelected);
        fragmentThree = FragmentThree.getInstance(bundle);
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,fragmentThree,FragmentThree.class.getSimpleName())
                .addToBackStack(FragmentTwo.class.getSimpleName())
                .commit();
    }

    @Override
    public void setFlag(boolean flagJobSelected) {
        this.flagJobSelected = flagJobSelected;
    }

    @Override
    public void setJob(String jobCompCode, String jobCode, String jobName) {
        this.jobCompCode = jobCompCode;
        this.jobCode = jobCode;
        this.jobName = jobName;
    }

    @Override
    public void setEmployee( String empName) {
        this.empNameFromDashboard1 = empName;
    }

    public void makeAlertErrorOccurred(String errorMessage){
        final AlertDialog.Builder alertBox = new AlertDialog.Builder(DashboardActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        if (errorMessage!=null)
            alertBox.setMessage(errorMessage);
        else
            alertBox.setMessage("Some Error Occurred");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }

    public void showProgressDialog(String displayMessage){
        progressDialog = ProgressDialog.show(DashboardActivity.this,getString(R.string.application_name),displayMessage);

    }

    public void hideProgressDialog(){
        if (progressDialog!=null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    void getValuesFromSharedPreference() {
        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        jobCompCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_comp_code),null);
        jobCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_code),null);
        jobName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_name),null);
        crewCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_crew_code),null);
    }
}
