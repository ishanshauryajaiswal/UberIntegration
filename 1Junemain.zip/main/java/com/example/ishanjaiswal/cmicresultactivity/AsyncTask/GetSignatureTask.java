package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;
import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;

/**
 * Created by ishan.jaiswal on 5/1/2018.
 */

public class GetSignatureTask extends AsyncTask<Void,Void,Bitmap> {

    Context mContext;
    DashboardTaskListener mListener;
    String signatureOraSeq;
    GetSignature enumSignature;

    public GetSignatureTask(Context mContext, DashboardTaskListener mListener, String signatureOraSeq, GetSignature enumSignature) {
        this.mContext = mContext;
        this.mListener = mListener;
        this.signatureOraSeq = signatureOraSeq;
        this.enumSignature = enumSignature;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            mListener.onGetSignatureStarted();
            super.onPreExecute();
        }
    }

    @Override
    protected Bitmap doInBackground(Void... params) {
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(mContext);
                Bitmap imageSignature = requestCall.getSignature(mContext,signatureOraSeq, enumSignature);
                Log.e("tatti", imageSignature.getByteCount()+"");
                return imageSignature;
            } catch (Exception e) {
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if (!isCancelled()) {
            mListener.onGetSignatureCompleted(bitmap, enumSignature);
            super.onPostExecute(bitmap);
        }
    }

    @Override
    protected void onCancelled() {
        mListener.onTaskCancelled();
        super.onCancelled();
    }
}
