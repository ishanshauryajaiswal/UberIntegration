package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PciInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


/**
 * Created by parneet.singh on 11/28/2016.
 */
public class PciTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private String phaseCode,categoryCode,jobCode,compcode;
    private PciInterface pciInterface;

    public PciTask(Context context,String phaseCode,String categoryCode ,String jobCode,String compcode, PciInterface pciInterface)
    {
        this.context = context;
        this.phaseCode = phaseCode;
        this.categoryCode = categoryCode;
        this.pciInterface = pciInterface;
        this.jobCode = jobCode;
        this.compcode = compcode ;
    }


    @Override
    protected void onPreExecute()
    {
        if (!isCancelled())
            pciInterface.BeforeCompleted();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(context);
                result = requestCall.pciTask(context, phaseCode, categoryCode, jobCode, compcode);
            } catch (Exception e) {
            }
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        if (!isCancelled())
            pciInterface.ResultFromPciWebservice(response);
    }
}