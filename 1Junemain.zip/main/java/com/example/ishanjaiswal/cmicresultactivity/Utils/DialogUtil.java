package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.example.ishanjaiswal.cmicresultactivity.R;

/**
 * Created by ishan.jaiswal on 5/30/2018.
 */

public class DialogUtil {

    public static void makeAlertErrorOccurred(Context context, String errorMessage){
        AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
        alertBox.setTitle(context.getString(R.string.app_name));
        if (errorMessage!=null)
            alertBox.setMessage(errorMessage);
        else
            alertBox.setMessage("Some Error Occurred");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            }
        });
        alertBox.show();
    }
}
