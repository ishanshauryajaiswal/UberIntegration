package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.RecyclerViewClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;
import com.example.ishanjaiswal.cmicresultactivity.adapters.CrewMemberAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ProjectListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.RvDashboardAdapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class FragmentOne extends Fragment {

    private static final String TAG = FragmentOne.class.getSimpleName();
    private TextView tvDesignation, tvSelectedName, tvArrow, tvDate, tvCalendar, tvRefresh;
    private TextView tvWeek1Heading, tvWeek2Heading;
    private TextView tvRegTotal1, tvOtTotal1, tvDotTotal1;
    private TextView tvRegTotal2, tvOtTotal2, tvDotTotal2;
    private TextView tvPerson, tvJob;
    private RelativeLayout rlSelectedJob, rlCalendar, rlMain;
    private RecyclerView rvDashboard;
    private PopupWindow popup;
    private ProgressBar popupProgressBar;
    private ListView lvPopup;
    private RvDashboardAdapter rvDashboardAdapter;
    private FragmentClickListener mListener;
    private String firstDayOfWeek;
    private String mDate, mTradeName, mTrade, mJobNameFromTimesheet;
    private String startDateWeek1,startDateWeek2,endDateWeek2;
    private boolean flagJobSelected = true;
    private Calendar cal = Calendar.getInstance();
    private List<User> mPersonList;
    private List<JobData> mJobList;
    private List<Dashboard> mList;
    private SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE"), sdf = new SimpleDateFormat("yyyy-MM-dd");
    static FragmentOne fragmentOne;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getValuesFromSharedPreference();
        if (savedInstanceState!=null)
            mList = (List<Dashboard>) savedInstanceState.getSerializable("DashboardList");
        //setRetainInstance(true);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("DashboardList",(ArrayList<Dashboard>)mList);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_one,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        getInitialDate();
        loadDashBoardData();
    }

    private void initView(View view) {
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        tvDesignation = (TextView)view.findViewById(R.id.tv_designation_dashboard);
        rlMain = (RelativeLayout)view.findViewById(R.id.rl_dashboard);
        rlSelectedJob = (RelativeLayout)view.findViewById(R.id.rl_selected_dashboard);
        tvSelectedName = (TextView)view.findViewById(R.id.tv_selected_name_dashboard);
        tvSelectedName.setText("Job: ".concat(mJobNameFromTimesheet));
        tvDesignation.setText(mTrade+" : "+mTradeName);
        tvArrow = (TextView)view.findViewById(R.id.tv_arrow_dashboard);
        tvDate = (TextView)view.findViewById(R.id.tv_date_dashboard);
        tvCalendar = (TextView)view.findViewById(R.id.tv_calendar_dashboard);
        tvRefresh = (TextView)view.findViewById(R.id.tv_refresh_dashboard);
        tvRefresh.setTypeface(typeface);tvArrow.setTypeface(typeface);tvCalendar.setTypeface(typeface);
        tvWeek1Heading = (TextView)view.findViewById(R.id.tv_week1_dashboard);
        tvWeek2Heading = (TextView)view.findViewById(R.id.tv_week2_dashboard);
        tvRegTotal1 = (TextView)view.findViewById(R.id.tv_reg_total_1_dashboard);
        tvOtTotal1 = (TextView)view.findViewById(R.id.tv_ot_total_1_dashboard);
        tvDotTotal1 = (TextView)view.findViewById(R.id.tv_dot_total_1_dashboard);
        tvRegTotal2 = (TextView)view.findViewById(R.id.tv_reg_total_2_dashboard);
        tvOtTotal2 = (TextView)view.findViewById(R.id.tv_ot_total_2_dashboard);
        tvDotTotal2 = (TextView)view.findViewById(R.id.tv_dot_total_2_dashboard);
        rvDashboard = (RecyclerView)view.findViewById(R.id.rv_dashboard);
        rvDashboardAdapter = new RvDashboardAdapter(getContext(), new ArrayList(),recyclerViewClickListener);
        rvDashboard.setAdapter(rvDashboardAdapter);
        rvDashboard.setLayoutManager(new LinearLayoutManager(getContext()));
        rlSelectedJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopup(view);
            }
        });
        rlCalendar = (RelativeLayout)view.findViewById(R.id.rl_date_dashboard);
        rlCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectDateFromCalendar();
            }
        });
        tvRegTotal1 = (TextView)view.findViewById(R.id.tv_reg_total_1_dashboard);
        tvOtTotal1 = (TextView)view.findViewById(R.id.tv_ot_total_1_dashboard);
        tvDotTotal1 = (TextView)view.findViewById(R.id.tv_dot_total_1_dashboard);
        tvRegTotal2 = (TextView)view.findViewById(R.id.tv_reg_total_2_dashboard);
        tvOtTotal2 = (TextView)view.findViewById(R.id.tv_ot_total_2_dashboard);
        tvDotTotal2 = (TextView)view.findViewById(R.id.tv_dot_total_2_dashboard);
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mList = null;
                mListener.retrieveDashboardData(mDate);
            }
        });
    }

    public void setUpUI(List<Dashboard> dashboardList){
        mList = dashboardList;
        if (mList!=null && mList.size()>0) {
            rvDashboardAdapter.setmList(dashboardList);
            rvDashboardAdapter.notifyDataSetChanged();
            calculateFooterValues(dashboardList);
        }
        else{
            final AlertDialog.Builder alertBox = new AlertDialog.Builder(getContext());
            alertBox.setTitle("CMiC Mobile Crew Time");
            alertBox.setMessage("No Data Present For This Date");
            alertBox.setPositiveButton("GO BACK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mListener.onBackPressed();
                }
            });
            alertBox.show();
        }
    }

    public void populateCrewMemberList(List<User> list){
        mPersonList = list;
        CrewMemberAdapter crewMemberAdapter = new CrewMemberAdapter(getContext(),(ArrayList<User>) list,new HashMap<String, Boolean>(),false);
        lvPopup.setAdapter(crewMemberAdapter);
        lvPopup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                User user = (User)adapterView.getItemAtPosition(i);
                tvSelectedName.setText("Person: ".concat(user.getName()));
                flagJobSelected = false;
                mListener.setFlag(flagJobSelected);
                mListener.setEmployee(user.getName());
                loadDashBoardData();
                popup.dismiss();
            }
        });
    }

    public void populateJobData(List<JobData> list){
        mJobList = list;
        ProjectListAdapter jobDataAdapter = new ProjectListAdapter(getActivity(),(ArrayList<JobData>)list);
        lvPopup.setAdapter(jobDataAdapter);
        lvPopup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                JobData jobData = (JobData)adapterView.getItemAtPosition(i);
                tvSelectedName.setText("Job: ".concat(jobData.getJobname()));
                flagJobSelected = true;
                mListener.setFlag(flagJobSelected);
                mListener.setJob(jobData.getJobcompcode(),jobData.getJobcode(), jobData.getJobname());
                loadDashBoardData();
                popup.dismiss();
            }
        });
    }

    public void showPopUpProgressbar(){
        if (popupProgressBar!=null)
            popupProgressBar.setVisibility(View.VISIBLE);}
    public void hidePopUpProgressbar(){
        if (popupProgressBar!=null)
            popupProgressBar.setVisibility(View.GONE);}

    private void showPopup(View view){
        LayoutInflater lInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View popup_view = lInflater.inflate(R.layout.popup_dashboard, null);
        final EditText etSearch = (EditText)popup_view.findViewById(R.id.et_search_popup_dashboard);
        popup = new PopupWindow(popup_view,800,ViewGroup.LayoutParams.WRAP_CONTENT,true);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable());
        popup_view.measure(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        //popup.setAnimationStyle(R.style.popup_window_fade_out);
        WindowManager w = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = w.getDefaultDisplay();
        Point size = new Point(); display.getSize(size); int width = size.x; int height = size.y;
        float y = rlSelectedJob.getY()+rlSelectedJob.getHeight()+120;
        popup.showAtLocation(popup_view,Gravity.NO_GRAVITY,width/4,(int)y);
        //popup.showAsDropDown(rlSelectedJob, (int) (width/4 - rlSelectedJob.getX()),0,Gravity.CENTER_HORIZONTAL);
        tvPerson = (TextView) popup_view.findViewById(R.id.tv_person_popup_dashboard);
        tvJob = (TextView) popup_view.findViewById(R.id.tv_job_popup_dashboard);
        lvPopup = (ListView) popup_view.findViewById(R.id.lv_popup_dashboard);
        popupProgressBar = (ProgressBar)popup_view.findViewById(R.id.pb_popup_dashboard);
        tvPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagJobSelected = false;
                etSearch.setText("");
                lvPopup.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_activated_1));
                tvPerson.setBackgroundColor(getResources().getColor(R.color.colorWhite));
                tvPerson.setTextColor(getResources().getColor(R.color.colorRed));
                tvJob.setBackgroundColor(getResources().getColor(R.color.colorRed));
                tvJob.setTextColor(getResources().getColor(R.color.colorWhite));
                mListener.retrieveCrewMemberData();
            }
        });
        tvJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagJobSelected = true;
                etSearch.setText("");
                lvPopup.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_activated_1));
                tvPerson.setBackgroundColor(getResources().getColor(R.color.colorRed));
                tvPerson.setTextColor(getResources().getColor(R.color.colorWhite));
                tvJob.setBackgroundColor(getResources().getColor(R.color.colorWhite));
                tvJob.setTextColor(getResources().getColor(R.color.colorRed));
                mListener.retrieveJobData();
            }
        });
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    s = s.toString().toLowerCase();
                    if (flagJobSelected) {
                        if (lvPopup.getAdapter() != null && mJobList != null && mJobList.size() > 0) {
                            ArrayList<JobData> filteredList = new ArrayList<>();
                            for (int i = 0; i < mJobList.size(); i++) {
                                final String txtCrewName = mJobList.get(i).getJobname().toLowerCase();
                                final String txtCrewCode = mJobList.get(i).getJobcode().toLowerCase();
                                if (txtCrewName.contains(s) || txtCrewCode.contains(s))
                                    filteredList.add(mJobList.get(i));
                            }
                            ProjectListAdapter adapter = (ProjectListAdapter) lvPopup.getAdapter();
                            adapter.setList(filteredList);
                            adapter.notifyDataSetChanged();
                        }
                    } else {
                        if (lvPopup.getAdapter() != null && mPersonList != null && mPersonList.size() > 0) {
                            ArrayList<User> filteredList = new ArrayList<>();
                            for (int i = 0; i < mPersonList.size(); i++) {
                                String txtCrewName = mPersonList.get(i).getName().toLowerCase();
                                String txtCrewCode = mPersonList.get(i).getUniCode().toLowerCase();
                                String txtCrewTradeName = mPersonList.get(i).getTradeName().toLowerCase();
                                String txtCrewTradeCode = mPersonList.get(i).getTradeCode().toLowerCase();
                                if (txtCrewName.contains(s) || txtCrewCode.contains(s) || txtCrewTradeName.contains(s) || txtCrewTradeCode.contains(s))
                                    filteredList.add(mPersonList.get(i));
                            }
                            CrewMemberAdapter adapter = new CrewMemberAdapter(getContext(), filteredList, new HashMap<String, Boolean>(), false);
                            adapter.setCrewMemberDetails(filteredList);
                            lvPopup.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        }
                    }
                } catch (ClassCastException e) {
                    e.printStackTrace();
                    Log.e(TAG, e.getMessage());
                }
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        tvPerson.callOnClick();
    }

    public static Rect locateView(View v) {
        int[] loc_int = new int[2];
        if (v == null)
            return null;
        try {
            v.getLocationOnScreen(loc_int);
        } catch (NullPointerException npe) {
            return null;
        }
        Rect location = new Rect();
        location.left = loc_int[0];
        location.top = loc_int[1];
        location.right = loc_int[0] + v.getWidth();
        location.bottom = loc_int[1] + v.getHeight();
        return location;
    }

    public static FragmentOne getInstance(){
        fragmentOne = new FragmentOne();
        return fragmentOne;
    }

    void getValuesFromSharedPreference(){
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        mJobNameFromTimesheet = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_name),"");
        mTradeName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_trade_name),null);
        mTrade = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_name), null);
        firstDayOfWeek = defaultSharedPreferences.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
    }

    private void getInitialDate(){
        if (mDate!=null && mDate.length()>0){
            int year = Integer.parseInt(mDate.split("\\-")[0]);
            int month = Integer.parseInt(mDate.split("\\-")[1]);
            int day = Integer.parseInt(mDate.split("\\-")[2]);
            cal = Calendar.getInstance();
            cal.set(year, month-1, day);
        }
        int firstDayNum = CollectionUtils.dayConverter().get(firstDayOfWeek).intValue();
        String currentDay = sdfDay.format(cal.getTime());
        int currentDayNum = CollectionUtils.dayConverter().get(currentDay).intValue();
        int difference = calculateDifference(currentDayNum,firstDayNum)-1;
        cal.add(Calendar.DATE,difference);
        mDate = sdf.format(cal.getTime());
    }

    private int calculateDifference(int first, int selected){
        int difference = 0;
        while (first!=selected){
            if (first==7) {difference++;first = 1;}
            else {difference++; first++;}
        }
        return difference;
    }

    private void selectDateFromCalendar() {
        DatePickerDialog fromDatePickerDialog = new DatePickerDialog(getActivity(), R.style.DatePickerDailog, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                cal.set(year,monthOfYear,dayOfMonth);
                String daySelected = sdfDay.format(cal.getTime());
                ArrayList<String> week = CollectionUtils.getWeek(firstDayOfWeek);
                String lastDayOfWeek = week.get(6);
                if (daySelected.equalsIgnoreCase(lastDayOfWeek)){
                    mDate = sdf.format(cal.getTime());
                    mList = null;
                    loadDashBoardData();
                }
                else
                    Snackbar.make(rlMain,"Please Select "+lastDayOfWeek,Toast.LENGTH_SHORT).show();
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        fromDatePickerDialog.show();
    }

    private void loadDashBoardData(){
        cal.add(Calendar.DATE,-6);
        startDateWeek1 = sdf.format(cal.getTime());
        cal.add(Calendar.DATE,-1);
        endDateWeek2 = sdf.format(cal.getTime());
        cal.add(Calendar.DATE,-6);
        startDateWeek2 = sdf.format(cal.getTime());
        tvWeek1Heading.setText(mDate.concat(" TO ").concat(startDateWeek1));
        tvWeek2Heading.setText(endDateWeek2.concat(" TO ").concat(startDateWeek2));
        tvDate.setText(mDate);
        if (mList == null)
            mListener.retrieveDashboardData(mDate);
        else
            setUpUI(mList);
        cal = Calendar.getInstance();
    }
    private void calculateFooterValues(List<Dashboard> dashboardList){
        double rt1=0.0,rt2=0.0,ot1=0.0,ot2=0.0,dot1=0.0,dot2=0.0;
        for (Dashboard dashboard:dashboardList){
            rt1+=dashboard.getRegHrs();
            rt2+=dashboard.getPrevRegHrs();
            ot1=dashboard.getOtHrs();
            ot2+=dashboard.getPrevOtHrs();
            dot1+=dashboard.getDotHrs();
            dot2+=dashboard.getPrevDotHrs();
        }
        tvRegTotal1.setText(String .valueOf(rt1));
        tvRegTotal2.setText(String .valueOf(rt2));
        tvOtTotal1.setText(String .valueOf(ot1));
        tvOtTotal2.setText(String .valueOf(ot2));
        tvDotTotal1.setText(String .valueOf(dot1));
        tvDotTotal2.setText(String .valueOf(dot2));
    }

    private RecyclerViewClickListener recyclerViewClickListener= new RecyclerViewClickListener() {
        @Override
        public void onRecyclerViewRowClicked(String crewCode, String crewName, int week) {
            if (week==1) mListener.onCrewMemberSelected(crewCode, crewName, mDate);
            else mListener.onCrewMemberSelected(crewCode, crewName, endDateWeek2);
        }
        @Override
        public void onRecyclerViewDashboard2RowClicked(String empNumber, String empName) {
        }
    };

}
