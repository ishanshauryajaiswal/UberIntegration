package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */

public class LinkingEmployeeWithCrewTask extends AsyncTask<Void,Void,String>
{
    private static final String TAG = LinkingEmployeeWithCrewTask.class.getSimpleName();
    private Context context;
    private String crewOraseq;
    private ArrayList<User> selectedUsers;
    private LinkingEmployeeInterface linkingEmployeeInterface;
    public LinkingEmployeeWithCrewTask(Context context, String crewOraseq,ArrayList<User> selectedUsers,
                                       LinkingEmployeeInterface linkingEmployeeInterface)
    {
        this.context = context;
        this.crewOraseq = crewOraseq;
        this.selectedUsers = selectedUsers;
        this.linkingEmployeeInterface = linkingEmployeeInterface;
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        linkingEmployeeInterface.onPreExecute();
    }

    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall(context);
            response = requestCall.linkEmployeeWithCrew(context,crewOraseq, selectedUsers);
        }
        catch (Exception e)
        {
            Log.e(TAG,e.toString());
        }
        return response;
    }
    protected void onPostExecute(final String response)
    {
        linkingEmployeeInterface.onPostExecute(response);
    }

 public interface LinkingEmployeeInterface{
     public void onPostExecute(String response);
     public void onPreExecute();
 }
}