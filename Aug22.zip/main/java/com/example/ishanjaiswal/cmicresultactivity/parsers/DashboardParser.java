package com.example.ishanjaiswal.cmicresultactivity.parsers;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class DashboardParser {
    String tableName;
    Context context;
    int numberOfRemainingRecords;
    private static final String TAG = DashboardParser.class.getSimpleName();

    ArrayList<Dashboard> listValues = new ArrayList<Dashboard>();
    public ArrayList<Dashboard> parseDashboardData(final String response) {
        try {
            if (response != null) {
                JSONObject jsonObject = new JSONObject(response);
                tableName = jsonObject.getString("table");
                numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
                JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
                JSONArray Rows = jsonObject.getJSONArray("rows");
                JSONArray attributes = RowDefinition.getJSONArray("attrNames");
                Set<String> requiredAttributes = new HashSet<>();

                requiredAttributes.add("JobAcsCode");
                requiredAttributes.add("JobCompCode");
                requiredAttributes.add("JobCode");
                requiredAttributes.add("PycrCode");
                requiredAttributes.add("PycrName");
                requiredAttributes.add("NhHrs");
                requiredAttributes.add("OtHrs");
                requiredAttributes.add("DotHrs");
                requiredAttributes.add("PrevNhHrs");
                requiredAttributes.add("PrevOtHrs");
                requiredAttributes.add("PrevDotHrs");

                HashMap<String, Integer> attributeIndex = new HashMap<>();

                for (int i = 0; i < attributes.length(); i++) {
                    String strAttribute = attributes.getString(i);

                    if (requiredAttributes.contains(strAttribute)) {
                        attributeIndex.put(strAttribute, i);
                    }
                }

                ArrayList<JSONArray> attributeValues = new ArrayList<>();


                for (int j = 0; j < Rows.length(); j++) {
                    JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                }

                HashMap<String, Dashboard> weekData_Map = new HashMap<>();
                for (int k = 0; k < attributeValues.size(); k++) {
                    String PycrCode;
                    PycrCode = attributeValues.get(k).getString(attributeIndex.get("PycrCode"));
                    Dashboard dashboardModal = new Dashboard();

                    if (attributeIndex.get("NhHrs") != null) {
                        Double normalHours = attributeValues.get(k).getDouble(attributeIndex.get("NhHrs"));
                        dashboardModal.setRegHrs(normalHours);
                    }
                    if (attributeIndex.get("PrevNhHrs") != null) {
                        Double normalHours = attributeValues.get(k).getDouble(attributeIndex.get("PrevNhHrs"));
                        dashboardModal.setPrevRegHrs(normalHours);
                    }
                    if (attributeIndex.get("OtHrs") != null) {
                        Double otHrs = attributeValues.get(k).getDouble(attributeIndex.get("OtHrs"));
                        dashboardModal.setOtHrs(otHrs);
                    }
                    if (attributeIndex.get("PrevOtHrs") != null) {
                        Double prevOtHrs = attributeValues.get(k).getDouble(attributeIndex.get("PrevOtHrs"));
                        dashboardModal.setPrevOtHrs(prevOtHrs);
                    }
                    if (attributeIndex.get("DotHrs") != null) {
                        Double dotHrs = attributeValues.get(k).getDouble(attributeIndex.get("DotHrs"));
                        dashboardModal.setDotHrs(dotHrs);
                    }
                    if (attributeIndex.get("PrevDotHrs") != null) {
                        Double prevDotHrs = attributeValues.get(k).getDouble(attributeIndex.get("PrevDotHrs"));
                        dashboardModal.setPrevDotHrs(prevDotHrs);
                    }

                    if(attributeValues.get(k).getString(attributeIndex.get("JobAcsCode")) == null)
                    {
                        dashboardModal.setJobAcsCode("");

                    }
                    else
                    {
                        dashboardModal.setJobAcsCode(attributeValues.get(k).getString(attributeIndex.get("JobAcsCode")));
                    }
                    if(attributeValues.get(k).getString(attributeIndex.get("JobCompCode")) == null)
                    {
                        dashboardModal.setJobCompCode("");
                    }
                    else
                    {
                        dashboardModal.setJobCompCode(attributeValues.get(k).getString(attributeIndex.get("JobCompCode")));

                    }
                    if(attributeValues.get(k).getString(attributeIndex.get("JobCode")) == null)
                    {
                        dashboardModal.setJobCode("");

                    }
                    else
                    {
                        dashboardModal.setJobCode(attributeValues.get(k).getString(attributeIndex.get("JobCode")));
                    }
                    if(attributeValues.get(k).getString(attributeIndex.get("PycrCode")) == null)
                    {
                        dashboardModal.setPycrCode("");

                    }
                    else
                    {
                        dashboardModal.setPycrCode(attributeValues.get(k).getString(attributeIndex.get("PycrCode")));
                    }
                    if(attributeValues.get(k).getString(attributeIndex.get("PycrCode")) == null)
                    {
                        dashboardModal.setPycrCode("");
                    }
                    else
                    {
                        dashboardModal.setPycrCode(attributeValues.get(k).getString(attributeIndex.get("PycrCode")));
                    }
                    if(attributeValues.get(k).getString(attributeIndex.get("PycrName")) == null)
                    {
                        dashboardModal.setPycrName("");

                    }
                    else
                    {
                        dashboardModal.setPycrName(attributeValues.get(k).getString(attributeIndex.get("PycrName")));
                    }
                    weekData_Map.put(PycrCode, dashboardModal);
                }
                listValues = new ArrayList<Dashboard>(weekData_Map.values());

            } else {

            }
        }
        catch (JSONException e) {
            Log.e(TAG, e.toString());
            e.printStackTrace();
        }
        catch (Exception e) {
            Log.e(TAG, e.toString());
            e.printStackTrace();
        }
        Log.d("List from parser", String.valueOf(listValues));
        return listValues;
    }

}