package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public interface InsertCrewInterface {
    public void onPostTask(String result);
    public void onPreTask();
}
