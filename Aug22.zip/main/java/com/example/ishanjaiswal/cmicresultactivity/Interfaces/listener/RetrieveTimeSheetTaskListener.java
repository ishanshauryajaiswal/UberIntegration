package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
 * Created by ishan.jaiswal on 2/15/2018.
 */

public interface RetrieveTimeSheetTaskListener
{
    public void postRetrieveTimesheetTask(String result);
    public void preRetrieveTimesheetTask();
}