package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.RecyclerViewClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class RvDashboardAdapter extends RecyclerView.Adapter<RvDashboardAdapter.ViewHolder> {

    private Context mContext;
    private List<Dashboard> mList;
    private RecyclerViewClickListener mListener;


    public RvDashboardAdapter(Context mContext, List mList, RecyclerViewClickListener mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @Override
    public RvDashboardAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_dashboard,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Dashboard dashboard = mList.get(position);
        holder.tvCrewCode.setText(dashboard.getPycrCode());
        holder.tvCrewName.setText(dashboard.getPycrName());
        holder.tvREG1.setText(String .valueOf(dashboard.getRegHrs()));
        holder.tvOT1.setText(String .valueOf(dashboard.getOtHrs()));
        holder.tvDOT1.setText(String .valueOf(dashboard.getDotHrs()));
        holder.tvREG2.setText(String .valueOf(dashboard.getPrevRegHrs()));
        holder.tvOT2.setText(String .valueOf(dashboard.getPrevOtHrs()));
        holder.tvDOT2.setText(String .valueOf(dashboard.getPrevDotHrs()));
        holder.llCellWeek1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onRecyclerViewRowClicked(mList.get(position).getPycrCode(),mList.get(position).getPycrName(), 1);
            }
        });
        holder.llCellWeek2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onRecyclerViewRowClicked(mList.get(position).getPycrCode(),mList.get(position).getPycrName(),2);
            }
        });
    }


    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(List<Dashboard> mList) {
        this.mList = mList;
    }

    protected static class ViewHolder extends RecyclerView.ViewHolder{
        private LinearLayout llCellWeek1, llCellWeek2;
        private TextView tvCrewName, tvCrewCode;
        private TextView tvREG1, tvOT1, tvDOT1, tvREG2, tvOT2, tvDOT2;
        public ViewHolder(View itemView) {
            super(itemView);
            llCellWeek1 = (LinearLayout)itemView.findViewById(R.id.ll_dashboard_list_cell_week1);
            llCellWeek2 = (LinearLayout)itemView.findViewById(R.id.ll_dashboard_list_cell_week2);
            tvCrewName = (TextView)itemView.findViewById(R.id.tv_crew_name_dashboard);
            tvCrewCode = (TextView)itemView.findViewById(R.id.tv_crew_code_dashboard);
            tvREG1 = (TextView)itemView.findViewById(R.id.tv_reg_1_dashboard_row);
            tvREG2 = (TextView)itemView.findViewById(R.id.tv_reg_2_dashboard_row);
            tvOT1 = (TextView)itemView.findViewById(R.id.tv_ot_1_dashboard_row);
            tvOT2 = (TextView)itemView.findViewById(R.id.tv_ot_2_dashboard_row);
            tvDOT1 = (TextView)itemView.findViewById(R.id.tv_dot_1_dashboard_row);
            tvDOT2 = (TextView)itemView.findViewById(R.id.tv_dot_2_dashboard_row);
        }
    }
}
