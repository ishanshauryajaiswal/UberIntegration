package com.example.ishanjaiswal.cmicresultactivity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.BasicTaskListenerInterface;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.ClearLocalStorageTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.Dashboard2Task;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DeleteTimesheetTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetConfigForAdvancedModeTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetPhaseTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.PciTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.RetrievingTimeSheetTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.SubmittingTask;
import com.example.ishanjaiswal.cmicresultactivity.Database.DBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanAllEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CategoryTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CustomClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PciInterface;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PhaseInterface;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.RetrieveTimeSheetTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.SubmittingTimeSheetInterface;
import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.ConfigMode;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOut;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;
import com.example.ishanjaiswal.cmicresultactivity.Utils.DeleteDataUtility;
import com.example.ishanjaiswal.cmicresultactivity.Utils.DialogUtil;
import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.NotifyApproverDialogFragment;
import com.example.ishanjaiswal.cmicresultactivity.Utils.ScreenUtil;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.StringUtil;
import com.example.ishanjaiswal.cmicresultactivity.Utils.SubmitStatus;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityCategoryListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityJobListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityPciListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityPhaseListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.RvDynamicAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.RvStaticAdapter;
import com.example.ishanjaiswal.cmicresultactivity.parsers.ConfigModeParser;
import com.example.ishanjaiswal.cmicresultactivity.parsers.Dashboard2Parser;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();
    RecyclerView recyclerViewStatic, recyclerViewDynamic;
    private RelativeLayout rl,rlHome, rlDashboard;
    LinearLayout linearLayoutDynamicHeader, linearLayoutDynamicFooter;
    int mTouchedRvTag;
    String selectedCrewCode, selectedCrewName, selectedProjectCode, selectedProjectName, selectedResponsiblePerson, selectedTradeName,
            selectedHrtTradeName;
    String workDate, workDay, firstDayOfWeek;
    String selectedOraSew, selectedProjectCompCode;
    ProgressDialog mainProgressDialog;
    CrewTimeSheet mCrewTimeSheet;
    RvStaticAdapter rvStaticAdapter;
    RvDynamicAdapter rvDynamicAdapter;
    Typeface typeface;
    TextView tvBack, tvSheetTitle, tvMode, tvMenu, tvDay, tvDate, tvCalendar, tvCrewname
            , tvResponsiblePerson, tvHrtTradeName, tvTradeName, tvTimeinOut;
    TextView tvFooterReg, tvFooterOt, tvFooterDot, tvFooterInOut;
    private TextView tvHome, tvDashboard;
    private ImageView ivHome,ivDashboard;
    private ImageButton btnSubmitTimesheet, btnDeleteTimesheet;
    Button btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven;
    ArrayList<Button> listWeek;
    private  Button btnSelectedJob;
    Calendar cal;
    DatePickerDialog fromDatePickerDialog;
    private static final SimpleDateFormat sdfDayNew = new SimpleDateFormat("EEEE"), sdfNew = new SimpleDateFormat("yyyy-MM-dd");
    HashMap<String, String > hashmapDateToButton;
    private boolean isRegularModeSelected, isInOutModeSelected, isBreakTimeSelected;
    SharedPreferences ishanSharedPreference, defaultSharedPreference;
    SharedPreferences.Editor ishanPreferenceEditor, defaultPreferenceEditor;
    private static final int REQUEST_CODE_PROJECT = 0;
    private static final int REQUEST_CODE_CREW_DETAILS = 1;
    private static final int REQUEST_CODE_CREW_LIST = 2;
    private static final int REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON = 3;
    private int normalTimeFromSettings, overTimeFromSettings;
    private double maxNormalTimeFromSettings;
    private IshanDBHelper mDbInstance;
    private DeleteTimesheetTask mDeleteTimesheetTask;
    private boolean isAdvancedModeConfiged = false;
    private ConfigMode configAdvancedMode = new ConfigMode();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDbInstance = IshanDBHelper.getInstance(MainActivity.this);
        initViews();
    }

    @Override
    protected void onPostResume(){
        super.onPostResume();
        getValuesFromSharedPreference();
        mCrewTimeSheet = mDbInstance.getTimeSheetFromDatabase();
        if (mDbInstance.isTimeSheetPresent() && mCrewTimeSheet!=null) {
            if (validateTimeSheetFromDatabaseWithSharePreference()) {
                workDate = mCrewTimeSheet.getWorkDate();
                setUPColorForWeekDayButtons(getEndDateOfWeek());
                setUpUIElements(mCrewTimeSheet);
            }
            else {
                setWorkdateToTodaysDate();
                setUPColorForWeekDayButtons(getEndDateOfWeek());
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
        }
        else {
            setWorkdateToTodaysDate();
            setUPColorForWeekDayButtons(getEndDateOfWeek());
            retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
        }
        getValuesFromSharedPreference();
        if (!isAdvancedModeConfiged)
            getAdvancedModeConfiguration();
    }

    private void getAdvancedModeConfiguration() {
        GetConfigForAdvancedModeTask configTask = new GetConfigForAdvancedModeTask(MainActivity.this, "", new BasicTaskListenerInterface() {
            @Override
            public void onTaskStarted(String progressDialogMessage) {
            }

            @Override
            public void onTaskComplete(String response) {
                if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                    isAdvancedModeConfiged = true;
                    ConfigModeParser configModeParser = new ConfigModeParser();
                    configAdvancedMode = configModeParser.parse(response);
                }
                else {
                    isAdvancedModeConfiged = false;
                }
            }
        });
        configTask.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG,"Time-Sheet Activity Destroyed");
        if (mDeleteTimesheetTask!=null && !mDeleteTimesheetTask.getStatus().equals(AsyncTask.Status.FINISHED))
            mDeleteTimesheetTask.cancel(true);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void setUpUIElements(CrewTimeSheet crewTimeSheet){
        recyclerViewStatic.clearOnScrollListeners();
        recyclerViewDynamic.clearOnScrollListeners();
        isInoutModeEnabled();
        if (isRegularModeSelected)
            tvMode.setText("A");
        else
            tvMode.setText("R");
        tvMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchRegularAndAdvancedMode();
            }
        });
        mCrewTimeSheet = crewTimeSheet;
        calculateTotalHours(mCrewTimeSheet);
        calculateFooterHours(mCrewTimeSheet);
        rvStaticAdapter = new RvStaticAdapter(mCrewTimeSheet.getEmpTimeSheet(), this, isInOutModeSelected);
        rvStaticAdapter.setCallback(rvStaticCallback);
        recyclerViewStatic.setAdapter(rvStaticAdapter);
        recyclerViewStatic.setLayoutManager(new LinearLayoutManager(this));
        rvDynamicAdapter = new RvDynamicAdapter(mCrewTimeSheet.getEmpTimeSheet(), this);
        rvDynamicAdapter.setCustomClickListener(customClickListener);
        recyclerViewDynamic.setAdapter(rvDynamicAdapter);
        recyclerViewDynamic.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewStatic.addOnScrollListener(custom_scroll_listner);
        recyclerViewDynamic.addOnScrollListener(custom_scroll_listner);
        recyclerViewStatic.addOnItemTouchListener(custom_item_touch_listner);
        recyclerViewDynamic.addOnItemTouchListener(custom_item_touch_listner);
        setUpDynamicHeaderAndFooter();
        btnSelectedJob.setText(selectedProjectName);
        tvCrewname.setText(selectedCrewName);
        tvResponsiblePerson.setText(selectedResponsiblePerson);
        tvHrtTradeName.setText(selectedHrtTradeName.concat(": "));
        tvTradeName.setText(selectedTradeName);
        setUpWeekdaysButtons(firstDayOfWeek);
        linkButtonsToDate();
        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenuDialog();
            }
        });
        tvResponsiblePerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                responsiblePersonClicked();
            }
        });
        tvDashboard.setTextColor(getResources().getColor(R.color.colorBlack));
        ivDashboard.setColorFilter(getResources().getColor(R.color.colorBlack));
        tvHome.setTextColor(getResources().getColor(R.color.colorLightBlue));
        ivHome.setColorFilter(getResources().getColor(R.color.colorLightBlue));
        if (mCrewTimeSheet.getSubmitStatus()!=null)
            setUPColorForToday(mCrewTimeSheet.getSubmitStatus());
    }

    private void isInoutModeEnabled() {
        RelativeLayout rlStatic = (RelativeLayout) findViewById(R.id.rlStatic);
        TextView tvHeaderStatic = (TextView)findViewById(R.id.headerTime);
        TextView tvFooterStatic = (TextView)findViewById(R.id.tvFooterInOutTotal);
        RelativeLayout.LayoutParams paramsInOutVisible = new RelativeLayout.LayoutParams(ScreenUtil.dpToPx(MainActivity.this,540),RelativeLayout.LayoutParams.WRAP_CONTENT);
        RelativeLayout.LayoutParams paramsInOutInvisible = new RelativeLayout.LayoutParams(ScreenUtil.dpToPx(MainActivity.this,360),RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsInOutVisible.addRule(RelativeLayout.BELOW,R.id.toolbar_activity_main);
        paramsInOutInvisible.addRule(RelativeLayout.BELOW,R.id.toolbar_activity_main);
        if (isInOutModeSelected){
            rlStatic.setLayoutParams(paramsInOutVisible);
            tvHeaderStatic.setVisibility(View.VISIBLE);
            tvFooterStatic.setVisibility(View.VISIBLE);
            tvTimeinOut.setVisibility(View.VISIBLE);
        }
        else {
            rlStatic.setLayoutParams(paramsInOutInvisible);
            tvHeaderStatic.setVisibility(View.GONE);
            tvFooterStatic.setVisibility(View.GONE);
            tvTimeinOut.setVisibility(View.GONE);
        }
    }

    private void setUpDynamicHeaderAndFooter() {
        linearLayoutDynamicHeader.removeAllViews();
        linearLayoutDynamicFooter.removeAllViews();
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(dpToPx(180),
                dpToPx(Integer.parseInt(getResources().getString(R.string.header_cell_height))));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ArrayList<SubmittedActivityFromCrewModal> activities = mCrewTimeSheet.getCrewActivity();
        ArrayList<Double> footerTotalValues = new ArrayList<>();
        LayoutInflater inflater = (LayoutInflater)getApplicationContext().getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
        //Setting up Header and Footers for Activities
        for (int i = 0; i < activities.size(); i++) {
            LinearLayout dynamicHeader = new LinearLayout(this);
            dynamicHeader.setLayoutParams(params);
            dynamicHeader.addView(inflater.inflate(R.layout.activity_header,null));
            TextView tvActivityName = (TextView)dynamicHeader.findViewWithTag("ACTIVITY_NAME");
            TextView tvActivityDotImage = (TextView)dynamicHeader.findViewWithTag("ACTIVITY_DOT_IMAGE");
            tvActivityName.setText(mCrewTimeSheet.getCrewActivity().get(i).getActivityName());
            tvActivityDotImage.setTypeface(typeface);

            final int finalI1 = i;
            dynamicHeader.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    customClickListener.activityHeaderLongPressed(view, finalI1);
                    return true;
                }
            });
            dynamicHeader.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    customClickListener.activityHeaderClicked(finalI1);
                }
            });


            linearLayoutDynamicHeader.addView(dynamicHeader);
            final int finalI = i;
            double footerRegTotal = 0.0, footerOtTotal = 0.0, footerDotTotal = 0.0;
            for (int row = 0; row < mCrewTimeSheet.getEmpTimeSheet().size(); row++) {
                footerRegTotal = footerRegTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getStandardTime();
                footerOtTotal = footerOtTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getOverTime();
                footerDotTotal = footerDotTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getDoubleOverTime();
            }
            LinearLayout.LayoutParams footerTvParams = new TableRow.LayoutParams(0, dpToPx(70), 1f);
            LinearLayout lFooter = new LinearLayout(this);
            lFooter.removeAllViews();
            lFooter.setLayoutParams(rowParams);
            lFooter.setOrientation(LinearLayout.HORIZONTAL);
            TextView regTotal, otTotal, dotTotal;
            regTotal = new TextView(this);
            regTotal.setLayoutParams(footerTvParams);
            regTotal.setTextColor(Color.BLACK);
            regTotal.setText(footerRegTotal+"");
            regTotal.setGravity(Gravity.CENTER);
            regTotal.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.style_textview_static_footer_start));

            otTotal = new TextView(this);
            otTotal.setLayoutParams(footerTvParams);
            otTotal.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            otTotal.setTextColor(Color.BLACK);
            otTotal.setText(footerOtTotal+"");
            otTotal.setGravity(Gravity.CENTER);

            dotTotal = new TextView(this);
            dotTotal.setLayoutParams(footerTvParams);
            dotTotal.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            dotTotal.setTextColor(Color.BLACK);
            dotTotal.setText(footerDotTotal+"");
            dotTotal.setGravity(Gravity.CENTER);
            //dotTotal.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.style_textview_static_footer));


            lFooter.addView(regTotal);
            lFooter.addView(otTotal);
            lFooter.addView(dotTotal);
            linearLayoutDynamicFooter.addView(lFooter);
        }
    }

    void deleteActivity(View view, final int activityColumn){
        String activityName = mCrewTimeSheet.getCrewActivity().get(activityColumn).getActivityName();
        final DeletePopup deletePopup = new DeletePopup(MainActivity.this, R.layout.delete_popup, activityColumn, activityName, new DeletePopupInterface() {
            @Override
            public void deleteValues(int deletePosition) {
                final CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
                //Activity not submitted on server
                if (StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(activityColumn).getSeqNo())){
                    deleteActivityLocally(activityColumn);
                }
                //Activity already on server
                else {
                    mCrewTimeSheet.getCrewActivity().get(activityColumn).setDeleteFlag("Y");
                    submitTimeSheet();
                }
            }
            @Override
            public void dismiss() {}
            @Override
            public void refreshWebserviceCall(String compCode, String jobCode) {}
            @Override
            public void personWebServiceCall(String employeeOraseq) {}
        });
        deletePopup.show(view);
    }

    private void deleteActivityLocally(int activityColumn){
        mCrewTimeSheet.getCrewActivity().remove(activityColumn);
        for (EmployeeDataForCrew e: mCrewTimeSheet.getEmpTimeSheet())
            e.getTimeSheet().remove(activityColumn);
        timeSheetEdited();
        setUpUIElements(mCrewTimeSheet);
        mDbInstance.insertDefaultActivityModel(workDate, selectedCrewCode,selectedProjectCode, mCrewTimeSheet.getCrewActivity());
        mDbInstance.insertTimeSheetInDatabase(mCrewTimeSheet);
    }

    private void deleteCrewMember(View view, final int position) {
        final String crewMemberName = mCrewTimeSheet.getEmpTimeSheet().get(position).getEmpName();
        DeletePopup deletePopup = new DeletePopup(MainActivity.this, R.layout.delete_popup, position, crewMemberName, new DeletePopupInterface() {
            @Override
            public void deleteValues(int deletePosition) {
                final CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
                final String empNo = mCrewTimeSheet.getEmpTimeSheet().get(position).getEmpNo();
                //Fetching Crew Details
                Log.d(TAG, "Deleting Crew Member: Fetching Crew Details");
                IshanAllEmployeeDBHelper allEmployeeDBHelper = new IshanAllEmployeeDBHelper(MainActivity.this);
                String pyceOraSeqofDeletedMember= allEmployeeDBHelper.getPyceOraSeqOfEmployee(empNo);
                Log.d(TAG,"Deleting Crew Member EmpNumber and OraSeq - "+empNo+"  "+pyceOraSeqofDeletedMember);
                DeleteCrewEmployeeTask deleteCrewEmployeeTask = new DeleteCrewEmployeeTask(
                        MainActivity.this, pyceOraSeqofDeletedMember, new DeleteCrewEmployeeTask.DeleteCrewEmployeeInterface() {
                    @Override
                    public void preTask() {
                        mainProgressDialog = ProgressDialog.show(MainActivity.this, null,"     Deleting Crew Member from Timesheet...");
                    }
                    @Override
                    public void postTask(String response) {
                        if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                            Log.d(TAG, "Deleting Crew Member: Deleting From Crew Successful Response - " + response);
                            mCrewTimeSheet.getEmpTimeSheet().get(position).setDeleteFlag("Y");
                            submitTimeSheet();
                        }
                        else {
                            DialogUtil.dismissProgressDialog(mainProgressDialog);
                            makeAlertErrorOccurred(response);
                            Log.d(TAG, "Deleting Crew Member: Deleting From Crew Unsuccessful Response - " + response);
                        }
                    }
                });
                deleteCrewEmployeeTask.execute();
                }
            @Override
            public void dismiss() {

            }
            @Override
            public void refreshWebserviceCall(String compCode, String jobCode) {

            }
            @Override
            public void personWebServiceCall(String employeeOraseq) {

            }
        });
        deletePopup.show(view);
    }

    private void initViews() {
        changeColor();
        typeface = Typeface.createFromAsset(getAssets(),"fonts/cmic_icons.ttf");
        rl = (RelativeLayout) findViewById(R.id.rltMain);
        recyclerViewStatic = (RecyclerView) findViewById(R.id.rvStatic);
        recyclerViewDynamic = (RecyclerView) findViewById(R.id.rvDynamic);
        linearLayoutDynamicHeader = (LinearLayout) findViewById(R.id.headerDynamic);
        linearLayoutDynamicFooter = (LinearLayout) findViewById(R.id.footerDynamic);
        linearLayoutDynamicHeader.removeAllViews();
        linearLayoutDynamicFooter.removeAllViews();
        recyclerViewStatic.setTag(0);
        recyclerViewDynamic.setTag(1);
        typeface = Typeface.createFromAsset(getAssets(),"fonts/cmic_icons.ttf");
        tvBack = (TextView)findViewById(R.id.back);
        tvSheetTitle = (TextView)findViewById(R.id.daily_crew_sheet_text);
        btnSelectedJob = (Button)findViewById(R.id.btnselectProject);
        btnSubmitTimesheet = (ImageButton)findViewById(R.id.submit);
        tvMenu = (TextView)findViewById(R.id.menu_icon);
        tvMode = (TextView)findViewById(R.id.RegularAdvanceMode);
        tvDay = (TextView)findViewById(R.id.txtDayMiddle);
        tvDate = (TextView)findViewById(R.id.txtDateMiddle);
        tvCalendar = (TextView)findViewById(R.id.selectedDate);
        tvCrewname = (TextView)findViewById(R.id.txtcrewname);
        btnDeleteTimesheet = (ImageButton) findViewById(R.id.delete);
        tvResponsiblePerson = (TextView)findViewById(R.id.txtresponsibleperson);
        tvHrtTradeName = (TextView)findViewById(R.id.txthrttradename);
        tvTradeName = (TextView)findViewById(R.id.txthrtname);
        tvTimeinOut = (TextView)findViewById(R.id.timeinout);
        tvMenu.setTypeface(typeface);
        tvCalendar.setTypeface(typeface);
        tvBack.setTypeface(typeface);
        tvTimeinOut.setTypeface(typeface);
        btnOne = (Button)findViewById(R.id.btnOne);
        btnTwo = (Button)findViewById(R.id.btnTwo);
        btnThree = (Button)findViewById(R.id.btnThree);
        btnFour = (Button)findViewById(R.id.btnFour);
        btnFive = (Button)findViewById(R.id.btnFive);
        btnSix = (Button)findViewById(R.id.btnSix);
        btnSeven = (Button)findViewById(R.id.btnSeven);
        listWeek = new ArrayList<Button>();
        listWeek.add(btnOne);listWeek.add(btnTwo);listWeek.add(btnThree);listWeek.add(btnFour);
        listWeek.add(btnFive);listWeek.add(btnSix);listWeek.add(btnSeven);
        rlHome = (RelativeLayout)findViewById(R.id.rlHome);
        rlDashboard = (RelativeLayout)findViewById(R.id.rlDashboard);
        tvHome = (TextView)findViewById(R.id.tvHome);
        tvDashboard = (TextView)findViewById(R.id.tvDashboard);
        ivDashboard = (ImageView)findViewById(R.id.btnDashboard);
        ivHome = (ImageView)findViewById(R.id.btnHome);
        tvCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED))
                    unsavedTimesheetAlertDialog();
                else
                    showCalenderToSelectDate();
            }
        });
        tvFooterReg = (TextView)findViewById(R.id.tvFooterREGTotal);
        tvFooterOt = (TextView)findViewById(R.id.tvFooterOTTotal);
        tvFooterDot = (TextView)findViewById(R.id.tvFooterDOTTotal);
        tvFooterInOut = (TextView)findViewById(R.id.tvFooterInOutTotal);
        btnSelectedJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED)){
                    unsavedTimesheetAlertDialog();
                }
                else {
                    Intent intent = new Intent(MainActivity.this, ProjectListActivity.class);
                    intent.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
                    startActivityForResult(intent, REQUEST_CODE_PROJECT);
                }
            }
        });
        tvCrewname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchCrew();
            }
        });
        btnSubmitTimesheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitTimeSheet();
            }
        });
        btnDeleteTimesheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteTimesheet();
            }
        });
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tvTimeinOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InOutPopup timeInOutPopup = new InOutPopup(MainActivity.this, inOutCallback, true, 0);
                timeInOutPopup.show();
            }
        });
        rlDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDashboard.setTextColor(getResources().getColor(R.color.colorLightBlue));
                ivDashboard.setColorFilter(getResources().getColor(R.color.colorLightBlue));
                tvHome.setTextColor(getResources().getColor(R.color.colorBlack));
                ivHome.setColorFilter(getResources().getColor(R.color.colorBlack));
                Intent intentDashboardActivity = new Intent(MainActivity.this, DashboardActivity.class);
                intentDashboardActivity.putExtra(getString(R.string.cmic_intent_extras_work_date),mCrewTimeSheet.getWorkDate());
                startActivity(intentDashboardActivity);
            }
        });
        //rlDashboard.callOnClick();
    }

    private void switchCrew() {
        if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED)){
            unsavedTimesheetAlertDialog();                }
        else {
            Intent intent = new Intent(MainActivity.this, CrewListActivity.class);
            intent.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
            intent.putExtra("InsertedNewCrewOraseq", selectedOraSew);
            startActivityForResult(intent, REQUEST_CODE_CREW_LIST);
        }
    }

    private void calendarOperations() {
        cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE yyyy.MM.dd");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy.MM.dd");
        SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");
        setFirstDayInCalendarInstance();
        int diff = calculateDifference(cal.getFirstDayOfWeek() , cal.get(Calendar.DAY_OF_WEEK));
        String date = sdfDate.format(cal.getTime());
        String day = sdfDay.format(cal.getTime());
        Date todaysDate = (cal.getTime());
        cal.add(Calendar.DAY_OF_WEEK, 1-diff);
        for (int i = 2; i <= 7; i++) {
            cal.add(Calendar.DAY_OF_WEEK,1);
            int x = cal.getFirstDayOfWeek();
            int y = cal.get(Calendar.DAY_OF_WEEK);
        }
    }
    private void linkButtonsToDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE yyyy.MM.dd");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy.MM.dd");
        SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");
        workDate = mCrewTimeSheet.getWorkDate();
        int year = Integer.parseInt(workDate.split("\\-")[0]);
        int month = Integer.parseInt(workDate.split("\\-")[1]);
        int day = Integer.parseInt(workDate.split("\\-")[2]);
        cal = Calendar.getInstance();
//Month starts from 0-11. so subtract 1
        --month;
        cal.set(year, month, day);
        String dayOfWeek = sdfDay.format(cal.getTime());
        tvDate.setText(workDate);
        tvDay.setText(dayOfWeek);
        setFirstDayInCalendarInstance();
        int diff = calculateDifference(cal.getFirstDayOfWeek() , cal.get(Calendar.DAY_OF_WEEK));
        cal.add(Calendar.DAY_OF_WEEK, 0-diff);
        String date = sdfDate.format(cal.getTime());
        dayOfWeek = sdfDay.format(cal.getTime());
        hashmapDateToButton = new HashMap<>();
        hashmapDateToButton.put(dayOfWeek.substring(0,3), date);
        for (int i = 2; i <= 7; i++) {
            cal.add(Calendar.DAY_OF_WEEK,1);
            date = sdfDate.format(cal.getTime());
            dayOfWeek = sdfDay.format(cal.getTime());
            hashmapDateToButton.put(dayOfWeek.substring(0,3), date);
        }
        setUpWeek2();
    }

    private String  getEndDateOfWeek(){
        int year = Integer.parseInt(workDate.split("\\-")[0]);
        int month = Integer.parseInt(workDate.split("\\-")[1]);
        month--;
        int day = Integer.parseInt(workDate.split("\\-")[2]);
        Calendar tempCal = Calendar.getInstance();
        tempCal.set(year, month, day);
        String endDate;
        int firstDayNum = CollectionUtils.dayConverter().get(firstDayOfWeek).intValue();
        String currentDay = sdfDayNew.format(tempCal.getTime());
        int currentDayNum = CollectionUtils.dayConverter().get(currentDay).intValue();
        int difference = calculateDifference(currentDayNum,firstDayNum)-1;
        tempCal.add(Calendar.DATE,difference);
        endDate = sdfNew.format(tempCal.getTime());
        return endDate;
    }


    private int calculateDifference(int first, int selected){
        int difference = 0;
        while (first!=selected){
            if (first==7) {difference++;first = 1;}
            else {difference++; first++;}
        }
        return difference;
    }

    private void setFirstDayInCalendarInstance() {
        int dayNum = CollectionUtils.dayConverter().get(firstDayOfWeek).intValue();
        switch (dayNum){
            case 1:
                cal.setFirstDayOfWeek(Calendar.SUNDAY);
                break;
            case 2:
                cal.setFirstDayOfWeek(Calendar.MONDAY);
                break;
            case 3:
                cal.setFirstDayOfWeek(Calendar.TUESDAY);
                break;
            case 4:
                cal.setFirstDayOfWeek(Calendar.WEDNESDAY);
                break;
            case 5:
                cal.setFirstDayOfWeek(Calendar.THURSDAY);
                break;
            case 6:
                cal.setFirstDayOfWeek(Calendar.FRIDAY);
                break;
            case 7:
                cal.setFirstDayOfWeek(Calendar.SATURDAY);
                break;
        }
    }

    private void setUpWeekdaysButtons(String firstDay) {
        int i=0;
        ArrayList<String> week = CollectionUtils.getWeek(firstDay);
        for (Button btn : listWeek){
            btn.setText(week.get(i++).substring(0,3));
        }
    }

    private void setUpWeek2(){
        workDate = mCrewTimeSheet.getWorkDate();
        StringBuilder tempWorkDate = new StringBuilder(workDate);
        for (int i = 0; i < tempWorkDate.length(); i++)
            if (tempWorkDate.charAt(i) == '-')
                tempWorkDate.setCharAt(i, '.');

        for (final Button btn : listWeek){
            if (hashmapDateToButton.get(String.valueOf(btn.getText())).equalsIgnoreCase(tempWorkDate.toString())){
                btn.setBackgroundColor(Color.parseColor("#ffffff"));
                btn.setTextColor(Color.parseColor("#1780FB"));
            }
            else {
                btn.setBackgroundColor(Color.parseColor("#1780FB"));
                btn.setTextColor(Color.parseColor("#ffffff"));
            }
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED))
                        unsavedTimesheetAlertDialog();
                    else {
                        workDate = hashmapDateToButton.get(String.valueOf(btn.getText()));
                        StringBuilder changeWorkDateFormat = new StringBuilder(workDate);
                        for (int i = 0; i < changeWorkDateFormat.length(); i++)
                            if (changeWorkDateFormat.charAt(i) == '.')
                                changeWorkDateFormat.setCharAt(i, '-');
                        workDate = changeWorkDateFormat.toString();
                        retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            if (requestCode == REQUEST_CODE_PROJECT){
                getValuesFromSharedPreference();
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
            else if (requestCode == REQUEST_CODE_CREW_DETAILS){
                /* Ishan Code prior to local Database
                ArrayList<User> addedEmployees = (ArrayList<User>) data.getSerializableExtra(getString(R.string.cmic_intent_extras_added_crew_members));
                ArrayList<ActivityTimeForCrew> a = new ArrayList<ActivityTimeForCrew>();
                for (User crewMember : addedEmployees){
                    a = new ArrayList<ActivityTimeForCrew>();
                    for (int i =0;i<mCrewTimeSheet.getCrewActivity().size(); i++){
                        ActivityTimeForCrew activity = new ActivityTimeForCrew(null,0,null,0,null,0,mCrewTimeSheet.getCrewCode()
                                ,mCrewTimeSheet.getWorkDate(),crewMember.getEmployeeNo());
                        a.add(activity);
                    }
                    EmployeeDataForCrew e = new EmployeeDataForCrew("null",crewMember.getEmployeeNo(), crewMember.getName()
                    ,crewMember.getTradeCode(), crewMember.getTradeName(), mCrewTimeSheet.getEmpTimeSheet().size()+"",
                            a,0,0,0,null,null,null);
                    e.setTimeInOutModals(null);
                    mCrewTimeSheet.getEmpTimeSheet().add(e);
                }
                */
                mCrewTimeSheet = mDbInstance.getTimeSheetFromDatabase();
                setUpUIElements(mCrewTimeSheet);
            }
            else if (requestCode == REQUEST_CODE_CREW_LIST){
                getValuesFromSharedPreference();
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
            else if (requestCode == REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON){
                getValuesFromSharedPreference();
                setUpUIElements(mCrewTimeSheet);
            }
        }

        //when activites for result fail
        else if (resultCode == Activity.RESULT_CANCELED){
            if (requestCode == REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON){
                getValuesFromSharedPreference();
                setUpUIElements(mCrewTimeSheet);
                //makeAlertErrorOccurred("Some Error Occurred While Updating Responsible Person For Crew");
            }
        }
    }

    private RvStaticAdapter.Callback rvStaticCallback = new RvStaticAdapter.Callback() {
        @Override
        public void crewMemberLongClicked(View v, int position) {
            deleteCrewMember(v,position);
        }

        @Override
        public void showEmployeeTimeInOut(int position) {
            if (isInOutModeSelected) {
                InOutPopup timeInOutPopup = new InOutPopup(MainActivity.this, inOutCallback, false, position);
                timeInOutPopup.show();
            }
        }
    };

    private CustomClickListener customClickListener = new CustomClickListener() {
        @Override
        public void activityHeaderClicked(int position) {
            if (isRegularModeSelected){
                Toast.makeText(MainActivity.this, "Regular Mode Selected", Toast.LENGTH_SHORT).show();
                RegularModePopUp(position);
            }
            else {
                Toast.makeText(MainActivity.this, "Advanced Mode Selected", Toast.LENGTH_SHORT).show();
                advancedModeDialogFragment(position);
            }
        }

        @Override
        public void activityHeaderLongPressed(View v, int position) {
            deleteActivity(v, position);
        }

        @Override
        public void rowItemClicked(int listPosition, int activityPosition) {
            EnterTimePopUp enterTimePopUp = new EnterTimePopUp(MainActivity.this, customClickListener, mCrewTimeSheet, listPosition, activityPosition);
            enterTimePopUp.show();
            //TimePopUp(listPosition, activityPosition);
        }

        @Override
        public void enterTimePopUpDone(CrewTimeSheet crewTimeSheet) {
            mCrewTimeSheet = crewTimeSheet;
            timeSheetEdited();
            setUpUIElements(mCrewTimeSheet);
            new MainActivity.insertTimesheetInDatabaseTask().execute();
        }

    };

    private InOutPopup.Callback inOutCallback = new InOutPopup.Callback() {
        @Override
        public void inOutPopUpSubmittedForAllEmployees(List<TimeInOut> timeInOutList) {
            for (EmployeeDataForCrew e : mCrewTimeSheet.getEmpTimeSheet()){
                List<TimeInOut> clonedTimeInOutList = new ArrayList<>();
                for (TimeInOut timeInOut:timeInOutList) {
                    timeInOut.setEmployeeNumber(e.getEmpNo());
                    clonedTimeInOutList.add(new TimeInOut(timeInOut));
                }
                e.setTimeInOuts(clonedTimeInOutList);
            }
            new insertTimesheetInDatabaseTask().execute();
        }

        @Override
        public void inOutPopUpSubmittedForIndividualEmployee(List<TimeInOut> timeInOutList, int employeePosition) {
            EmployeeDataForCrew e = mCrewTimeSheet.getEmpTimeSheet().get(employeePosition);
            if (timeInOutList != null && timeInOutList.size() > 0) {
                for (TimeInOut timeInOut : timeInOutList)
                    timeInOut.setEmployeeNumber(e.getEmpNo());
            }
            e.setTimeInOuts(timeInOutList);
            new insertTimesheetInDatabaseTask().execute();
        }

        @Override
        public void inOutPopUpClearInOutTimeForAllEmployees() {
            for (EmployeeDataForCrew e : mCrewTimeSheet.getEmpTimeSheet())
                e.setTimeInOuts(new ArrayList<TimeInOut>());
            new insertTimesheetInDatabaseTask().execute();
        }

        @Override
        public void inOutPopUpClearInOutTimeForIndividualEmployee(int employeePosition) {
            EmployeeDataForCrew e = mCrewTimeSheet.getEmpTimeSheet().get(employeePosition);
            e.setTimeInOuts(new ArrayList<TimeInOut>());
            new insertTimesheetInDatabaseTask().execute();
        }

        @Override
        public List<TimeInOut> initValuesGlobal() {
            List<TimeInOut> list = null;
            if (mCrewTimeSheet.getEmpTimeSheet().size()!=0)
                list = mCrewTimeSheet.getEmpTimeSheet().get(0).getTimeInOuts();
            return list;
        }

        @Override
        public List<TimeInOut> initValuesForEmployee(int mEmployeePosition) {
            return mCrewTimeSheet.getEmpTimeSheet().get(mEmployeePosition).getTimeInOuts();
        }
    };

    private void dismissProgressDialog() {
        if (mainProgressDialog != null && mainProgressDialog.isShowing())
            mainProgressDialog.dismiss();
    }

    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = getApplicationContext().getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density + 0.5f);
    }

    private void changeColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }
    }

    private RecyclerView.OnScrollListener custom_scroll_listner = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if ((int) recyclerView.getTag() == mTouchedRvTag) {
                for (int noOfRecyclerView = 0; noOfRecyclerView < 2; noOfRecyclerView++) {
                    if (noOfRecyclerView != (int) recyclerView.getTag()) {
                        RecyclerView tempRecyclerView = (RecyclerView) rl.findViewWithTag(noOfRecyclerView);
                        tempRecyclerView.scrollBy(dx, dy);
                    }
                }
            }
        }
    };

    private RecyclerView.OnItemTouchListener custom_item_touch_listner = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            mTouchedRvTag = (int) rv.getTag();
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    };

    boolean isAsyncTaskRunning = false;

    public void retrieveWebserviceFromCrewCode(String currDate, String crewCode, String projectCode) {
        RetrievingTimeSheetTask retrieveParser = new RetrievingTimeSheetTask(this, crewCode, currDate, projectCode, new RetrieveTimeSheetTaskListener() {
            @Override
            public void postRetrieveTimesheetTask(String response) {
                isAsyncTaskRunning = false;
                if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                    RetrieveTimeSheetParser retrieveTimeSheetParser = new RetrieveTimeSheetParser(getApplicationContext());
                    mCrewTimeSheet = retrieveTimeSheetParser.parseCrewTimesheetData(response);
                    if (!StringUtil.isStringNull(mCrewTimeSheet.getSeqNo()))
                        mCrewTimeSheet.setSubmitStatus(SubmitStatus.SUCCESS);
                    else
                        mCrewTimeSheet.setSubmitStatus(SubmitStatus.NOT_SUBMITTED);
                    new insertTimesheetInDatabaseTask().execute();
                } else {
                    DialogUtil.dismissProgressDialog(mainProgressDialog);
                    makeAlertErrorOccurred(response);
                }
            }
            @Override
            public void preRetrieveTimesheetTask() {
                isAsyncTaskRunning = true;
                mainProgressDialog = DialogUtil.showProgressDialog(mainProgressDialog, "Retrieving Timesheet", MainActivity.this);
            }
        });
        if (!isAsyncTaskRunning)
            retrieveParser.execute();
        else {
            Log.d(TAG,"RetrievingTimeSheetTask Previous Task Running");
        }
    }

    private DeleteTimesheetTask.DeleteTimesheetTaskListener deleteTimesheetTaskListener = new DeleteTimesheetTask.DeleteTimesheetTaskListener() {
        @Override
        public void preDeleteTimesheet() {
            mainProgressDialog = DialogUtil.showProgressDialog(mainProgressDialog, "Deleting Timesheet", MainActivity.this);
        }

        @Override
        public void postDeleteTimesheet(boolean response) {
            DialogUtil.dismissProgressDialog(mainProgressDialog);
            if (response == true){
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
            else
                DialogUtil.makeAlertErrorOccurred(MainActivity.this, "Some Error Occured.\nUnable to Delete Timesheet.");
        }
    };

    private void deleteTimesheet(){
        if (isTimeSheetSubmittedOnServer()){
            if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED))
                unsavedTimesheetAlertDialog();
            else {
                mDeleteTimesheetTask = new DeleteTimesheetTask(MainActivity.this, selectedCrewCode, workDate, selectedProjectCode, mCrewTimeSheet.getSeqNo(), deleteTimesheetTaskListener);
                mDeleteTimesheetTask.execute();
            }
        }
        else {
            makeSnackbar("Timesheet not present on Server");
        }
    }

    private String setWorkdateToTodaysDate() {
        cal = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat df1 = new SimpleDateFormat("EEEE");
        workDate = df.format(cal.getTime());
        workDay = df1.format(cal.getTime());
        return workDate;
    }

    private void getValuesFromSharedPreference(){
        ishanSharedPreference = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        defaultPreferenceEditor = defaultSharedPreference.edit();
        selectedCrewCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_code)
        ,getString(R.string.cmic_shared_preference_no_crew_code));
        selectedProjectCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_code)
        ,getString(R.string.cmic_shared_preference_no_project_code));
        selectedCrewName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_name),"Crew Name");
        selectedProjectCompCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_comp_code),
                "NOCOMPCODE");
        selectedProjectName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_name)
                ,"NOPROJECTNAME");
        selectedResponsiblePerson = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_responsible_person)
                ,"NORESPONSIBLEPERSON");
        if (selectedResponsiblePerson.equalsIgnoreCase("null") || selectedResponsiblePerson.equalsIgnoreCase(""))
            selectedResponsiblePerson = "Not Selected";
        selectedTradeName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_hrt_name)
                ,"NOHRTNAME");
        selectedHrtTradeName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_hrt_trade_name)
                ,"NOHRTTRADENAME");
        selectedOraSew = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_ora_seq)
                ,"NOORASEQ");
        isRegularModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_regular_mode),false);
        isInOutModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_inout_mode),false);
        maxNormalTimeFromSettings = Double.parseDouble(defaultSharedPreference.getString(getString(R.string.settings_key_max_normal_time),
                getString(R.string.settings_max_normal_time_default)));
        normalTimeFromSettings = Integer.parseInt(defaultSharedPreference.getString(getString(R.string.settings_key_normal_time),
                getString(R.string.settings_normal_time_default)));
        overTimeFromSettings = Integer.parseInt(defaultSharedPreference.getString(getString(R.string.settings_key_over_time),
                getString(R.string.settings_over_time_default)));
        firstDayOfWeek = defaultSharedPreference.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
        if (mCrewTimeSheet!=null) {
            mCrewTimeSheet.setCrewCode(selectedCrewCode);
            mCrewTimeSheet.setJobCode(selectedProjectCode);
            mCrewTimeSheet.setJobCompCode(selectedProjectCompCode);
        }
    }

    private boolean validateTimeSheetFromDatabaseWithSharePreference(){
        if (selectedCrewCode!=null && selectedProjectCode!=null && selectedCrewCode.equalsIgnoreCase(mCrewTimeSheet.getCrewCode()) && selectedProjectCode.equalsIgnoreCase(mCrewTimeSheet.getJobCode()))
            return true;
        else
            return false;
    }

    private boolean isTimeSheetSubmittedOnServer(){
        if (mCrewTimeSheet!=null && mCrewTimeSheet.getSeqNo()!=null && !mCrewTimeSheet.getSeqNo().equals("") && !mCrewTimeSheet.getSeqNo().equalsIgnoreCase("null"))
            return true;
        else
            return false;
    }

    //onTaskStarted datePicker
    private void showCalenderToSelectDate() {
        cal = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(this, R.style.DatePickerDailog, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar tempCalendar = Calendar.getInstance();
                tempCalendar.set(year,monthOfYear,dayOfMonth);
                workDate = sdfNew.format(tempCalendar.getTime());
                setUPColorForWeekDayButtons(getEndDateOfWeek());
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }

        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        fromDatePickerDialog.show();
    }

    private void timeSheetEdited(){
        mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
        setUPColorForToday(mCrewTimeSheet.getSubmitStatus());
    }

    private void setUPColorForToday(SubmitStatus submitStatus){
        Drawable gray = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_gray);
        Drawable green = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_green);
        Drawable red = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_red);
        Drawable yellow = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_yellow);
        int year = Integer.parseInt(workDate.split("\\-")[0]);
        int month = Integer.parseInt(workDate.split("\\-")[1]);
        month--;
        int day = Integer.parseInt(workDate.split("\\-")[2]);
        Calendar tempCal = Calendar.getInstance();
        tempCal.set(year, month, day);
        String currentDay = sdfDayNew.format(tempCal.getTime());
        ArrayList<String> week = CollectionUtils.getWeek(firstDayOfWeek);
        int indexOfButton = week.indexOf(currentDay);
        if (submitStatus.equals(SubmitStatus.SUCCESS))
            listWeek.get(indexOfButton).setCompoundDrawablesWithIntrinsicBounds(null, null, green, null);
        if (submitStatus.equals(SubmitStatus.FAILURE))
            listWeek.get(indexOfButton).setCompoundDrawablesWithIntrinsicBounds(null, null, red, null);
        if (submitStatus.equals(SubmitStatus.EDITED))
            listWeek.get(indexOfButton).setCompoundDrawablesWithIntrinsicBounds(null, null, yellow, null);
        if (submitStatus.equals(SubmitStatus.NOT_SUBMITTED))
            listWeek.get(indexOfButton).setCompoundDrawablesWithIntrinsicBounds(null, null, gray, null);
    }

    private void setUPColorForWeekDayButtons(String endDate){
        Dashboard2Task dashboard2Task = new Dashboard2Task(MainActivity.this, selectedProjectCompCode, selectedProjectCode, selectedCrewCode, endDate, new DashboardTaskListener() {
            @Override
            public void beforeDashboardTaskStarted(String displayMessage) {
                mainProgressDialog = DialogUtil.showProgressDialog(mainProgressDialog, "Fetching Colors", MainActivity.this);
            }
            @Override
            public void onDashboardTaskComplete(String response) {
            }

            @Override
            public void onTaskCancelled() {
            }

            @Override
            public void onDashboard2TaskComplete(String response) {
                DialogUtil.dismissProgressDialog(mainProgressDialog);
                if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                    Dashboard2Parser parser = new Dashboard2Parser(true);
                    List<Dashboard2> dashboard2List = parser.parseDashboard2Data(response);
                    boolean[] submitStatusForEachDayArray = {false,false,false,false,false,false,false};
                    for (Dashboard2 eachEmployee : dashboard2List){
                        List<AllTimes> allTimes = eachEmployee.getTimesList();
                        for (int i=0;i<7;i++){
                            AllTimes timeForEachDay = allTimes.get(i);
                            if (timeForEachDay.getReg()>0 || timeForEachDay.getOt()>0 || timeForEachDay.getDot()>0)
                                submitStatusForEachDayArray[i] = true;
                        }
                    }
                    for (int i=0;i<7;i++){
                        Drawable gray = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_gray);
                        Drawable green = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_button_green);
                        Button btn = listWeek.get(i);
                        if (submitStatusForEachDayArray[i])
                            btn.setCompoundDrawablesWithIntrinsicBounds(null,null,green ,null);
                        else
                            btn.setCompoundDrawablesWithIntrinsicBounds(null,null,gray ,null);
                    }
                    if (mCrewTimeSheet!=null && mCrewTimeSheet.getSubmitStatus()!=null && mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED))
                        timeSheetEdited();
                }
                else
                    makeAlertErrorOccurred(response);
            }

            @Override
            public void onDashboard3TaskComplete(String response) {
            }

            @Override
            public void onGetSignatureOraSeqStarted(String displayMessage) {
            }

            @Override
            public void onGetSignatureOraSeqCompleted(String response) {
            }

            @Override
            public void onGetSignatureStarted() {
            }

            @Override
            public void onGetSignatureCompleted(Bitmap bitmap, GetSignature enumSignature) {
            }

            @Override
            public void onPostSignatureTaskStarted(String displayMessage) {
            }

            @Override
            public void onPostSignatureTaskCompleted(String response, Signature enumSignature) {
            }

            @Override
            public void onDeleteSignatureTaskStarted(String displayMessage) {

            }

            @Override
            public void onDeleteSignatureTaskCompleted(String response, Signature enumSignature) {

            }
        }, true);
        dashboard2Task.execute();
    }

    public void calculateTotalHours(CrewTimeSheet crewTimeSheet){
        ArrayList<EmployeeDataForCrew> empTimesheet = crewTimeSheet.getEmpTimeSheet();
        ArrayList<SubmittedActivityFromCrewModal> activityTimeSheet = crewTimeSheet.getCrewActivity();
        if (crewTimeSheet!=null){
            for (int numberOfEmployee = 0; numberOfEmployee < empTimesheet.size(); numberOfEmployee++) {
                double totalREG = 0.0, totalOT = 0.0, totalDOT = 0.0;

                for (int numberOfActivities = 0; numberOfActivities < activityTimeSheet.size(); numberOfActivities++) {

                    totalREG = totalREG + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getStandardTime();
                    totalOT = totalOT + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getOverTime();
                    totalDOT = totalDOT + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getDoubleOverTime();
                }
                empTimesheet.get(numberOfEmployee).setTotalRtHour(totalREG);
                empTimesheet.get(numberOfEmployee).setTotalOtHour(totalOT);
                empTimesheet.get(numberOfEmployee).setTotalDotHour(totalDOT);
            }
        }
        else
            Log.d("MAINACTIVITY", "Timesheet is Null");
    }

    private void calculateFooterHours(CrewTimeSheet crewTimeSheet) {
        ArrayList<EmployeeDataForCrew> empTimesheet = crewTimeSheet.getEmpTimeSheet();
        ArrayList<SubmittedActivityFromCrewModal> activityTimeSheet = crewTimeSheet.getCrewActivity();
        if (crewTimeSheet!=null){
            double totalREG = 0.0, totalOT = 0.0, totalDOT = 0.0, totalInOut = 0.0;
            for (int numberOfEmployee = 0; numberOfEmployee < empTimesheet.size(); numberOfEmployee++) {
                totalREG = totalREG + empTimesheet.get(numberOfEmployee).getTotalRtHour();
                totalOT = totalOT + empTimesheet.get(numberOfEmployee).getTotalOtHour();
                totalDOT = totalDOT + empTimesheet.get(numberOfEmployee).getTotalDotHour();
                totalInOut = totalInOut + empTimesheet.get(numberOfEmployee).getTotalTimeInOut();
            }
            tvFooterReg.setText(totalREG+"");
            tvFooterOt.setText(totalOT+"");
            tvFooterDot.setText(totalDOT+"");
            tvFooterInOut.setText(String.format("%.2f",totalInOut));
        }
        else
            Log.d("MAINACTIVITY", "method calculateFooterHours:  Timesheet is Null");
    }

    private void responsiblePersonClicked(){
        Intent i = new Intent(MainActivity.this, CrewDetailsActivity.class);
        i.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
        i.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), false);
        i.putExtra(getString(R.string.cmic_intent_extras_selected_crew_code),selectedCrewCode);
        i.putExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq),selectedOraSew);
        startActivityForResult(i,REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON);
    }

    private void switchRegularAndAdvancedMode(){
        if (isRegularModeSelected){
            isRegularModeSelected = false;
            Log.d(TAG,"Advanced Mode Selected");
            defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_regular_mode),false).commit();
            tvMode.setText("R");
            makeSnackbar("Switched to Advanced Mode");
        }
        else {
            isRegularModeSelected = true;
            Log.d(TAG,"Regular Mode Selected");
            defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_regular_mode),true).commit();
            tvMode.setText("A");
            makeSnackbar("Switched to Regular Mode");
        }
    }

    private void addActivity(){
        final Dialog dialognewactivity = new Dialog(MainActivity.this);
        dialognewactivity.requestWindowFeature(Window.FEATURE_NO_TITLE); //before
        dialognewactivity.setContentView(R.layout.adding_new_activity);
        TextView txtaddactivityok = (TextView) dialognewactivity.findViewById(R.id.txtaddactivityok);
        final TextView txtaddactivitycancel = (TextView) dialognewactivity.findViewById(R.id.txtaddactivitycancel);
        final EditText etActivityName = (EditText) dialognewactivity.findViewById(R.id.etactivityname);
        etActivityName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etActivityName.setFocusable(true);
                etActivityName.setFocusableInTouchMode(true);
                InputMethodManager inputMethodManager =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.toggleSoftInputFromWindow(
                        txtaddactivitycancel.getApplicationWindowToken(),
                        InputMethodManager.SHOW_FORCED, 0);
            }
        });
        txtaddactivityok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String activityName = String.valueOf(etActivityName.getText());
                if (checkDuplicateActivityName(activityName)) {
                    ArrayList<SubmittedActivityFromCrewModal> activitiesDataAdd = mCrewTimeSheet.getCrewActivity();
                    SubmittedActivityFromCrewModal lastActivity = activitiesDataAdd.get(activitiesDataAdd.size() - 1);
                    int columnNo = Integer.parseInt(lastActivity.getColumnNo()) + 1;
                    SubmittedActivityFromCrewModal newActivity = new SubmittedActivityFromCrewModal(""
                            , columnNo + "", "", "", activityName, "", "", ""
                            , mCrewTimeSheet.getCrewCode(), mCrewTimeSheet.getWorkDate());
                    activitiesDataAdd.add(newActivity);
                    mCrewTimeSheet.setCrewActivity(activitiesDataAdd);
                    ArrayList<EmployeeDataForCrew> employeeDataAdd = mCrewTimeSheet.getEmpTimeSheet();
                    for (int i = 0; i < employeeDataAdd.size(); i++) {
                        ActivityTimeForCrew activity = new ActivityTimeForCrew("null", 0, "null", 0, "null", 0, mCrewTimeSheet.getCrewCode()
                                , mCrewTimeSheet.getWorkDate(), employeeDataAdd.get(i).getEmpNo());
                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().add(activity);
                    }
                    dialognewactivity.dismiss();
                    timeSheetEdited();
                    mDbInstance.insertTimeSheetInDatabase(mCrewTimeSheet);
                    setUpUIElements(mCrewTimeSheet);
                    mDbInstance.insertDefaultActivityModel(workDate, selectedCrewCode, selectedProjectCode, mCrewTimeSheet.getCrewActivity());
                    //new insertTimesheetInDatabaseTask().execute();
                }
                else
                    makeSnackbar("Duplicate Activity Name");
            }
        });
        dialognewactivity.show();
    }

    private boolean checkDuplicateActivityName(String activityName){
        boolean flag = true;
        for (SubmittedActivityFromCrewModal activityFromCrewModal : mCrewTimeSheet.getCrewActivity()){
            if (activityFromCrewModal.getActivityName().equals(activityName))
                flag = false;
        }
        return flag;
    }

    private void submitTimeSheet() {
        //check normal time of each employee less than max normal time from settings
        boolean flag = true;
        for (EmployeeDataForCrew employee : mCrewTimeSheet.getEmpTimeSheet()){
            if (employee.getTotalRtHour() > maxNormalTimeFromSettings ){
                flag = false;
                MessagePromptDialogFragment fragment = MessagePromptDialogFragment.newInstance("Normal Time of "+employee.getEmpName()+"should be equal to or less than " + maxNormalTimeFromSettings);
                fragment.show(getSupportFragmentManager(),MessagePromptDialogFragment.class.getSimpleName());
                break;
            }
            if (isInOutModeSelected){
                Double total = employee.getTotalRtHour()+employee.getTotalOtHour()+employee.getTotalDotHour();
                if (total != employee.getTotalTimeInOut()){
                    flag = false;
                    MessagePromptDialogFragment fragment = MessagePromptDialogFragment.newInstance(employee.getEmpName().concat("'s In and Out time should be equal to total of normal, overtime and double overtime hours"));
                    fragment.show(getSupportFragmentManager(),MessagePromptDialogFragment.class.getSimpleName());
                    break;
                }
            }
        }
        if (flag) {
            CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
            String jsonSubmitWithSeqNo = creatingSubmitJson.getCrewTimeJSONAsString(mCrewTimeSheet);
            SubmittingTask submittingTask = new SubmittingTask(getApplicationContext(), jsonSubmitWithSeqNo, submittingTimeSheetInterface);
            submittingTask.execute();
            mDbInstance.insertDefaultActivityModel(workDate, selectedCrewCode, selectedProjectCode, mCrewTimeSheet.getCrewActivity());
        }
    }

    private SubmittingTimeSheetInterface submittingTimeSheetInterface= new SubmittingTimeSheetInterface(){
        @Override
        public void onTaskComplete(String response) {
            if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                RetrieveTimeSheetParser retrieveTimeSheetParser = new RetrieveTimeSheetParser(getApplicationContext());
                mCrewTimeSheet = retrieveTimeSheetParser.parseCrewTimesheetData(response);
                mCrewTimeSheet.setSubmitStatus(SubmitStatus.SUCCESS);
                setUPColorForToday(mCrewTimeSheet.getSubmitStatus());
                new insertTimesheetInDatabaseTask().execute();
            }
            else {
                DialogUtil.dismissProgressDialog(mainProgressDialog);
                makeAlertErrorOccurred(response);
                mCrewTimeSheet.setSubmitStatus(SubmitStatus.FAILURE);
                setUPColorForToday(mCrewTimeSheet.getSubmitStatus());
            }
        }
        @Override
        public void onTaskStarted() {
            mainProgressDialog = DialogUtil.showProgressDialog(mainProgressDialog, "Submitting Timeshet", MainActivity.this);
        }
    };

    private MenuDialogFragment.MenuDialogListener menuDialogListener = new MenuDialogFragment.MenuDialogListener() {
        @Override
        public void addCrewMember() {
            Intent i = new Intent(MainActivity.this, CrewDetailsActivity.class);
            i.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
            i.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), true);
            i.putExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq),selectedOraSew);
            i.putExtra(getString(R.string.cmic_intent_extras_selected_crew_code),selectedCrewCode);
            i.putExtra(getString(R.string.cmic_intent_extras_timesheet),mCrewTimeSheet);
            startActivityForResult(i,REQUEST_CODE_CREW_DETAILS);
        }

        @Override
        public void switchCrew() {
            MainActivity.this.switchCrew();
        }

        @Override
        public void addActivity() {
            MainActivity.this.addActivity();
        }

        @Override
        public void notifyApprover() {
            MainActivity.this.notifyApprover();
        }

        @Override
        public void switchRegularAdvancedMode() {
            switchRegularAndAdvancedMode();
        }

        @Override
        public void switchInOutMode() {
            if (isInOutModeSelected){
                isInOutModeSelected = false;
                defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_inout_mode),false).commit();
                setUpUIElements(mCrewTimeSheet);
            }
            else {
                isInOutModeSelected = true;
                defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_inout_mode),true).commit();
                setUpUIElements(mCrewTimeSheet);
            }
        }

        @Override
        public void clearData() {
            ClearLocalStorageTask clearLocalStorageTask = new ClearLocalStorageTask(getApplicationContext(), clearLocalStorageListener);
            clearLocalStorageTask.execute();
        }

        @Override
        public void logout() {
            ClearLocalStorageTask clearLocalStorageTask = new ClearLocalStorageTask(getApplicationContext(), clearLocalStorageListener);
            clearLocalStorageTask.execute();
        }

        @Override
        public void settings() {
            Intent intentForSettingActivity = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intentForSettingActivity);
        }

        @Override
        public void cancel() {

        }
    };

    private ClearLocalStorageTask.ClearLocalStorageListener clearLocalStorageListener = new ClearLocalStorageTask.ClearLocalStorageListener() {
        @Override
        public void onTaskStarted() {
            mainProgressDialog = ProgressDialog.show(MainActivity.this, getString(R.string.app_name) ,"Deleting All Data");
        }

        @Override
        public void onTaskComplete() {
            dismissProgressDialog();
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }

        @Override
        public void onTaskCancelled() {
            dismissProgressDialog();
            makeAlertErrorOccurred("Some Error Occurred While Deleting Data");
        }
    };

    private NotifyApproverDialogFragment.NotifyApproverDialogListener notifyApproverDialogListener = new NotifyApproverDialogFragment.NotifyApproverDialogListener() {
        @Override
        public void sendSMS() {
           MainActivity.this.sendSMS();
        }

        @Override
        public void sendMail() {
            MainActivity.this.sendMail();
        }
    };

    private void notifyApprover() {
        NotifyApproverDialogFragment notifyApproverDialogFragment = NotifyApproverDialogFragment.newInstance(notifyApproverDialogListener);
        notifyApproverDialogFragment.show(getSupportFragmentManager(),NotifyApproverDialogFragment.class.getSimpleName());
    }

    private SendSmsDialogFragment.SendSmsDialogListener sendSmsDialogListener = new SendSmsDialogFragment.SendSmsDialogListener() {
        @Override
        public void sendSmsIntent(String number) {
            String subject = "TimeSheet Dated: ".concat(workDate);
            StringBuilder body = new StringBuilder("Please review the submitted timesheet with the follwing details\n\n");
            body.append("Crew Code: ".concat(mCrewTimeSheet.getCrewCode()));
            body.append("\nCrew Name: ".concat(selectedCrewName));
            body.append("\nCrew Date: ".concat(workDate));
            body.append("\nJob Name: ".concat(selectedProjectName));
            body.append("\nForeman: ".concat(selectedResponsiblePerson));
            body.append("\nActivities: ");
            for (SubmittedActivityFromCrewModal activity: mCrewTimeSheet.getCrewActivity()) {
                String phaseCode, phaseName, categoryName, categoryCode, phase, category;
                phaseCode = activity.getPhaseCode();
                phaseName = activity.getPhaseName();
                categoryCode = activity.getCatCode();
                categoryName = activity.getCategoryName();
                if (phaseCode!=null && phaseName!=null && !phaseCode.equalsIgnoreCase("null") && !phaseCode.equalsIgnoreCase("------")&& phaseCode.length()>0)
                    phase = "Phase Code: ".concat(phaseCode).concat(" Phase Name: ").concat(phaseName);
                else
                    phase = "No Phase";
                if (categoryCode!=null && categoryName!=null && !categoryCode.equalsIgnoreCase("null") && !categoryCode.equalsIgnoreCase("------") && categoryCode.length()>0)
                    category = "Category Code: ".concat(categoryCode).concat(" Category Name: ").concat(categoryName);
                else
                    category = "No Category";
                body.append("\n".concat(activity.getActivityName().concat("-").concat(phase).concat(", ").concat(category)));
            }

            Uri uri = Uri.parse("smsto:".concat(number));
            Intent it = new Intent(Intent.ACTION_SENDTO, uri);
            it.putExtra("sms_body", body.toString());
            startActivity(it);
        }
    };

    private void sendSMS(){
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) {
            SendSmsDialogFragment fragment = SendSmsDialogFragment.newInstance(sendSmsDialogListener);
            fragment.show(getSupportFragmentManager(),SendSmsDialogFragment.class.getSimpleName());
        } else {
            DialogUtil.makeAlertErrorOccurred(MainActivity.this, "Device has no Messaging Functionality");
        }
    }

    private void sendMail() {
        String email = defaultSharedPreference.getString(getString(R.string.settings_key_approver_email),"example@example.com");
        String subject = "TimeSheet Dated: ".concat(workDate);
        StringBuilder body = new StringBuilder("Please review the submitted timesheet with the follwing details\n\n");
        body.append("Crew Code: ".concat(mCrewTimeSheet.getCrewCode()));
        body.append("\nCrew Name: ".concat(selectedCrewName));
        body.append("\nCrew Date: ".concat(workDate));
        body.append("\nJob Name: ".concat(selectedProjectName));
        body.append("\nForeman: ".concat(selectedResponsiblePerson));
        body.append("\nActivities: ");
        for (SubmittedActivityFromCrewModal activity: mCrewTimeSheet.getCrewActivity()) {
            String phaseCode, phaseName, categoryName, categoryCode, phase, category;
            phaseCode = activity.getPhaseCode();
            phaseName = activity.getPhaseName();
            categoryCode = activity.getCatCode();
            categoryName = activity.getCategoryName();
            if (phaseCode!=null && phaseName!=null && !phaseCode.equalsIgnoreCase("null") && !phaseCode.equalsIgnoreCase("------")&& phaseCode.length()>0)
                phase = "Phase Code: ".concat(phaseCode).concat(" Phase Name: ").concat(phaseName);
            else
                phase = "No Phase";
            if (categoryCode!=null && categoryName!=null && !categoryCode.equalsIgnoreCase("null") && !categoryCode.equalsIgnoreCase("------") && categoryCode.length()>0)
                category = "Category Code: ".concat(categoryCode).concat(" Category Name: ").concat(categoryName);
            else
                category = "No Category";
            body.append("\n".concat(activity.getActivityName().concat("-").concat(phase).concat(", ").concat(category)));
        }

        try {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                    "mailto:", email, null));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
            emailIntent.putExtra(Intent.EXTRA_TEXT, body.toString());
            startActivity(Intent.createChooser(emailIntent, "Send email..."));
        }
        catch (Exception e){
            DialogUtil.makeAlertErrorOccurred(MainActivity.this, "Setup Email Account on the Device First");
        }
    }

    //onTaskStarted Menu
    private void showMenuDialog() {
        MenuDialogFragment menuDialogFragment = MenuDialogFragment.newInstance(menuDialogListener);
        menuDialogFragment.show(getSupportFragmentManager(),MenuDialogFragment.class.getSimpleName());
}

    private void unsavedTimesheetAlertDialog(){
        final Dialog unsavedTimesheetDialog = new Dialog(MainActivity.this);
        unsavedTimesheetDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        unsavedTimesheetDialog.setContentView(R.layout.unsaved_timesheet_popup);
        TextView tvSubmit = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_submit);
        TextView tvDiscard = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_discard);
        TextView tvCancel = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_cancel);
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitTimeSheet();
                unsavedTimesheetDialog.dismiss();
            }
        });
        tvDiscard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCrewTimeSheet.getSeqNo()!=null && mCrewTimeSheet.getSeqNo()!="" && !mCrewTimeSheet.getSeqNo().equalsIgnoreCase("null"))
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.SUCCESS);
                else
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.NOT_SUBMITTED);
                setUPColorForToday(mCrewTimeSheet.getSubmitStatus());
                retrieveWebserviceFromCrewCode(mCrewTimeSheet.getWorkDate(), mCrewTimeSheet.getCrewCode(), mCrewTimeSheet.getJobCode());
                unsavedTimesheetDialog.dismiss();
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                unsavedTimesheetDialog.dismiss();
            }
        });
        unsavedTimesheetDialog.show();
    }

    private void RegularModePopUp(final int finalI){
        //TextWatcher etactivitywatcher = null;
        final Dialog regularModeDialog = new Dialog(MainActivity.this);
        regularModeDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        regularModeDialog.setContentView(R.layout.regularmode_dialog);
        final TextView cancel = (TextView) regularModeDialog.findViewById(R.id.txtcancel);
        TextView txtactivity = (TextView) regularModeDialog.findViewById(R.id.txtactivity);
        final EditText etActivityName = (EditText) regularModeDialog.findViewById(R.id.etactivity);

        if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
            etActivityName.setText(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
        } else {
            etActivityName.setText("Activity" + finalI+1);
        }

        etActivityName.requestFocus();
        TextView ok = (TextView) regularModeDialog.findViewById(R.id.txtok);
        TextView batchUpdate = (TextView) regularModeDialog.findViewById(R.id.txtbachupdate);
        if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
            txtactivity.setText(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
        } else {
            txtactivity.setText("Activity" + finalI+1);
        }

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regularModeDialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String activityName = etActivityName.getText().toString();
                if (StringUtil.isStringNull(activityName))
                    Toast.makeText(getApplicationContext(), "Enter Activity Name", Toast.LENGTH_SHORT).show();
                else {
                    regularModeDialog.dismiss();
                    mCrewTimeSheet.getCrewActivity().get(finalI).setActivityName(activityName);
                    timeSheetEdited();
                    setUpUIElements(mCrewTimeSheet);
                    new insertTimesheetInDatabaseTask().execute();
                }
            }
        });

        batchUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regularModeDialog.dismiss();
                final Dialog BatchUpdateDialog = new Dialog(MainActivity.this);
                BatchUpdateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE); //before
                BatchUpdateDialog.setContentView(R.layout.batchupdate_dialog);
                TextView cancel = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchcancel);
                final TextView ok = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchok);
                TextView txtbatchactivityname = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchactivityname);
                final EditText etbatchactivity = (EditText) BatchUpdateDialog.findViewById(R.id.txtstandardTime);
                etbatchactivity.requestFocus();
                etbatchactivity.setInputType(InputType.TYPE_CLASS_NUMBER);
                TextView txtaActivityName = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchactivityname);
                if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
                    txtbatchactivityname.setText(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
                } else {
                    txtbatchactivityname.setText("Activity" + finalI);
                }
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BatchUpdateDialog.dismiss();
                    }
                });

                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (etbatchactivity.getText().toString().equalsIgnoreCase("") || etbatchactivity.getText().toString().equalsIgnoreCase("null")) {
                        } else {
                            double batchDialogValue = Double.parseDouble(etbatchactivity.getText().toString());
                            for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                                if (batchDialogValue <= normalTimeFromSettings) {
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(batchDialogValue);
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setOverTime(0);
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setDoubleOverTime(0);
                                } else {
                                    double subtractedValue = (Double.valueOf(etbatchactivity.getText().toString())) - normalTimeFromSettings;
                                    if (subtractedValue <= overTimeFromSettings) {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setOverTime(subtractedValue);
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setDoubleOverTime(0);
                                    } else {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setOverTime(Double.valueOf(overTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setDoubleOverTime(batchDialogValue - (normalTimeFromSettings + overTimeFromSettings));
                                    }
                                }
                            }
                            timeSheetEdited();
                            setUpUIElements(mCrewTimeSheet);
                            new insertTimesheetInDatabaseTask().execute();
                        }
                        BatchUpdateDialog.dismiss();
                    }
                });

                BatchUpdateDialog.show();
            }
        });
        regularModeDialog.show();
    }

    private AdvancedModeDialogFragment.AdvancedModeDialogListener advancedModeDialogListener = new AdvancedModeDialogFragment.AdvancedModeDialogListener() {
        @Override
        public void insertTimeSheetInDatabase(CrewTimeSheet crewTimeSheet) {
            mCrewTimeSheet = crewTimeSheet;
            setUpUIElements(mCrewTimeSheet);
            new MainActivity.insertTimesheetInDatabaseTask().execute();
        }

        @Override
        public void hideProgressDialog() {
            dismissProgressDialog();
        }

        @Override
        public void makeErrorAlert(String response) {
            makeAlertErrorOccurred(response);
        }

        @Override
        public void showProgressDialog(String displayMessage) {
            mainProgressDialog = ProgressDialog.show(MainActivity.this, getString(R.string.app_name) ,displayMessage);
        }
    };

    public void advancedModeDialogFragment(int activityPosition){
        AdvancedModeDialogFragment advancedModeDialogFragment = AdvancedModeDialogFragment.newInstance(advancedModeDialogListener, mCrewTimeSheet, activityPosition, configAdvancedMode);
        advancedModeDialogFragment.show(getSupportFragmentManager(),AdvancedModeDialogFragment.class.getSimpleName());
    }

    private void makeAlertErrorOccurred(String errorMessage){
        AlertDialog.Builder alertBox = new AlertDialog.Builder(MainActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        if (errorMessage!=null)
            alertBox.setMessage(errorMessage);
        else
            alertBox.setMessage("Some Error Occurred");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }

    private void makeSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT)
                .show();
    }

    public class insertTimesheetInDatabaseTask extends AsyncTask<Void,Void,Void>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mainProgressDialog!=null && mainProgressDialog.isShowing()){
            }
            else {
                mainProgressDialog = ProgressDialog.show(MainActivity.this, null, "        Inserting TimeSheet in Database");
            }
        }
        @Override
        protected Void doInBackground(Void... params) {
            mDbInstance.insertTimeSheetInDatabase(mCrewTimeSheet);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (mainProgressDialog!=null && mainProgressDialog.isShowing())
                DialogUtil.dismissProgressDialog(mainProgressDialog);
            setUpUIElements(mCrewTimeSheet);
        }
    }
}