package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.content.Context;
import android.preference.PreferenceManager;

import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.R;

public class DeleteDataUtility {

    public static void deleteAllData(Context context){
        IshanDBHelper dbHelper = IshanDBHelper.getInstance(context);
        dbHelper.deleteLocalDatabase();
        context.getSharedPreferences(context.getString(R.string.cmic_shared_preference),Context.MODE_PRIVATE).edit().clear().commit();
        PreferenceManager.getDefaultSharedPreferences(context).edit().clear().commit();
    }
}
