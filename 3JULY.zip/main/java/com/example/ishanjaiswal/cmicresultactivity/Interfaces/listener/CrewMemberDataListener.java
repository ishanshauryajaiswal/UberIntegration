package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
  Created by parneet.singh on 10/20/2016.
 */
public interface CrewMemberDataListener {

    void onCrewMemberDataTaskCompleted(String result);
    void onCrewMemberDataTaskStarted();
    void onCrewMemberDataTaskCancelled();
}
