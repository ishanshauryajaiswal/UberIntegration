package com.example.ishanjaiswal.cmicresultactivity.parsers;

import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.SignatureOraSeqModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by ishan.jaiswal on 5/4/2018.
 */

public class GetSignatureOraSeqParser {
    private static final String TAG = GetSignatureOraSeqParser.class.getSimpleName();
    SignatureOraSeqModel signatureOraSeqModel = null;
    public SignatureOraSeqModel parseSignatureOraSeq(String response){
        try {
            if (response!=null){
                JSONObject jsonObject = new JSONObject(response);
                JSONObject rowDefinition = jsonObject.getJSONObject("rowDefinition");
                JSONArray attrNames = rowDefinition.getJSONArray("attrNames");

                Set<String> requiredAttributes = new HashSet<>();
                requiredAttributes.add("CrwsigOraseq");
                requiredAttributes.add("CrwsigEmpOraseq");
                requiredAttributes.add("CrwsigTshFromDate");
                requiredAttributes.add("CrwsigTshToDate");

                if (jsonObject.has("rows")) {
                    JSONArray rows = jsonObject.getJSONArray("rows");
                    HashMap<String, Integer> attributeIndex = new HashMap<>();
                    for (int i = 0; i < attrNames.length(); i++) {
                        String strAttribute = attrNames.getString(i);

                        if (requiredAttributes.contains(strAttribute)) {
                            attributeIndex.put(strAttribute, i);
                        }
                    }
                    ArrayList<JSONArray> attributeValues = new ArrayList<>();
                    for (int j = 0; j < rows.length(); j++) {
                        JSONArray values = rows.getJSONObject(j).getJSONArray("attrValues");
                        attributeValues.add(values);
                    }
                    for (int k=0; k<attributeValues.size(); k++){
                        signatureOraSeqModel = new SignatureOraSeqModel();
                        signatureOraSeqModel.setSignOraSeq((attributeValues.get(k).getString(attributeIndex.get("CrwsigOraseq"))));
                        signatureOraSeqModel.setSignEmpOraSeq((attributeValues.get(k).getString(attributeIndex.get("CrwsigEmpOraseq"))));
                        signatureOraSeqModel.setSignTshToDate((attributeValues.get(k).getString(attributeIndex.get("CrwsigTshFromDate"))));
                        signatureOraSeqModel.setSignTshFromDate((attributeValues.get(k).getString(attributeIndex.get("CrwsigTshToDate"))));
                        break;
                    }
                    return signatureOraSeqModel ;
                }
            }
        }
        catch (JSONException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        catch (Exception e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        return signatureOraSeqModel;
    }

}
