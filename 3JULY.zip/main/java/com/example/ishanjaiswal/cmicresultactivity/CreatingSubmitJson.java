package com.example.ishanjaiswal.cmicresultactivity;

import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOut;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/28/2018.
 */

public class CreatingSubmitJson {

    // main keys
    private String KEY_CREW_CODE = "CrewCode";
    private String KEY_CREW_ACTIVITY = "CrewActivity";
    private String KEY_SEQ_NO = "SeqNo";
    private String KEY_WORK_DATE = "WorkDate";
    private String KEY_JOB_CODE = "JobCode";
    private String KEY_EMP_TIMESHEET = "EmpTimesheet";

    // employee timesheet keys
    private String KEY_TIMESHEET_DELETE_FLAG = "DeleteFlag";
    private String KEY_TIMESHEET_EMP_NO = "EmpNo";
    private String KEY_TIMESHEET_EMP_NAME = "EmpName";
    private String KEY_TIMESHEET_TRD_CODE = "TrdCode";
    private String KEY_TIMESHEET_TRD_NAME = "TrdName";
    private String KEY_TIMESHEET_ROW_NUM = "RowNum";
    private String KEY_TIMESHEET_OT_SEQ_NO = "otSeqNo";
    private String KEY_TIMESHEET_DOT_HOUR = "dotHour";
    private String KEY_TIMESHEET_RT_SEQ_NO = "rtSeqNo";
    private String KEY_TIMESHEET_RT_HOUR = "rtHour";
    private String KEY_TIMESHEET_DOT_SEQ_NO = "dotSeqNo";
    private String KEY_TIMESHEET_OT_HOUR = "otHour";
    private String KEY_TIMESHEET_TIMESHEET = "Timesheet";
    private String KEY_TIMESHEET_TIME_IN_OUT = "InOutTime";

    // crew activity keys
    private String KEY_CREW_ACTIVITY_DELETEFLAG = "DeleteFlag";
    private String KEY_CREW_ACTIVITY_SEQ_NO = "SeqNo";
    private String KEY_CREW_ACTIVITY_COLOUMN_NO = "ColumnNo";
    private String KEY_CREW_ACTIVITY_ACTIVITY_NAME = "ActivityName";
    private String KEY_CREW_ACTIVITY_PHASE_CODE = "PhaseCode";
    private String KEY_CREW_ACTIVITY_CAT_CODE = "CatCode";
    private String KEY_CREW_ACTIVITY_WBS_CODE = "WbsCode";
    private String KEY_CREW_ACTIVITY_PCILINEORASEQ = "PciLineOraseq";


    public String getCrewTimeJSONAsString(CrewTimeSheet crewTimeSheet) {
        JSONObject jsonObject = new JSONObject();
        try
        {
            // json array for crew Activity
            JSONArray crewActivityJsonArray = new JSONArray();
            ArrayList<SubmittedActivityFromCrewModal> crewActivity = crewTimeSheet.getCrewActivity();
            if (crewActivity != null)
            {
                for (int i = 0; i < crewActivity.size(); i++)
                {
                    JSONObject crewActivityObjects = new JSONObject();
                    SubmittedActivityFromCrewModal submittedActivityFromCrewModal = crewActivity.get(i);
                    if (submittedActivityFromCrewModal.getDeleteFlag() == null || submittedActivityFromCrewModal.getDeleteFlag().equals("")) {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_DELETEFLAG,JSONObject.NULL);
                    } else {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_DELETEFLAG, submittedActivityFromCrewModal.getDeleteFlag());
                    }
                    // crewActivityObjects.put(KEY_CREW_ACTIVITY_DELETEFLAG, submittedActivityFromCrewModal.getDeleteFlag());
                    if (submittedActivityFromCrewModal.getSeqNo() == null || submittedActivityFromCrewModal.getSeqNo().equals("null"))
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_SEQ_NO, JSONObject.NULL);
                    } else
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_SEQ_NO, submittedActivityFromCrewModal.getSeqNo());
                    }
                    crewActivityObjects.put(KEY_CREW_ACTIVITY_COLOUMN_NO, String.valueOf(i));
                    if(submittedActivityFromCrewModal.getActivityName() == null)
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_ACTIVITY_NAME,"");
                    }
                    else
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_ACTIVITY_NAME, submittedActivityFromCrewModal.getActivityName());
                    }
                    if( submittedActivityFromCrewModal.getPhaseCode() == null )
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_PHASE_CODE, "");
                    }
                    else
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_PHASE_CODE,submittedActivityFromCrewModal.getPhaseCode());
                    }
                    if(submittedActivityFromCrewModal.getCatCode() == null)
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_CAT_CODE,"");
                    }
                    else
                    {
                        crewActivityObjects.put(KEY_CREW_ACTIVITY_CAT_CODE, submittedActivityFromCrewModal.getCatCode());
                    }
                    crewActivityObjects.put(KEY_CREW_ACTIVITY_WBS_CODE, JSONObject.NULL);
                    crewActivityObjects.put(KEY_CREW_ACTIVITY_PCILINEORASEQ, JSONObject.NULL);
                    crewActivityJsonArray.put(i, crewActivityObjects);
                }
            }

            // json array for employee timesheet
            JSONArray empTimeSheets = new JSONArray();
            ArrayList<EmployeeDataForCrew> employeeDataForCrewsList = crewTimeSheet.getEmpTimeSheet();
            if (employeeDataForCrewsList != null)
            {
                for (int k = 0; k < employeeDataForCrewsList.size(); k++) {
                    JSONObject empTimeSheetObject = new JSONObject();

                    EmployeeDataForCrew employeeDataForCrew = employeeDataForCrewsList.get(k);
                    if(employeeDataForCrew.getDeleteFlag() == null || employeeDataForCrew.getDeleteFlag().equals("null"))
                    {
                        empTimeSheetObject.put(KEY_TIMESHEET_DELETE_FLAG, JSONObject.NULL);
                    }
                    else
                    {
                        empTimeSheetObject.put(KEY_TIMESHEET_DELETE_FLAG, employeeDataForCrew.getDeleteFlag());
                    }
                    empTimeSheetObject.put(KEY_TIMESHEET_EMP_NO, employeeDataForCrew.getEmpNo());
                    empTimeSheetObject.put(KEY_TIMESHEET_ROW_NUM, employeeDataForCrew.getRowNo());
                    JSONArray activityTimeForCrewJSONArray = new JSONArray();
                    ArrayList<ActivityTimeForCrew> activityTimeForCrewArrayList = employeeDataForCrew.getTimeSheet();
                    if (activityTimeForCrewArrayList != null) {
                        for (int l = 0; l < activityTimeForCrewArrayList.size(); l++) {
                            ActivityTimeForCrew activityTimeForCrew = activityTimeForCrewArrayList.get(l);
                            JSONObject timeSheetObject = new JSONObject();

                            String overTimeSeqNumber = activityTimeForCrew.getOverTimeSeqNumber();
                            String standardTimeSeqNumber = activityTimeForCrew.getStandardTimeSeqNumber();
                            String doubleOverTimeSeqNumber = activityTimeForCrew.getDoubleOverTimeSeqNumber();
                            if (overTimeSeqNumber != null && !overTimeSeqNumber.isEmpty() && !overTimeSeqNumber.equalsIgnoreCase("null")) {
                                timeSheetObject.put(KEY_TIMESHEET_OT_SEQ_NO, activityTimeForCrew.getOverTimeSeqNumber());
                            } else {
                                timeSheetObject.put(KEY_TIMESHEET_OT_SEQ_NO, JSONObject.NULL);
                            }

                            timeSheetObject.put(KEY_TIMESHEET_DOT_HOUR, String.valueOf(activityTimeForCrew.getDoubleOverTime()));

                            if (standardTimeSeqNumber != null && !standardTimeSeqNumber.isEmpty() && !standardTimeSeqNumber.equalsIgnoreCase("null")) {
                                timeSheetObject.put(KEY_TIMESHEET_RT_SEQ_NO, activityTimeForCrew.getStandardTimeSeqNumber());
                            } else {
                                timeSheetObject.put(KEY_TIMESHEET_RT_SEQ_NO, JSONObject.NULL);
                            }

                            timeSheetObject.put(KEY_TIMESHEET_RT_HOUR, String.valueOf(activityTimeForCrew.getStandardTime()));

                            if (doubleOverTimeSeqNumber != null && !doubleOverTimeSeqNumber.isEmpty() && !doubleOverTimeSeqNumber.equalsIgnoreCase("null")) {
                                timeSheetObject.put(KEY_TIMESHEET_DOT_SEQ_NO, activityTimeForCrew.getDoubleOverTimeSeqNumber());
                            } else {
                                timeSheetObject.put(KEY_TIMESHEET_DOT_SEQ_NO, JSONObject.NULL);
                            }

                            timeSheetObject.put(KEY_TIMESHEET_OT_HOUR, String.valueOf(activityTimeForCrew.getOverTime()));
                            activityTimeForCrewJSONArray.put(l, timeSheetObject);

                        }
                    } else {
                        Log.d("Log", String.valueOf(activityTimeForCrewArrayList.size()));
                    }
                    empTimeSheetObject.put(KEY_TIMESHEET_TIMESHEET, activityTimeForCrewJSONArray);
                    JSONArray timeInOutForEmployee = new JSONArray();
                    if (crewTimeSheet.getEmpTimeSheet().get(k).getTimeInOuts()!=null && crewTimeSheet.getEmpTimeSheet().get(k).getTimeInOuts().size()>0) {
                        for (TimeInOut timeInOut : crewTimeSheet.getEmpTimeSheet().get(k).getTimeInOuts()) {
                            JSONObject obj = new JSONObject();
                            obj.put("timeIn", timeInOut.getTimeIn());
                            obj.put("timeOut", timeInOut.getTimeOut());
                            timeInOutForEmployee.put(obj);
                        }
                    }
                    empTimeSheetObject.put(KEY_TIMESHEET_TIME_IN_OUT,timeInOutForEmployee);
                    empTimeSheets.put(k, empTimeSheetObject);
                }
            }
            else
            {
                Log.d("EmployeeDataFor Crew", "null");
            }
            jsonObject.put(KEY_CREW_CODE, crewTimeSheet.getCrewCode());
            jsonObject.put(KEY_CREW_ACTIVITY, crewActivityJsonArray);
            if (crewTimeSheet.getSeqNo() == null || crewTimeSheet.getSeqNo().equals("null")) {
                jsonObject.put(KEY_SEQ_NO, JSONObject.NULL);
            } else {
                jsonObject.put(KEY_SEQ_NO, crewTimeSheet.getSeqNo());
            }
            jsonObject.put(KEY_WORK_DATE, crewTimeSheet.getWorkDate());
            jsonObject.put(KEY_JOB_CODE, crewTimeSheet.getJobCode());
            jsonObject.put(KEY_EMP_TIMESHEET, empTimeSheets);
            Log.d("Submit JSON",jsonObject.toString());
            return jsonObject.toString();
        } catch (JSONException e) {
            Log.d("JSONException in Submit", e.toString());
        } catch (Exception e) {
            Log.d("Exception in Submit", e.toString());
        }

        return jsonObject.toString();
    }
}
