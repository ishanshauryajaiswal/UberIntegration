package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Utils.DeleteDataUtility;

public class ClearLocalStorageTask extends AsyncTask<Void, Void, Void> {

    public interface ClearLocalStorageListener{
        void onTaskStarted();
        void onTaskComplete();
        void onTaskCancelled();
    }

    private Context mContext;
    private ClearLocalStorageListener mListener;

    public ClearLocalStorageTask(Context mContext, ClearLocalStorageListener mListener) {
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.onTaskStarted();
        }
    }

    @Override
    protected Void doInBackground(Void... voids) {
        if (!isCancelled())
            DeleteDataUtility.deleteAllData(mContext);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        if (!isCancelled()) {
            super.onPostExecute(aVoid);
            mListener.onTaskComplete();
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        mListener.onTaskCancelled();
    }
}
