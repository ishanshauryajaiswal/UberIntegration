package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.RetrieveTimeSheetTaskListener;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/15/2018.
 */

public class RetrievingTimeSheetTask extends AsyncTask<Void,Void,String>
{
    //    private String authCode;
    private Context context;
    private String crewCode;
    private String jobCode;
    private ArrayList<CrewTimeSheet> result;
    private RetrieveTimeSheetTaskListener RetrieveTimeSheetTaskListener;
    private String workDate;
    private static final String TAG = RetrievingTimeSheetTask.class.getSimpleName();
    public RetrievingTimeSheetTask(Context context, String crewCode, String workDate, String jobCode, RetrieveTimeSheetTaskListener RetrieveTimeSheetTaskListener)
    {
        this.context = context;
        this.crewCode = crewCode;
        this.jobCode = jobCode;
        this.workDate = workDate;
        this.RetrieveTimeSheetTaskListener = RetrieveTimeSheetTaskListener;
    }
    @Override
    protected void onPreExecute()
    {
        if (!isCancelled())
            RetrieveTimeSheetTaskListener.preRetrieveTimesheetTask();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(context);
                response = requestCall.retrievingTimeSheet(context, crewCode, workDate, jobCode);
            } catch (Exception e) {
                Log.e(TAG,"Exception in doInBackground" + e.getMessage());
            }
        }
        return response;
    }
    protected void onPostExecute(String response)
    {
        if (!isCancelled())
            RetrieveTimeSheetTaskListener.postRetrieveTimesheetTask(response);
    }

}
