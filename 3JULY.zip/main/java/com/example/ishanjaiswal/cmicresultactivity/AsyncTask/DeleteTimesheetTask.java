package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 6/4/2018.
 */

//Response of this request is the old sequence number of the saved timesheet
public class DeleteTimesheetTask extends AsyncTask<Void, Void, Boolean> {

    public interface DeleteTimesheetTaskListener{
        void preDeleteTimesheet();
        void postDeleteTimesheet(boolean response);
    }

    private DeleteTimesheetTaskListener mListener;
    private Context mContext;
    private String crewCode, workDate, jobCode, seqNo;


    public DeleteTimesheetTask(Context mContext, String crewCode, String workDate, String jobCode, String seqNo, DeleteTimesheetTaskListener listener) {
        this.mContext = mContext;
        this.crewCode = crewCode;
        this.workDate = workDate;
        this.jobCode = jobCode;
        this.seqNo = seqNo;
        this.mListener = listener;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.preDeleteTimesheet();
        }
    }

    @Override
    protected Boolean doInBackground(Void... params) {
        if (!isCancelled()) {
            RequestCall requestCall = new RequestCall(mContext);
            String response = requestCall.deleteTimesheet(mContext, crewCode, workDate, jobCode);
            if (response.equalsIgnoreCase(seqNo))
                return true;
            else
                return false;
        }
        else
            return false;
    }

    @Override
    protected void onPostExecute(Boolean status) {
        super.onPostExecute(status);
        if (!isCancelled())
            mListener.postDeleteTimesheet(status);
    }
}
