package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetPhaseTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.JobDataTask2;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.PciTask;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CategoryTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PciInterface;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PhaseInterface;
import com.example.ishanjaiswal.cmicresultactivity.Model.ConfigMode;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseWithChild;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;
import com.example.ishanjaiswal.cmicresultactivity.Utils.StringUtil;
import com.example.ishanjaiswal.cmicresultactivity.Utils.SubmitStatus;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityCategoryListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityJobListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityPciListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ActivityPhaseListAdapter;
import com.example.ishanjaiswal.cmicresultactivity.adapters.ProjectListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 6/11/2018.
 */

public class AdvancedModeDialogFragment extends DialogFragment {

    public interface AdvancedModeDialogListener{
        void showProgressDialog(String message);
        void hideProgressDialog();
        void makeErrorAlert(String message);
        void insertTimeSheetInDatabase(CrewTimeSheet crewTimeSheet);
    }

    private Context mContext;
    private AdvancedModeDialogListener mListener;
    private String mActivityName;
    private int mActivityClickedPosition;
    private SharedPreferences sharedPreferences;
    private IshanDBHelper dbHelper;

    private RelativeLayout relativeComp,relativeJob, relativePhase, relativeCategory, relativePci, r1 , r2;
    private TextView tvComp, tvJob ,tvPhase, tvCategory, tvPciCode, arrowimgComp, arrowimgjob, arrowimgphase, arrowimgcategory, arrowimgpci, imgcross, imgbtnback;
    private ImageButton normalHours;
    private Button btndone;
    private ListView listview;
    private EditText etsearch;

    private CrewTimeSheet mCrewTimeSheet;
    private int normalTimeFromSettings, overTimeFromSettings;
    String clickedPhaseCode, clickedProjectCode, clickedCategoryCode, clickedCompCode, clickedJobCode, clickedPciCode;
    String clickedPhaseName, clickedProjectName, clickedCategoryName, selectedProjectName, selectedProjectCode, selectedProjectCompCode;
    ArrayList<JobData> jobDataForPopup;
    ActivityJobListAdapter activityJobListAdapter;
    ArrayList<PhaseModal> phaseModals;
    ActivityPhaseListAdapter activityPhaseListAdapter;
    ActivityCategoryListAdapter activityCategoryListAdapter;
    ActivityPciListAdapter activityPciListAdapter;
    ArrayList<PciModal> pciModals = null;
    private ConfigMode mConfigMode;

    public void setListener(AdvancedModeDialogListener mListener) {
        this.mListener = mListener;
    }

    public void setmActivityClickedPosition(int mActivityClickedPosition) {
        this.mActivityClickedPosition = mActivityClickedPosition;
    }

    public void setCrewTimesheet(CrewTimeSheet crewTimesheet){
        this.mCrewTimeSheet = crewTimesheet;
    }

    public void setConfigMode(ConfigMode mConfigMode) {
        this.mConfigMode = mConfigMode;
    }

    public static AdvancedModeDialogFragment newInstance(AdvancedModeDialogListener listener, CrewTimeSheet crewTimeSheet, int activityPosition, ConfigMode configMode){
        AdvancedModeDialogFragment fragment = new AdvancedModeDialogFragment();
        fragment.setListener(listener);
        fragment.setCrewTimesheet(crewTimeSheet);
        fragment.setmActivityClickedPosition(activityPosition);
        fragment.setConfigMode(configMode);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        return  inflater.inflate(R.layout.activity_popup,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getValuesFromSharedPref();
        initView(view);
    }

    public void onResume()
    {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout(getResources().getDimensionPixelSize(R.dimen.dialog_advanced_mode_width),
                getResources().getDimensionPixelSize(R.dimen.dialog_advanced_mode_height));
        window.setGravity(Gravity.CENTER);
    }

    private void initView(final View view){
        Typeface typeface = Typeface.createFromAsset(mContext.getAssets(),"fonts/cmic_icons.ttf");
        normalHours = (ImageButton) view.findViewById(R.id.click);
        tvComp = (TextView) view.findViewById(R.id.tv_comp);
        tvJob = (TextView)view.findViewById(R.id.txtjob);
        tvPhase = (TextView)view.findViewById(R.id.txtphase);
        tvCategory = (TextView)view.findViewById(R.id.txtcategory);
        tvPciCode = (TextView)view.findViewById(R.id.txtpci);
        listview = (ListView)view.findViewById(R.id.activity_popup_list_view);
        arrowimgComp = (TextView)view.findViewById(R.id.iv_comp_arrow);
        arrowimgjob = (TextView)view.findViewById(R.id.activity_popup_imageView0);
        arrowimgphase = (TextView)view.findViewById(R.id.activity_popup_imageView1);
        arrowimgcategory = (TextView)view.findViewById(R.id.activity_popup_imageView2);
        arrowimgpci = (TextView)view.findViewById(R.id.activity_popup_imageView3);
        imgcross = (TextView)view.findViewById(R.id.activity_popup_imgcross);
        imgbtnback = (TextView)view.findViewById(R.id.activity_popup_back);
        btndone = (Button)view.findViewById(R.id.activity_popup_done);
        etsearch = (EditText)view.findViewById(R.id.ettxtActivity);
        relativeComp = (RelativeLayout)view.findViewById(R.id.rl_comp);
        relativeJob = (RelativeLayout)view.findViewById(R.id.rljob);
        relativePhase = (RelativeLayout)view.findViewById(R.id.rlphase);
        relativeCategory = (RelativeLayout)view.findViewById(R.id.rlcategory);
        relativePci = (RelativeLayout)view.findViewById(R.id.rlpci);
        r1 = (RelativeLayout)view.findViewById(R.id.activity_popup_relativeLayout1);
        r2 = (RelativeLayout)view.findViewById(R.id.activity_popup_relativeLayout2);
        tvComp.setText(selectedProjectCompCode);
        tvComp.setTextColor(ContextCompat.getColor(mContext, R.color.colorBlack));
        tvJob.setText(selectedProjectName);
        tvJob.setTextColor(ContextCompat.getColor(mContext, R.color.colorBlack));
        arrowimgComp.setTypeface(typeface);
        arrowimgjob.setTypeface(typeface);
        arrowimgcategory.setTypeface(typeface);
        arrowimgphase.setTypeface(typeface);
        arrowimgpci.setTypeface(typeface);
        imgcross.setTypeface(typeface);
        imgbtnback.setTypeface(typeface);
        clickedJobCode = selectedProjectCode;
        clickedCompCode = selectedProjectCompCode;
        if (mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getActivityName().equals("")) {
            etsearch.setHint(mActivityName);
        } else {
            etsearch.setHint(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getActivityName());
        }
        etsearch.setTextColor(Color.rgb(169, 169, 169));
        tvPciCode.setTextColor(Color.BLACK);
        final int[] currentList = {0};
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (currentList[0]) {
                    case 0:
                        final PhaseModal itemAtPosition0 = (PhaseModal) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        clickedPhaseName = itemAtPosition0.getPhaseName();
                        clickedPhaseCode = itemAtPosition0.getPhaseCode();
                        tvPhase.setText(clickedPhaseCode);
                        tvPhase.setTextColor(ContextCompat.getColor(mContext,R.color.colorBlack));
                        break;
                    case 1:
                        final PhaseWithChild itemAtPosition1 = (PhaseWithChild) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        clickedCategoryName = itemAtPosition1.getCatName();
                        clickedCategoryCode = itemAtPosition1.getJcatCode();
                        tvCategory.setText(clickedCategoryCode);
                        tvCategory.setTextColor(ContextCompat.getColor(mContext,R.color.colorBlack));
                        break;
                    case 2:
                        final PciModal itemAtPosition2 = (PciModal) parent.getItemAtPosition(position);
                        clickedPciCode = itemAtPosition2.getPciLineOraseq();
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        tvPciCode.setText(itemAtPosition2.getPciCode());
                        tvPciCode.setTextColor(ContextCompat.getColor(mContext,R.color.colorBlack));
                        break;
                    case 3:
                        final JobData itemAtPosition3 = (JobData) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        clickedCompCode = itemAtPosition3.getJobcompcode();
                        clickedJobCode = itemAtPosition3.getJobcode();
                        tvJob.setText(clickedJobCode);
                        if (mConfigMode.isShowCompany()){
                            tvComp.setText(clickedCompCode);
                            mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setJobCompCode(clickedCompCode);
                        }
                        break;
                }
            }
        });

        if (StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getActivityName())){
            etsearch.setHint("Enter Activity Name");
        } else {
            etsearch.setHint(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getActivityName());
        }

        if (StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getPciLineOraseq())) {
            tvPciCode.setText("Select Pci");
        } else {
            tvPciCode.setText(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getPciLineOraseq());
        }

        if (StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getPhaseName()) || StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getPhaseCode())) {
            tvPhase.setText("Select Phase");
        } else {
            tvPhase.setText(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getPhaseCode());
        }

        if (StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getCatCode()) || StringUtil.isStringNull(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getCategoryName())) {
            tvCategory.setText("Select Category");

        } else {
            tvCategory.setText(mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).getCatCode());
        }


        //search Bar AdvancedModePopUp

        etsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        etsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        //Cross button
        imgcross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        //Back button
        imgbtnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.VISIBLE);
                r2.setVisibility(View.INVISIBLE);
            }
        });
        //normal hours for correesponding activity
        normalHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog normalHoursPopup = new Dialog(mContext);
                normalHoursPopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
                normalHoursPopup.setContentView(R.layout.normal_hours_popup);
                final EditText etsearch = (EditText) normalHoursPopup.findViewById(R.id.ettxtNormalHours);
                TextView tvActivityName = (TextView) normalHoursPopup.findViewById(R.id.activityname);
                TextView normalHoursOk = (TextView) normalHoursPopup.findViewById(R.id.normalhoursok);
                TextView normalHourscancel = (TextView) normalHoursPopup.findViewById(R.id.normalhourscancel);
                tvActivityName.setText(mActivityName);
                normalHoursOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (etsearch.getText().toString().equalsIgnoreCase("") || etsearch.getText().toString().equalsIgnoreCase("null")) {
                        } else {
                            double batchDialogValue = Double.parseDouble(etsearch.getText().toString());
                            for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                                if (batchDialogValue <= normalTimeFromSettings) {
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setStandardTime(batchDialogValue);
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setOverTime(0);
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setDoubleOverTime(0);
                                } else {
                                    double subtractedValue = (Double.valueOf(etsearch.getText().toString())) - normalTimeFromSettings;
                                    if (subtractedValue <= overTimeFromSettings) {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setOverTime(subtractedValue);
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setDoubleOverTime(0);
                                    } else {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setOverTime(Double.valueOf(overTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(mActivityClickedPosition).setDoubleOverTime(batchDialogValue - (normalTimeFromSettings + overTimeFromSettings));
                                    }
                                }
                            }
                            mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                            mListener.insertTimeSheetInDatabase(mCrewTimeSheet);
                        }
                        normalHoursPopup.dismiss();
                        dismiss();
                }});

                normalHourscancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        normalHoursPopup.dismiss();
                    }
                });

                normalHoursPopup.show();
            }
        });

        relativeComp.setEnabled(false);

        relativeJob.setEnabled(mConfigMode.isShowJob());

        relativeJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.GONE);
                r2.setVisibility(View.VISIBLE);
                JobDataTask2 jobDataTask = new JobDataTask2(getContext(), new JobDataListener() {
                    @Override
                    public void beforeJobDataTaskStarted(String displayMessage) {
                        mListener.showProgressDialog("         Fetching Jobs List ...");
                    }

                    @Override
                    public void onJobDataTaskComplete(String response) {
                        Log.d("hurray",response);
                        if (response != null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                            ArrayList<JobData> jobDataList = new ArrayList<>();
                            jobDataList = new JobDataParser().parseJobData(response);
                            ProjectListAdapter jobDataAdapter = new ProjectListAdapter(getActivity(), jobDataList);
                            listview.setAdapter(jobDataAdapter);
                            currentList[0] = 3;
                            mListener.hideProgressDialog();
                        }
                        else {
                            mListener.hideProgressDialog();
                            mListener.makeErrorAlert(response);
                        }
                    }

                    @Override
                    public void onJobDataTaskCancelled() {

                    }
                });
                jobDataTask.execute();
            }
        });

        relativePhase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.GONE);
                r2.setVisibility(View.VISIBLE);
                GetPhaseTask phasewebservice = new GetPhaseTask(mContext, clickedCompCode, clickedJobCode, new PhaseInterface() {
                    @Override
                    public void onTaskComplete(String response) {
                        mListener.hideProgressDialog();
                        if (response != null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                            PhaseWithChildParser phaseWithChildParser = new PhaseWithChildParser();
                            phaseModals = phaseWithChildParser.parsePhaseJsonData(response);
                            ActivityPhaseListAdapter activityJobListAdapter = new ActivityPhaseListAdapter(mContext, phaseModals);
                            listview.setAdapter(activityJobListAdapter);
                            currentList[0] = 0;
                            PhaseWithChildParser phaseWithChildParser1 = new PhaseWithChildParser();
                            ArrayList<PhaseWithChild> categoryList = phaseWithChildParser1.parseCategoryJsonData(response);
                            dbHelper.insertPhaseAndCategory(categoryList);
                        }
                        else
                            mListener.makeErrorAlert(response);
                    }
                    @Override
                    public void onTaskStarted() {
                        mListener.showProgressDialog("         Fetching GetPhaseTask List ...");
                    }

                }, new CategoryTaskListener() {//TODO ISHAN
                    @Override
                    public void onEndCat(String response) {

                    }
                });
                phasewebservice.execute();
                final EditText editTextSearch = (EditText)view.findViewById(R.id.searchphase);
                editTextSearch.setText("");
                editTextSearch.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if (phaseModals != null) {
                            s = s.toString().toLowerCase();
                            Log.d("svalue", (String) s);
                            final ArrayList<PhaseModal> filteredList = new ArrayList<>();
                            for (int i = 0; i < phaseModals.size(); i++) {
                                final String txtPhaseName = phaseModals.get(i).getPhaseName().toLowerCase();
                                final String txtPhaseCode = phaseModals.get(i).getPhaseCode().toLowerCase();
                                if (txtPhaseName.contains(s) || txtPhaseCode.contains(s))
                                    filteredList.add(phaseModals.get(i));
                            }
                            if (activityPhaseListAdapter == null) {
                                activityPhaseListAdapter = new ActivityPhaseListAdapter(mContext, filteredList);
                                listview.setAdapter(activityPhaseListAdapter);
                            } else
                                activityPhaseListAdapter.setList(filteredList);
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });
            }
        });

        //RelativeLayout Category
        relativeCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (tvPhase.getText().equals("Select Phase")) {
                    Toast toast = Toast.makeText(mContext, "    Please select phase    ", Toast.LENGTH_LONG);
                    View toastView = toast.getView();
                    toastView.setBackground(ContextCompat.getDrawable(mContext, R.drawable.toast_background));
                    toast.show();
                } else {
                    r1.setVisibility(View.GONE);
                    r2.setVisibility(View.VISIBLE);
                    final List<PhaseWithChild> categoryList = dbHelper.getCategoryFromPhaseCode(clickedPhaseCode);
                    activityCategoryListAdapter = new ActivityCategoryListAdapter(mContext, categoryList);

                    listview.setAdapter(activityCategoryListAdapter);

                    listview.post(new Runnable() {
                        @Override
                        public void run() {
                            listview.setAdapter(activityCategoryListAdapter);
                        }
                    });
                    currentList[0] = 1;
                    final EditText editTextSearch = (EditText) view.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
//                    final EditText editTextSearch = (EditText) activityPopup.view.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
                    editTextSearch.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            s = s.toString().toLowerCase();
                            Log.d("svalue", (String) s);
                            final List<PhaseWithChild> filteredList = new ArrayList<>();
                            final List<PhaseWithChild> catDetails = categoryList;
                            for (int i = 0; i < catDetails.size(); i++) {
                                final String txtCategoryName = catDetails.get(i).getCatName().toLowerCase();
                                final String txtCategoryCode = catDetails.get(i).getJcatCode().toLowerCase();
                                if (txtCategoryName.contains(s) || txtCategoryCode.contains(s)) {
                                    filteredList.add(catDetails.get(i));
                                }
                            }
                            if (activityCategoryListAdapter == null) {
                                activityCategoryListAdapter = new ActivityCategoryListAdapter(mContext, filteredList);
                                listview.setAdapter(activityCategoryListAdapter);
                            } else {
                                activityCategoryListAdapter.setList(filteredList);
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                        }
                    });
                }
            }
        });

        relativePci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickedPhaseCode == null || clickedCategoryCode == null) {
                    Toast toast = Toast.makeText(mContext, "    Please Select PhaseCode and CategoryCode First  ", Toast.LENGTH_LONG);
                    View toastView = toast.getView();
                    toastView.setBackground(ContextCompat.getDrawable(mContext, R.drawable.toast_background));
                    toast.show();
                } else {
                    r1.setVisibility(View.GONE);
                    r2.setVisibility(View.VISIBLE);

                    PciTask pciTask = new PciTask(mContext, clickedPhaseCode, clickedCategoryCode, selectedProjectCode,
                            clickedCompCode, new PciInterface() {

                        @Override
                        public ArrayList<PciModal> ResultFromPciWebservice(String response) {
                            if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                                mListener.hideProgressDialog();
                                PciParser pciParser = new PciParser();
                                pciModals = pciParser.pciDataParser(response);
                                activityPciListAdapter = new ActivityPciListAdapter(mContext, pciModals);
                                listview.setAdapter(activityPciListAdapter);
                                currentList[0] = 2;
                            }
                            else
                                mListener.makeErrorAlert(response);
                            return pciModals;
                        }

                        @Override
                        public void BeforeCompleted() {
                            mListener.showProgressDialog("         Fetching Pci Data...");
                        }
                    });
                    pciTask.execute();
                    final EditText editTextSearch = (EditText)view.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
                    editTextSearch.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            s = s.toString().toLowerCase();
                            Log.d("svalue", (String) s);
                            final ArrayList<PciModal> filteredList = new ArrayList<>();
                            for (int i = 0; i < pciModals.size(); i++) {
                                final String txtPciName = pciModals.get(i).getPciCode().toLowerCase();
                                final String txtPciCode = pciModals.get(i).getPciName().toLowerCase();
                                if (txtPciName.contains(s) || txtPciCode.contains(s)) {
                                    filteredList.add(pciModals.get(i));
                                }
                            }
                            if (activityPciListAdapter == null) {
                                activityPciListAdapter = new ActivityPciListAdapter(mContext, filteredList);
                                listview.setAdapter(activityPhaseListAdapter);
                            } else {
                                activityPciListAdapter.setList(filteredList);
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                        }
                    });
                }
            }
        });

        btndone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etsearch.getText().toString().equals("")) {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setActivityName("Activity" + mActivityClickedPosition);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setActivityName(etsearch.getText().toString());
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (selectedProjectName == null || selectedProjectName.equalsIgnoreCase("null") || selectedProjectName.equals("")) {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setJobName("");
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setJobName(selectedProjectName);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (clickedPhaseName == null || clickedPhaseName.equalsIgnoreCase("null") || clickedPhaseName.equals("")) {
                    tvPhase.setText("Select Phase");
                    // mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setPhaseName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setPhaseName(clickedPhaseName);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (clickedCategoryName == null || clickedCategoryName.equalsIgnoreCase("null") || clickedCategoryName.equals("")) {
                    tvCategory.setText("Select Category");
                    // mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setCategoryName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setCategoryName(clickedCategoryName);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }

                if (clickedCategoryCode == null || clickedCategoryCode.equalsIgnoreCase("null") || clickedCategoryCode.equals("")) {
                    tvCategory.setText("Select Category");
                    //mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setCatCode("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setCatCode(clickedCategoryCode);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (clickedPhaseCode == null || clickedPhaseCode.equalsIgnoreCase("null") || clickedPhaseCode.equals("")) {
                    tvPhase.setText("Select Phase");
                    //    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setPhaseCode("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setPhaseCode(clickedPhaseCode);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (mActivityName == null || mActivityName.equalsIgnoreCase("null") || mActivityName.equals("")) {
                    tvPhase.setText("Select Phase");
                    // mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setmmActivityName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setActivityName(mActivityName);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (clickedPciCode == null || clickedPciCode.equals("")) {
                    tvPciCode.setText("Select Phase");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(mActivityClickedPosition).setPciLineOraseq(clickedPciCode);
                    mCrewTimeSheet.setSubmitStatus(SubmitStatus.EDITED);
                }
                if (mCrewTimeSheet.getSubmitStatus().equals(SubmitStatus.EDITED))
                    mListener.insertTimeSheetInDatabase(mCrewTimeSheet);
                dismiss();
            }
        });
    }

    private void getValuesFromSharedPref() {
        sharedPreferences = mContext.getSharedPreferences(mContext.getString(R.string.cmic_shared_preference),Context.MODE_PRIVATE);
        selectedProjectCode = sharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_project_code)
                ,mContext.getString(R.string.cmic_shared_preference_no_project_code));
        selectedProjectCompCode = sharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_project_comp_code),
                "NOCOMPCODE");
        selectedProjectName = sharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_project_name)
                ,"NOPROJECTNAME");

        SharedPreferences defaultSharedPref = PreferenceManager.getDefaultSharedPreferences(mContext);
            normalTimeFromSettings = Integer.parseInt(defaultSharedPref.getString(mContext.getString(R.string.settings_key_max_normal_time)
                , mContext.getString(R.string.settings_normal_time_default)));
            overTimeFromSettings = Integer.parseInt(defaultSharedPref.getString(mContext.getString(R.string.settings_key_over_time)
                , mContext.getString(R.string.settings_over_time_default)));
        dbHelper = IshanDBHelper.getInstance(mContext);
    }
}
