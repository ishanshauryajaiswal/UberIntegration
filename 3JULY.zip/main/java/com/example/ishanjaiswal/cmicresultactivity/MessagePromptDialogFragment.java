package com.example.ishanjaiswal.cmicresultactivity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Utils.ScreenUtil;

/**
 * Created by ishan.jaiswal on 5/31/2018.
 */

public class MessagePromptDialogFragment extends DialogFragment {


    private TextView tvMessageContent;
    private TextView tvOk;
    private String messageContent;

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public static MessagePromptDialogFragment newInstance(String messageContent){
        MessagePromptDialogFragment fragment = new MessagePromptDialogFragment();
        fragment.setMessageContent(messageContent);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        return inflater.inflate(R.layout.dialog_messsage_prompt,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout(getResources().getDimensionPixelSize(R.dimen.dialog_message_prompt_width),
                getResources().getDimensionPixelSize(R.dimen.dialog_message_prompt_height));
        window.setGravity(Gravity.CENTER);
    }

    private void initView(View view) {
        tvMessageContent = (TextView) view.findViewById(R.id.tv_message_prompt_dialog_message);
        tvOk = (TextView) view.findViewById(R.id.tv_message_prompt_dialog_ok);
        tvMessageContent.setText(messageContent);
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }
}
