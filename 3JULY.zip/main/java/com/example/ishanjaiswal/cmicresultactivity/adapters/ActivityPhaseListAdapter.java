package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

;

import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by parneet.singh on 2/16/2017.
 */
public class ActivityPhaseListAdapter extends BaseAdapter implements Filterable
{

    private ArrayList<PhaseModal> phaseDetails;
    private Context context;
    private LayoutInflater mInflater;
    private List<PhaseModal>filteredData = null;
    private ItemFilter mFilter = new ItemFilter();
    public ActivityPhaseListAdapter(Context context, ArrayList<PhaseModal> phaseDetails)
    {
        this.context = context;
        this.phaseDetails = phaseDetails;
    }

    @Override
    public int getCount()
    {
        if(phaseDetails!=null)
            return phaseDetails.size();
        return 0;
    }

    @Override
    public PhaseModal getItem(int position)
    {
        return phaseDetails.get(position);
    }
    public  void  setList(ArrayList<PhaseModal> list)
    {
        phaseDetails = list;
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        PhaseModal phaseDetails = getItem(position);
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listViewItem = inflater.inflate(R.layout.activity_phase_details, null);
        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtPhaseDetails);
       // final EditText search =(EditText) listViewItem.findViewById(R.id.search);
      /*  search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setFocusableInTouchMode(true);
                search.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        context.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);

            }
        });*/
        txt_project.setText("("+phaseDetails.getPhaseCode() +") - "+ phaseDetails.getPhaseName());
        return listViewItem;
    }



    @Override
    public Filter getFilter()
    {
        return mFilter;
    }

    // Searching On basis of every property Of PhaseDetails
    private class ItemFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterString = constraint.toString().toLowerCase();
            FilterResults results = new FilterResults();
            final List<PhaseModal> list = phaseDetails;
            int count = list.size();
            final ArrayList<PhaseModal> nlist = new ArrayList<PhaseModal>(count);
            PhaseModal phaseModal ;
            for (int i = 0; i < count; i++)
            {
                phaseModal = list.get(i);
                    if (phaseModal.getPhaseCode().equals(filterString)||phaseModal.getPhaseName().equals(filterString))
                    {
                        nlist.add(phaseModal);
                    }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }
        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredData = (ArrayList<PhaseModal>) results.values;
            notifyDataSetChanged();

        }
    }
}
