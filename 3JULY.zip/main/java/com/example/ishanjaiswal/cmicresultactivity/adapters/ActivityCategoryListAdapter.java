package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;


import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CategoryDetails;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseWithChild;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by parneet.singh on 2/16/2017.
 */
public class ActivityCategoryListAdapter extends BaseAdapter implements Filterable
{

    private List<PhaseWithChild> mCategoryList;
    private Context context;
    private LayoutInflater mInflater;
    private List<PhaseModal>filteredData = null;
    private ItemFilter mFilter = new ItemFilter();
    public ActivityCategoryListAdapter(Context context, List<PhaseWithChild> CategoryDetails)
    {
        this.context = context;
        this.mCategoryList = CategoryDetails;
    }

    @Override
    public int getCount()
    {
        if(mCategoryList !=null)
            return mCategoryList.size();
        return 0;
    }
    public  void  setList(List<PhaseWithChild> list)
    {
        mCategoryList = list;
        notifyDataSetChanged();
    }

    @Override
    public PhaseWithChild getItem(int position)
    {
        return mCategoryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        PhaseWithChild category = mCategoryList.get(position);
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listViewItem = inflater.inflate(R.layout.activity_phase_details, null);
        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtPhaseDetails);
        txt_project.setText("("+category.getJcatCode() +") - "+ category.getCatName());
        return listViewItem;
    }



    @Override
    public Filter getFilter()
    {
        return mFilter;
    }

    // Searching On basis of every property Of PhaseDetails
    private class ItemFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterString = constraint.toString().toLowerCase();
            FilterResults results = new FilterResults();
            final List<PhaseWithChild> list = mCategoryList;
            int count = list.size();
            final List<PhaseWithChild> nlist = new ArrayList<>();
            for (int i = 0; i < count; i++)
            {
                PhaseWithChild category = list.get(i);
                if (category.getJcatCode().equals(filterString)||category.getCatName().equals(filterString))
                {
                    nlist.add(category);
                }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }
        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredData = (ArrayList<PhaseModal>) results.values;
            notifyDataSetChanged();

        }
    }
}
