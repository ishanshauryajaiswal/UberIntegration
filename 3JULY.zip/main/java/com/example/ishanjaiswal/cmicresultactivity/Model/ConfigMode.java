package com.example.ishanjaiswal.cmicresultactivity.Model;

public class ConfigMode {

    private boolean showJob;
    private boolean showCompany;

    public ConfigMode() {
        showJob = false;
        showCompany = false;
    }

    public boolean isShowJob() {
        return showJob;
    }

    public void setShowJob(boolean showJob) {
        this.showJob = showJob;
    }

    public boolean isShowCompany() {
        return showCompany;
    }

    public void setShowCompany(boolean showCompany) {
        this.showCompany = showCompany;
    }

}
