package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by shaurya on 21/04/18.
 */

public class Dashboard2 implements Serializable {
    List<AllTimes> timesList;
    String pycrResponsibleEmpOraseq, pycrResponsibleEmpNo, pycrResponsibleEmpName;
    String jobAcsCode, jobCompCode, jobCode;
    String pycrCode, pycrName, empNo, empTrdCode, empTrdName, empFirstName, empLastName;
    AllTimes totalTime;

    public String getPycrResponsibleEmpOraseq() {
        return pycrResponsibleEmpOraseq;
    }

    public void setPycrResponsibleEmpOraseq(String pycrResponsibleEmpOraseq) {
        this.pycrResponsibleEmpOraseq = pycrResponsibleEmpOraseq;
    }

    public String getPycrResponsibleEmpNo() {
        return pycrResponsibleEmpNo;
    }

    public void setPycrResponsibleEmpNo(String pycrResponsibleEmpNo) {
        this.pycrResponsibleEmpNo = pycrResponsibleEmpNo;
    }

    public String getPycrResponsibleEmpName() {
        return pycrResponsibleEmpName;
    }

    public void setPycrResponsibleEmpName(String pycrResponsibleEmpName) {
        this.pycrResponsibleEmpName = pycrResponsibleEmpName;
    }

    public String getJobAcsCode() {
        return jobAcsCode;
    }

    public void setJobAcsCode(String jobAcsCode) {
        this.jobAcsCode = jobAcsCode;
    }

    public String getJobCompCode() {
        return jobCompCode;
    }

    public void setJobCompCode(String jobCompCode) {
        this.jobCompCode = jobCompCode;
    }

    public String getJobCode() {
        return jobCode;
    }

    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    public String getPycrCode() {
        return pycrCode;
    }

    public void setPycrCode(String pycrCode) {
        this.pycrCode = pycrCode;
    }

    public String getPycrName() {
        return pycrName;
    }

    public void setPycrName(String pycrName) {
        this.pycrName = pycrName;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getEmpTrdCode() {
        return empTrdCode;
    }

    public void setEmpTrdCode(String empTrdCode) {
        this.empTrdCode = empTrdCode;
    }

    public String getEmpTrdName() {
        return empTrdName;
    }

    public void setEmpTrdName(String empTrdName) {
        this.empTrdName = empTrdName;
    }

    public String getEmpFirstName() {
        return empFirstName;
    }

    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    public String getEmpLastName() {
        return empLastName;
    }

    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    public AllTimes getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(AllTimes totalTime) {
        this.totalTime = totalTime;
    }

    public String getCrewMemberName() {
        return empFirstName.concat(" ").concat(empLastName);
    }

    public List<AllTimes> getTimesList() {
        return timesList;
    }

    public void setTimesList(List<AllTimes> timesList) {
        this.timesList = timesList;
    }
}
