package com.example.ishanjaiswal.cmicresultactivity.Utils;

/**
 * Created by ishan.jaiswal on 5/4/2018.
 */

public enum SubmitStatus {
    SUCCESS,
    FAILURE,
    EDITED,
    NOT_SUBMITTED
}
