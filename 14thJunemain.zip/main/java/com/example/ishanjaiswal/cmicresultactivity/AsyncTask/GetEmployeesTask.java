package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CrewMemberDataListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

public class GetEmployeesTask extends AsyncTask<Void,Void,String>
{
    private Context context;
    private CrewMemberDataListener employeeListener;
    public GetEmployeesTask(Context context, CrewMemberDataListener employeeListener){
        this.employeeListener=employeeListener;
        this.context=context;
    }

    @Override
    protected void onPreExecute()
    {
       employeeListener.onCrewMemberDataTaskStarted();
    }
    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall(context);
            response = requestCall.getAllEmployees(context);
        }
        catch (Exception e)
        {
            Log.d("error1234567", e.toString());
        }
        return response;
    }
    @Override
    protected void onPostExecute(String result)
    {
        employeeListener.onCrewMemberDataTaskCompleted(result);
    }
}
