package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
 * Created by ishan.jaiswal on 4/23/2018.
 */

public interface RecyclerViewClickListener {
    void onRecyclerViewRowClicked(String crewCode, String crewName, int week);
    void onRecyclerViewDashboard2RowClicked(String empNumber, String empName);
}
