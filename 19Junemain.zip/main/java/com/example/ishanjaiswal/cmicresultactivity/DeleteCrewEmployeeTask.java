package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

/**
 * Created by ishan.jaiswal on 3/12/2018.
 */

public class DeleteCrewEmployeeTask extends AsyncTask<Void,Void, String> {

    public interface DeleteCrewEmployeeInterface{
        public void preTask();
        public void postTask(String response);
    }
    private Context mContext;
    private DeleteCrewEmployeeInterface deleteCrewEmployeeInterface;
    private String mPyceOraSeq;

    public DeleteCrewEmployeeTask(Context mContext, String mPyceOraSeq, DeleteCrewEmployeeInterface deleteCrewEmployeeInterface) {
        this.mContext = mContext;
        this.deleteCrewEmployeeInterface = deleteCrewEmployeeInterface;
        this.mPyceOraSeq = mPyceOraSeq;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        deleteCrewEmployeeInterface.preTask();
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall(mContext);
            response = requestCall.deleteCrewMember(mContext, mPyceOraSeq);
            Log.d("DeleteEmployeeInCrew ", response);
        }
        catch (Exception e)
        {
            Log.d("Error Delete Employee",e.toString());
        }
        return response;
    }

    @Override
    protected void onPostExecute(String response) {
        super.onPostExecute(response);
        deleteCrewEmployeeInterface.postTask(response);
    }
}
