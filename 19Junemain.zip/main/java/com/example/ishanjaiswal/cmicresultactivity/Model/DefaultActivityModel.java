package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 6/6/2018.
 */

public class DefaultActivityModel {


    String selectedCrewCode, selectedJobCode;
}
