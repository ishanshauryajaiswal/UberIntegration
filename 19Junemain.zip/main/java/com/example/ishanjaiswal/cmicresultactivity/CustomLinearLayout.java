package com.example.ishanjaiswal.cmicresultactivity;

import android.widget.LinearLayout;

/**
 * Created by ishan.jaiswal on 1/31/2018.
 */

public class CustomLinearLayout {

    public CustomLinearLayout(LinearLayout customCell) {



    }
}
