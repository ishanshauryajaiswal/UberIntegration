package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CustomClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.MyListner;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 1/30/2018.
 */

public class RvStaticAdapter extends RecyclerView.Adapter<RvStaticAdapter.ViewHolder> {
    private static final int viewSpacing = 3;
    private ArrayList<EmployeeDataForCrew> mList;
    private Context mContext;
    CustomClickListener customClickListener;
    private boolean timeInOutMode;
    private static final int smallTextWidth = 60;
    private static final int smallTextWidthLast = 59;
    private static final int layoutWidth = 180;

    public void setCustomClickListener(CustomClickListener customClickListener) {
        this.customClickListener = customClickListener;
    }

    public RvStaticAdapter(ArrayList<EmployeeDataForCrew> mList, Context mContext, boolean timeInOutMode) {
        this.mList = mList;
        this.mContext = mContext;
        this.timeInOutMode = timeInOutMode;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout ll = new LinearLayout(mContext);
        int width;
        if (timeInOutMode)
            width = layoutWidth*3;
        else
            width = layoutWidth*2;
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(dpToPx(width), RecyclerView.LayoutParams.WRAP_CONTENT);
        ll.setLayoutParams(layoutParams);
        return new ViewHolder(ll, mContext,width);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        EmployeeDataForCrew employeeDataForCrew = mList.get(position);
        holder.crewMemberName.setText(employeeDataForCrew.getEmpName());
        holder.crewMemberCode.setText("("+employeeDataForCrew.getTradeCode()+")-"+employeeDataForCrew.getTradeName());
        double regTime = employeeDataForCrew.getTotalRtHour();
        double otTime  = employeeDataForCrew.getTotalOtHour();
        double dotTime = employeeDataForCrew.getTotalDotHour();
        if (regTime>0)
            holder.regValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        if (otTime>0)
            holder.otValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        if (dotTime>0)
            holder.dotValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        holder.regValue.setText(regTime + "");
        holder.otValue.setText(otTime + "");
        holder.dotValue.setText(dotTime + "");
        if (employeeDataForCrew.getTimeInOuts() == null)
            holder.totalTime.setText("0.0");
        else {
            if (employeeDataForCrew.getTotalTimeInOut()>0)
                holder.totalTime.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            holder.totalTime.setText(String.valueOf(String.format("%.2f", employeeDataForCrew.getTotalTimeInOut())));
        }
        if (!timeInOutMode) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(360),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))));
            //holder.linearLayoutRow.setLayoutParams(params);
            holder.totalTime.setVisibility(View.GONE);
        }

        holder.linearLayoutCrewMember.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                customClickListener.crewMemberLongClicked(v,position);
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(ArrayList<EmployeeDataForCrew> mList) {
        this.mList = mList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView crewMemberName,crewMemberCode, dotImage, regValue, otValue, dotValue, totalTime;
        LinearLayout linearLayoutRow, linearLayoutCrewMember;
        Context mContext;
        MyListner myListner;
        Typeface tf;
        void setMyListner(MyListner myListner){
            this.myListner = myListner;
        }

        public ViewHolder(View itemView, Context mContext, int width) {
            super(itemView);
            this.mContext = mContext;
            tf = Typeface.createFromAsset(mContext.getAssets(),"fonts/cmic_icons.ttf");
            //linearLayout: Main Linear Layout Containing 2 TextViews and 1 LinearLayout
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(width),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))));
            LinearLayout linearLayout = (LinearLayout) itemView;
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setLayoutParams(params);
            linearLayout.removeAllViews();

            LinearLayout.LayoutParams tvParams = new TableRow.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))), 1f);
            LinearLayout.LayoutParams crewMemberTvParams = new TableRow.LayoutParams(dpToPx(179),0, 1f);
            LinearLayout.LayoutParams crewMemberParams = new LinearLayout.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))),1f);


            linearLayoutCrewMember = new LinearLayout(mContext);
            linearLayoutCrewMember.setOrientation(LinearLayout.VERTICAL);
            linearLayoutCrewMember.setLayoutParams(crewMemberParams);
            linearLayoutCrewMember.setGravity(Gravity.CENTER);
            //linearLayoutCrewMember.setPadding(0, viewSpacing, 0, 0);
            linearLayoutCrewMember.removeAllViews();


            crewMemberName = new TextView(mContext);
            crewMemberName.setLayoutParams(crewMemberTvParams);
            crewMemberName.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            crewMemberName.setTextSize(16);
            crewMemberName.setSingleLine(true);
            crewMemberName.setMaxLines(1);
            crewMemberName.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            crewMemberName.setGravity(Gravity.LEFT);
            crewMemberName.setPadding(10,5,0,0);
            crewMemberName.setEllipsize(TextUtils.TruncateAt.END);
            crewMemberName.setTextColor(Color.BLACK);

            crewMemberCode = new TextView(mContext);
            crewMemberCode.setLayoutParams(crewMemberTvParams);
            crewMemberCode.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            crewMemberCode.setSingleLine(true);
            crewMemberCode.setEllipsize(TextUtils.TruncateAt.END);
            crewMemberCode.setMaxLines(1);
            crewMemberCode.setGravity(Gravity.LEFT);
            crewMemberCode.setTextColor(Color.BLACK);
            crewMemberCode.setPadding(10, 5, 10, 0);

            dotImage = new TextView(mContext);
            dotImage.setLayoutParams(crewMemberTvParams);
            dotImage.setPadding(0, 10, 10, 0);
            dotImage.setText("\uE612");
            dotImage.setTypeface(tf);
            dotImage.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            dotImage.setGravity(Gravity.RIGHT);
            dotImage.setGravity(Gravity.BOTTOM);
            dotImage.setTextColor(Color.rgb(23, 128, 251));
            dotImage.setTextSize(20);
            dotImage.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);


            linearLayoutCrewMember.addView(crewMemberName);
            linearLayoutCrewMember.addView(crewMemberCode);
            linearLayoutCrewMember.addView(dotImage);
            linearLayout.addView(linearLayoutCrewMember);

            //linearLayoutRow: Inner Linear Layout Containing 3 TextViews of the 3 Values
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))),1f);
            linearLayoutRow = new LinearLayout(mContext);
            linearLayoutRow.setOrientation(LinearLayout.HORIZONTAL);
            linearLayoutRow.setLayoutParams(rowParams);
            linearLayoutRow.removeAllViews();
            linearLayoutRow.setGravity(1);
            //linearLayoutRow.setPadding(0, viewSpacing, 0, 0);

            regValue = new TextView(mContext);
            regValue.setLayoutParams(tvParams);
            regValue.setGravity(Gravity.CENTER);
            regValue.setTextColor(Color.BLACK);
            regValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));


            otValue = new TextView(mContext);
            otValue.setLayoutParams(tvParams);
            otValue.setGravity(Gravity.CENTER);
            otValue.setTextColor(Color.BLACK);
            otValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            dotValue = new TextView(mContext);
            dotValue.setLayoutParams(tvParams);
            dotValue.setGravity(Gravity.CENTER);
            dotValue.setTextColor(Color.BLACK);
            dotValue.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));

            linearLayoutRow.addView(regValue); linearLayoutRow.addView(otValue); linearLayoutRow.addView(dotValue);
            linearLayout.addView(linearLayoutRow);

            totalTime = new TextView(mContext);
            totalTime.setLayoutParams(tvParams);
            totalTime.setGravity(Gravity.CENTER);
            totalTime.setTextColor(Color.BLACK);
            totalTime.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            totalTime.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            //totalTime.setPadding(0, viewSpacing, 0, 0);
            linearLayout.addView(totalTime);
            linearLayout.setPadding(0, viewSpacing, 0, 0);

        }

        public int dpToPx(int dp) {
            DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
            return Math.round(dp * displayMetrics.density+0.5f);
        }
    }

    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density+0.5f);
    }
}