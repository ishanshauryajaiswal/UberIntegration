package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/1/2018.
 */
import org.greenrobot.eventbus.EventBus;

public class GlobalBus {
    private static EventBus sBus;
    public static EventBus getBus() {
        if (sBus == null)
            sBus = EventBus.getDefault();
        return sBus;
    }
}
