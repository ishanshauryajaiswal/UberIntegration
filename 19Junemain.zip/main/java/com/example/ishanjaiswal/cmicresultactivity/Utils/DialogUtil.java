package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.content.ContextCompat;

import com.example.ishanjaiswal.cmicresultactivity.R;

/**
 * Created by ishan.jaiswal on 5/30/2018.
 */

public class DialogUtil {

    public static void makeAlertErrorOccurred(Context context, String errorMessage){
        AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
        alertBox.setTitle(context.getString(R.string.app_name));
        if (errorMessage!=null)
            alertBox.setMessage(errorMessage);
        else
            alertBox.setMessage("Some Error Occurred");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            }
        });
        alertBox.show();
    }

    public static ProgressDialog showProgressDialog(ProgressDialog progressDialog, String message, Context context){
        if (progressDialog != null){
            progressDialog.dismiss();
        }
        return ProgressDialog.show(context, context.getString(R.string.app_name), message);
    }

    public static void dismissProgressDialog(ProgressDialog progressDialog){
        if (progressDialog!=null)
            progressDialog.dismiss();
    }
}
