package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.content.Context;
import android.util.DisplayMetrics;

/**
 * Created by ishan.jaiswal on 5/30/2018.
 */

public class ScreenUtil {

    public static int dpToPx(Context context,int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density + 0.5f);
    }

    public static int dpToPx(Context context, float dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density + 0.5f);
    }
}
