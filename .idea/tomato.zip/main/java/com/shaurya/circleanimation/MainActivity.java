package com.shaurya.circleanimation;

import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etName, etId;
    CheckBox dealFood, dealDrinks;
    Button spank;
    boolean food = false, drinks = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    private void initViews() {
        etName = findViewById(R.id.et_name);
        etId = findViewById(R.id.et_id);
        dealFood = findViewById(R.id.cb_food);
        dealDrinks = findViewById(R.id.cb_drinks);
        spank = findViewById(R.id.btn_spank);

        dealFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dealFood.setChecked(true);
                food = true;
                drinks = !food;
                dealDrinks.setChecked(false);
            }
        });

        dealDrinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dealDrinks.setChecked(true);
                drinks = true;
                food = !drinks;
                dealFood.setChecked(false);
            }
        });

        spank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard(MainActivity.this);
                if (validateInput()){
                    Details.RESTAURANT_NAME = etName.getText().toString();
                    Details.VISIT_ID = etId.getText().toString();
                    if (food)
                        Details.DEAL ="Please show this to your server and enjoy 1 + 1 on any dish on the menu";
                    else
                        Details.DEAL = "Please show this to your server and enjoy 2 + 2 on any drink on the menu";
                    startActivity(new Intent(MainActivity.this, GoldActivity.class));
                }
            }
        });

    }

    private boolean validateInput(){

        String name = etName.getText().toString();
        String id = etId.getText().toString();
        boolean flag = true;
        if (TextUtils.isEmpty(name)){
            flag = false;
            showSnackbar("Feed me Outlet Name you  IDIOT");
        }
        else if (TextUtils.isEmpty(id)){
            flag = false;
            showSnackbar("Feed me Visit ID  CHUTIYE");
        }
        else if(food == drinks){
            flag = false;
            showSnackbar("Select a Deal  PAPPU");
        }
        else
            flag = true;
        return flag;
    }

    private void showSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT).show();
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
