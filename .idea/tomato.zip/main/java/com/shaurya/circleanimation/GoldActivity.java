package com.shaurya.circleanimation;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class GoldActivity extends AppCompatActivity{

    ImageView imageView;
    Animation expand,shrink;

    TextView tvName, tvId, tvDeal;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gold);
        Toolbar toolbar = findViewById(R.id.collapsing_toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null)
        {
            // Display home menu item.
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        // Set collapsing tool bar title.
        CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout)findViewById(R.id.collapsing_toolbar_layout);
        collapsingToolbarLayout.setTitle("");

        // Set collapsing tool bar image.
        ImageView collapsingToolbarImageView = (ImageView)findViewById(R.id.collapsing_toolbar_image_view);
        collapsingToolbarImageView.setImageResource(R.drawable.image);

        initViews();
    }



    private void initViews() {
        imageView = findViewById(R.id.iv);
        expand = AnimationUtils.loadAnimation(this, R.anim.scale_up);
        expand.setAnimationListener(animationListenerExpand);
        shrink = AnimationUtils.loadAnimation(this, R.anim.scale_down);
        shrink.setAnimationListener(animationListenerShrink);
        imageView.startAnimation(expand);

        tvName = findViewById(R.id.tv_restaurant_name);
        tvId = findViewById(R.id.tv_visit_id);
        tvDeal = findViewById(R.id.tv_deal);

        tvName.setText(Details.RESTAURANT_NAME);
        tvId.setText(Details.VISIT_ID);
        tvDeal.setText(Details.DEAL);
    }




    private Animation.AnimationListener animationListenerExpand = new Animation.AnimationListener() {
        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {
            imageView.startAnimation(shrink);
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    };

    private Animation.AnimationListener animationListenerShrink = new Animation.AnimationListener() {
        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {
            imageView.startAnimation(expand);
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    };
}
