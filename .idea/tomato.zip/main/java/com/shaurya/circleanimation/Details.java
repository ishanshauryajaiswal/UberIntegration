package com.shaurya.circleanimation;

public class Details {

    public static String RESTAURANT_NAME;

    public static String VISIT_ID;

    public static String TIME;

    public static String DATE;

    public static String DAY;

    public static String DEAL;

}
