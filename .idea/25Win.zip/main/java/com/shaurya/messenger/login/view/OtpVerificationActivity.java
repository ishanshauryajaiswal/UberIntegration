package com.shaurya.messenger.login.view;


import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.ActivityOtpVerificationBinding;
import com.shaurya.messenger.home.view.HomeActivity;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.util.InputValidationUtil;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;
import com.shaurya.messenger.util.StringConstants;

import java.util.concurrent.TimeUnit;



public class OtpVerificationActivity extends AppCompatActivity {

    private static final String TAG = OtpVerificationActivity.class.getSimpleName();
    private static final String COUNTRY_CODE = "+91";

    private EditText etPhone, etOtp;
    private RelativeLayout rlBottom;

    private boolean mVerificationInProgress = false;
    private String mVerificationId = "";
    private String mPhoneNumber = "";

    private LoginVM mLoginViewModel;
    private ActivityOtpVerificationBinding mBinding;

    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;



    private void setUpPhoneVerificationCallback(){
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity),"Verification Successful");
                mVerificationInProgress = false;
                signInWithPhoneAuthCredential(credential);
                //mLoginViewModel.registerUserPhoneVerification();
                Log.d(TAG, "onVerificationCompleted:" + credential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                mVerificationInProgress = false;
                Log.w(TAG, "onVerificationFailed", e);
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);

                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity),"Invalid phone number.");
                } else if (e instanceof FirebaseTooManyRequestsException) {
                    // The SMS quota for the project has been exceeded
                    SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity),"Max Requests Quota Exceeded");
                }

            }

            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:" + verificationId);

                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                rlBottom.setVisibility(View.VISIBLE);


                SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity),"Verification Code Sent");

                mVerificationId = verificationId;
                mResendToken = token;
            }
        };
    }

    private void startPhoneNumberVerification(String phoneNumber) {
        // [START start_phone_auth]
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);

        mVerificationInProgress = true;
    }

    private void resendVerificationCode(String phoneNumber,
                                        PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks,         // OnVerificationStateChangedCallbacks
                token);             // ForceResendingToken from callbacks
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);

        mLoginViewModel = ViewModelProviders.of(this).get(LoginVM.class);

        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_otp_verification);

        mBinding.setLoginViewModel(mLoginViewModel.mLoginModel);

        if (savedInstanceState != null) {
            onRestoreInstanceState(savedInstanceState);
        }


        initViews();

        setUpPhoneVerificationCallback();

        setUpObservers();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mVerificationInProgress)
            startPhoneNumberVerification(mPhoneNumber);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_VERIFY_IN_PROGRESS, mVerificationInProgress);
        if (mPhoneNumber.length()>0)
            outState.putString(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_PHONE_NUMBER, mPhoneNumber);
        if (mVerificationId.length()>0)
            outState.putString(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_VERIFICATION_ID, mVerificationId);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mVerificationInProgress = savedInstanceState.getBoolean(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_VERIFY_IN_PROGRESS);
        mPhoneNumber = savedInstanceState.getString(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_PHONE_NUMBER);
        mVerificationId = savedInstanceState.getString(StringConstants.KEY_BUNDLE_OTP_ACTIVITY_VERIFICATION_ID);
    }


    private void initViews() {

        etPhone = findViewById(R.id.et_otp_phone);
        etOtp = findViewById(R.id.et_otp);
        rlBottom = findViewById(R.id.rl_otp_bottom);

        findViewById(R.id.btn_otp_send_otp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = etPhone.getText().toString();

                String validation = InputValidationUtil.validatePhone(phone);

                if (validation.equalsIgnoreCase(StringConstants.INPUT_VALID)){
                    mPhoneNumber = phone;
                     mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                     startPhoneNumberVerification(mPhoneNumber = COUNTRY_CODE.concat(mPhoneNumber));
                }
                else
                    SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity), validation);
            }
        });

        findViewById(R.id.tv_otp_resend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                resendVerificationCode(mPhoneNumber, mResendToken);
                //SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity), "Under Development");
            }
        });

        findViewById(R.id.btn_otp_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otp = etOtp.getText().toString();

                String validation = InputValidationUtil.validateOTP(otp);

                if (validation.equalsIgnoreCase(StringConstants.INPUT_VALID)) {
                    mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, otp);
                    signInWithPhoneAuthCredential(credential);
                }
                else
                    SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity), validation);
            }
        });
    }

    private void setUpObservers(){
        mLoginViewModel.getmSnackbarTextForOtpVerificationActivity().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(String snackbarMessage) {
                SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity), snackbarMessage);
            }
        });

        mLoginViewModel.getNavigateToHomeActivity().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                startActivity(new Intent(OtpVerificationActivity.this, HomeActivity.class));
                finish();
            }
        });


    }

    private void hideKeyboard(){
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow((null == getCurrentFocus()) ? null : getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.getCurrentUser().linkWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                        if (task.isSuccessful()) {
                            Log.d(TAG, "signInWithCredential:success");
                            mLoginViewModel.registerUserPhoneVerification();

                        } else {
                            // Sign in failed, display a message and update the UI
                            SnackbarUtils.showSnackbar(findViewById(R.id.content_otp_verification_activity), task.getException().getMessage());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                Log.w(TAG, "signInWithCredential:failure", task.getException());
                            }
                        }
                    }
                });
    }
}
