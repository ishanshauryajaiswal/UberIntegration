package com.shaurya.messenger.on_boarding.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.shaurya.messenger.R;
import com.shaurya.messenger.on_boarding.model.pojo.Interest;

import java.util.List;

public class RvInterestAdapter  extends RecyclerView.Adapter<RvInterestAdapter.ViewHolder> {

    private List<Interest> mList;



    @NonNull
    @Override
    public RvInterestAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.cell_recycler_view_interests, parent, false);

        // Return a new holder instance
        return new ViewHolder(contactView);
    }

    @Override
    public void onBindViewHolder(@NonNull RvInterestAdapter.ViewHolder holder, int position) {
        Interest interest = mList.get(position);
        holder.tvInterestName.setText(interest.getInterestTitle());

        holder.rlContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rlContent;
        TextView tvInterestName;

        public ViewHolder(View itemView) {
            super(itemView);
            rlContent = itemView.findViewById(R.id.rv_interest);
            tvInterestName = itemView.findViewById(R.id.tv_interest_name);
        }
    }
}
