package com.shaurya.messenger.on_boarding.viewmodel;

import android.databinding.BaseObservable;

import com.shaurya.messenger.BR;

public class UserTypeModel extends BaseObservable{

    private boolean progressBarVisibility;

    public boolean isProgressBarVisibility() {
        return progressBarVisibility;
    }

    public void setProgressBarVisibility(boolean progressBarVisibility) {
        this.progressBarVisibility = progressBarVisibility;
        notifyPropertyChanged(BR._all);
    }
}
