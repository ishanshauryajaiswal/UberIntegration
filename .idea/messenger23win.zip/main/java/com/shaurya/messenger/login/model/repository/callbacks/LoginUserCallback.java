package com.shaurya.messenger.login.model.repository.callbacks;

public interface LoginUserCallback {

    void Success();

    void Failure(String errorMessage);
}
