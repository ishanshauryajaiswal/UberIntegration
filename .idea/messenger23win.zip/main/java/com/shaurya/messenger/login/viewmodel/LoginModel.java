package com.shaurya.messenger.login.viewmodel;

import android.databinding.BaseObservable;

import com.shaurya.messenger.BR;

public class LoginModel extends BaseObservable {

    private boolean loginProgressBarVisibility;

    public LoginModel(){
        loginProgressBarVisibility = false;
    }

    public boolean isLoginProgressBarVisibility() {
        return loginProgressBarVisibility;
    }

    public void setLoginProgressBarVisibility(boolean loginProgressBarVisibility) {
        this.loginProgressBarVisibility = loginProgressBarVisibility;
        notifyPropertyChanged(BR._all);
    }
}
