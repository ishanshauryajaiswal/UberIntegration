package com.shaurya.messenger.login.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.ActivityLoginBinding;
import com.shaurya.messenger.home.view.HomeActivity;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.on_boarding.view.OnBoardingActivity;
import com.shaurya.messenger.util.SnackbarUtils;


public class LoginActivity extends AppCompatActivity {

    private static final String TAG = LoginActivity.class.getSimpleName();

    private static final int RC_SIGN_IN = 9001;

    private LoginButton btnFacebook;

    private LoginVM mLoginViewModel;
    private ActivityLoginBinding mBinding;

    private CallbackManager callbackManager;
    private GoogleSignInClient mGoogleSignInClient;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, "onCreate");

        setUpViewModel();

        setUpBinding();

        initViews();

        setUpObservers();

        if (savedInstanceState == null) {
            mLoginViewModel.setNavigateToLoginFragment();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(LoginActivity.this, gso);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void setUpViewModel() {
        mLoginViewModel = ViewModelProviders.of(this).get(LoginVM.class);
    }

    private void setUpBinding(){
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_login);
        mBinding.setLoginViewModel(mLoginViewModel.mLoginModel);
    }

    private void initViews(){

        btnFacebook = findViewById(R.id.login_button);


        //Facebook Login
        btnFacebook.setReadPermissions("email", "public_profile");
        callbackManager = CallbackManager.Factory.create();
        btnFacebook.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d(TAG, "facebook:onSuccess:" + loginResult);
                mLoginViewModel.loginUserFacebook(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                SnackbarUtils.showSnackbar(findViewById(R.id.content_login_activity),getString(R.string.some_error_occured));
                Log.d(TAG, "facebook:onCancel");
            }

            @Override
            public void onError(FacebookException error) {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                SnackbarUtils.showSnackbar(findViewById(R.id.content_login_activity),getString(R.string.some_error_occured));
                Log.d(TAG, "facebook:onError", error);
            }
        });

        findViewById(R.id.btn_login_facebook).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                btnFacebook.performClick();
            }
        });

        findViewById(R.id.btn_login_google).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });
    }

    private void setUpObservers() {

        mLoginViewModel.getNavigateToLoginFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction()
                        //.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_right, R.anim.exit_to_left)
                        .setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right,R.anim.enter_from_left, R.anim.exit_to_left)
                        .replace(R.id.login_container, obtainLoginFragment(), LoginFragment.class.getSimpleName())
                        .commit();
            }
        });

        mLoginViewModel.getNavigateToRegisterFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction()
                        //.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_left)
                        .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left)
                        .replace(R.id.login_container, obtainRegisterFragment(), RegisterFragment.class.getSimpleName())
                        .commit();
            }
        });

        mLoginViewModel.getNavigateToForgotPasswordFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left)
                        .replace(R.id.login_container, obtainForgotPasswordFragment(), ForgotPasswordFragment.class.getSimpleName())
                        .commit();
            }
        });

        mLoginViewModel.getNavigateToOnBoardingActivity().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                startActivity(new Intent(LoginActivity.this, OnBoardingActivity.class));
                finish();
            }
        });

        mLoginViewModel.getNavigateToHomeActivity().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                finish();
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Facebook Result
        callbackManager.onActivityResult(requestCode, resultCode, data);

        //Google Result
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                mLoginViewModel.loginUserGoogle(credential);
            } catch (ApiException e) {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                SnackbarUtils.showSnackbar(findViewById(R.id.content_login_activity),getString(R.string.some_error_occured));
                Log.w(TAG, "Google sign in failed", e);
            }
        }
    }

    @NonNull
    private LoginFragment obtainLoginFragment() {
        LoginFragment loginFragment = (LoginFragment) getSupportFragmentManager()
                .findFragmentByTag(LoginFragment.class.getSimpleName());

        if (loginFragment == null) {
            loginFragment = LoginFragment.newInstance();
        }
        return loginFragment;
    }

    @NonNull
    private RegisterFragment obtainRegisterFragment() {
        RegisterFragment registerFragment = (RegisterFragment) getSupportFragmentManager()
                .findFragmentByTag(RegisterFragment.class.getSimpleName());

        if (registerFragment == null) {
            registerFragment = RegisterFragment.newInstance();
        }
        return registerFragment;
    }

    @NonNull
    private ForgotPasswordFragment obtainForgotPasswordFragment() {
        ForgotPasswordFragment forgotPasswordFragment = (ForgotPasswordFragment) getSupportFragmentManager()
                .findFragmentByTag(ForgotPasswordFragment.class.getSimpleName());

        if (forgotPasswordFragment == null) {
            forgotPasswordFragment = ForgotPasswordFragment.newInstance();
        }
        return forgotPasswordFragment;
    }
}
