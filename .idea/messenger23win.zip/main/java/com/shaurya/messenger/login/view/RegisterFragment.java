package com.shaurya.messenger.login.view;


import android.app.Activity;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.FragmentRegisterBinding;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.util.InputValidationUtil;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;
import com.shaurya.messenger.util.StringConstants;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link RegisterFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RegisterFragment extends Fragment {

    private EditText etEmail, etPassword, etConfirmPassword;
    private LoginVM mLoginViewModel;
    private FragmentRegisterBinding mBinding;

    public RegisterFragment() {
    }

    public static RegisterFragment newInstance() {
        RegisterFragment fragment = new RegisterFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);

        mBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_register, container, false);

        mBinding.setLoginViewModel(mLoginViewModel.mLoginModel);

        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);
        initViews(view);
        setUpObservers();
    }

    private void initViews(View view) {

        etEmail = view.findViewById(R.id.et_register_email);
        etPassword = view.findViewById(R.id.et_register_password);
        etConfirmPassword = view.findViewById(R.id.et_register_confirm_password);


        view.findViewById(R.id.btn_register_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String confirmPassword = etConfirmPassword.getText().toString();
                String validation = InputValidationUtil.validateRegistrationCredentials(email, password, confirmPassword);

                if (validation.equalsIgnoreCase(StringConstants.INPUT_VALID)){
                    mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                    mLoginViewModel.registerUser(email, password);
                }
                else {
                    SnackbarUtils.showSnackbar(getView(), validation);
                }
            }
        });

        view.findViewById(R.id.btn_register_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginViewModel.setNavigateToLoginFragment();
            }
        });
    }

    private void setUpObservers(){

        mLoginViewModel.getmSnackbarTextForRegisterFragment().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(String snackbarMessage) {
                SnackbarUtils.showSnackbar(getView(), snackbarMessage);
            }
        });
    }

    private void hideKeyboard(){
        Activity context = getActivity();
        InputMethodManager inputManager = (InputMethodManager)
                context.getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow((null == context.getCurrentFocus()) ? null : context.getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
