package com.shaurya.messenger.login.model.repository.remote;

import android.support.annotation.NonNull;

import com.facebook.AccessToken;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shaurya.messenger.R;
import com.shaurya.messenger.login.model.repository.callbacks.FetchUserInterestCallback;
import com.shaurya.messenger.login.model.repository.callbacks.LoginUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.FetchUserTypeCallback;
import com.shaurya.messenger.login.model.repository.callbacks.RegisterUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.UserConfigurationCallback;
import com.shaurya.messenger.util.StringConstants;

public class LoginRemoteRepository {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;

    public LoginRemoteRepository() {
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS);
    }

    public void loginUser(String email, String password, final LoginUserCallback callback){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else{
                            try{
                                throw task.getException();
                            }

                            catch(FirebaseAuthInvalidCredentialsException e) {
                                callback.Failure("Invalid Credentials");
                            }
                            catch(Exception e) {

                                callback.Failure("Some error Occurred");
                            }
                        }
                    }
                });
    }

    public void loginFacebookUser(AccessToken token, final LoginUserCallback callback){
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else {
                            try{
                                throw task.getException();
                            }
                            catch(FirebaseAuthWeakPasswordException e) {
                                callback.Failure("Week Password");
                            }
                            catch(FirebaseAuthInvalidCredentialsException e) {
                                callback.Failure("Invalid Credentials");
                            }
                            catch(FirebaseAuthUserCollisionException e) {
                                callback.Failure("User exists with this e-mail");
                            }
                            catch(FirebaseAuthException e) {
                                callback.Failure(e.getErrorCode());
                            }
                            catch(Exception e) {
                                callback.Failure("Some error Occurred");
                            }
                        }
                    }
                });
    }

    public void loginGoogleUser(AuthCredential credential, final LoginUserCallback callback){
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            callback.Success();
                        } else {
                            try{
                                throw task.getException();
                            }
                            catch(FirebaseAuthWeakPasswordException e) {
                                callback.Failure("Week Password");
                            }
                            catch(FirebaseAuthInvalidCredentialsException e) {
                                callback.Failure("Invalid Credentials");
                            }
                            catch(FirebaseAuthUserCollisionException e) {
                                callback.Failure("User exists with this e-mail");
                            }
                            catch(FirebaseAuthException e) {
                                callback.Failure(e.getErrorCode());
                            }
                            catch(Exception e) {
                                callback.Failure("Some error Occurred");
                            }
                        }
                    }
                });
    }

    public void registerUser(String email, String password, final RegisterUserCallback callback){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else {
                            try{
                                throw task.getException();
                            }
                            catch(FirebaseAuthWeakPasswordException e) {
                                callback.Failure("Week Password");
                            }
                            catch(FirebaseAuthInvalidCredentialsException e) {
                                callback.Failure("Invalid Credentials");
                            }
                            catch(FirebaseAuthUserCollisionException e) {
                                callback.Failure("User exists with this e-mail");
                            }
                            catch(FirebaseAuthException e) {
                                callback.Failure(e.getErrorCode());
                            }
                            catch(Exception e) {
                                callback.Failure("Some error Occurred");
                            }
                        }
                    }
                });
    }

    public void forgotPassword(String email, final LoginUserCallback callback) {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else {
                            try{
                                throw task.getException();
                            }
                            catch(FirebaseAuthWeakPasswordException e) {
                                callback.Failure("Week Password");
                            }
                            catch(FirebaseAuthInvalidCredentialsException e) {
                                callback.Failure("Invalid Credentials");
                            }
                            catch(FirebaseAuthUserCollisionException e) {
                                callback.Failure("User exists with this e-mail");
                            }
                            catch(FirebaseAuthException e) {
                                callback.Failure(e.getErrorCode());
                            }
                            catch(Exception e) {
                                callback.Failure("Some error Occurred");
                            }
                        }
                    }
                });
    }


    public void getUserConfiguration(String userId, final UserConfigurationCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean valueType = false, valueInterest = false;
                if (dataSnapshot.child(StringConstants.KEY_USERS_TYPE).exists())
                    valueType = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_TYPE).getValue();
                if (dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).exists())
                    valueInterest = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).getValue();
                callback.Success(valueType, valueInterest);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }


    public void isUserTypeRegistered(String userId, final FetchUserTypeCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(StringConstants.KEY_USERS_TYPE).exists()){
                    boolean value = false;
                    value = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_TYPE).getValue();
                    callback.Success(value);
                }
                else
                    callback.Success(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }

    public void isUserInterestsRegistered(String userId, final FetchUserInterestCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).exists()){
                    boolean value = false;
                    value = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).getValue();
                    callback.Success(value);
                }
                else
                    callback.Success(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }


}
