package com.shaurya.messenger.home.model.repository.local;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeLocalRepository {

    private FirebaseAuth mAuth;

    public HomeLocalRepository() {
        mAuth = FirebaseAuth.getInstance();
    }

    public boolean isUserSignedIn(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser!=null)
            Log.e("Firebase Uid",currentUser.getUid());
        return currentUser != null;
    }

    public boolean isUserTypeRegistered() {
        return false;
    }
}
