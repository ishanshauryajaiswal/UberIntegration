package com.shaurya.messenger.home.model.repository.remote;

import com.google.firebase.database.FirebaseDatabase;

public class HomeRemoteRepository {

    private FirebaseDatabase mDatabase;

    public HomeRemoteRepository() {
        mDatabase = FirebaseDatabase.getInstance();
    }

}
