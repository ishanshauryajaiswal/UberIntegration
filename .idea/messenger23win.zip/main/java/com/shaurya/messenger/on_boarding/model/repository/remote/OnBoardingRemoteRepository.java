package com.shaurya.messenger.on_boarding.model.repository.remote;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserInterestsCallback;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserTypeCallback;
import com.shaurya.messenger.util.StringConstants;

import java.util.HashMap;
import java.util.Map;

public class OnBoardingRemoteRepository {

    DatabaseReference mDatabaseReference;

    public OnBoardingRemoteRepository(){
    }

    public void registerUserAsArtist(String userID, final RegisterUserTypeCallback callback){
        mDatabaseReference = FirebaseDatabase.getInstance().getReference()
                .child(StringConstants.TABLE_USERS).child(userID).child(StringConstants.KEY_USERS_TYPE);
        mDatabaseReference.setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }

    public void registerUserAsFan(String userID, final RegisterUserTypeCallback callback){
        mDatabaseReference = FirebaseDatabase.getInstance().getReference()
                .child(StringConstants.TABLE_USERS).child(userID).child(StringConstants.KEY_USERS_TYPE);
        mDatabaseReference.setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }

    public void registerUserInterests(String userID, final RegisterUserInterestsCallback callback){
        mDatabaseReference = FirebaseDatabase.getInstance().getReference()
                .child(StringConstants.TABLE_USERS).child(userID).child(StringConstants.KEY_USERS_INTERESTS);
        mDatabaseReference.setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }
}
