package com.shaurya.messenger.on_boarding.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.shaurya.messenger.R;
import com.shaurya.messenger.home.view.HomeActivity;
import com.shaurya.messenger.on_boarding.viewmodel.OnBoardingVM;


public class OnBoardingActivity extends AppCompatActivity {

    private static final String TAG = OnBoardingActivity.class.getSimpleName();
    private OnBoardingVM mOnBoardingViewModel;

    private Toolbar mToolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding);

        setUpToolbar();

        setUpViewModel();

        setUpObservers();

        if (savedInstanceState == null) {
            mOnBoardingViewModel.configUser();
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void setUpToolbar(){
        mToolbar = findViewById(R.id.app_toolbar);
        setSupportActionBar(mToolbar);
    }

    private void setUpViewModel(){
        mOnBoardingViewModel = ViewModelProviders.of(this).get(OnBoardingVM.class);
    }

    private void setUpObservers() {

        mOnBoardingViewModel.getNavigateToUserTypeFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction().replace(R.id.on_boarding_container,
                        obtainUserTypeFragment(), UserTypeFragment.class.getSimpleName()).commit();
            }
        });

        mOnBoardingViewModel.getNavigateToUserInterestsFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction().replace(R.id.on_boarding_container,
                        obtainUserInterestsFragment(), UserInterestsFragment.class.getSimpleName()).commit();
            }
        });

        mOnBoardingViewModel.getNavigateToHomeActivity().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                startActivity(new Intent(OnBoardingActivity.this, HomeActivity.class));
                finish();
            }
        });
    }

    @NonNull
    private UserTypeFragment obtainUserTypeFragment() {
        UserTypeFragment userTypeFragment = (UserTypeFragment) getSupportFragmentManager()
                .findFragmentByTag(UserTypeFragment.class.getSimpleName());

        if (userTypeFragment == null) {
            userTypeFragment = UserTypeFragment.newInstance();
        }
        return userTypeFragment;
    }

    @NonNull
    private UserInterestsFragment obtainUserInterestsFragment() {
        UserInterestsFragment userInterestsFragment = (UserInterestsFragment) getSupportFragmentManager()
                .findFragmentByTag(UserInterestsFragment.class.getSimpleName());

        if (userInterestsFragment == null) {
            userInterestsFragment = UserInterestsFragment.newInstance();
        }
        return userInterestsFragment;
    }
}
