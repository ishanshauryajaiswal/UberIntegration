package com.shaurya.messenger.on_boarding.model.pojo;

public class User {

    private String id;
    private boolean type;
    private boolean interests;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public boolean isInterests() {
        return interests;
    }

    public void setInterests(boolean interests) {
        this.interests = interests;
    }
}
