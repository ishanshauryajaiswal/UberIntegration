package com.shaurya.messenger.on_boarding.model.pojo;

import com.shaurya.messenger.util.StringConstants;

public enum UserType {
    ARTIST(StringConstants.KEY_USER_TYPE_ARTIST, 1),
    AUDIENCE(StringConstants.KEY_USER_TYPE_AUDIENCE, 2);

    private String stringValue;
    private int intValue;
    private UserType(String toString, int value) {
        stringValue = toString;
        intValue = value;
    }

    @Override
    public String toString() {
        return stringValue;
    }
}
