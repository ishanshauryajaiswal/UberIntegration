package com.shaurya.messenger.on_boarding.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.on_boarding.model.pojo.Interest;
import com.shaurya.messenger.on_boarding.model.pojo.UserType;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserInterestsCallback;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserTypeCallback;
import com.shaurya.messenger.on_boarding.model.repository.local.OnBoardingLocalRepository;
import com.shaurya.messenger.on_boarding.model.repository.remote.OnBoardingRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;

import java.util.List;

public class OnBoardingVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToUserTypeFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToUserInterestsFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToHomeActivity = new SingleLiveEvent<>();
    private MutableLiveData<List<Interest>> mInterestsList = new MutableLiveData<>();
    private OnBoardingLocalRepository mLocalRepository;
    private OnBoardingRemoteRepository mRemoteRepository;
    private LoginLocalRepository mLoginLocalRepository;
    private SnackbarMessage mSnackbarText = new SnackbarMessage();
    private MutableLiveData<Boolean> progressBarVisibility = new MutableLiveData<>();

    public OnBoardingBindingModel mBindingModel;

    private UserType userType;

    public OnBoardingVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new OnBoardingLocalRepository();
        mRemoteRepository = new OnBoardingRemoteRepository();
        mLoginLocalRepository = new LoginLocalRepository(application);
        mBindingModel = new OnBoardingBindingModel();
    }


    public SingleLiveEvent<Void> getNavigateToUserTypeFragment() {
        return navigateToUserTypeFragment;
    }

    public void setNavigateToUserTypeFragment() {
        navigateToUserTypeFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToUserInterestsFragment() {
        return navigateToUserInterestsFragment;
    }

    public void setNavigateToUserInterestsFragment(){
        navigateToUserInterestsFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToHomeActivity() {
        return navigateToHomeActivity;
    }

    public void setNavigateToHomeActivity() {
        navigateToHomeActivity.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    private void showSnackbarMessage(String message) {
        mSnackbarText.setValue(message);
    }

    public MutableLiveData<List<Interest>> getmInterestsList() {
        return mInterestsList;
    }

    public void setmInterestsList(List<Interest> interestsList) {
        mInterestsList.setValue(interestsList);
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public MutableLiveData<Boolean> getProgressBarVisibility() {
        return progressBarVisibility;
    }

    public void setProgressBarVisibility(boolean visibility) {
        this.progressBarVisibility.setValue(visibility);
    }




    public void configUser(){
        if (!mLoginLocalRepository.isUserTypeRegistered())
            setNavigateToUserTypeFragment();
        else if (!mLoginLocalRepository.isUserInterestRegistered())
            setNavigateToUserInterestsFragment();
        else
            setNavigateToHomeActivity();
    }

    public void registerUserAsArtist(){
        mBindingModel.setProgressBarVisibility(true);
        mRemoteRepository.registerUserAsArtist(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserAsFan(){
        mBindingModel.setProgressBarVisibility(true);
        mRemoteRepository.registerUserAsFan(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserInterests(){
        mRemoteRepository.registerUserInterests(mLocalRepository.getCurrentUserId(), registerUserInterestsCallback);
    }



    private RegisterUserTypeCallback registerUserTypeCallback = new RegisterUserTypeCallback() {
        @Override
        public void onSuccess() {
            mBindingModel.setProgressBarVisibility(false);
            mSnackbarText.setValue("Registration Successful");
            mLoginLocalRepository.saveUserConfiguration(mLoginLocalRepository.isUserPhoneVerfied(),true, true);
            setNavigateToHomeActivity();
        }

        @Override
        public void onFailure() {
            mBindingModel.setProgressBarVisibility(false);
            mSnackbarText.setValue("Some Error Occurred");
        }
    };

    private RegisterUserInterestsCallback registerUserInterestsCallback = new RegisterUserInterestsCallback() {
        @Override
        public void onSuccess() {
            mLoginLocalRepository.saveUserConfiguration(mLoginLocalRepository.isUserPhoneVerfied(),true, true);
            mSnackbarText.setValue("Interests Saved");
        }

        @Override
        public void onFailure() {
            mSnackbarText.setValue("Some Error Occurred");
        }
    };
}
