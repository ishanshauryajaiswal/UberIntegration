package com.shaurya.messenger.on_boarding.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.FragmentUserTypeBinding;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.on_boarding.model.pojo.Interest;
import com.shaurya.messenger.on_boarding.model.pojo.UserType;
import com.shaurya.messenger.on_boarding.view.adapter.RvInterestAdapter;
import com.shaurya.messenger.on_boarding.viewmodel.OnBoardingVM;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;

import java.util.ArrayList;
import java.util.List;


public class UserTypeFragment extends Fragment {

    private Button btnArtist;
    private Button btnFan;
    private RecyclerView rvInterest;
    private RvInterestAdapter mInterestAdapter;

    private OnBoardingVM mOnBoardingVM;

    private FragmentUserTypeBinding mBinding;

    public UserTypeFragment() {}


    public static UserTypeFragment newInstance() {
        UserTypeFragment fragment = new UserTypeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        setUpVieModel();

        mBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_user_type, container, false);

        mBinding.setOnBoardingBindingModel(mOnBoardingVM.mBindingModel);

        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);

        setUpObservers();
    }

    private void initViews(View view) {
        btnArtist = view.findViewById(R.id.btn_user_type_artist);
        btnFan = view.findViewById(R.id.btn_user_type_fan);
        rvInterest = view.findViewById(R.id.rv_interest);
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(),2);
        mInterestAdapter = new RvInterestAdapter(adapterCallback);
        rvInterest.setLayoutManager(layoutManager);
        rvInterest.setAdapter(mInterestAdapter);
        mOnBoardingVM.setmInterestsList(getDefaultInterestList());

        btnArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnArtist.setBackgroundColor(getResources().getColor(R.color.colorBlack));
                btnFan.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                mOnBoardingVM.setUserType(UserType.ARTIST);
                //mOnBoardingVM.registerUserAsArtist();
            }
        });

        btnFan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnFan.setBackgroundColor(getResources().getColor(R.color.colorBlack));
                btnArtist.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                mOnBoardingVM.setUserType(UserType.AUDIENCE);
                //mOnBoardingVM.registerUserAsFan();
            }
        });
    }

    private List<Interest> getDefaultInterestList() {
        List<Interest> list = new ArrayList<>();
        for (int i=1;i<=7;i++){
            Interest interest = new Interest("Interest "+i,false);
            list.add(interest);
        }
        return list;
    }

    private void setUpObservers(){
        mOnBoardingVM.getSnackbarMessage().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(String snackbarMessage) {
                SnackbarUtils.showSnackbar(getView(), snackbarMessage);
            }
        });

        mOnBoardingVM.getmInterestsList().observe(this, new Observer<List<Interest>>() {
            @Override
            public void onChanged(@Nullable List<Interest> interests) {
                mInterestAdapter.setmList(interests);
            }
        });

        mOnBoardingVM.getProgressBarVisibility().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean aBoolean) {
                mOnBoardingVM.mBindingModel.setProgressBarVisibility(aBoolean);
                getActivity().invalidateOptionsMenu();
            }
        });
    }

    private void setUpVieModel(){
        mOnBoardingVM = ViewModelProviders.of(getActivity()).get(OnBoardingVM.class);
    }

    private RvInterestAdapter.RvInterestAdapterCallback adapterCallback = new RvInterestAdapter.RvInterestAdapterCallback() {
        @Override
        public void onItemClicked(int position) {
            //TODO Something on Recycler View Cell CLick
        }
    };

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.onboarding_1,menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_done:
                submitUser();
                return true;
            default:
                break;
        }
        return false;
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        MenuItem item = menu.findItem(R.id.action_done);
        boolean visibility = mOnBoardingVM.mBindingModel.isProgressBarVisibility();

        if (visibility){
            item.setEnabled(false);
            //item.getIcon().setAlpha(130);
        }
        else {
            item.setEnabled(true);
            //item(setAlpha(255);
        }
    }

    private void submitUser() {

        if (mOnBoardingVM.getUserType()==null){
            SnackbarUtils.showSnackbar(getView(), "Kindly Select your User Category to Proceed");
            return;
        }

        if (mInterestAdapter.numberOfSelections() != 2){
            SnackbarUtils.showSnackbar(getView(), "Kindly Select 2 Interests to Proceed");
            return;
        }

        if (mOnBoardingVM.getUserType().equals(UserType.AUDIENCE))
            mOnBoardingVM.registerUserAsFan();
        else
            mOnBoardingVM.registerUserAsArtist();


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
