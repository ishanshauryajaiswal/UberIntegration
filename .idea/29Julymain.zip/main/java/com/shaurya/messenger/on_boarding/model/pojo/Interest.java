package com.shaurya.messenger.on_boarding.model.pojo;

public class Interest {

    private String interestTitle;
    private boolean selected;

    public Interest(String interestTitle, boolean selected) {
        this.interestTitle = interestTitle;
        this.selected = selected;
    }

    public String getInterestTitle() {
        return interestTitle;
    }

    public void setInterestTitle(String interestTitle) {
        this.interestTitle = interestTitle;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
