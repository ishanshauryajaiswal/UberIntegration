package com.shaurya.messenger.on_boarding.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.shaurya.messenger.R;
import com.shaurya.messenger.on_boarding.model.pojo.Interest;

import java.util.List;

public class RvInterestAdapter  extends RecyclerView.Adapter<RvInterestAdapter.ViewHolder> {


    public interface RvInterestAdapterCallback{
        void onItemClicked(int position);
    }

    private RvInterestAdapterCallback callback;
    private Context mContext;
    private List<Interest> mList;

    public RvInterestAdapter(RvInterestAdapterCallback callback) {
        this.callback = callback;
    }

    @NonNull
    @Override
    public RvInterestAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(mContext);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.cell_recycler_view_interests, parent, false);

        // Return a new holder instance
        return new ViewHolder(contactView);
    }

    @Override
    public void onBindViewHolder(@NonNull final RvInterestAdapter.ViewHolder holder, final int position) {
        final Interest interest = mList.get(position);
        holder.tvInterestName.setText(interest.getInterestTitle());
        if (interest.isSelected())
            holder.rlContent.setBackgroundColor(mContext.getResources().getColor(R.color.colorBlack));

        holder.rlContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (interest.isSelected()) {
                    interest.setSelected(false);
                    holder.rlContent.setBackgroundColor(mContext.getResources().getColor(R.color.colorAccent));
                    callback.onItemClicked(position);
                } else {
                    if (numberOfSelections()>=2)
                        Toast.makeText(mContext,"Select Only 2 Interests",Toast.LENGTH_SHORT).show();
                    else {
                        interest.setSelected(true);
                        holder.rlContent.setBackgroundColor(mContext.getResources().getColor(R.color.colorBlack));
                        callback.onItemClicked(position);
                    }
                }
            }
        });

    }

    public int numberOfSelections() {
        int c = 0;
        for (Interest i : mList)
            if (i.isSelected())
                c++;
        return c;
    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }

    public List<Interest> getmList() {
        return mList;
    }

    public void setmList(List<Interest> mList) {
        this.mList = mList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rlContent;
        TextView tvInterestName;

        public ViewHolder(View itemView) {
            super(itemView);
            rlContent = itemView.findViewById(R.id.rl_cell_interest);
            tvInterestName = itemView.findViewById(R.id.tv_interest_name);
        }
    }
}
