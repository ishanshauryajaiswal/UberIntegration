package com.example.ishanjaiswal.messenger.login.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

public class LoginVM extends AndroidViewModel {
    public LoginVM(@NonNull Application application) {
        super(application);
    }
}
