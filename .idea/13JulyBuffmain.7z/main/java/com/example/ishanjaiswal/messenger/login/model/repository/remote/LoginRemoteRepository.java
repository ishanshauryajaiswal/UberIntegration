package com.example.ishanjaiswal.messenger.login.model.repository.remote;

public class LoginRemoteRepository {
}
