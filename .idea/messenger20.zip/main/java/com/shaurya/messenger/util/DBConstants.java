package com.shaurya.messenger.util;

public class DBConstants {

    public static final String TABLE_USERS = "users";
    public static final String KEY_USERS_TYPE = "type";
    public static final String KEY_USERS_INTERESTS = "interests";
    public static final String KEY_SP_USER_TYPE = "sp_user_type";
    public static final String KEY_SP_USER_INTEREST = "sp_user_interest";
}
