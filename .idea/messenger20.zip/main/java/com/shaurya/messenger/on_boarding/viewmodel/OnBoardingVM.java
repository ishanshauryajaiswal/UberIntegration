package com.shaurya.messenger.on_boarding.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.messenger.R;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserInterestsCallback;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserTypeCallback;
import com.shaurya.messenger.on_boarding.model.repository.local.OnBoardingLocalRepository;
import com.shaurya.messenger.on_boarding.model.repository.remote.OnBoardingRemoteRepository;
import com.shaurya.messenger.util.DBConstants;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;

public class OnBoardingVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToUserInterestsFragment = new SingleLiveEvent<>();
    private DatabaseReference mDatabaseReference;
    private OnBoardingLocalRepository mLocalRepository;
    private OnBoardingRemoteRepository mRemoteRepository;
    private  SnackbarMessage mSnackbarText = new SnackbarMessage();

    public OnBoardingVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new OnBoardingLocalRepository();
        mRemoteRepository = new OnBoardingRemoteRepository();
    }


    public SingleLiveEvent<Void> getNavigateToUserInterestsFragment() {
        return navigateToUserInterestsFragment;
    }

    public void navigateToUserInterestsFragment(){
        navigateToUserInterestsFragment.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    private void showSnackbarMessage(Integer message) {
        mSnackbarText.setValue(message);
    }






    public void registerUserAsArtist(){
        mRemoteRepository.registerUserAsArtist(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserAsFan(){
        mRemoteRepository.registerUserAsFan(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserInterests(){
        mRemoteRepository.registerUserInterests(mLocalRepository.getCurrentUserId(), registerUserInterestsCallback);
    }



    private RegisterUserTypeCallback registerUserTypeCallback = new RegisterUserTypeCallback() {
        @Override
        public void onSuccess() {
            mSnackbarText.setValue(R.string.successfully_registered_user_type);
            navigateToUserInterestsFragment();
        }

        @Override
        public void onFailure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };

    private RegisterUserInterestsCallback registerUserInterestsCallback = new RegisterUserInterestsCallback() {
        @Override
        public void onSuccess() {
            mSnackbarText.setValue(R.string.successfully_registered_user_interests);
        }

        @Override
        public void onFailure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };
}
