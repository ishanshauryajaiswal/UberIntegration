package com.shaurya.messenger.login.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.facebook.AccessToken;
import com.shaurya.messenger.R;
import com.shaurya.messenger.login.model.repository.callbacks.LoginUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.RegisterUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.UserConfigurationCallback;
import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.login.model.repository.remote.LoginRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;


public class LoginVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToLoginFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToRegisterFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToHomeActivity = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToOnBoardingActivity = new SingleLiveEvent<>();
    private SnackbarMessage mSnackbarText = new SnackbarMessage();


    private LoginLocalRepository mLocalRepository;
    private LoginRemoteRepository mRemoteRepository;

    public LoginVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new LoginLocalRepository(application);
        mRemoteRepository = new LoginRemoteRepository();
    }


    public SingleLiveEvent<Void> getNavigateToRegisterFragment() {
        return navigateToRegisterFragment;
    }

    public void navigateToRegisterFragment(){
        navigateToRegisterFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToLoginFragment() {
        return navigateToLoginFragment;
    }

    public void setNavigateToLoginFragment(){
        navigateToLoginFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToHomeActivity() {
        return navigateToHomeActivity;
    }

    public void setNavigateToHomeActivity(){
        navigateToHomeActivity.call();
    }

    public SingleLiveEvent<Void> getNavigateToOnBoardingActivity() {
        return navigateToOnBoardingActivity;
    }

    public void setNavigateToOnBoardingActivity(){
        navigateToOnBoardingActivity.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    private void showSnackbarMessage(Integer message) {
        mSnackbarText.setValue(message);
    }

    public void loginUser(String email, String password){
        mRemoteRepository.loginUser(email, password, loginUserCallback);
    }

    public void registerUser(String email, String password){
        mRemoteRepository.registerUser(email, password, registerUserCallback);
    }

    public void handleFacebookAccessToken(AccessToken token){
        mRemoteRepository.loginFacebookUser(token, loginUserCallback);
    }

    LoginUserCallback loginUserCallback = new LoginUserCallback() {
        @Override
        public void Success() {

            mRemoteRepository.getUserConfiguration(mLocalRepository.getCurrentUserId(), userConfigurationCallback);
            if (!mLocalRepository.isUserTypeRegistered() || mLocalRepository.isUserInterestRegistered())
                setNavigateToOnBoardingActivity();
            else {
                setNavigateToHomeActivity();
            }
        }

        @Override
        public void Failure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };

    RegisterUserCallback registerUserCallback = new RegisterUserCallback() {
        @Override
        public void Success() {

            if (!mLocalRepository.isUserTypeRegistered() || mLocalRepository.isUserInterestRegistered())
                setNavigateToOnBoardingActivity();
            else {
                setNavigateToHomeActivity();
            }
        }

        @Override
        public void Failure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };

    UserConfigurationCallback userConfigurationCallback = new UserConfigurationCallback() {
        @Override
        public void Success(boolean userType, boolean userInterest) {
            mLocalRepository.saveUserConfiguration(userType, userInterest);
        }

        @Override
        public void Failure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };
}
