package com.shaurya.messenger.login.model.repository.local;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.shaurya.messenger.util.DBConstants;

public class LoginLocalRepository {
    private FirebaseAuth mAuth;
    private Application mApplicationContext;
    SharedPreferences sp;
    SharedPreferences.Editor spEditor;

    public LoginLocalRepository(Application applicationContext) {
        mAuth = FirebaseAuth.getInstance();
        mApplicationContext = applicationContext;
        sp = PreferenceManager.getDefaultSharedPreferences(mApplicationContext);
        spEditor = sp.edit();
    }

    public String getCurrentUserId(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        return currentUser.getUid();
    }

    public boolean isUserTypeRegistered(){
        return sp.getBoolean(DBConstants.KEY_SP_USER_TYPE,false);
    }

    public boolean isUserInterestRegistered(){
        return sp.getBoolean(DBConstants.KEY_SP_USER_INTEREST,false);
    }

    public void saveUserConfiguration(boolean userType, boolean userInterest){
        spEditor.putBoolean(DBConstants.KEY_SP_USER_TYPE, userType);
        spEditor.putBoolean(DBConstants.KEY_SP_USER_INTEREST, userInterest);
        spEditor.commit();
    }
}
