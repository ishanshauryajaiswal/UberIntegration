package com.shaurya.messenger.home.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.shaurya.messenger.home.model.repository.local.HomeLocalRepository;
import com.shaurya.messenger.home.model.repository.remote.HomeRemoteRepository;
import com.shaurya.messenger.login.model.repository.callbacks.FetchUserTypeCallback;
import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.login.model.repository.remote.LoginRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;

public class HomeVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToLoginActivity = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToOnBoardingActivity = new SingleLiveEvent<>();


    private HomeLocalRepository homeLocalRepository;
    private HomeRemoteRepository homeRemoteRepository;
    private LoginLocalRepository loginLocalRepository;
    private LoginRemoteRepository loginRemoteRepository;

    public HomeVM(@NonNull Application application) {
        super(application);
        homeLocalRepository = new HomeLocalRepository();
        homeRemoteRepository = new HomeRemoteRepository();
        loginLocalRepository = new LoginLocalRepository(application);
        loginRemoteRepository = new LoginRemoteRepository();
    }

    public SingleLiveEvent<Void> getNavigateToLoginActivity() {
        return navigateToLoginActivity;
    }

    public void setNavigateToLoginActivity(){
        navigateToLoginActivity.call();
    }

    public SingleLiveEvent<Void> getNavigateToOnBoardingActivity() {
        return navigateToOnBoardingActivity;
    }

    public void setNavigateToOnBoardingActivity() {
        navigateToOnBoardingActivity.call();
    }


    public void configUser(){
        if (!homeLocalRepository.isUserSignedIn())
            setNavigateToLoginActivity();
        else{
            if (!loginLocalRepository.isUserTypeRegistered() || loginLocalRepository.isUserInterestRegistered())
                setNavigateToOnBoardingActivity();
            else {
                //TODO loadFeed
            }
        }
    }


    /*
    FetchUserTypeCallback fetchUserTypeCallback = new FetchUserTypeCallback() {
        @Override
        public void Success(boolean isUserTypeRegistered) {
            if (isUserTypeRegistered) {
                String uID = loginLocalRepository.getCurrentUserId();
                loginRemoteRepository.isUserInterestsRegistered(uID, fetchUserInterestCallback);
            }
            else
                setNavigateToOnBoardingActivity();
        }

        @Override
        public void Failure() {

        }
    };

    FetchUserInterestCallback fetchUserInterestCallback = new FetchUserInterestCallback() {
        @Override
        public void Success(boolean isUserInterestRegistered) {
            if (!isUserInterestRegistered)
                setNavigateToOnBoardingActivity();
        }

        @Override
        public void Failure() {

        }
    };
    */

    public boolean isUserSignedIn(){
        return homeLocalRepository.isUserSignedIn();
    }


}
