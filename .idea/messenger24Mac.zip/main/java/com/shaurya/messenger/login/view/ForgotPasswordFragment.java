package com.shaurya.messenger.login.view;


import android.app.Activity;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.FragmentForgotPasswordBinding;
import com.shaurya.messenger.databinding.FragmentRegisterBinding;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.util.InputValidationUtil;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;
import com.shaurya.messenger.util.StringConstants;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ForgotPasswordFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ForgotPasswordFragment extends Fragment {

    private EditText etEmail;
    private LoginVM mLoginViewModel;
    private FragmentForgotPasswordBinding mBinding;

    public ForgotPasswordFragment() {
    }

    public static ForgotPasswordFragment newInstance() {
        ForgotPasswordFragment fragment = new ForgotPasswordFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);

        mBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_forgot_password, container, false);

        mBinding.setLoginViewModel(mLoginViewModel.mLoginModel);

        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);
        initViews(view);
        setUpObservers();
    }

    private void initViews(View view) {

        etEmail = view.findViewById(R.id.et_forgot_password_email);

        view.findViewById(R.id.btn_forgot_password_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                String email = etEmail.getText().toString();
                String validation = InputValidationUtil.validateEmail(email);

                if (validation.equalsIgnoreCase(StringConstants.INPUT_VALID)){
                    mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                    mLoginViewModel.forgotPassword(email);
                }
                else {
                    SnackbarUtils.showSnackbar(getView(), validation);
                }
            }
        });

        view.findViewById(R.id.btn_forgot_password_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mLoginViewModel.setNavigateToLoginFragment();
            }
        });

    }

    private void setUpObservers(){

        mLoginViewModel.getmSnackbarTextForForgotPasswordFragment().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(String snackbarMessage) {
                SnackbarUtils.showSnackbar(getView(), snackbarMessage);
            }
        });
    }

    private void hideKeyboard(){
        Activity context = getActivity();
        InputMethodManager inputManager = (InputMethodManager)
                context.getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow((null == context.getCurrentFocus()) ? null : context.getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
