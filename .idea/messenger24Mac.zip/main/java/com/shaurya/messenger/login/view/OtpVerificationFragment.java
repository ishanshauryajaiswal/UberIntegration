package com.shaurya.messenger.login.view;


import android.app.Activity;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.shaurya.messenger.R;
import com.shaurya.messenger.databinding.FragmentOtpVerificationBinding;
import com.shaurya.messenger.databinding.FragmentRegisterBinding;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.util.InputValidationUtil;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;
import com.shaurya.messenger.util.StringConstants;

import java.util.concurrent.TimeUnit;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OtpVerificationFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OtpVerificationFragment extends Fragment {

    private static final String TAG = OtpVerificationFragment.class.getSimpleName();

    private EditText etPhone, etOtp;
    private RelativeLayout rlBottom;

    private LoginVM mLoginViewModel;
    private FragmentOtpVerificationBinding mBinding;

    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;



    private void setUpPhoneVerificationCallback(){
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                mLoginViewModel.registerUserPhoneVerification();
                Log.d(TAG, "onVerificationCompleted:" + credential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                Log.w(TAG, "onVerificationFailed", e);
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);

                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    SnackbarUtils.showSnackbar(getView(),"Invalid phone number.");
                } else if (e instanceof FirebaseTooManyRequestsException) {
                    // The SMS quota for the project has been exceeded
                    SnackbarUtils.showSnackbar(getView(),"Max Requests Quota Exceeded");
                }

            }

            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:" + verificationId);

                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(false);
                rlBottom.setVisibility(View.VISIBLE);


                SnackbarUtils.showSnackbar(getView(),"Verification Code Sent");

                mResendToken = token;
            }
        };
    }

    private void startPhoneNumberVerification(String phoneNumber) {
        // [START start_phone_auth]
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                getActivity(),               // Activity (for callback binding)
                mCallbacks);

        mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
    }

    private void resendVerificationCode(String phoneNumber,
                                        PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                getActivity(),               // Activity (for callback binding)
                mCallbacks,         // OnVerificationStateChangedCallbacks
                token);             // ForceResendingToken from callbacks
    }




    public OtpVerificationFragment() {
    }

    public static OtpVerificationFragment newInstance() {
        OtpVerificationFragment fragment = new OtpVerificationFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);

        mBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_otp_verification, container, false);

        mBinding.setLoginViewModel(mLoginViewModel.mLoginModel);

        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLoginViewModel = ViewModelProviders.of(getActivity()).get(LoginVM.class);
        initViews(view);
        setUpObservers();
        setUpPhoneVerificationCallback();
    }

    private void initViews(View view) {

        etPhone = view.findViewById(R.id.et_otp_phone);
        etOtp = view.findViewById(R.id.et_otp);
        rlBottom = view.findViewById(R.id.rl_otp_bottom);

        view.findViewById(R.id.btn_otp_send_otp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = etPhone.getText().toString();

                String validation = InputValidationUtil.validatePhone(phone);

                if (validation.equalsIgnoreCase(StringConstants.INPUT_VALID)){
                    mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                    startPhoneNumberVerification(phone);
                }
                else {
                    SnackbarUtils.showSnackbar(getView(), validation);
                }
            }
        });

        view.findViewById(R.id.tv_otp_resend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                SnackbarUtils.showSnackbar(getView(), "Under Development");
            }
        });

        view.findViewById(R.id.btn_otp_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginViewModel.mLoginModel.setLoginProgressBarVisibility(true);
                mLoginViewModel.setNavigateToLoginFragment();
            }
        });
    }

    private void setUpObservers(){

        mLoginViewModel.getmSnackbarTextForRegisterFragment().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(String snackbarMessage) {
                SnackbarUtils.showSnackbar(getView(), snackbarMessage);
            }
        });
    }

    private void hideKeyboard(){
        Activity context = getActivity();
        InputMethodManager inputManager = (InputMethodManager)
                context.getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow((null == context.getCurrentFocus()) ? null : context.getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
