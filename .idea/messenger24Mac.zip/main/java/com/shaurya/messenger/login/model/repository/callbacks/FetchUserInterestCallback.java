package com.shaurya.messenger.login.model.repository.callbacks;

public interface FetchUserInterestCallback {

    void Success(boolean isUserInterestRegistered);

    void Failure();
}
