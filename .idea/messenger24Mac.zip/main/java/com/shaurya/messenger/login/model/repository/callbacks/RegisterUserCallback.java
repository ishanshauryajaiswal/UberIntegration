package com.shaurya.messenger.login.model.repository.callbacks;

public interface RegisterUserCallback {

    void Success();

    void Failure(String errorMessage);
}
