package com.shaurya.messenger.login.model.repository.remote;

public class LoginRemoteRepository {
}
