package com.shaurya.messenger.login.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.shaurya.messenger.R;
import com.shaurya.messenger.login.viewmodel.LoginVM;


public class LoginActivity extends AppCompatActivity {

    private LoginVM mLoginViewModel;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setUpViewModel();
        setUpObservers();
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.login_container,
                    obtainLoginFragment(), LoginFragment.class.getSimpleName()).commit();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void setUpViewModel() {
        mLoginViewModel = ViewModelProviders.of(this).get(LoginVM.class);
    }

    private void setUpObservers() {

        mLoginViewModel.getNavigateToRegisterFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction().replace(R.id.login_container,
                        obtainRegisterFragment(), RegisterFragment.class.getSimpleName()).commit();
            }
        });

    }

    @NonNull
    private LoginFragment obtainLoginFragment() {
        LoginFragment loginFragment = (LoginFragment) getSupportFragmentManager()
                .findFragmentByTag(LoginFragment.class.getSimpleName());

        if (loginFragment == null) {
            loginFragment = LoginFragment.newInstance();
        }
        return loginFragment;
    }

    @NonNull
    private RegisterFragment obtainRegisterFragment() {
        RegisterFragment registerFragment = (RegisterFragment) getSupportFragmentManager()
                .findFragmentByTag(RegisterFragment.class.getSimpleName());

        if (registerFragment == null) {
            registerFragment = RegisterFragment.newInstance();
        }
        return registerFragment;
    }
}
