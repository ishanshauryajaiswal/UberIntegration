package com.shaurya.messenger.login.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.shaurya.ishanjaiswal.messenger.util.SingleLiveEvent;

public class LoginVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToRegisterFragment = new SingleLiveEvent<>();

    public LoginVM(@NonNull Application application) {
        super(application);
    }


    public SingleLiveEvent<Void> getNavigateToRegisterFragment() {
        return navigateToRegisterFragment;
    }

    public void navigateToRegisterFragment(){
        navigateToRegisterFragment.call();
    }


}
