package com.shaurya.messenger.home.model.repository.remote;

public class HomeRemoteRepository {
}
