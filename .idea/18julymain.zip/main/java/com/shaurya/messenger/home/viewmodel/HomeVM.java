package com.shaurya.messenger.home.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.shaurya.messenger.home.model.repository.local.HomeLocalRepository;
import com.shaurya.messenger.home.model.repository.remote.HomeRemoteRepository;

public class HomeVM extends AndroidViewModel {

    private HomeLocalRepository localRepository;
    private HomeRemoteRepository remoteRepository;

    public HomeVM(@NonNull Application application) {
        super(application);
        localRepository = new HomeLocalRepository();
    }

    public boolean isUserSignedIn(){
        return localRepository.isUserSignedIn();
    }


}
