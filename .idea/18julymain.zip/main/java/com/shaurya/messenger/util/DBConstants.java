package com.shaurya.messenger.util;

public class DBConstants {

    public static final String TABLE_USERS = "users";
}
