package com.shaurya.messenger.on_boarding.model.repository.remote;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.messenger.util.DBConstants;

import java.util.HashMap;
import java.util.Map;

public class OnBoardingRemoteRepository {

    DatabaseReference mDatabaseReference;

    public OnBoardingRemoteRepository(){
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child(DBConstants.TABLE_USERS);
    }

    public void registerUserAsArtist(String userID){
        mDatabaseReference = mDatabaseReference.child(userID);
        Map<String,Boolean> map = new HashMap<>();
        map.put("type",true);
        mDatabaseReference.setValue(map);
    }

    public void registerUserAsFan(String userID){
        mDatabaseReference = mDatabaseReference.child(userID);
        Map<String,Boolean> map = new HashMap<>();
        map.put("type",true);
        mDatabaseReference.setValue(map);
        //TODO add callback
    }
}
