package com.shaurya.messenger.on_boarding.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.ishanjaiswal.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.on_boarding.model.repository.local.OnBoardingLocalRepository;
import com.shaurya.messenger.on_boarding.model.repository.remote.OnBoardingRemoteRepository;
import com.shaurya.messenger.util.DBConstants;

public class OnBoardingVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToUserInterestsFragment = new SingleLiveEvent<>();
    private DatabaseReference mDatabaseReference;
    private OnBoardingLocalRepository mLocalRepository;
    private OnBoardingRemoteRepository mRemoteRepository;

    public OnBoardingVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new OnBoardingLocalRepository();
        mRemoteRepository = new OnBoardingRemoteRepository();
    }


    public SingleLiveEvent<Void> getNavigateToUserInterestsFragment() {
        return navigateToUserInterestsFragment;
    }

    public void navigateToUserInterestsFragment(){
        navigateToUserInterestsFragment.call();
    }

    public void registerUserAsArtist(){
        mRemoteRepository.registerUserAsArtist(mLocalRepository.getCurrentUserId());
    }

    public void registerUserAsFan(){
        mRemoteRepository.registerUserAsFan(mLocalRepository.getCurrentUserId());
    }
}
