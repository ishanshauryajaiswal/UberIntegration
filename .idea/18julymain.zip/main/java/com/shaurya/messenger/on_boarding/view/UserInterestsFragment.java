package com.shaurya.messenger.on_boarding.view;


import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.shaurya.messenger.R;
import com.shaurya.messenger.on_boarding.viewmodel.OnBoardingVM;



public class UserInterestsFragment extends Fragment {

    private OnBoardingVM mOnBoardingVM;

    public UserInterestsFragment() {
    }

    public static UserInterestsFragment newInstance() {
        UserInterestsFragment fragment = new UserInterestsFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_interest, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mOnBoardingVM = ViewModelProviders.of(getActivity()).get(OnBoardingVM.class);
        initViews(view);
    }

    private void initViews(View view) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
