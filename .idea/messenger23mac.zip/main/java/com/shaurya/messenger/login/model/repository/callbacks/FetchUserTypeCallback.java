package com.shaurya.messenger.login.model.repository.callbacks;

public interface FetchUserTypeCallback {

    void Success(boolean isUserTypeRegistered);

    void Failure();
}
