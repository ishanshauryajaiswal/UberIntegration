package com.shaurya.messenger.login.model.repository.remote;

import android.support.annotation.NonNull;

import com.facebook.AccessToken;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shaurya.messenger.login.model.repository.callbacks.FetchUserInterestCallback;
import com.shaurya.messenger.login.model.repository.callbacks.LoginUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.FetchUserTypeCallback;
import com.shaurya.messenger.login.model.repository.callbacks.RegisterUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.UserConfigurationCallback;
import com.shaurya.messenger.util.StringConstants;

public class LoginRemoteRepository {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;

    public LoginRemoteRepository() {
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS);
    }

    public void loginUser(String email, String password, final LoginUserCallback callback){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else
                            callback.Failure();
                    }
                });
    }

    public void registerUser(String email, String password, final RegisterUserCallback callback){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else
                            callback.Failure();
                    }
                });
    }

    public void loginFacebookUser(AccessToken token, final LoginUserCallback callback){
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                            callback.Success();
                        else
                            callback.Failure();
                    }
                });
    }

    public void loginGoogleUser(AuthCredential credential, final LoginUserCallback callback){
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            callback.Success();
                        } else {
                            //Google Sign In Failed
                            callback.Failure();
                        }
                    }
                });
    }

    public void getUserConfiguration(String userId, final UserConfigurationCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean valueType = false, valueInterest = false;
                if (dataSnapshot.child(StringConstants.KEY_USERS_TYPE).exists())
                    valueType = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_TYPE).getValue();
                if (dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).exists())
                    valueInterest = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).getValue();
                callback.Success(valueType, valueInterest);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }


    public void isUserTypeRegistered(String userId, final FetchUserTypeCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(StringConstants.KEY_USERS_TYPE).exists()){
                    boolean value = false;
                    value = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_TYPE).getValue();
                    callback.Success(value);
                }
                else
                    callback.Success(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }

    public void isUserInterestsRegistered(String userId, final FetchUserInterestCallback callback){
        DatabaseReference databaseReference = mDatabase.getReference(StringConstants.TABLE_USERS).child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).exists()){
                    boolean value = false;
                    value = (boolean) dataSnapshot.child(StringConstants.KEY_USERS_INTERESTS).getValue();
                    callback.Success(value);
                }
                else
                    callback.Success(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.Failure();
            }
        });
    }
}
