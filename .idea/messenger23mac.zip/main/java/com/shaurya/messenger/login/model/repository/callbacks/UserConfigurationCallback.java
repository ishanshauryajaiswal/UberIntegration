package com.shaurya.messenger.login.model.repository.callbacks;

public interface UserConfigurationCallback {

    void Success(boolean userType, boolean userInterest);

    void Failure();
}
