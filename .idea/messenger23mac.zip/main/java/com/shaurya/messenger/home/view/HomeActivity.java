package com.shaurya.messenger.home.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.shaurya.messenger.R;
import com.shaurya.messenger.home.viewmodel.HomeVM;
import com.shaurya.messenger.login.view.LoginActivity;
import com.shaurya.messenger.on_boarding.view.OnBoardingActivity;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = HomeActivity.class.getSimpleName();
    private HomeVM homeViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        homeViewModel = ViewModelProviders.of(this).get(HomeVM.class);
        Log.e(TAG, "onCreate");
        initViews();

        setUpObservables();
    }



    @Override
    protected void onStart() {
        super.onStart();
        homeViewModel.configUser();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initViews() {

    }

    private void setUpObservables() {
        homeViewModel.getNavigateToLoginActivity().observe(this, loginActivityObserver);
        homeViewModel.getNavigateToOnBoardingActivity().observe(this, onBoardingActivityObserver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        homeViewModel.getNavigateToLoginActivity().removeObserver(loginActivityObserver);
        homeViewModel.getNavigateToOnBoardingActivity().removeObserver(onBoardingActivityObserver);
    }


    Observer loginActivityObserver = new Observer() {
        @Override
        public void onChanged(@Nullable Object o) {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    };

    Observer onBoardingActivityObserver = new Observer() {
        @Override
        public void onChanged(@Nullable Object o) {
            Intent intent = new Intent(HomeActivity.this, OnBoardingActivity.class);
            startActivity(intent);
            finish();
        }
    };
}
