package com.shaurya.messenger.util;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationUtil {


    public static String validateLoginCredentials(String email, String password) {
        if (TextUtils.isEmpty(email))
            return "Enter Email";
        if (TextUtils.isEmpty(password))
            return "Enter Password";

        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches())
            return "Enter Valid Email";
        if (password.length() < 8)
            return "Password should have minimum 8 charachters";
        return StringConstants.INPUT_VALID;
    }

    public static String validateRegistrationCredentials(String displayName, String email, String password){

        if (TextUtils.isEmpty(displayName))
            return "Kindly Enter Your Name";
        if (TextUtils.isEmpty(email))
            return "Enter Email";
        if (TextUtils.isEmpty(password))
            return "Enter Password";

        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches())
            return "Enter Valid Email";
        if (password.length() < 8)
            return "Password should have minimum 8 charachters";
        return StringConstants.INPUT_VALID;
    }
}