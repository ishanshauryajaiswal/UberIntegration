package com.shaurya.messenger.on_boarding.view;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.shaurya.messenger.R;
import com.shaurya.messenger.login.viewmodel.LoginVM;
import com.shaurya.messenger.on_boarding.viewmodel.OnBoardingVM;
import com.shaurya.messenger.util.SnackbarMessage;
import com.shaurya.messenger.util.SnackbarUtils;


public class UserTypeFragment extends Fragment {

    private Button btnArtist;
    private Button btnFan;

    private OnBoardingVM mOnBoardingVM;

    public UserTypeFragment() {}


    public static UserTypeFragment newInstance() {
        UserTypeFragment fragment = new UserTypeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_user_type, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mOnBoardingVM = ViewModelProviders.of(getActivity()).get(OnBoardingVM.class);

        initViews(view);

        setUpObservers();
    }

    private void initViews(View view) {
        btnArtist = view.findViewById(R.id.btn_user_type_artist);
        btnFan = view.findViewById(R.id.btn_user_type_fan);

        btnArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOnBoardingVM.registerUserAsArtist();
            }
        });

        btnFan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOnBoardingVM.registerUserAsFan();
            }
        });
    }

    private void setUpObservers(){
        mOnBoardingVM.getSnackbarMessage().observe(this, new SnackbarMessage.SnackbarObserver() {
            @Override
            public void onNewMessage(int snackbarMessageResourceId) {
                SnackbarUtils.showSnackbar(getView(), getString(snackbarMessageResourceId));
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
