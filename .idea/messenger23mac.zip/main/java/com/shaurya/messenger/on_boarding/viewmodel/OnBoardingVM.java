package com.shaurya.messenger.on_boarding.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.shaurya.messenger.R;
import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserInterestsCallback;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserTypeCallback;
import com.shaurya.messenger.on_boarding.model.repository.local.OnBoardingLocalRepository;
import com.shaurya.messenger.on_boarding.model.repository.remote.OnBoardingRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;

public class OnBoardingVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToUserTypeFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToUserInterestsFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToHomeActivity = new SingleLiveEvent<>();
    private DatabaseReference mDatabaseReference;
    private OnBoardingLocalRepository mLocalRepository;
    private OnBoardingRemoteRepository mRemoteRepository;
    private LoginLocalRepository mLoginLocalRepository;
    private  SnackbarMessage mSnackbarText = new SnackbarMessage();

    public OnBoardingVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new OnBoardingLocalRepository();
        mRemoteRepository = new OnBoardingRemoteRepository();
        mLoginLocalRepository = new LoginLocalRepository(application);
    }


    public SingleLiveEvent<Void> getNavigateToUserTypeFragment() {
        return navigateToUserTypeFragment;
    }

    public void setNavigateToUserTypeFragment() {
        navigateToUserTypeFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToUserInterestsFragment() {
        return navigateToUserInterestsFragment;
    }

    public void setNavigateToUserInterestsFragment(){
        navigateToUserInterestsFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToHomeActivity() {
        return navigateToHomeActivity;
    }

    public void setNavigateToHomeActivity() {
        navigateToHomeActivity.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    private void showSnackbarMessage(Integer message) {
        mSnackbarText.setValue(message);
    }







    public void configUser(){
        if (!mLoginLocalRepository.isUserTypeRegistered())
            setNavigateToUserTypeFragment();
        else if (!mLoginLocalRepository.isUserInterestRegistered())
            setNavigateToUserInterestsFragment();
        else
            setNavigateToHomeActivity();
    }

    public void registerUserAsArtist(){
        mRemoteRepository.registerUserAsArtist(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserAsFan(){
        mRemoteRepository.registerUserAsFan(mLocalRepository.getCurrentUserId(), registerUserTypeCallback);
    }

    public void registerUserInterests(){
        mRemoteRepository.registerUserInterests(mLocalRepository.getCurrentUserId(), registerUserInterestsCallback);
    }



    private RegisterUserTypeCallback registerUserTypeCallback = new RegisterUserTypeCallback() {
        @Override
        public void onSuccess() {
            mSnackbarText.setValue(R.string.successfully_registered_user_type);
            mLoginLocalRepository.saveUserConfiguration(true, false);
            setNavigateToUserInterestsFragment();
        }

        @Override
        public void onFailure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };

    private RegisterUserInterestsCallback registerUserInterestsCallback = new RegisterUserInterestsCallback() {
        @Override
        public void onSuccess() {
            mLoginLocalRepository.saveUserConfiguration(true, true);
            mSnackbarText.setValue(R.string.successfully_registered_user_interests);
        }

        @Override
        public void onFailure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };
}
