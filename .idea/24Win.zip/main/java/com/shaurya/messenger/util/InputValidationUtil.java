package com.shaurya.messenger.util;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationUtil {


    public static String validateLoginCredentials(String email, String password) {
        if (TextUtils.isEmpty(email))
            return "Enter Email";
        if (TextUtils.isEmpty(password))
            return "Enter Password";

        String regex = "^[A-Za-z0-9+_.-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches())
            return "Enter Valid Email";
        if (password.length() < 6)
            return "Password should have minimum 6 characters";
        return StringConstants.INPUT_VALID;
    }

    public static String validateRegistrationCredentials(String email, String password, String confirmPassword){

        if (TextUtils.isEmpty(email))
            return "Kindly Enter Your Name";
        if (TextUtils.isEmpty(password))
            return "Enter Email";
        if (TextUtils.isEmpty(confirmPassword))
            return "Re-Enter Password";

        String regex = "^[A-Za-z0-9+_.-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches())
            return "Enter Valid Email";
        if (password.length() < 6)
            return "Password should have minimum 6 characters";
        if (!password.equalsIgnoreCase(confirmPassword))
            return "Passwords not matching";
        return StringConstants.INPUT_VALID;
    }

    public static String validateEmail(String email) {
        if (TextUtils.isEmpty(email))
            return "Enter Email";
        String regex = "^[A-Za-z0-9+_.-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches())
            return "Enter Valid Email";
        return StringConstants.INPUT_VALID;
    }

    public static String validatePhone(String phone) {
        if (TextUtils.isEmpty(phone))
            return "Enter Number";
        if (phone.length()!=10)
            return "Number should be of 10 digits";
        return StringConstants.INPUT_VALID;
    }

    public static String validateOTP(String otp) {
        if (TextUtils.isEmpty(otp))
            return "Enter Number";
        if (otp.length()!=6)
            return "Code should be of 6 digits";
        else
            return StringConstants.INPUT_VALID;
    }
}