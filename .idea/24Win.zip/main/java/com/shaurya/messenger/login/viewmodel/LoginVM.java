package com.shaurya.messenger.login.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.facebook.AccessToken;
import com.google.firebase.auth.AuthCredential;
import com.shaurya.messenger.login.model.repository.callbacks.LoginUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.RegisterUserCallback;
import com.shaurya.messenger.login.model.repository.callbacks.UserConfigurationCallback;
import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.login.model.repository.remote.LoginRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;


public class LoginVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToLoginFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToRegisterFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToForgotPasswordFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToOtpVerificationActivity = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToHomeActivity = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToOnBoardingActivity = new SingleLiveEvent<>();
    private SnackbarMessage mSnackbarText = new SnackbarMessage();
    private SnackbarMessage mSnackbarTextForRegisterFragment = new SnackbarMessage();
    private SnackbarMessage mSnackbarTextForForgotPasswordFragment = new SnackbarMessage();
    private SnackbarMessage mSnackbarTextForOtpVerificationActivity = new SnackbarMessage();

    public LoginModel mLoginModel;

    private LoginLocalRepository mLocalRepository;
    private LoginRemoteRepository mRemoteRepository;

    public LoginVM(@NonNull Application application) {
        super(application);
        mLoginModel = new LoginModel();
        mLocalRepository = new LoginLocalRepository(application);
        mRemoteRepository = new LoginRemoteRepository();
    }

    public SingleLiveEvent<Void> getNavigateToLoginFragment() {
        return navigateToLoginFragment;
    }

    public void setNavigateToLoginFragment(){
        navigateToLoginFragment.call();
    }


    public SingleLiveEvent<Void> getNavigateToRegisterFragment() {
        return navigateToRegisterFragment;
    }

    public void navigateToRegisterFragment(){
        navigateToRegisterFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToForgotPasswordFragment() {
        return navigateToForgotPasswordFragment;
    }

    public void setNavigateToForgotPasswordFragment() {
        navigateToForgotPasswordFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToOtpVerificationActivity() {
        return navigateToOtpVerificationActivity;
    }

    public void setNavigateToOtpVerificationFragment() {
        navigateToOtpVerificationActivity.call();
    }

    public SingleLiveEvent<Void> getNavigateToHomeActivity() {
        return navigateToHomeActivity;
    }

    public void setNavigateToHomeActivity(){
        navigateToHomeActivity.call();
    }

    public SingleLiveEvent<Void> getNavigateToOnBoardingActivity() {
        return navigateToOnBoardingActivity;
    }

    public void setNavigateToOnBoardingActivity(){
        navigateToOnBoardingActivity.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    public SnackbarMessage getmSnackbarTextForRegisterFragment() {
        return mSnackbarTextForRegisterFragment;
    }

    public SnackbarMessage getmSnackbarTextForForgotPasswordFragment() {
        return mSnackbarTextForForgotPasswordFragment;
    }

    public SnackbarMessage getmSnackbarTextForOtpVerificationActivity() {
        return mSnackbarTextForOtpVerificationActivity;
    }

    private void showSnackbarMessage(String  message) {
        mSnackbarText.setValue(message);
    }

    public void loginUser(String email, String password){
        mRemoteRepository.loginUser(email, password, loginUserCallback);
    }

    public void loginUserFacebook(AccessToken token){
        mRemoteRepository.loginFacebookUser(token, loginUserCallback);
    }

    public void loginUserGoogle(AuthCredential credential){
        mRemoteRepository.loginGoogleUser(credential, loginUserCallback);
    }

    public void registerUser(String email, String password){
        mRemoteRepository.registerUser(email, password, registerUserCallback);
    }

    public void forgotPassword(String email) {
        mRemoteRepository.forgotPassword(email, forgotPasswordCallback);
    }

    public void registerUserPhoneVerification(){
        mRemoteRepository.registerUserPhoneVerification(mLocalRepository.getCurrentUserId(), otpVerifiedCallback);
    }

    //Chained Network Request. After Login we request to get user configuration
    LoginUserCallback loginUserCallback = new LoginUserCallback() {
        @Override
        public void Success() {
            mRemoteRepository.getUserConfiguration(mLocalRepository.getCurrentUserId(), userConfigurationCallback);
        }

        @Override
        public void Failure(String errorMessage) {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarText.setValue(errorMessage);
        }
    };

    RegisterUserCallback registerUserCallback = new RegisterUserCallback() {
        @Override
        public void Success() {

            mLoginModel.setLoginProgressBarVisibility(false);
            if (!mLocalRepository.isUserPhoneVerfied()){
                setNavigateToOtpVerificationFragment();
            }
            else if (!mLocalRepository.isUserTypeRegistered() || mLocalRepository.isUserInterestRegistered())
                setNavigateToOnBoardingActivity();
            else {
                setNavigateToHomeActivity();
            }
        }

        @Override
        public void Failure(String errorMessage) {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarTextForRegisterFragment.setValue(errorMessage);
        }
    };

    LoginUserCallback forgotPasswordCallback = new LoginUserCallback() {
        @Override
        public void Success() {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarTextForForgotPasswordFragment.setValue("Sent");
            setNavigateToLoginFragment();
        }

        @Override
        public void Failure(String errorMessage) {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarTextForForgotPasswordFragment.setValue(errorMessage);
        }
    };

    LoginUserCallback otpVerifiedCallback = new LoginUserCallback() {
        @Override
        public void Success() {
            mLoginModel.setLoginProgressBarVisibility(false);
            setNavigateToOnBoardingActivity();
        }

        @Override
        public void Failure(String errorMessage) {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarTextForOtpVerificationActivity.setValue(errorMessage);
        }
    };

    UserConfigurationCallback userConfigurationCallback = new UserConfigurationCallback() {
        @Override
        public void Success(boolean phoneVerified, boolean userType, boolean userInterest) {
            mLoginModel.setLoginProgressBarVisibility(false);
            mLocalRepository.saveUserConfiguration(phoneVerified, userType, userInterest);
            if (!mLocalRepository.isUserPhoneVerfied()){
                setNavigateToOtpVerificationFragment();
            }
            else if (!mLocalRepository.isUserTypeRegistered() || mLocalRepository.isUserInterestRegistered())
                setNavigateToOnBoardingActivity();
            else {
                setNavigateToHomeActivity();
            }
        }

        @Override
        public void Failure() {
            mLoginModel.setLoginProgressBarVisibility(false);
            mSnackbarText.setValue("Some Error Occured");
        }
    };


}
