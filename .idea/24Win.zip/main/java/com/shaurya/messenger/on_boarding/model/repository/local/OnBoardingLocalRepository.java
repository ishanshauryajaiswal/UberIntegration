package com.shaurya.messenger.on_boarding.model.repository.local;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class OnBoardingLocalRepository {

    private FirebaseAuth mAuth;

    public OnBoardingLocalRepository() {
        mAuth = FirebaseAuth.getInstance();
    }

    public String getCurrentUserId(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        return currentUser.getUid();
    }
}
