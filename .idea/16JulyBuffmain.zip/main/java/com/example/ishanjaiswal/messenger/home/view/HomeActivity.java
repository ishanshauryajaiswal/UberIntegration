package com.example.ishanjaiswal.messenger.home.view;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ishanjaiswal.messenger.R;
import com.example.ishanjaiswal.messenger.home.viewmodel.HomeVM;
import com.example.ishanjaiswal.messenger.login.view.LoginActivity;

public class HomeActivity extends AppCompatActivity {

    private HomeVM homeViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        homeViewModel = ViewModelProviders.of(this).get(HomeVM.class);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (homeViewModel.isUserSignedIn() == false){
            navigateToLoginActivity();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void navigateToLoginActivity() {
        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
