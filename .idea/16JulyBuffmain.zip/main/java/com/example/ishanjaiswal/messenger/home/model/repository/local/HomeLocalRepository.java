package com.example.ishanjaiswal.messenger.home.model.repository.local;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeLocalRepository {

    private FirebaseAuth mAuth;

    public HomeLocalRepository() {
        mAuth = FirebaseAuth.getInstance();
    }

    public boolean isUserSignedIn(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        return currentUser != null;
    }
}
