package com.example.ishanjaiswal.messenger.login.model.repository.local;

public class LoginLocalRepository {
}
