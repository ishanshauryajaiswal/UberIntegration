package com.example.ishanjaiswal.messenger.home.model.repository.remote;

public class HomeRemoteRepository {
}
