package com.shaurya.messenger.on_boarding.view;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.shaurya.messenger.R;
import com.shaurya.messenger.login.view.LoginFragment;
import com.shaurya.messenger.login.view.RegisterFragment;
import com.shaurya.messenger.on_boarding.viewmodel.OnBoardingVM;


public class OnBoardingActivity extends AppCompatActivity {

    private OnBoardingVM mOnBoardingViewModel;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding);
        setUpViewModel();
        setUpObservers();
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.on_boarding_container,
                    obtainUserTypeFragment(), UserTypeFragment.class.getSimpleName()).commit();
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void setUpViewModel() {
        mOnBoardingViewModel = ViewModelProviders.of(this).get(OnBoardingVM.class);
    }

    private void setUpObservers() {

        mOnBoardingViewModel.getNavigateToUserInterestsFragment().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getSupportFragmentManager().beginTransaction().replace(R.id.on_boarding_container,
                        obtainUserInterestsFragment(), UserInterestsFragment.class.getSimpleName()).commit();
            }
        });

    }

    @NonNull
    private UserTypeFragment obtainUserTypeFragment() {
        UserTypeFragment userTypeFragment = (UserTypeFragment) getSupportFragmentManager()
                .findFragmentByTag(UserTypeFragment.class.getSimpleName());

        if (userTypeFragment == null) {
            userTypeFragment = UserTypeFragment.newInstance();
        }
        return userTypeFragment;
    }

    @NonNull
    private UserInterestsFragment obtainUserInterestsFragment() {
        UserInterestsFragment userInterestsFragment = (UserInterestsFragment) getSupportFragmentManager()
                .findFragmentByTag(UserInterestsFragment.class.getSimpleName());

        if (userInterestsFragment == null) {
            userInterestsFragment = UserInterestsFragment.newInstance();
        }
        return userInterestsFragment;
    }
}
