package com.shaurya.messenger.on_boarding.model.repository.callbacks;

public interface RegisterUserTypeCallback {

    void onSuccess();

    void onFailure();
}
