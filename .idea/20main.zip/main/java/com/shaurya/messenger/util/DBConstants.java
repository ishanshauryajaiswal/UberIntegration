package com.shaurya.messenger.util;

public class DBConstants {

    public static final String TABLE_USERS = "users";
    public static final String KEY_USERS_TYPE = "type";
    public static final String KEY_USERS_INTERESTS = "interests";
}
