package com.shaurya.messenger.on_boarding.model.repository.remote;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserInterestsCallback;
import com.shaurya.messenger.on_boarding.model.repository.callbacks.RegisterUserTypeCallback;
import com.shaurya.messenger.util.DBConstants;

import java.util.HashMap;
import java.util.Map;

public class OnBoardingRemoteRepository {

    DatabaseReference mDatabaseReference;

    public OnBoardingRemoteRepository(){
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child(DBConstants.TABLE_USERS);
    }

    public void registerUserAsArtist(String userID, final RegisterUserTypeCallback callback){
        mDatabaseReference = mDatabaseReference.child(userID);
        Map<String,Boolean> map = new HashMap<>();
        map.put("type",true);
        mDatabaseReference.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }

    public void registerUserAsFan(String userID, final RegisterUserTypeCallback callback){
        mDatabaseReference = mDatabaseReference.child(userID);
        Map<String,Boolean> map = new HashMap<>();
        map.put("type",true);
        mDatabaseReference.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }

    public void registerUserInterests(String userID, final RegisterUserInterestsCallback callback){
        mDatabaseReference = mDatabaseReference.child(userID);
        Map<String,Boolean> map = new HashMap<>();
        map.put("type",true);
        mDatabaseReference.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful())
                    callback.onSuccess();
                else
                    callback.onFailure();
            }
        });
    }
}
