package com.shaurya.messenger.login.model.repository.local;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginLocalRepository {
    private FirebaseAuth mAuth;

    public LoginLocalRepository() {
        mAuth = FirebaseAuth.getInstance();
    }

    public String getCurrentUserId(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        return currentUser.getUid();
    }
}
