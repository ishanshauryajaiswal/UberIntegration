package com.shaurya.messenger.login.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.shaurya.messenger.R;
import com.shaurya.messenger.login.model.repository.callbacks.LoginUserCallback;
import com.shaurya.messenger.login.model.repository.local.LoginLocalRepository;
import com.shaurya.messenger.login.model.repository.remote.LoginRemoteRepository;
import com.shaurya.messenger.util.SingleLiveEvent;
import com.shaurya.messenger.util.SnackbarMessage;


public class LoginVM extends AndroidViewModel {

    private SingleLiveEvent<Void> navigateToRegisterFragment = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> navigateToHomeActivity = new SingleLiveEvent<>();
    private SnackbarMessage mSnackbarText = new SnackbarMessage();


    private LoginLocalRepository mLocalRepository;
    private LoginRemoteRepository mRemoteRepository;

    public LoginVM(@NonNull Application application) {
        super(application);
        mLocalRepository = new LoginLocalRepository();
        mRemoteRepository = new LoginRemoteRepository();
    }


    public SingleLiveEvent<Void> getNavigateToRegisterFragment() {
        return navigateToRegisterFragment;
    }

    public void navigateToRegisterFragment(){
        navigateToRegisterFragment.call();
    }

    public SingleLiveEvent<Void> getNavigateToHomeActivity() {
        return navigateToHomeActivity;
    }

    public void navigateToHomeActivity(){
        navigateToHomeActivity.call();
    }

    public SnackbarMessage getSnackbarMessage() {
        return mSnackbarText;
    }

    private void showSnackbarMessage(Integer message) {
        mSnackbarText.setValue(message);
    }




    public void loginUser(String email, String password){
        mRemoteRepository.loginUser(email, password, loginUserCallback);
    }

    LoginUserCallback loginUserCallback = new LoginUserCallback() {
        @Override
        public void Success() {
            navigateToHomeActivity();
        }

        @Override
        public void Failure() {
            mSnackbarText.setValue(R.string.some_error_occured);
        }
    };


}
