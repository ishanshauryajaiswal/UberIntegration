package com.shaurya.messenger.home.model.repository.remote;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaurya.messenger.util.DBConstants;

public class HomeRemoteRepository {

    private FirebaseDatabase mDatabase;

    public HomeRemoteRepository() {
        mDatabase = FirebaseDatabase.getInstance();
    }

}
