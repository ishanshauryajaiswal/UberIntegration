package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.ProjectListInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


public class ProjectListTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private ProjectListInterface projectListInterface;

    public ProjectListTask(Context context, ProjectListInterface projectListInterface)
    {

        this.context = context;
        this.projectListInterface = projectListInterface;
    }


    @Override
    protected void onPreExecute()
    {
        projectListInterface.BeforeCompleted();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        try
        {
            RequestCall requestCall = new RequestCall(context);
            result = requestCall.requestJobData(context);
            Log.d(" RESPONSE projectList", result);
        }
        catch(Exception e)
        {
            Log.d("error in ProjectList",e.toString());
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        Log.d("parneet", response);
        projectListInterface.ResultFromProjectListWebservice(response);
        // /RetrieveTimeSheetInterface.RetrieveTimeSheetInterface(response);

    }
}

