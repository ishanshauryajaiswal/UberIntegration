package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 5/1/2018.
 */

public interface SignatureTaskListener {
    void onGetSignatureStarted();

    void onGetSignatureCompleted(String response);
}
