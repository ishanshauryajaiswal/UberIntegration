package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.RecyclerViewClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class FragmentTwo extends Fragment {
    private RelativeLayout rlBack, rlMain;
    private RecyclerView rvStatic, rvDynamic;private int mTouchedRvTag;
    private TextView tvRegTotal, tvOtTotal,tvDotTotal, tvWeek;
    private RvDynamicAdapterDashboard2 rvDynamicAdapter;
    private RvStaticAdapterDashboard2 rvStaticAdapter;
    private String mDate, firstDayOfWeek;
    private TextView headerViews[];
    private LinearLayout footerViews[];
    private FragmentClickListener mListener;
    String mJobCode, mJobName, mJobCompCode, mCrewName, mEmpName;
    private boolean flagJobSelected;
    private List<Dashboard2> mList;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getValuesFromSharedPreference();
        Bundle bundle = getArguments();
        mDate = bundle.getString(getString(R.string.cmic_fragment_extras_date_from_dashboard),null);
        mJobCompCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_comp_code_from_dashboard), null);
        mJobCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_code_from_dashboard), null);
        mJobName = bundle.getString(getString(R.string.cmic_fragment_extras_job_name_from_dashboard),null);
        mCrewName = bundle.getString(getString(R.string.cmic_fragment_extras_crew_name_from_dashboard), null);
        mEmpName = bundle.getString(getString(R.string.cmic_fragment_extras_employee_name_from_dashboard), null);
        flagJobSelected = bundle.getBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),true);
        if (savedInstanceState != null)
            mList = (List<Dashboard2>) savedInstanceState.getSerializable("Dashboard2List");
        //setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_two,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        if (mList == null)
            mListener.retrieveDashboard2Data();
        else
            setUpDashboard(mList);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("Dashboard2List", (ArrayList<Dashboard2>)mList);
    }

    private void initView(View view) {
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        rlMain = (RelativeLayout)view.findViewById(R.id.rlDasboard2);
        rlBack = (RelativeLayout)view.findViewById(R.id.rl_heading_dashboard2);
        TextView tvJob = (TextView)view.findViewById(R.id.tv_job_details_dashboard2);
        if (flagJobSelected)
            tvJob.setText("Job: ".concat(mJobCode).concat("  ").concat(mJobName));
        else
            tvJob.setText("Person: ".concat(mEmpName));
        TextView tvCrewName = (TextView)view.findViewById(R.id.tv_crew_name_dashboard2);
        tvCrewName.setText("Crew: ".concat(mCrewName));
        tvWeek  = (TextView)view.findViewById(R.id.tv_week_dashboard2);
        rvStatic = (RecyclerView)view.findViewById(R.id.rv_static_dashboard2);
        rvDynamic = (RecyclerView)view.findViewById(R.id.rv_dynamic_dashboard2);
        rvStatic.setTag(0);rvDynamic.setTag(1);
        tvRegTotal = (TextView)view.findViewById(R.id.tv_footer_reg_dashboard2);
        tvOtTotal = (TextView)view.findViewById(R.id.tv_footer_ot_dashboard2);
        tvDotTotal = (TextView)view.findViewById(R.id.tv_footer_dot_dashboard2);
        TextView[] textViewsHeader = {(TextView) view.findViewById(R.id.tv_day1_dashboard2),(TextView)view.findViewById(R.id.tv_day2_dashboard2),(TextView)view.findViewById(R.id.tv_day3_dashboard2),(TextView)view.findViewById(R.id.tv_day4_dashboard2),(TextView)view.findViewById(R.id.tv_day5_dashboard2),(TextView)view.findViewById(R.id.tv_day6_dashboard2),(TextView)view.findViewById(R.id.tv_day7_dashboard2)};
        headerViews = textViewsHeader;
        LinearLayout[] linearLayoutsFooter = {(LinearLayout) view.findViewById(R.id.ll_footer_dashboard2_day1),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day2),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day3),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day4),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day5),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day6),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day7)};
        footerViews = linearLayoutsFooter;
        TextView tvBack = (TextView)view.findViewById(R.id.tv_back_dashboard2);tvBack.setTypeface(typeface);
        rlBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onBackPressed();
            }
        });
    }

    public void setUpDashboard(List<Dashboard2> mList){
        this.mList = mList;
        if (mList!=null && mList.size()>0) {
            setUpToolbar();
            setUpHeader();
            rvStatic.clearOnScrollListeners();rvDynamic.clearOnScrollListeners();
            rvStaticAdapter = new RvStaticAdapterDashboard2(mList,getContext(), recyclerViewClickListener);
            rvStatic.setAdapter(rvStaticAdapter);
            rvStatic.setLayoutManager(new LinearLayoutManager(getContext()));
            rvDynamicAdapter = new RvDynamicAdapterDashboard2(mList,getContext(), recyclerViewClickListener);
            rvDynamic.setAdapter(rvDynamicAdapter);
            rvDynamic.setLayoutManager(new LinearLayoutManager(getContext()));
            rvStatic.addOnScrollListener(custom_scroll_listner);rvDynamic.addOnScrollListener(custom_scroll_listner);
            rvStatic.addOnItemTouchListener(custom_item_touch_listner);rvDynamic.addOnItemTouchListener(custom_item_touch_listner);
            calculateFooter(mList);
        }
        else{
            final AlertDialog.Builder alertBox = new AlertDialog.Builder(getContext());
            alertBox.setTitle("CMiC Mobile Crew Time");
            alertBox.setMessage("No Data Present For This Date");
            alertBox.setPositiveButton("GO BACK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mListener.onBackPressed();
                }
            });
            alertBox.show();
        }
    }

    private void setUpToolbar(){
        int year = Integer.parseInt(mDate.split("\\-")[0]);
        int month = Integer.parseInt(mDate.split("\\-")[1]);
        int day = Integer.parseInt(mDate.split("\\-")[2]);
        Calendar cal = Calendar.getInstance();
        cal.set(year, month-1, day);
        cal.add(Calendar.DAY_OF_WEEK, -6);
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = sdfDate.format(cal.getTime());
        tvWeek.setText(mDate+" TO "+startDate);
    }

    private void setUpHeader(){
        List<String> week = CollectionUtils.getWeek(firstDayOfWeek);
        for (int i=0;i<headerViews.length;i++)
            headerViews[i].setText(week.get(i));
    }

    private void calculateFooter(List<Dashboard2> list){
        List<AllTimes> totalAllTimesList = new ArrayList<>();
        for (int i=0;i<7;i++)
            totalAllTimesList.add(new AllTimes());
        for (int j=0;j<list.size();j++){
            Dashboard2 dashboard2 = list.get(j);
            List<AllTimes> allTimesList = dashboard2.getTimesList();
            for (int i = 0; i < allTimesList.size(); i++){
                totalAllTimesList.get(i).setReg(totalAllTimesList.get(i).getReg()+allTimesList.get(i).getReg());
                totalAllTimesList.get(i).setOt(totalAllTimesList.get(i).getOt()+allTimesList.get(i).getOt());
                totalAllTimesList.get(i).setDot(totalAllTimesList.get(i).getDot()+allTimesList.get(i).getDot());
            }
        }
        for (int j=0;j<list.size();j++) {
            TextView regTotal = (TextView)footerViews[j].getChildAt(0);
            TextView otTotal = (TextView)footerViews[j].getChildAt(1);
            TextView dotTotal = (TextView)footerViews[j].getChildAt(2);
            regTotal.setText(String .valueOf(totalAllTimesList.get(j).getReg()));
            otTotal.setText(String .valueOf(totalAllTimesList.get(j).getOt()));
            dotTotal.setText(String .valueOf(totalAllTimesList.get(j).getDot()));
        }
        AllTimes allTimesTotalStaticFooter = new AllTimes();
        for (int i=0;i<7;i++){
            allTimesTotalStaticFooter.setReg(allTimesTotalStaticFooter.getReg()+totalAllTimesList.get(i).getReg());
            allTimesTotalStaticFooter.setOt(allTimesTotalStaticFooter.getOt()+totalAllTimesList.get(i).getOt());
            allTimesTotalStaticFooter.setDot(allTimesTotalStaticFooter.getDot()+totalAllTimesList.get(i).getDot());
        }
        tvRegTotal.setText(String.valueOf(allTimesTotalStaticFooter.getReg()));
        tvOtTotal.setText(String.valueOf(allTimesTotalStaticFooter.getOt()));
        tvDotTotal.setText(String.valueOf(allTimesTotalStaticFooter.getDot()));
    }


    void getValuesFromSharedPreference(){
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        firstDayOfWeek = defaultSharedPreferences.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
    }

    public static FragmentTwo getInstance(Bundle bundle){
        FragmentTwo fragmentTwo = new FragmentTwo();
        fragmentTwo.setArguments(bundle);
        return fragmentTwo;
    }

    private RecyclerViewClickListener recyclerViewClickListener= new RecyclerViewClickListener() {
        @Override
        public void onRecyclerViewRowClicked(String crewCode, String crewName, int week) {
        }

        @Override
        public void onRecyclerViewDashboard2RowClicked(String empNumber, String empName) {
            mListener.onCrewMemberSelectedDashboard2(empNumber, empName);
        }
    };

    private RecyclerView.OnScrollListener custom_scroll_listner = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if ((int) recyclerView.getTag() == mTouchedRvTag) {
                for (int noOfRecyclerView = 0; noOfRecyclerView < 2; noOfRecyclerView++) {
                    if (noOfRecyclerView != (int) recyclerView.getTag()) {
                        RecyclerView tempRecyclerView = (RecyclerView) rlMain.findViewWithTag(noOfRecyclerView);
                        tempRecyclerView.scrollBy(dx, dy);
                    }
                }
            }
        }
    };

    private RecyclerView.OnItemTouchListener custom_item_touch_listner = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            mTouchedRvTag = (int) rv.getTag();
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    };
}
