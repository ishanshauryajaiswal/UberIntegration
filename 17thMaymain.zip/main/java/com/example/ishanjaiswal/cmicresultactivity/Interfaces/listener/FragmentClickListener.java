package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface FragmentClickListener {
    void retrieveDashboardData(String date);
    void retrieveCrewMemberData();
    void retrieveJobData();
    void onCrewMemberSelected(String crewCode, String crewName, String date);
    void retrieveDashboard2Data();
    void retrieveDashboard3Data();
    void onBackPressed();
    void setFlag(boolean flagJobSelected);
    void setJob(String jobcCompCode, String jobCode, String jobName);
    void setEmployee(String employeeName);
    void onCrewMemberSelectedDashboard2(String empNumber, String empName);

    void retrieveSignatures( String empNumber, String startDate, String endDate);
    void postSignature(String empOraSeq, String startDate, String endDate, String encodedImage, Signature signatureEnum);
}
