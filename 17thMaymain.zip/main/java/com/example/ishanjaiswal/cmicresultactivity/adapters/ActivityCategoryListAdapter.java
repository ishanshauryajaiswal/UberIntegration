package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;


import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CategoryDetails;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by parneet.singh on 2/16/2017.
 */
public class ActivityCategoryListAdapter extends BaseAdapter implements Filterable
{

    private ArrayList<CategoryDetails> CategoryDetails;
    private Context context;
    private LayoutInflater mInflater;
    private List<PhaseModal>filteredData = null;
    private ItemFilter mFilter = new ItemFilter();
    public ActivityCategoryListAdapter(Context context, ArrayList<CategoryDetails> CategoryDetails)
    {
        this.context = context;
        this.CategoryDetails = CategoryDetails;
    }

    @Override
    public int getCount()
    {
        if(CategoryDetails!=null)
            return CategoryDetails.size();
        return 0;
    }
    public  void  setList(ArrayList<CategoryDetails> list)
    {
        CategoryDetails = list;
        notifyDataSetChanged();
    }

    @Override
    public CategoryDetails getItem(int position)
    {
        return CategoryDetails.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        CategoryDetails CategoryDetailsObj = CategoryDetails.get(position);
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listViewItem = inflater.inflate(R.layout.activity_phase_details, null);
        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtPhaseDetails);
        // final EditText search =(EditText) listViewItem.findViewById(R.id.search);
      /*  search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setFocusableInTouchMode(true);
                search.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        context.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);

            }
        });*/
        txt_project.setText("("+CategoryDetailsObj.getCategoryCode() +") - "+ CategoryDetailsObj.getCategoryName());
        return listViewItem;
    }



    @Override
    public Filter getFilter()
    {
        return mFilter;
    }

    // Searching On basis of every property Of PhaseDetails
    private class ItemFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterString = constraint.toString().toLowerCase();
            FilterResults results = new FilterResults();
            final List<CategoryDetails> list = CategoryDetails;
            int count = list.size();
            final ArrayList<CategoryDetails> nlist = new ArrayList<CategoryDetails>(count);
            CategoryDetails CategoryDetails ;
            for (int i = 0; i < count; i++)
            {
                CategoryDetails = list.get(i);
                if (CategoryDetails.getCategoryJobCode().equals(filterString)||CategoryDetails.getCategoryName().equals(filterString))
                {
                    nlist.add(CategoryDetails);
                }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }
        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredData = (ArrayList<PhaseModal>) results.values;
            notifyDataSetChanged();

        }
    }
}
