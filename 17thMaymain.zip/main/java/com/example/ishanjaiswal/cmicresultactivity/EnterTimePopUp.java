package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CustomClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;

/**
 * Created by ishan.jaiswal on 5/10/2018.
 */

public class EnterTimePopUp extends Dialog {
    private Context mContext;
    private CustomClickListener mCustomClickListener;
    private CrewTimeSheet mCrewTimeSheet;
    private int mRowNumber, mActivityColumnNumber;
    private SharedPreferences defaultSharedPreference;
    private double maxRegTimeFromSettings, maxOtTimeFromSettings;

    private TextView tvCancel, tvPlusRegTime, tvPlusOtTime, tvPlusDotTime, tvMinusRegTime, tvMinusOtTime, tvMinusDotTime;
    private EditText etRegTime, etOtTime, etDotTime;
    private Button btnDone;
    private double regTime, otTime, dotTime;

    public EnterTimePopUp(@NonNull Context context , CustomClickListener customClickListener, CrewTimeSheet crewTimeSheet, int rowNumber, int activityColumnNumber) {
        super(context);
        mContext = context;
        mCustomClickListener = customClickListener;
        mCrewTimeSheet = crewTimeSheet;
        mRowNumber = rowNumber;
        mActivityColumnNumber = activityColumnNumber;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup);
        initViews();
        defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(mContext);
        maxRegTimeFromSettings = Double.parseDouble(defaultSharedPreference.getString(mContext.getString(R.string.settings_key_max_normal_time), mContext.getString(R.string.settings_normal_time_default)));
        maxRegTimeFromSettings = Double.parseDouble(defaultSharedPreference.getString(mContext.getString(R.string.settings_key_over_time), mContext.getString(R.string.settings_over_time_default)));
        regTime = mCrewTimeSheet.getEmpTimeSheet().get(rowNumber).getTimeSheet().get(activityColumnNumber).getStandardTime();
        otTime = mCrewTimeSheet.getEmpTimeSheet().get(rowNumber).getTimeSheet().get(activityColumnNumber).getOverTime();
        dotTime = mCrewTimeSheet.getEmpTimeSheet().get(rowNumber).getTimeSheet().get(activityColumnNumber).getDoubleOverTime();
    }

    private void initViews() {
        tvCancel = (TextView) findViewById(R.id.cancel);
        tvPlusRegTime = (TextView) findViewById(R.id.txtplusst);
        tvPlusOtTime = (TextView) findViewById(R.id.txtplusot);
        tvPlusDotTime = (TextView) findViewById(R.id.txtplusdot);
        tvMinusRegTime = (TextView) findViewById(R.id.txtminusst);
        tvMinusOtTime = (TextView) findViewById(R.id.txtminusot);
        tvMinusDotTime = (TextView) findViewById(R.id.txtminusdot);
        btnDone = (Button) findViewById(R.id.btndone);
        etRegTime = (EditText) findViewById(R.id.etst);
        etOtTime = (EditText) findViewById(R.id.etot);
        etDotTime = (EditText) findViewById(R.id.etdot);

        etRegTime.setText(String.valueOf(regTime));
        etOtTime.setText(String.valueOf(otTime));
        etDotTime.setText(String.valueOf(dotTime));

        Typeface typeface = Typeface.createFromAsset(mContext.getAssets(),"fonts/cmic_icons.ttf");;
        tvCancel.setTypeface(typeface);
        tvPlusRegTime.setTypeface(typeface);
        tvPlusOtTime.setTypeface(typeface);
        tvPlusDotTime.setTypeface(typeface);
        tvMinusRegTime.setTypeface(typeface);
        tvMinusOtTime.setTypeface(typeface);
        tvMinusDotTime.setTypeface(typeface);

        tvPlusRegTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                regTime+= 0.5;
                etRegTime.setText(String.valueOf(regTime));
            }
        });

        tvPlusOtTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otTime+=  0.5;
                etOtTime.setText(String.valueOf(otTime));
            }
        });

        tvPlusDotTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dotTime+= 0.5;
                etDotTime.setText(String.valueOf(dotTime));

            }
        });

        tvMinusRegTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (regTime > 0) {
                    regTime = regTime - 0.5;
                    etRegTime.setText(String.valueOf(regTime));
                }

            }
        });
        tvMinusOtTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (otTime > 0) {
                    otTime = otTime - 0.5;
                    etOtTime.setText(String.valueOf(otTime));
                }
            }
        });
        tvMinusDotTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (dotTime > 0) {
                    dotTime = dotTime - 0.5;
                    etDotTime.setText(String.valueOf(dotTime));
                }
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        etRegTime.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                etRegTime.setFocusable(true);
                etRegTime.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
                return false;
            }
        });
        etOtTime.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                etOtTime.setFocusable(true);
                etOtTime.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
                return false;
            }
        });

        etDotTime.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                etDotTime.setFocusable(true);
                etDotTime.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
                return false;
            }
        });

        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCrewTimeSheet.getEmpTimeSheet().get(mRowNumber).getTimeSheet().get(mActivityColumnNumber).setStandardTime(regTime);
                mCrewTimeSheet.getEmpTimeSheet().get(mRowNumber).getTimeSheet().get(mActivityColumnNumber).setOverTime(otTime);
                mCrewTimeSheet.getEmpTimeSheet().get(mRowNumber).getTimeSheet().get(mActivityColumnNumber).setDoubleOverTime(dotTime);
                mCrewTimeSheet.setEdited(true);
                mCustomClickListener.enterTimePopUpDone(mCrewTimeSheet);
                dismiss();
            }
        });

        checkFlagsForEdit(true, false);
    }

    private void checkFlagsForEdit(boolean flagOt, boolean flagDot) {
        if (!flagOt){
            tvPlusOtTime.setEnabled(false);
            tvPlusOtTime.setBackgroundColor(ContextCompat.getColor(mContext,R.color.colorDarkGreyButton));
            tvMinusOtTime.setEnabled(false);
            tvMinusOtTime.setBackgroundColor(ContextCompat.getColor(mContext,R.color.colorDarkGreyButton));
        }
        if (!flagDot){
            tvPlusDotTime.setEnabled(false);
            tvPlusDotTime.setBackgroundColor(ContextCompat.getColor(mContext,R.color.colorDarkGreyButton));
            tvMinusDotTime.setEnabled(false);
            tvMinusDotTime.setBackgroundColor(ContextCompat.getColor(mContext,R.color.colorDarkGreyButton));
        }
    }
}
