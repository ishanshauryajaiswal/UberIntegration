package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;


import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CrewListTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 Created by parneet.singh on 10/26/2016.
 */
public class CrewListActivityTask extends AsyncTask<Void,Void,String>
{
    private static final String TAG = CrewListActivityTask.class.getSimpleName();
    private Context context;
    private CrewListTaskListener crewListTaskListener;
    public CrewListActivityTask(Context context,CrewListTaskListener crewListTaskListener)
    {
        this.context = context;
        this.crewListTaskListener = crewListTaskListener;
    }

    @Override
    protected void onPreExecute()
    {
        crewListTaskListener.onPreCrewListTask();
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall(context);
        response = requestCall.selectCrewList(context);
        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        crewListTaskListener.onPostCrewListTask(response);
    }
}
