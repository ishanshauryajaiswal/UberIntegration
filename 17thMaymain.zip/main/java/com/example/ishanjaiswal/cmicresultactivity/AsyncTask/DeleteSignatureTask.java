package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

/**
 * Created by ishan.jaiswal on 5/1/2018.
 */

public class DeleteSignatureTask extends AsyncTask<Void,Void,String> {

    Context mContext;
    DashboardTaskListener mListener;
    String empOraSeq;
    String tshFromDate;
    String tshToDate;
    Signature enumSignature;

    public DeleteSignatureTask(Context mContext, DashboardTaskListener mListener, String empOraSeq, String tshFromDate, String tshToDate, Signature enumSignature) {
        this.mContext = mContext;
        this.mListener = mListener;
        this.empOraSeq = empOraSeq;
        this.tshFromDate = tshFromDate;
        this.tshToDate = tshToDate;
        this.enumSignature = enumSignature;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.onPostSignatureTaskStarted("Deleting Signature");
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(mContext);
                response = requestCall.deleteSignature(mContext, empOraSeq, tshFromDate, tshToDate, enumSignature);
                return response;
            } catch (Exception e) {
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String response) {
        if (!isCancelled()) {
            super.onPostExecute(response);
            mListener.onPostSignatureTaskCompleted(response, enumSignature);
        }
    }

    @Override
    protected void onCancelled() {
        mListener.onTaskCancelled();
        super.onCancelled();
    }
}
