package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

/**
 * Created by parneet.singh on 8/31/2016.
 */
public class CrewListDBHelper
{
    static DatabaseConstants databaseCostants = new DatabaseConstants();
    SQLiteDatabase db;
    Context context;

    DBHelper mdb;
    public CrewListDBHelper(Context context)
    {
        this.context=context;
        mdb = new DBHelper(context);
        db = mdb.getWritableDatabase();
    }
    public boolean insertCrew(String crewCode,String crewName,String crewOraseq)
    {
        Log.d("crewCode", crewCode);
        Log.d("jobcompcode", crewName);
        Log.d("jobName", crewOraseq);
        try
        {
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.PycrCode, crewCode);
            contentValues.put(databaseCostants.PycrName, crewName);
            contentValues.put(databaseCostants.PycrOraseq, crewOraseq);
            db.insertOrThrow(databaseCostants.TABLE_CREW_LIST, null, contentValues);
            Log.d("InsertedCrewList", "Successfull");
            // onCreate(db);
        }
        catch (SQLiteException e)
        {
            Log.d("insertedError",e.toString());
            return false;

        }
        catch (Exception e){
            Log.d("InsertedError",e.toString());
            return false;
        }

        return true;
    }

    public boolean dropSelectedJobs()
    {
        try
        {
            // SQLiteDatabase db = this.getReadableDatabase();
            db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_CREW_LIST);
            return true;
        }
        catch(Exception e)
        {
            Log.d("error",e.toString());
            return false;
        }
    }

    public ArrayList<InsertCrew> selectAllCrewList()
    {
        //insertSelectedJobs("2","23","demo");
        ArrayList<InsertCrew> array_list = new ArrayList();
        try
        {
            // SQLiteDatabase db = this.getReadableDatabase();
            Cursor res =  db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_CREW_LIST, null);
            res.moveToFirst();
            while(res.isAfterLast() == false){
                InsertCrew insertCrew = new InsertCrew();
                insertCrew.setPycrName(res.getString(res.getColumnIndex(databaseCostants.PycrName)));
                insertCrew.setPycrCode(res.getString(res.getColumnIndex(databaseCostants.PycrCode)));
                insertCrew.setPycrOraseq(res.getString(res.getColumnIndex(databaseCostants.PycrOraseq)));
                array_list.add(insertCrew);
                //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
                res.moveToNext();
            }

            for (int i=0;i<array_list.size();i++){
                //  Log.d("jobdata",array_list.get(i).getJobname());
                //  Log.d("jobcompcode",array_list.get(i).getJobcompcode());
                //  Log.d("jobcode",array_list.get(i).getJobcode());
            }
            return array_list;
        }
        catch(Exception e)
        {
            Log.d("error in jobdata",e.toString());
            return null;
        }
    }
    public boolean selectedCrewOraseq(String selectedOraseq)
    {
        try {
            Log.d("selectedOraseq",selectedOraseq);
            // db = this.getReadableDatabase();
            Cursor cur = db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_CREW_LIST + " WHERE crewOraseq = '" + selectedOraseq + "'", null);
            boolean exist = (cur.getCount() > 0);
            cur.close();

            return exist;
        }
        catch (Exception e)
        {
            Log.d("Exception","database");
            return false;
        }

    }
    public String selectCrewOraseq(String selectedOraseq)
    {
        //insertSelectedJobs("2","23","demo");
        String array_list = new String();
        try
        {
            // SQLiteDatabase db = this.getReadableDatabase();
            Cursor res =  db.rawQuery("SELECT " + databaseCostants.PycrOraseq + " FROM " + databaseCostants.TABLE_CREW_LIST + " where " + databaseCostants.Username + " = '" + selectedOraseq + "'", null);
            res.moveToFirst();
            while(res.isAfterLast() == false){
                //array_list.add()
                InsertCrew insertCrew = new InsertCrew();
                //  insertCrew.setPycrName(res.getString(res.getColumnIndex(databaseCostants.PycrName)));
                // insertCrew.setPycrCode(res.getString(res.getColumnIndex(databaseCostants.PycrCode)));
                // insertCrew.setPycrOraseq(res.getString(res.getColumnIndex(databaseCostants.PycrOraseq)));
                // array_list.add(insertCrew);
                //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
                res.moveToNext();
            }


            return array_list;
        }
        catch(Exception e)
        {
            Log.d("error in jobdata",e.toString());
            return null;
        }
    }


}
