package com.example.ishanjaiswal.cmicresultactivity;

import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseWithChild;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class PhaseWithChildParser


{

    HashMap<String, String> responseMap = new HashMap<>();
    HashMap<String, HashMap<String, String>> masters = new HashMap<>();
    ArrayList<String> MasterRow = new ArrayList<>();
    ArrayList<String> ChildRows = new ArrayList<>();
    HashMap<String, HashMap<String, String>> child = new HashMap<>();
    ArrayList<PhaseWithChild> list = new ArrayList();


    public ArrayList<PhaseModal> parsePhaseJsonData(String response)
    {
        ArrayList<PhaseModal> phaseModalArrayList = new ArrayList<>();
        try {
            Log.d("ResponseParsernew", response);
            JSONObject jsonObject = new JSONObject(response);
            String table = jsonObject.getString("table");
            JSONObject rowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray attrNamesJsonArray = rowDefinition.getJSONArray("attrNames");

            JSONArray mainRows = jsonObject.getJSONArray("rows");
            // JSONArray mainrowsJsonArray = mainRows.getJSONArray()
            for (int i = 0; i < mainRows.length(); i++) {
                JSONObject objectInMainRows = mainRows.getJSONObject(i);
                JSONObject masterRowObject = objectInMainRows.getJSONObject("masterRow");
                JSONArray attarValuesInMasterRow = masterRowObject.getJSONArray("attrValues");
                String compCode = attarValuesInMasterRow.getString(0);
                String jobCode = attarValuesInMasterRow.getString(1);
                String phaseCode = attarValuesInMasterRow.getString(2);
                String phaseName = attarValuesInMasterRow.getString(3);
                PhaseModal phaseModal = new PhaseModal(compCode, jobCode, phaseCode, phaseName);
                phaseModalArrayList.add(phaseModal);
            }
        } catch (Exception e) {
            Log.d("Error in GetPhaseTask", e.toString());
        }
        return phaseModalArrayList;
    }

    public ArrayList<PhaseWithChild> parseCategoryJsonData(String response)
    {
        ArrayList<PhaseWithChild> phaseWithChildArrayList = new ArrayList<>();
        try {
            Log.d("ResponseParsernew", response);
            JSONObject jsonObject = new JSONObject(response);
            String table = jsonObject.getString("table");
            JSONArray childRowDefination = jsonObject.getJSONArray("childRowDefinitions");
            for (int i = 0; i < childRowDefination.length(); i++) {
                JSONObject objectChildRowDefination = childRowDefination.getJSONObject(i);
                String tableName = jsonObject.getString("table");
                JSONObject rowDefinationobject = objectChildRowDefination.getJSONObject("rowDefinition");
                JSONArray attrNames = rowDefinationobject.getJSONArray("attrNames");
            }

            JSONArray mainRows = jsonObject.getJSONArray("rows");
            for (int i = 0; i < mainRows.length(); i++) {
                Log.d("main rows ", String.valueOf(mainRows.length()));
                JSONObject objectInRows = mainRows.getJSONObject(i);
                JSONArray childRowsArray = objectInRows.getJSONArray("childRows");
                for (int j = 0; j < childRowsArray.length(); j++) {
                    Log.d("childrowlength", String.valueOf(childRowsArray.length()));
                    JSONObject objectInChildRows = childRowsArray.getJSONObject(j);
                    JSONArray rowsInChildRows = objectInChildRows.getJSONArray("rows");
                    for (int k = 0; k < rowsInChildRows.length(); k++) {
                        if (rowsInChildRows != null && rowsInChildRows.length() > 0) {
                            Log.d("rowsInChildRows", String.valueOf(rowsInChildRows.length()));
                            JSONObject objectInrowsInChildRows = rowsInChildRows.getJSONObject(k);
                            JSONArray attrValues = objectInrowsInChildRows.getJSONArray("attrValues");
                            if (attrValues != null && attrValues.length() > 0) {
                                Log.d("attrs Child rows", String.valueOf(attrValues.length()));
                                String JcatCompCode = attrValues.getString(0);
                                String JcatJobCode = attrValues.getString(1);
                                String JcatPhsCode = attrValues.getString(2);
                                String JcatCode = attrValues.getString(3);
                                String CatName = attrValues.getString(4);
                                PhaseWithChild phaseWithChildModal = new PhaseWithChild(JcatJobCode, JcatCode, CatName, JcatPhsCode, JcatCompCode);
                                phaseWithChildArrayList.add(phaseWithChildModal);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.d("Error in category", e.toString());
        }
        return phaseWithChildArrayList;
    }
}
