package com.example.ishanjaiswal.cmicresultactivity.Database;

/**
 * Created by parneet.singh on 8/29/2016.
 */
public class DatabaseConstants
{
    private static final int DATABASE_VERSION = 1;
    //DATABASE NAME
    public static final String DATABASE_NAME = "CMiCMobileCrewTimeDB";

    //TABLES NAME
    public static final String TABLE_USER = "User";
    public static final String TABLE_SELECTED_JOBS = "SelectedJobs";
    public static final String TABLE_CATEGORY = "Category";
    public static final String TABLE_PHASE = "GetPhaseTask";
    public static final String TABLE_EMPLOYEE= "Employee_Demo";
    public static final String TABLE_CREW_DETAILS = "CrewDetails";
    public static final String TABLE_EMPLOYEE_LINKING_CREW = "CrewEmployee";
    public static final String CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES = "insertingSelectedEmployees";
    public static final String TABLE_SUBMITTED_TIME_CREW = "SubmittedTimeCrew";
    public static final String TABLE_EMPLOYEE_DATA_FOR_CREW = "EmployeeDataForCrew";
    public static final String TABLE_SUBMITTED_ACTIVITY_FROM_CREW = "SubmittedActivityFromCrew";
    public static final String TABLE_ACTIVITY_TIME_FOR_CREW = "ActivityTimeForCrew";
    public static final String TABLE_CREW_LIST = "CrewList";
    public static final String TABLE_DASHBOARD = "Dashboard";
    public static final String TABLE_DASHBOARD_CREW_MEMBERS = "DashboardCrewMembers";
    public static final String TABLE_DASHBOARD_CREW_MEMBERS_DETAILS = "DashboardCrewMembersDetail";

    public static final String TABLE_SUBMITTED_TIMESHEET = "SubmittedTimesheet";
    public static final String TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET = "SubmittedActivityForTimesheet";
    public static final String TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW= "SubmittedEmployeeDataForCrew";
    public static final String TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE = "SubmittedActivityTimeForCrew";
    public static final String TABLE_SUBMITTED_TIME_IN_OUT = "SubmittedTimeInOut";



    //User Table - column names
    public static final String Username = "Username";
    public static final String Password = "Password";

    //SelectedJobs Table - column names
    public static final String jobcode = "jobcode";
    public static final String jobcompcode = "jobcompcode";
    public static final String jobname = "jobname";

    //Category Table - column names
    public static final String categoryname = "categoryname";
    public static final String categorycode = "categorycode";
    public static final String categoryphasecode = "categoryphasecode";
    public static final String categoryjobcode ="categoryjobcode";

    //GetPhaseTask Table - column names
    public static final String phasejobcode = "jobcode";
    public static final String phasecode = "phasecode";
    public static final String phasename = "phasename";
    public static final String phasecompcode = "phasecompcode";

    //Employee Table
    public static final String empname = "empname";
    public static final String empcode = "empcode";
    public static final String pkey = "pkey";
    public static final String empusername = "empusername";

    //CrewDetails
    public static final String crewname = "crewname";
    public static final String crewcode ="crewcode";
    public static final String creworaseq ="creworaseq";

    //Linking Crew with Employee
    public static final String pycecreworaseq = "PyceCrewOraseq";
    public static final String pycecrewcode ="PyceCrewCode";
    public static final String pycecrewname ="PyceCrewName";
    public static final String pyceemporaseq = "PyceEmpOraseq";
    public static final String pyceempno ="PyceEmpNo";
    public static final String pyceoraseq ="PyceOraseq";
    public static final String pyceempname ="PyceEmpName";
    public static final String pycetrdcode ="PyceTrdCode";
    public static final String pycetrdname ="PyceTrdName";


    //Inserting Selected Employees
    public static final String pyelEmpNumber = "PyelEmpNo";
    public static final String pyelEmpOraseq ="PyelEmpOraseq";
    public static final String pyelEmpName ="PyelEmpName";
    public static final String pyelAccessCode = "PyelAccessCode";
    public static final String pyelCompName ="PyelCompName";
    public static final String pyelPrnCode ="PyelPrnCode";
    public static final String pyelPrnName ="PyelPrnName";
    public static final String pyelCompCode = "PyelCompCode";
    public static final String pyelTrdCode = "PyelTrdCode";
    public static final String pyelTrdName = "PyelTrdName";
    public static final String pyelUniCode = "PyelUniCode";
    public static final String pyelUniName = "PyelUniName";

    //submittedTimeCrew
    public static final String seqNumber = "SequenceNumber";
    public static final String workDate = "WorkDate";

    public static final String deleteFlag = "DeleteFlag";
    //EmployeeForCrew
    public static final String employeeNumber = "EmployeeNumber";
    public static final String rowNumber = "RowNumber";

    //SubmittedActivityforCrew
    public static final String WBSCode = "WBSCode";
    public static final String columnNumber = "ColumnNumber";
    public static final String activityName = "ActivityName";
    public static final String PcilineOraseq = "PcilineOraseq";

    //ActivtyTimeForCrew
    public static final String otseqNumber = "OtSeqNumber";
    public static final String dothour = "DotHour";
    public static final String rtSeqNumber = "RtSeqNumber";
    public static final String rtHours = "Rthours";
    public static final String dotSeqNumber = "DotSeqNumber";
    public static final String otHour = "OtHour";

    //CrewList
    public static final String PycrCode = "CrewCode";
    public static final String PycrName = "CrewName";
    public static final String PycrOraseq = "crewOraseq";


    //TABLE SUBMITTED TIMESHEET
    public static final String CrewCode_SubmittedTimesheet = "CrewCode";
    public static final String JobCode_SubmittedTimesheet = "JobCode";
    public static final String SeqNo_SubmittedTimesheet = "SeqNo";
    public static final String WorkDate_SubmittedTimesheet = "WorkDate";

    //TABLE SUBMITTED ACTIVITY FOR TIMESHEET
    public static final String ActivityName_SubmittedaActivityForTimeSheet = "ActivityName";
    public static final String CategoryCode_SubmittedaActivityForTimeSheet  = "CategoryCode";
    public static final String ColoumnNumber_SubmittedaActivityForTimeSheet = "ColoumnNumber";
    public static final String CrewCode_SubmittedaActivityForTimeSheet  = "CrewCode";
    public static final String JobCode_SubmittedaActivityForTimeSheet = "JobCode";
    public static final String PciLineOraseq_SubmittedaActivityForTimeSheet  = "PciLineOraseq";
    public static final String PhaseCode_SubmittedaActivityForTimeSheet = "PhaseCode";
    public static final String SeqNumber_SubmittedaActivityForTimeSheet  = "SeqNumber";
    public static final String WbsCode_SubmittedaActivityForTimeSheet = "WbsCode";
    public static final String WorkDate_SubmittedaActivityForTimeSheet  = "WorkDate";



    //TABLE SUBMITTED EMPLOYEE DATA FOR CREW
    public static final String CrewCode_SubmittedEmployeeDataForCrew = "CrewCode";
    public static final String EmployeeName_SubmittedEmployeeDataForCrew  = "EmployeeName";
    public static final String EmployeeNumber_SubmittedEmployeeDataForCrew  = "EmployeeNumber";
    public static final String EmployeeOraseq_SubmittedEmployeeDataForCrew = "EmployeeOraseq";
    public static final String EmployeeTradeCode_SubmittedEmployeeDataForCrew  = "EmployeeTradeCode";
    public static final String EmployeeTradeName_SubmittedEmployeeDataForCrew  = "EmployeeTradeName";
    public static final String JobCode_SubmittedEmployeeDataForCrew  = "JobCode";
    public static final String RowNumber_SubmittedEmployeeDataForCrew  = "RowNumber";
    public static final String WorkDate_SubmittedEmployeeDataForCrew  = "WorkDate";

    //RETRIEVE SUBMITTED ACTIVITY FOR EMPLOYEE
    public static final String ActivityName_SubmittedActivityTimeForEmployee = "ActivityName";
    public static final String ColoumnNumber_SubmittedActivityTimeForEmployee  = "ColoumnNumber";
    public static final String Dothours_SubmittedActivityTimeForEmployee  = "DotHours";
    public static final String DotSeqNumber_SubmittedActivityTimeForEmployee = "DotSeqNumber";
    public static final String EmployeeNumber_SubmittedActivityTimeForEmployee = "EmployeeNumber";
    public static final String OtHours_SubmittedActivityTimeForEmployee  = "OtHours";
    public static final String OtSeqNumber_SubmittedActivityTimeForEmployee  = "OtSeqNumber";
    public static final String RtHours_SubmittedActivityTimeForEmployee = "Rthours";
    public static final String RtSeqNumber_SubmittedActivityTimeForEmployee = "RtSeqNumber";

    public static final String CrewCode_SubmittedActivityTimeForEmployee  = "CrewCode";
    public static final String JobCode_SubmittedActivityTimeForEmployee = "JobCode";
    public static final String WorkDate_SubmittedActivityTimeForEmployee = "WorkDate";


    //SUBMITTED TIME IN OUT

    public static final String ActivityName_SubmittedTimeInOut  = "ActivityName";
    public static final String CrewCode_SubmittedTimeInOut  = "CrewCode";
    public static final String EmployeeNumber_SubmittedTimeInOut  = "EmployeeNumber";
    public static final String InOutIndex_SubmittedTimeInOut  = "InOutIndex";
    public static final String IsGlobal_SubmittedTimeInOut  = "IsGlobal";
    public static final String JobCode_SubmittedTimeInOut  = "JobCode";
    public static final String TimeIn_SubmittedTimeInOut  = "TimeIn";
    public static final String TimeOut_SubmittedTimeInOut  = "TimeOut";
    public static final String TotalInOutForEmployee_SubmittedTimeInOut  = "TotalInOutForEmployee";
    public static final String WorkDate_SubmittedTimeInOut  = "WorkDate";




    //Dashboard
    public static final String DashboardDate = "Date";
    public static final String DashboardWeek = "Week";
    public static final String DashboardJobAcsCode ="JobAcsCode";
    public static final String DashboardJobCompCode ="JobCompCode";
    public static final String DashboardJobCode = "JobCode";
    public static final String DashboardPycrCode ="PycrCode";
    public static final String DashboardPycrName ="PycrName";
    public static final String DashboardEmpNo ="EmpNo";
    public static final String DashboardEmpTrdCode = "EmpTrdCode";
    public static final String DashboardEmpTrdName = "EmpTrdName";
    public static final String DashboardEmpFirstName = "EmpFirstName";
    public static final String DashboardEmpLastName = "EmpLastName";
    public static final String DashboardprevNhHrs = "prevNhHrs";
    public static final String DashboardprevOtHrs = "prevOtHrs";
    public static final String DashboardprevDotHrs = "prevDotHrs";
    public static final String DashboardNhHrs = "NhHrs";
    public static final String DashboardOtHrs = "OtHrs";
    public static final String DashboardDotHrs = "DotHrs";

    //DashboardCrew
    public static final String Date = "Date";
    public static final String Week = "Week";
    public static final String JobAcsCode ="JobAcsCode";
    public static final String JobCompCode ="JobCompCode";
    public static final String dashboardJobCode = "JobCode";
    public static final String dashboardPycrCode ="PycrCode";
    public static final String dashboardPycrName ="PycrName";
    public static final String EmpNo ="EmpNo";
    public static final String EmpTrdCode = "EmpTrdCode";
    public static final String EmpTrdName = "EmpTrdName";
    public static final String EmpFirstName = "EmpFirstName";
    public static final String EmpLastName = "EmpLastName";
    public static final String prevNhHrs = "prevNhHrs";
    public static final String prevOtHrs = "prevOtHrs";
    public static final String prevDotHrs = "prevDotHrs";
    public static final String NhHrs = "NhHrs";
    public static final String OtHrs = "OtHrs";
    public static final String DotHrs = "DotHrs";

    //DashboardCrewMembers

    public static final String TshEmpNoDetail ="JobAcsCode";
    public static final String TshWorkcompCodeDetail ="JobCompCode";
    public static final String TshjobcodeDetail = "JobCode";
    public static final String TshPhaseDetail ="PycrCode";
    public static final String PyCrCodeDetail ="PycrName";
    public static final String PyCrNameDetail ="PycrName";
    public static final String EmpFirstNameDetail = "EmpFirstName";
    public static final String EmpLastNameDetail = "EmpLastName";
    public static final String NhHrsTot = "NhHrsTot";
    public static final String OtHrsTot = "OtHrsTot";
    public static final String DotHrsTot = "DotHrsTot";
    public static final String NhHrs1 = "NhHrs1";
    public static final String OtHrs1 = "OtHrs1";
    public static final String DotHrs1 = "DotHrs1";
    public static final String NhHrs2 = "NhHrs2";
    public static final String OtHrs2 = "OtHrs2";
    public static final String DotHrs2 = "DotHrs2";
    public static final String NhHrs3 = "NhHrs3";
    public static final String OtHrs3 = "OtHrs3";
    public static final String DotHrs3 = "DotHrs3";
    public static final String NhHrs4 = "NhHrs4";
    public static final String OtHrs4 = "OtHrs4";
    public static final String DotHrs4 = "DotHrs4";
    public static final String NhHrs5 = "NhHrs5";
    public static final String OtHrs5 = "OtHrs5";
    public static final String DotHrs5 = "DotHrs5";
    public static final String NhHrs6 = "NhHrs6";
    public static final String OtHrs6 = "OtHrs6";
    public static final String DotHrs6 = "DotHrs6";
    public static final String NhHrs7 = "NhHrs7";
    public static final String OtHrs7 = "OtHrs7";
    public static final String DotHrs7 = "DotHrs7";
    public static final String Total_REG = "Total_REG";
    public static final String Total_OT = "Total_OT";
    public static final String Total_DOT = "Total_DOT";

    //Dashboard Crew Members Detail Coloumns
    //Dashboard Detail - DD

    public static final String DDSelectedDate ="SelectedDate";
    public static final String DDEmpAcsCode ="EmpAcsCode";
    public static final String DDEmpNo ="EmpNo";
    public static final String DDEmpFirstName = "EmpFirstName";
    public static final String DDEmpLastName ="EmpLastName";
    public static final String DDTshDataType ="TshDataType";
    public static final String DDTshWorkCompCode ="TshWorkCompCode";
    public static final String DDTshJobCode = "TshJobCode";
    public static final String DDTshPhase = "TshPhase";
    public static final String DDTshCategory = "TshCategory";
    public static final String DDTshDeptCode = "TshDeptCode";
    public static final String DDTshGlAccCode = "TshGlAccCode";
    public static final String DDTshTradeCode = "TshTradeCode";
    public static final String DDTshUnionCode = "TshUnionCode";
    public static final String DDTshShiftCode = "TshShiftCode";
    public static final String DDTshJobName = "TshJobName";
    public static final String DDTshPhaseName = "TshPhaseName";
    public static final String DDTshCategoryName = "TshCategoryName";
    public static final String DDTshDeptName = "TshDeptName";
    public static final String DDTshGlAccName = "TshGlAccName";
    public static final String DDTshTradeName = "TshTradeName";
    public static final String DDTshUnionName = "TshUnionName";
    public static final String DDTshShiftName = "TshShiftName";
    public static final String DDNhHrsTot = "NhHrsTot";
    public static final String DDOtHrsTot = "OtHrsTot";
    public static final String DDDotHrsTot = "DotHrsTot";
    public static final String DDOtherHrsTot = "OtherHrsTot";
    public static final String DDNhHrs1 = "NhHrs1";
    public static final String DDOtHrs1 = "OtHrs1";
    public static final String DDDotHrs1 = "DotHrs1";
    public static final String DDNhHrs2 = "NhHrs2";
    public static final String DDOtHrs2 = "OtHrs2";
    public static final String DDDotHrs2 = "DotHrs2";
    public static final String DDNhHrs3 = "NhHrs3";
    public static final String DDOtHrs3 = "OtHrs3";
    public static final String DDDotHrs3 = "DotHrs3";
    public static final String DDNhHrs4 = "NhHrs4";
    public static final String DDOtHrs4 = "OtHrs4";
    public static final String DDDotHrs4 = "DotHrs4";
    public static final String DDNhHrs5 = "NhHrs5";
    public static final String DDOtHrs5 = "OtHrs5";
    public static final String DDDotHrs5 = "DotHrs5";
    public static final String DDNhHrs6 = "NhHrs6";
    public static final String DDOtHrs6 = "OtHrs6";
    public static final String DDDotHrs6 = "DotHrs6";
    public static final String DDNhHrs7 = "NhHrs7";
    public static final String DDOtHrs7 = "OtHrs7";
    public static final String DDDotHrs7 = "DotHrs7";
    public static final String DDTotal_REG = "Total_REG";
    public static final String DDTotal_OT = "Total_OT";
    public static final String DDTotal_DOT = "Total_DOT";


}
