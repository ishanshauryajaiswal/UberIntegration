package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by parneet.singh on 4/21/2017.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by parneet.singh on 7/4/2016.
 */
public class CrewMemberAdapter extends ArrayAdapter<User>
{
    Viewholder viewHolder;
    private ArrayList<User> crewMemberDetails;
    private HashMap<String ,Boolean> checkedEmployees = new HashMap<>();
    public Context context;
    boolean flag ;
    ArrayList<User> preChecked;

    public void setCrewMemberDetails(ArrayList<User> crewMemberDetails) {
        this.crewMemberDetails = crewMemberDetails;
        notifyDataSetChanged();
    }

    public CrewMemberAdapter(Context context, ArrayList<User> crewMemberDetails, HashMap<String,Boolean> checkedEmployees, boolean  flag)
    {

        super(context,0,crewMemberDetails);
        this.context=context;
        this.flag = flag;
        this.crewMemberDetails = crewMemberDetails;
        this.preChecked = crewMemberDetails;
        this.checkedEmployees = checkedEmployees;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {

        final User user = getItem(position);
        if (convertView == null) {
            viewHolder = new Viewholder();
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_user, parent, false);
        }
        // Lookup view for data population

        User crewMember  = getItem(position);
        viewHolder.textViewName = (TextView) convertView.findViewById(R.id.txtMemberName);
        viewHolder.textViewDescription = (TextView) convertView.findViewById(R.id.txtMemberTradeName);
        viewHolder.checkBox = (CheckBox) convertView.findViewById(R.id.chkbox);

        if(flag)
        {
            viewHolder.checkBox.setVisibility(View.VISIBLE);
        }
        else
        {
            viewHolder.checkBox.setVisibility(View.INVISIBLE);
        }

        String empNo = crewMemberDetails.get(position).getEmployeeNo();
        boolean isContained = false;
        if(checkedEmployees == null || checkedEmployees.size()<=0)
        {
            viewHolder.checkBox.setChecked(false);
        }
        else
        {
            for (int i = 0; i < checkedEmployees.size(); i++)
            {
                if (checkedEmployees.containsKey(empNo)) {
                    if (checkedEmployees.get(empNo)) {
                        isContained = true;
                    }
                }
            }
        }

        viewHolder.checkBox.setChecked(isContained);
        // Populate the data into the template view using the data object
        viewHolder.textViewName.setText("( " +crewMemberDetails.get(position).getEmployeeNo()+" ) " +crewMemberDetails.get(position).getName());
        viewHolder.textViewDescription.setText("( " +crewMemberDetails.get(position).getTradeCode()+" ) " +crewMemberDetails.get(position).getTradeName());

        return convertView;
    }

    @Override
    public int getCount()
    {
        return crewMemberDetails.size();
    }

    public void setCheckedEmployees(HashMap<String,Boolean> checkedEmployees){this.checkedEmployees=checkedEmployees;}


    public class Viewholder
    {
        TextView textViewEmpNumber;
        TextView textViewName;
        TextView textViewDescription;
        CheckBox checkBox;
    }




}
