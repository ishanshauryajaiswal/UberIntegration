package com.example.ishanjaiswal.cmicresultactivity.parsers;

/**
 * Created by parneet.singh on 11/7/2017.
 */

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Dashboard2Parser {

    boolean isJobSelected;
    public List<Dashboard2> listDashboardData = new ArrayList<>();

    public Dashboard2Parser(boolean isJobSelected) {
        this.isJobSelected = isJobSelected;
    }

    public List<Dashboard2> parseDashboard2Data(final String response) {
        try {
            if (response != null) {
                JSONObject jsonObject = new JSONObject(response);
                String tableName = jsonObject.getString("table");
                int numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
                JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
                JSONArray Rows = jsonObject.getJSONArray("rows");
                JSONArray attributes = RowDefinition.getJSONArray("attrNames");
                Set<String> requiredAttributes = new HashSet<>();
                if (isJobSelected){
                    requiredAttributes.add("JobAcsCode");
                    requiredAttributes.add("JobCompCode");
                    requiredAttributes.add("JobCode");
                }
                else {
                    requiredAttributes.add("PycrResponsibleEmpOraseq");
                    requiredAttributes.add("PycrResponsibleEmpNo");
                    requiredAttributes.add("PycrResponsibleEmpName");
                }
                requiredAttributes.add("PycrCode");
                requiredAttributes.add("PycrName");
                requiredAttributes.add("EmpNo");
                requiredAttributes.add("EmpTrdCode");
                requiredAttributes.add("EmpTrdName");
                requiredAttributes.add("EmpFirstName");
                requiredAttributes.add("EmpLastName");
                requiredAttributes.add("NhHrsTot");
                requiredAttributes.add("OtHrsTot");
                requiredAttributes.add("DotHrsTot");
                requiredAttributes.add("NhHrs1");
                requiredAttributes.add("OtHrs1");
                requiredAttributes.add("DotHrs1");
                requiredAttributes.add("NhHrs2");
                requiredAttributes.add("OtHrs2");
                requiredAttributes.add("DotHrs2");
                requiredAttributes.add("NhHrs3");
                requiredAttributes.add("OtHrs3");
                requiredAttributes.add("DotHrs3");
                requiredAttributes.add("NhHrs4");
                requiredAttributes.add("OtHrs4");
                requiredAttributes.add("DotHrs4");
                requiredAttributes.add("NhHrs5");
                requiredAttributes.add("OtHrs5");
                requiredAttributes.add("DotHrs5");
                requiredAttributes.add("NhHrs6");
                requiredAttributes.add("OtHrs6");
                requiredAttributes.add("DotHrs6");
                requiredAttributes.add("NhHrs7");
                requiredAttributes.add("OtHrs7");
                requiredAttributes.add("DotHrs7");
                HashMap<String, Integer> attributeIndex = new HashMap<>();
                for (int i = 0; i < attributes.length(); i++) {
                    String strAttribute = attributes.getString(i);

                    if (requiredAttributes.contains(strAttribute)) {
                        attributeIndex.put(strAttribute, i);
                    }
                }
                ArrayList<JSONArray> attributeValues = new ArrayList<>();
                for (int j = 0; j < Rows.length(); j++) {
                    JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                }

                for (int k = 0; k < attributeValues.size(); k++) {
                    Dashboard2 dashboard2 = new Dashboard2();

                    AllTimes allTimesTotal = new AllTimes();
                    List<AllTimes> allTimesList = new ArrayList<>();
                    for (int i = 1; i <= 7; i++)
                        allTimesList.add(new AllTimes());
                    if (attributeIndex.get("NhHrsTot") != 0 || attributeIndex.get("NhHrsTot") != null) {
                        String NhHrsTot = attributeValues.get(k).getString(attributeIndex.get("NhHrsTot"));
                        allTimesTotal.setReg(Double.parseDouble(NhHrsTot));
                    }
                    if (attributeIndex.get("OtHrsTot") != 0 || attributeIndex.get("OtHrsTot") != null) {
                        String OtHrsTot = attributeValues.get(k).getString(attributeIndex.get("OtHrsTot"));
                        allTimesTotal.setOt(Double.parseDouble(OtHrsTot));
                    }
                    //overTimeHours
                    if (attributeIndex.get("DotHrsTot") != 0 || attributeIndex.get("DotHrsTot") != null) {
                        String DotHrsTot = attributeValues.get(k).getString(attributeIndex.get("DotHrsTot"));
                        allTimesTotal.setDot(Double.parseDouble(DotHrsTot));
                    }
                    dashboard2.setTotalTime(allTimesTotal);
                    if (attributeIndex.get("NhHrs1") != 0 || attributeIndex.get("NhHrs1") != null) {
                        String NhHrs1 = attributeValues.get(k).getString(attributeIndex.get("NhHrs1"));
                        allTimesList.get(0).setReg(Double.parseDouble(NhHrs1));
                    }
                    if (attributeIndex.get("NhHrs2") != 0 || attributeIndex.get("NhHrs1") != null) {
                        String NhHrs2 = attributeValues.get(k).getString(attributeIndex.get("NhHrs2"));
                        allTimesList.get(1).setReg(Double.parseDouble(NhHrs2));
                    }
                    if (attributeIndex.get("NhHrs3") != 0 || attributeIndex.get("NhHrs3") != null) {
                        String NhHrs3 = attributeValues.get(k).getString(attributeIndex.get("NhHrs3"));
                        allTimesList.get(2).setReg(Double.parseDouble(NhHrs3));
                    }
                    if (attributeIndex.get("NhHrs4") != 0 || attributeIndex.get("NhHrs4") != null) {
                        String NhHrs4 = attributeValues.get(k).getString(attributeIndex.get("NhHrs4"));
                        allTimesList.get(3).setReg(Double.parseDouble(NhHrs4));
                    }
                    if (attributeIndex.get("NhHrs5") != 0 || attributeIndex.get("NhHrs5") != null) {
                        String NhHrs5 = attributeValues.get(k).getString(attributeIndex.get("NhHrs5"));
                        allTimesList.get(4).setReg(Double.parseDouble(NhHrs5));
                    }
                    if (attributeIndex.get("NhHrs6") != 0 || attributeIndex.get("NhHrs6") != null) {
                        String NhHrs6 = attributeValues.get(k).getString(attributeIndex.get("NhHrs6"));
                        allTimesList.get(5).setReg(Double.parseDouble(NhHrs6));
                    }
                    if (attributeIndex.get("NhHrs7") != 0 || attributeIndex.get("NhHrs7") != null) {
                        String NhHrs7 = attributeValues.get(k).getString(attributeIndex.get("NhHrs7"));
                        allTimesList.get(6).setReg(Double.parseDouble(NhHrs7));
                    }
                    if (attributeIndex.get("OtHrs1") != 0 || attributeIndex.get("OtHrs1") != null) {
                        String OtHrs1 = attributeValues.get(k).getString(attributeIndex.get("OtHrs1"));
                        allTimesList.get(0).setOt(Double.parseDouble(OtHrs1));
                    }
                    if (attributeIndex.get("OtHrs2") != 0 || attributeIndex.get("OtHrs2") != null) {
                        String OtHrs2 = attributeValues.get(k).getString(attributeIndex.get("OtHrs2"));
                        allTimesList.get(1).setOt(Double.parseDouble(OtHrs2));
                    }
                    if (attributeIndex.get("OtHrs3") != 0 || attributeIndex.get("OtHrs3") != null) {
                        String OtHrs3 = attributeValues.get(k).getString(attributeIndex.get("OtHrs3"));
                        allTimesList.get(2).setOt(Double.parseDouble(OtHrs3));
                    }
                    if (attributeIndex.get("OtHrs4") != 0 || attributeIndex.get("OtHrs4") != null) {
                        String OtHrs4 = attributeValues.get(k).getString(attributeIndex.get("OtHrs4"));
                        allTimesList.get(3).setOt(Double.parseDouble(OtHrs4));
                    }
                    if (attributeIndex.get("OtHrs5") != 0 || attributeIndex.get("OtHrs5") != null) {
                        String OtHrs5 = attributeValues.get(k).getString(attributeIndex.get("OtHrs5"));
                        allTimesList.get(4).setOt(Double.parseDouble(OtHrs5));
                    }
                    if (attributeIndex.get("OtHrs6") != 0 || attributeIndex.get("OtHrs6") != null) {
                        String OtHrs6 = attributeValues.get(k).getString(attributeIndex.get("OtHrs6"));
                        allTimesList.get(5).setOt(Double.parseDouble(OtHrs6));
                    }
                    if (attributeIndex.get("OtHrs7") != 0 || attributeIndex.get("OtHrs7") != null) {
                        String OtHrs7 = attributeValues.get(k).getString(attributeIndex.get("OtHrs7"));
                        allTimesList.get(6).setOt(Double.parseDouble(OtHrs7));
                    }
                    if (attributeIndex.get("DotHrs1") != 0 || attributeIndex.get("DotHrs1") != null) {
                        String DotHrs1 = attributeValues.get(k).getString(attributeIndex.get("DotHrs1"));
                        allTimesList.get(0).setDot(Double.parseDouble(DotHrs1));
                    }
                    if (attributeIndex.get("DotHrs2") != 0 || attributeIndex.get("DotHrs2") != null) {
                        String DotHrs2 = attributeValues.get(k).getString(attributeIndex.get("DotHrs2"));
                        allTimesList.get(1).setDot(Double.parseDouble(DotHrs2));
                    }
                    if (attributeIndex.get("DotHrs3") != 0 || attributeIndex.get("DotHrs3") != null) {
                        String DotHrs3 = attributeValues.get(k).getString(attributeIndex.get("DotHrs3"));
                        allTimesList.get(2).setDot(Double.parseDouble(DotHrs3));
                    }
                    if (attributeIndex.get("DotHrs4") != 0 || attributeIndex.get("DotHrs4") != null) {
                        String DotHrs4 = attributeValues.get(k).getString(attributeIndex.get("DotHrs4"));
                        allTimesList.get(3).setDot(Double.parseDouble(DotHrs4));
                    }
                    if (attributeIndex.get("DotHrs5") != 0 || attributeIndex.get("DotHrs5") != null) {
                        String DotHrs5 = attributeValues.get(k).getString(attributeIndex.get("DotHrs5"));
                        allTimesList.get(4).setDot(Double.parseDouble(DotHrs5));
                    }
                    if (attributeIndex.get("DotHrs6") != 0 || attributeIndex.get("DotHrs6") != null) {
                        String DotHrs6 = attributeValues.get(k).getString(attributeIndex.get("DotHrs6"));
                        allTimesList.get(5).setDot(Double.parseDouble(DotHrs6));
                    }
                    if (attributeIndex.get("DotHrs7") != 0 || attributeIndex.get("DotHrs7") != null) {
                        Log.d("DOT 7 Parser", attributeValues.get(k).getString(attributeIndex.get("DotHrs7")));
                        String DotHrs7 = attributeValues.get(k).getString(attributeIndex.get("DotHrs7"));
                        allTimesList.get(6).setDot(Double.parseDouble(DotHrs7));
                    }
                    dashboard2.setTimesList(allTimesList);
                    if (isJobSelected){
                        dashboard2.setJobCompCode(attributeValues.get(k).getString(attributeIndex.get("JobCompCode")));
                        dashboard2.setJobCode(attributeValues.get(k).getString(attributeIndex.get("JobCode")));
                        dashboard2.setJobAcsCode(attributeValues.get(k).getString(attributeIndex.get("JobAcsCode")));
                    }
                    else {
                        dashboard2.setPycrResponsibleEmpName(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpName")));
                        dashboard2.setPycrResponsibleEmpNo(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpNo")));
                        dashboard2.setPycrResponsibleEmpOraseq(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpOraseq")));
                    }
                    dashboard2.setPycrCode(attributeValues.get(k).getString(attributeIndex.get("PycrCode")));
                    dashboard2.setPycrName(attributeValues.get(k).getString(attributeIndex.get("PycrName")));
                    dashboard2.setEmpNo(attributeValues.get(k).getString(attributeIndex.get("EmpNo")));
                    dashboard2.setEmpTrdCode(attributeValues.get(k).getString(attributeIndex.get("EmpTrdCode")));
                    dashboard2.setEmpTrdName(attributeValues.get(k).getString(attributeIndex.get("EmpTrdName")));
                    dashboard2.setEmpFirstName(attributeValues.get(k).getString(attributeIndex.get("EmpFirstName")));
                    dashboard2.setEmpLastName(attributeValues.get(k).getString(attributeIndex.get("EmpLastName")));
                    listDashboardData.add(dashboard2);
                }
            }
            else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listDashboardData;
    }

}
