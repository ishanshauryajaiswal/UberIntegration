package com.example.ishanjaiswal.cmicresultactivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;


/**
  Created by parneet.singh on 10/20/2016.
 */
public class GetEmployees extends AsyncTask<Void,Void,String>
{
    private Context context;
    private FillEmployeeListener employeeListener;
    private String authCode;
    public GetEmployees(Context context, String authCode, FillEmployeeListener employeeListener){
        this.employeeListener=employeeListener;
        this.context=context;
        this.authCode=authCode;
    }

    @Override
    protected void onPreExecute()
    {
       employeeListener.beforeCompleted();
    }
    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall();
            response = requestCall.getAllEmployees(context);
        }
        catch (Exception e)
        {
            Log.d("error1234567", e.toString());
        }
        return response;
    }
    @Override
    protected void onPostExecute(String result)
    {
//        dialog.dismiss();
        employeeListener.afterCompleted(result);
    }
}
