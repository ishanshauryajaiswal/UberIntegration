package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

/**
 Created by parneet.singh on 10/26/2016.
 */
public class CrewListActivityTask extends AsyncTask<Void,Void,String>
{
    private String authCode;
    private Context context;
    private String crewCode;
    private CrewListInterface crewListInterface;
    public CrewListActivityTask(String authCode,Context context,CrewListInterface crewListInterface)
    {
        this.authCode = authCode;
        this.context = context;
        this.crewCode = crewCode;
        this.crewListInterface = crewListInterface;
    }

    @Override
    protected void onPreExecute()
    {
        //  progressdialog = ProgressDialog.show(context, "Cmic Mobile Crew Time", ".....Fetching Employees");
        crewListInterface.Beforecompletion();
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall();
        //Log.d("AuthcodeCrewList: ", authCode);
        response = requestCall.selectCrewList(context,authCode);

        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
       /* progressBar.setVisibility(View.INVISIBLE);*/
        if(response!=null)
        {
            CrewCreationParser crewCreationParser = new CrewCreationParser();
            //crewCreationParser.parseInsertCrewData(response);
            ArrayList<InsertCrew> insertedArrayList = crewCreationParser.parseInsertCrewData(response);
            crewListInterface.selectCrewList(insertedArrayList);
        }
        else
        {
            final AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
            alertBox.setTitle("CMiC Mobile Crew Time");
            alertBox.setMessage("Error Fetching Data");
            alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    Intent back = new Intent(context, MainActivity.class);
                    context.startActivity(back);
                }
            });
            alertBox.show();


        }
    }
}
