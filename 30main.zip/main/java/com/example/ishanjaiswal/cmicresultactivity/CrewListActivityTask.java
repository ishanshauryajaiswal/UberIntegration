package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

/**
 Created by parneet.singh on 10/26/2016.
 */
public class CrewListActivityTask extends AsyncTask<Void,Void,String>
{
    private static final String TAG = CrewListActivityTask.class.getSimpleName();
    private Context context;
    private CrewListInterface crewListInterface;
    public CrewListActivityTask(Context context,CrewListInterface crewListInterface)
    {
        this.context = context;
        this.crewListInterface = crewListInterface;
    }

    @Override
    protected void onPreExecute()
    {
        crewListInterface.onPreCrewListTask();
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall(context);
        response = requestCall.selectCrewList(context);
        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        crewListInterface.onPostCrewListTask(response);
    }
}
