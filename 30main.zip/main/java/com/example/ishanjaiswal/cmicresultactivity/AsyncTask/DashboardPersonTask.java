package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/23/2018.
 */

    public class DashboardPersonTask extends AsyncTask<Void, Void, String> {


        String date,employeeOraseq;
        Context context;
        DashboardTaskListener mListener;

        public DashboardPersonTask(Context context, String employeeOraseq,String date , DashboardTaskListener mListener) {
            this.context = context;
            this.employeeOraseq = employeeOraseq;
            this.mListener = mListener;
            this.date = date;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mListener.beforeDashboardTaskStarted("Fetching");
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = "";
            try {
                RequestCall requestCall = new RequestCall(context);
                response = requestCall.personData(context,employeeOraseq,date);
                return response;
            } catch (Exception e) {
                return null;
            }
        }
        @Override
        protected void onPostExecute(String response)
        {

            super.onPostExecute(response);

            if (response == null) {
            }
            else
            {
                mListener.onDashboardTaskComplete(response);
            }
        }
    }
