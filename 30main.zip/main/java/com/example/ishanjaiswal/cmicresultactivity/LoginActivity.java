package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.facebook.stetho.Stetho;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    EditText txtUsername;
    EditText txtPassword;
    Button btnSubmit;
    Button btnOffline;
    ImageButton btnvision;
    String username, password;
    ProgressDialog progress;
    SharedPreferences ishanSharedPreferences;
    SharedPreferences.Editor ishanSharedPrefereceEditor;
    String crewCodeFromPreferences, projectCodeFromPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Stetho.initializeWithDefaults(this);
        //Bugsee.launch(getApplication(), getString(R.string.key_bugsee));
        getValuesFromSharedPreference();
        txtUsername = (EditText)findViewById(R.id.txtUserName);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        btnvision = (ImageButton)findViewById(R.id.btnvision);
        btnSubmit = (Button)findViewById(R.id.btnlogin);
        btnOffline = (Button)findViewById(R.id.btnoffline);

        txtUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                txtUsername.setFocusable(true);
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(txtUsername, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                username = txtUsername.getText().toString().trim();
                password = txtPassword.getText().toString().trim();
                new AuthenticateTask().execute();
            }
        });
        btnvision.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                        break;
                    case MotionEvent.ACTION_UP:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        break;
                }
                return true;
            }
        });
        btnOffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(LoginActivity.this, "Under Development",Toast.LENGTH_SHORT).show();
            }
        });
        btnSubmit.callOnClick();
    }

    private void getValuesFromSharedPreference() {
        ishanSharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), 0);
        ishanSharedPrefereceEditor = ishanSharedPreferences.edit();
        crewCodeFromPreferences = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_crew_code),
                getString(R.string.cmic_shared_preference_no_crew_code));
        projectCodeFromPreferences = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_project_code),
                getString(R.string.cmic_shared_preference_no_project));
    }


    public class AuthenticateTask extends AsyncTask<Void, Void, String>
    {

        @Override
        protected void onPreExecute()
        {
            progress=ProgressDialog.show(LoginActivity.this,null,"      Authenticating...");
            super.onPreExecute();

        }
        String auth = "", authEncoded = "";
        @Override
        protected String doInBackground(Void... params)
        {
            String response="";
            try
            {
                auth = username + ":" + password;
                authEncoded = new String(Base64.encode(auth.getBytes("UTF-8"), Base64.NO_WRAP));
                RequestCall requestCall = new RequestCall(getApplicationContext());
                response = requestCall.requestAuthenticate(getApplicationContext(),authEncoded);
            }
            catch (Exception e)
            {
                return null;
            }
            return response;
        }

        @Override
        protected void onPostExecute(String response)
        {

            super.onPostExecute(response);
            progress.dismiss();
            if (response == null || response.equalsIgnoreCase(getString(R.string.internal_server_error)))
            {
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(LoginActivity.this);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("Invalid Login Details");
                alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                    }
                });
                alertBox.show();

            }
            else
            {
                /*
                if (!crewCodeFromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_crew_code))
                        && !projectCodeFromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_project))){
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else {
                */
                ishanSharedPrefereceEditor.putString(getString(R.string.cmic_shared_preference_username), username);
                ishanSharedPrefereceEditor.putString(getString(R.string.cmic_shared_preference_password), password);
                ishanSharedPrefereceEditor.putString(getString(R.string.cmic_shared_preference_autchcode), authEncoded);
                ishanSharedPrefereceEditor.commit();
                LoginParser loginParser = new LoginParser();
                ArrayList<LoginModal> arrayList = loginParser.parseLoginData(response);
                for (int i = 0; i < arrayList.size(); i++)
                {
                    String hrtTradeName = arrayList.get(i).getHrtTrdName();
                    String hrtName = arrayList.get(i).getHrtFirstName() + arrayList.get(i).getHrtLastName();
                    ishanSharedPrefereceEditor.putString(getString(R.string.cmic_shared_preference_hrt_trade_name), hrtTradeName);
                    ishanSharedPrefereceEditor.putString(getString(R.string.cmic_shared_preference_hrt_name), hrtName);
                    ishanSharedPrefereceEditor.commit();
                }
                Intent intent = new Intent(LoginActivity.this, CrewListActivity.class);
                startActivity(intent);
            }
        }
    }
    @Override
    public void onBackPressed()
    {
        finish();
        super.onBackPressed();
    }
}