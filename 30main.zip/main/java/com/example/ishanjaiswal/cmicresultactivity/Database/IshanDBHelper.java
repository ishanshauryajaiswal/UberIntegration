package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOut;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeSheetDetails;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */


public class IshanDBHelper extends SQLiteOpenHelper {
    private static IshanDBHelper mInstance;
    private static final String DBName="DATABASE";
    private static final int DBVersion = 1;
    private static IshanDBConstants D = new IshanDBConstants();
    private static final String TAG = IshanDBHelper.class.getSimpleName();

    private IshanDBHelper(Context context) {
        super(context, DBName, null, DBVersion);
    }

    public static synchronized IshanDBHelper getInstance(Context context){
        if (mInstance == null)
            mInstance = new IshanDBHelper(context);
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(D.CREATE_TABLE_EMPLOYEE_DATA);
            db.execSQL(D.CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
            db.execSQL(D.CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
            db.execSQL(D.CREATE_TABLE_TIME_IN_OUT);
            db.execSQL(D.CREATE_TABLE_TIMESHEET);
            db.execSQL(D.CREATE_TABLE_CREW_LIST);
            db.execSQL(D.CREATE_TABLE_PROJECT_LIST);
            db.execSQL(D.CREATE_TABLE_SELECTED_EMPLOYEES);
            db.execSQL(D.CREATE_TABLE_ALL_EMPLOYEES);
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_EMPLOYEE_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_TIME_IN_OUT);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_CREW_LIST);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_PROJECT_LIST);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_SELECTED_EMPLOYEES);
        db.execSQL("DROP TABLE IF EXISTS " + D.CREATE_TABLE_ALL_EMPLOYEES);
        onCreate(db);
    }


    //Insert Functions
    public void insertEmployeeInDatabase(EmployeeDataForCrew employee){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.EmployeeOraseq_EmployeeDataForCrew, Integer.parseInt(employee.getEmployeeOraseq()));
            values.put(D.DeleteFlag_EmployeeDataForCrew, employee.getDeleteFlag());
            values.put(D.EmployeeName_EmployeeDataForCrew, employee.getEmpName());
            values.put(D.EmployeeNumber_EmployeeDataForCrew, employee.getEmpNo());
            values.put(D.EmployeeTradeCode_EmployeeDataForCrew, employee.getTradeCode());
            values.put(D.EmployeeTradeName_EmployeeDataForCrew, employee.getTradeName());
            values.put(D.PeriodFlag_EmployeeDataForCrew, employee.getPeriodFlag());
            values.put(D.RowNumber_EmployeeDataForCrew, employee.getRowNo());
            int id = (int) db.insertWithOnConflict(D.TABLE_EMPLOYEE_DATA_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_EMPLOYEE_DATA_FOR_CREW,values, D.EmployeeNumber_EmployeeDataForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeNumber_EmployeeDataForCrew)+""});
            }
            ArrayList<SubmittedActivityFromCrewModal> activities = this.getActivityForTimesheet();
            int i=0;
            for (SubmittedActivityFromCrewModal a:activities) {
                this.insertActivityTimeForEmployee(Integer.parseInt(employee.getEmployeeOraseq()), Integer.parseInt(a.getColoumnNo()), employee.getTimeSheet().get(i++));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
        }
    }

    public void insertAllEmployeeInDatabase(ArrayList<EmployeeDataForCrew> employeeList){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            String sql = "insert or replace into "+ D.TABLE_EMPLOYEE_DATA_FOR_CREW + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            for (EmployeeDataForCrew employee : employeeList) {
                statement.clearBindings();
                statement.bindLong(1, Integer.parseInt(employee.getEmployeeOraseq()));
                statement.bindString(2, employee.getDeleteFlag());
                statement.bindString(3, employee.getEmpNo());
                statement.bindString(4, employee.getEmpName());
                statement.bindString(5, employee.getTradeCode());
                statement.bindString(6, employee.getTradeName());
                statement.bindString(7, employee.getRowNo());
                statement.bindString(8, employee.getPeriodFlag());
                statement.executeInsert();
            }
            db.setTransactionSuccessful();
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public void insertActivityTimeForEmployee(int empOraSeq, int columnNo, ActivityTimeForCrew activityTimeForCrew){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.ColoumnNumber_ActivityForTimeSheet,columnNo);
            values.put(D.EmployeeOraSeq_ActivityTimeForCrew, empOraSeq);
            values.put(D.rtSeqNumber, activityTimeForCrew.getStandardTimeSeqNumber());
            values.put(D.rtHours, activityTimeForCrew.getStandardTime());
            values.put(D.otseqNumber, activityTimeForCrew.getOverTimeSeqNumber());
            values.put(D.otHour, activityTimeForCrew.getOverTime());
            values.put(D.dotSeqNumber, activityTimeForCrew.getDoubleOverTimeSeqNumber());
            values.put(D.dothour, activityTimeForCrew.getDoubleOverTime());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_TIME_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_TIME_FOR_CREW,values, D.EmployeeOraSeq_ActivityTimeForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeOraSeq_ActivityTimeForCrew)+""});
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
        }
    }

    public void insertActivityTimeForAllEmployee(ArrayList<EmployeeDataForCrew> employeeList, ArrayList<SubmittedActivityFromCrewModal> activityFromCrewModals){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            String sql = "insert or replace into "+ D.TABLE_ACTIVITY_TIME_FOR_CREW + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            for (EmployeeDataForCrew e : employeeList){
                for (int i=0; i<activityFromCrewModals.size();i++) {
                    ActivityTimeForCrew activityTimeForCrew = e.getTimeSheet().get(i);
                    int colNo = Integer.parseInt(activityFromCrewModals.get(i).getColoumnNo());
                    statement.clearBindings();
                    statement.bindLong(1, Long.parseLong(e.getEmployeeOraseq()));
                    statement.bindLong(2,colNo);
                    statement.bindString(3, activityTimeForCrew.getStandardTimeSeqNumber());
                    statement.bindDouble(4, activityTimeForCrew.getStandardTime());
                    statement.bindString(5, activityTimeForCrew.getOverTimeSeqNumber());
                    statement.bindDouble(6, activityTimeForCrew.getOverTime());
                    statement.bindString(7, activityTimeForCrew.getDoubleOverTimeSeqNumber());
                    statement.bindDouble(8, activityTimeForCrew.getDoubleOverTime());
                    statement.executeInsert();
                }
            }
            db.setTransactionSuccessful();
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public void insertTimeInOutForAllEmployees(ArrayList<EmployeeDataForCrew> employeeList){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            String sql = "insert or replace into "+ D.TABLE_TIME_IN_OUT + " VALUES (?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            for (EmployeeDataForCrew e : employeeList) {
                List<TimeInOut> timeInOutList = e.getTimeInOuts();
                if (timeInOutList != null && timeInOutList.size() > 0) {
                    for (TimeInOut timeInOut : timeInOutList) {
                        if (timeInOut != null) {
                            statement.clearBindings();
                            if (timeInOut.getEmployeeNumber()!=null && timeInOut.getEmployeeNumber().length()>0)
                                statement.bindString(1, timeInOut.getEmployeeNumber());
                            else
                                statement.bindString(1, e.getEmpNo());
                            statement.bindLong(2, timeInOut.getIndex());
                            statement.bindString(3, timeInOut.getTimeIn());
                            statement.bindString(4, timeInOut.getTimeOut());
                            statement.bindDouble(5, timeInOut.getTotal());
                            statement.executeInsert();
                        }
                    }
                }
            }
            db.setTransactionSuccessful();
        }
        catch (NullPointerException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public void insertTimeInOutForOneEmployee(TimeInOut timeInOut){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            String sql = "insert or replace into "+ D.TABLE_TIME_IN_OUT + " VALUES (?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.clearBindings();
            statement.bindString(1, timeInOut.getEmployeeNumber());
            statement.bindLong(2, timeInOut.getIndex());
            statement.bindString(3,timeInOut.getTimeIn());
            statement.bindString(3,timeInOut.getTimeOut());
            statement.bindDouble(3,timeInOut.getTotal());
            statement.executeInsert();
            db.setTransactionSuccessful();
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public void insertActivityForTimesheet(SubmittedActivityFromCrewModal activity) {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.ActivityName_ActivityForTimeSheet, activity.getActivityName());
            values.put(D.CategoryCode_ActivityForTimeSheet, activity.getCatCode());
            values.put(D.ColoumnNumber_ActivityForTimeSheet, Integer.parseInt(activity.getColoumnNo()));
            values.put(D.DeleteFlag_ActivityForTimeSheet, activity.getDeleteFlag());
            values.put(D.JobCode_ActivityForTimeSheet, activity.getjobCode());
            values.put(D.PciLineOraseq_ActivityForTimeSheet, activity.getPciLineOraseq());
            values.put(D.PhaseCode_ActivityForTimeSheet, activity.getPhaseCode());
            values.put(D.SeqNumber_ActivityForTimeSheet, activity.getSeqNo());
            values.put(D.WbsCode_ActivityForTimeSheet, activity.getWbsCode());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_FOR_TIMESHEET, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_FOR_TIMESHEET,values, D.ColoumnNumber_ActivityForTimeSheet+"=?",new String [] {values.getAsInteger(D.ColoumnNumber_ActivityForTimeSheet)+""});
            }
        } catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
        }
    }

    public void insertTimesheetDetailsInDatabase(String crewCode,String jobCode,String jobCompCode,String seqNo,String workDate,String submitStatus,boolean state){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.Timesheet_CrewCode, crewCode);
            values.put(D.Timesheet_JobCode, jobCode);
            values.put(D.Timesheet_JobCompCode, jobCompCode);
            values.put(D.Timesheet_SeqNumber, seqNo);
            values.put(D.Timesheet_WorkDate, workDate);
            values.put(D.Timesheet_SubmitStatus, submitStatus);
            if (state)
                values.put(D.TimesheetState, 1);
            else
                values.put(D.TimesheetState, 0);
            int id = (int) db.insertWithOnConflict(D.TABLE_TIMESHEET, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_TIMESHEET,values, D.Timesheet_WorkDate+"=?",new String [] {values.getAsString(D.Timesheet_WorkDate)});
            }
        }
        catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
        }
    }

    public void insertTimeSheetInDatabase(CrewTimeSheet crewTimeSheet){
        deleteTimeSheetFromDatabase();
        ArrayList<SubmittedActivityFromCrewModal> activityFromCrewModals = crewTimeSheet.getCrewActivity();
        for (SubmittedActivityFromCrewModal s : activityFromCrewModals)
            this.insertActivityForTimesheet(s);
        ArrayList<EmployeeDataForCrew> employeeDataForCrews = crewTimeSheet.getEmpTimeSheet();
        this.insertAllEmployeeInDatabase(employeeDataForCrews);
        this.insertActivityTimeForAllEmployee(employeeDataForCrews,activityFromCrewModals);
        this.insertTimeInOutForAllEmployees(employeeDataForCrews);
        this.insertTimesheetDetailsInDatabase(crewTimeSheet.getCrewCode(), crewTimeSheet.getJobCode(), crewTimeSheet.getJobCompCode(), crewTimeSheet.getSeqNo(), crewTimeSheet.getWorkDate(),"", crewTimeSheet.isEdited());
    }



    //Retrieve Functions
    public ArrayList<EmployeeDataForCrew> getEmployeeDataForCrewFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cursor = null;
        try {
            db.beginTransaction();
            ArrayList<EmployeeDataForCrew> employeeDataForCrews = new ArrayList<>();
            cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_EMPLOYEE_DATA_FOR_CREW, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    EmployeeDataForCrew e = new EmployeeDataForCrew();
                    e.setEmployeeOraseq(cursor.getString(0));
                    e.setDeleteFlag(cursor.getString(1)+"");
                    e.setEmpNo(cursor.getString(2));
                    e.setEmpName(cursor.getString(3));
                    e.setTradeCode(cursor.getString(4));
                    e.setTradeName(cursor.getString(5));
                    e.setRowNo(cursor.getString(6));
                    e.setPeriodFlag(cursor.getString(7));
                    employeeDataForCrews.add(e);
                    cursor.moveToNext();
                }
            }
            db.setTransactionSuccessful();
            return employeeDataForCrews;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            if (cursor!=null)
                cursor.close();
            db.endTransaction();
        }
        return null;
    }

    public ArrayList<SubmittedActivityFromCrewModal> getActivityForTimesheet(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cursor = null;
        try {
            db.beginTransaction();
            ArrayList<SubmittedActivityFromCrewModal> submittedActivityFromCrewModals = new ArrayList<>();
            cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_FOR_TIMESHEET, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    SubmittedActivityFromCrewModal s = new SubmittedActivityFromCrewModal();
                    s.setDeleteFlag(cursor.getString(0));
                    s.setActivityName(cursor.getString(1));
                    s.setCatCode(cursor.getString(2));
                    s.setColoumnNo(cursor.getString(3));
                    s.setjobCode(cursor.getString(4));
                    s.setPciLineOraseq(cursor.getString(5));
                    s.setPhaseCode(cursor.getString(6));
                    s.setSeqNo(cursor.getString(7));
                    s.setWbsCode(cursor.getString(8));
                    submittedActivityFromCrewModals.add(s);
                    cursor.moveToNext();
                }
            }
            db.setTransactionSuccessful();
            return submittedActivityFromCrewModals;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            if (cursor!=null)
                cursor.close();
            db.endTransaction();
        }
        return null;
    }

    public HashMap<Integer,ActivityTimeForCrew> getActivityTimeForCrewFromDatabase(int empOraSeq){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cursor = null;
        try {db.beginTransaction();
            HashMap<Integer,ActivityTimeForCrew> hashMap = new HashMap<>();
            cursor = db.rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_TIME_FOR_CREW +
                    " WHERE "+ D.EmployeeOraSeq_ActivityTimeForCrew + " =?",new String [] {String.valueOf(empOraSeq)});
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    ActivityTimeForCrew a = new ActivityTimeForCrew();
                    a.setStandardTimeSeqNumber(cursor.getString(2));
                    a.setStandardTime(Double.parseDouble(cursor.getString(3)));
                    a.setOverTimeSeqNumber(cursor.getString(4));
                    a.setOverTime(Double.parseDouble(cursor.getString(5)));
                    a.setDoubleOverTimeSeqNumber(cursor.getString(6));
                    a.setDoubleOverTime(Double.parseDouble(cursor.getString(7)));
                    hashMap.put(cursor.getInt(1),a);
                    cursor.moveToNext();
                }
            }
            db.setTransactionSuccessful();
            return hashMap;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            if (cursor!=null)
                cursor.close();
            db.endTransaction();
        }
        return null;
    }

    public List<TimeInOut> getTimeInOutForEmployeeFromDatabase(String empNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cursor = null;
        try {
            db.beginTransaction();
            List<TimeInOut> timeInOutList = new ArrayList<>();
            cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_TIME_IN_OUT + " WHERE "+ D.TIMEINOUT_EMPLOYEE_NUMBER + " =?",new String [] {String.valueOf(empNumber)});
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    TimeInOut timeInOut = new TimeInOut();
                    timeInOut.setEmployeeNumber(cursor.getString(0));
                    timeInOut.setIndex(cursor.getInt(1));
                    timeInOut.setTimeIn(cursor.getString(2));
                    timeInOut.setTimeOut(cursor.getString(3));
                    timeInOut.setTotal(cursor.getDouble(4));
                    timeInOutList.add(timeInOut);
                    cursor.moveToNext();
                }
            }
            db.setTransactionSuccessful();
            return timeInOutList;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            if (cursor!=null)
                cursor.close();
            db.endTransaction();
        }
        return null;
    }

    public TimeSheetDetails getTimesheetDetailsFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cursor = null;
        try {
            db.beginTransaction();
            TimeSheetDetails timeSheetDetails = new TimeSheetDetails();
            cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_TIMESHEET, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    timeSheetDetails.setCrewCode(cursor.getString(0));
                    timeSheetDetails.setJoCode(cursor.getString(1));
                    timeSheetDetails.setJobCompCode(cursor.getString(2));
                    timeSheetDetails.setSeqNo(cursor.getString(3));
                    timeSheetDetails.setWorkDate(cursor.getString(4));
                    timeSheetDetails.setSubmitStatus(cursor.getString(5));
                    if (cursor.getInt(cursor.getColumnIndex(D.TimesheetState)) == 1)
                        timeSheetDetails.setState(true);
                    else
                        timeSheetDetails.setState(false);
                    cursor.moveToNext();
                }
            }
            db.setTransactionSuccessful();
            return timeSheetDetails;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            if (cursor!=null)
                cursor.close();
            db.endTransaction();
        }
        return null;
    }

    public CrewTimeSheet getTimeSheetFromDatabase(){
        CrewTimeSheet crewTimeSheet = new CrewTimeSheet();
        crewTimeSheet.setCrewActivity(this.getActivityForTimesheet());
        ArrayList<EmployeeDataForCrew> employeeDataForCrews;
        employeeDataForCrews = this.getEmployeeDataForCrewFromDatabase();
        crewTimeSheet.setEmpTimeSheet(employeeDataForCrews);
        for (EmployeeDataForCrew e : employeeDataForCrews){
            ArrayList<SubmittedActivityFromCrewModal> activities;
            activities = crewTimeSheet.getCrewActivity();
            ArrayList<ActivityTimeForCrew> activityTimeForCrew = new ArrayList<>();
            for (int i = 0; i < activities.size(); i++){
                HashMap<Integer,ActivityTimeForCrew> hashMap = this.getActivityTimeForCrewFromDatabase(Integer.parseInt(e.getEmployeeOraseq()));
                ActivityTimeForCrew a = hashMap.get(Integer.parseInt(activities.get(i).getColoumnNo()));
                activityTimeForCrew.add(a);
            }
            e.setTimeSheet(activityTimeForCrew);
            e.setTimeInOuts(this.getTimeInOutForEmployeeFromDatabase(e.getEmpNo()));
        }
        TimeSheetDetails t = this.getTimesheetDetailsFromDatabase();
        crewTimeSheet.setCrewCode(t.getCrewCode());
        crewTimeSheet.setJobCode(t.getJoCode());
        crewTimeSheet.setJobCompCode(t.getJobCompCode());
        crewTimeSheet.setSeqNo(t.getSeqNo());
        crewTimeSheet.setWorkDate(t.getWorkDate());
        crewTimeSheet.setEdited(t.getState());
        if (t.getCrewCode()==null ||t.getCrewCode().equalsIgnoreCase("")|| t.getCrewCode().equalsIgnoreCase("null") ||  t.getCrewCode().isEmpty())
            return null;
        return crewTimeSheet;
    }

    public void deleteTimeSheetFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            db.execSQL("DELETE FROM " + D.TABLE_TIMESHEET);
            db.execSQL("DELETE FROM " + D.TABLE_EMPLOYEE_DATA_FOR_CREW);
            db.execSQL("DELETE FROM " + D.TABLE_ACTIVITY_TIME_FOR_CREW);
            db.execSQL("DELETE FROM " + D.TABLE_ACTIVITY_FOR_TIMESHEET);
            db.execSQL("DELETE FROM " + D.TABLE_TIME_IN_OUT);
            db.setTransactionSuccessful();
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public boolean isTimeSheetPresent(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        boolean empty = true;
        Cursor cur = db.rawQuery("SELECT COUNT(*) FROM "+D.TABLE_TIMESHEET, null);
        if (cur != null && cur.moveToFirst()) {
            empty = (cur.getInt (0) == 0);
        }
        cur.close();
        return !empty;
    }

    public void setTimeSheetStateInDatabase(boolean isEdited, String workDate){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            if (isEdited)
                values.put(D.TimesheetState,1);
            else
                values.put(D.TimesheetState,0);
            db.update(D.TABLE_TIMESHEET, values, D.Timesheet_WorkDate+"=?",new String[]{workDate});
        }
        catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {

        }
    }
}

