package com.example.ishanjaiswal.cmicresultactivity;

import java.io.Serializable;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class InitCrewModel implements Serializable {
    String crewName,crewCode,crewOraSeq;

    public InitCrewModel(String crewName, String crewCode, String crewOraSeq) {
        this.crewCode = crewCode;
        this.crewName = crewName;
        this.crewOraSeq = crewOraSeq;
    }

    public String getCrewCode() {
        return crewCode;
    }

    public String getCrewName() {
        return crewName;
    }

    public String getCrewOraSeq() {
        return crewOraSeq;
    }
}
