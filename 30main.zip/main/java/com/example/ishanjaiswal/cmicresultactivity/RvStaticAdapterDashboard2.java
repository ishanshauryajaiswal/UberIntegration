package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.RecyclerViewClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;
import java.util.List;

/**
 * Created by ishan.jaiswal on 1/30/2018.
 */

public class RvStaticAdapterDashboard2 extends RecyclerView.Adapter<RvStaticAdapterDashboard2.ViewHolder> {

    private List<Dashboard2> mList;
    private Context mContext;
    private RecyclerViewClickListener mListener;

    public RvStaticAdapterDashboard2(List<Dashboard2> mList, Context mContext,RecyclerViewClickListener mListener) {
        this.mList = mList;
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_static_dashboard2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final Dashboard2 dashboard2 = mList.get(position);
        AllTimes allTimesTotal = dashboard2.getTotalTime();
        holder.tvCrewMemberName.setText(dashboard2.getCrewMemberName());
        holder.tvRegTotal.setText(String.valueOf(allTimesTotal.getReg()));
        holder.tvOtTotal.setText(String.valueOf(allTimesTotal.getOt()));
        holder.tvDotTotal.setText(String.valueOf(allTimesTotal.getDot()));
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onRecyclerViewDashboard2RowClicked(dashboard2.getEmpNo(), dashboard2.getEmpFirstName().concat(" ".concat(dashboard2.getEmpLastName())));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(List<Dashboard2> mList) {
        this.mList = mList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCrewMemberName, tvRegTotal, tvOtTotal, tvDotTotal;
        LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            linearLayout = (LinearLayout)itemView.findViewById(R.id.ll_dashboard2_list_cell);
            tvCrewMemberName = (TextView)itemView.findViewById(R.id.tvCrewMemberNameDashboard2);
            tvRegTotal = (TextView)itemView.findViewById(R.id.tvREGValue);
            tvOtTotal = (TextView)itemView.findViewById(R.id.tvOTValue);
            tvDotTotal = (TextView)itemView.findViewById(R.id.tvDOTValue);
        }
    }
}