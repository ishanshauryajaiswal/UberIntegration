package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 Created by parneet.singh on 8/8/2016.
 */
public class ServerConnection
{
    private static final String TAG = ServerConnection.class.getSimpleName();
    private static final HashMap<Integer, String> hmStatusCodes = CollectionUtils.hashMapStatusCodes;
    OkHttpClient okHttpClient = new OkHttpClient();
    String username,password,authEncoded;
    Context mContext;
    SharedPreferences ishanSharedPreferences;
    public ServerConnection(Context context){
        mContext=context;
        ishanSharedPreferences = mContext.getSharedPreferences(mContext.getString(R.string.cmic_shared_preference), context.MODE_PRIVATE);
        username = ishanSharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_username), null);
        password = ishanSharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_password), null);
        authEncoded = ishanSharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_autchcode),null);
    }

    public String Login(String url, String auth) throws IOException
    {
        this.authEncoded = auth;
        Log.d(TAG, "Connection: URL = : " + url);
        okHttpClient.setConnectTimeout(7000, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(7000, TimeUnit.SECONDS);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).build();
        try
        {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]
                    {
                            new X509TrustManager() {
                                @Override
                                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                    return null;
                                }
                            }
                    };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient okHttpClient = new OkHttpClient();
            okHttpClient.setSslSocketFactory(sslSocketFactory);
            okHttpClient.setHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
            Response response = okHttpClient.newCall(request).execute();
            int responsecode = response.code();
            Log.d(TAG,"Login: Code "+ String.valueOf(responsecode));
            if (responsecode == 200)
            {
                Log.d(TAG, "Login: Successful");
                return response.body().string();
            }
            else
            {
                if (hmStatusCodes.containsKey(responsecode)) {
                    Log.d(TAG, "Login: Unsuccessful");
                    return hmStatusCodes.get(responsecode);
                }
                else
                    return mContext.getString(R.string.internal_server_error);
            }
        }
        catch (Exception e)
        {
            Log.d(TAG,"Login: Exception - " +e.getMessage());
            return mContext.getString(R.string.internal_server_error);
        }

    }

    public String Connection(String url) throws IOException
    {
        Log.d(TAG, "Connection: URL = : " + url);
        okHttpClient.setConnectTimeout(7000, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(7000, TimeUnit.SECONDS);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).build();
        try
        {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]
                    {
                            new X509TrustManager() {
                                @Override
                                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                    return null;
                                }
                            }
                    };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient okHttpClient = new OkHttpClient();
            okHttpClient.setSslSocketFactory(sslSocketFactory);
            okHttpClient.setHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            Log.d(TAG,"Connection: Code "+ String.valueOf(responseCode));
            if (responseCode == 200)
            {
                Log.d(TAG, "Connection: Successful");
                return response.body().string();
            }
            else {
                Log.d(TAG, "Login: Unsuccessful");
                if (hmStatusCodes.containsKey(responseCode))
                    return hmStatusCodes.get(responseCode);
                else
                    return mContext.getString(R.string.internal_server_error);
            }
        }
        catch (Exception e)
        {
            Log.d(TAG,"Connection: Exception - " +e.getMessage());
            return mContext.getString(R.string.internal_server_error);
        }

    }

    public String putRequestConnection(String url, String parameters)
    {
        okHttpClient.setConnectTimeout(90, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(90,TimeUnit.SECONDS);
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, parameters);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        try
        {
            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            Log.d(TAG, " UpdateResponsiblePerson: Response Code - " + responseCode);
            Log.d(TAG," UpdateResponsiblePerson: Response - " + response.toString());
            switch (responseCode) {
                case 200: {
                    Log.d(TAG,"UpdateResponsiblePerson Successful");
                    return response.body().string();
                }
                default:
                    Log.d(TAG, "UpdateResponsiblePerson: Unsuccessful");
                    if (hmStatusCodes.containsKey(responseCode))
                        return hmStatusCodes.get(responseCode);
                    else
                        return mContext.getString(R.string.internal_server_error);
            }
        } catch (Exception e) {
            return mContext.getString(R.string.internal_server_error);
        }
    }

    public String ConnectionUploadSignature(String url ,String fileName,Bitmap bitmap) throws Exception
    {
        String result = null;
        DataOutputStream wr=null;
        StringBuffer sb = new StringBuffer();
        InputStream is = null;
        String boundary = "-------------------------acebdf13572468";
        String contentType = "multipart/form-data; boundary=";
        contentType = contentType + boundary;
        Log.d("ContentType",contentType);
        byte[] byteArray = getBytesFromBitmap(bitmap);
        Log.d("ByteArray", String.valueOf(byteArray));


        String encodedImage = Base64.encodeToString(byteArray , Base64.DEFAULT);

        URL fileurl = null;
        fileurl = new URL(url);
        Log.d("Upload Signature", String.valueOf(fileurl));

        try {
            HttpURLConnection conection = null;
    /*Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).build();*/
            conection = (HttpURLConnection) fileurl.openConnection();

            conection.setRequestProperty("Content-Type", contentType);

            // conection.setRequestProperty("charset", "utf-8");
            conection.setRequestProperty("Authorization", "Basic " + authEncoded);
            conection.setInstanceFollowRedirects(false);
            conection.setUseCaches(true);
            conection.setDoInput(true);
            conection.setDoOutput(true);
            conection.setChunkedStreamingMode(0);

            conection.setDefaultUseCaches(true);
            conection.setRequestMethod("PUT");

            String upperBoundry = "---------------------------acebdf13572468" +

                    "\r\n" +

                    "Content-Disposition: form-data; name=\"file\"; filename=\""
                    + fileName + ".jpg " +

                    "\r\n" +

                    "Content-Type: " + contentType +

                    "\r\n" +

                    "\r\n";

            String lowerBoundry = "\r\n" +

                    "---------------------------acebdf13572468--" +

                    "\r\n";

            String postData = upperBoundry + encodedImage + lowerBoundry;
            byte[] byteData = new byte[0];
            byteData = postData.getBytes("UTF-8");
            conection.getOutputStream().write(byteData);
            // wr.write(byteData);
            conection.connect();
            int status = conection.getResponseCode();
            Log.d("PUTRequest", status + "");
            if (status == 200)
            {
                is = new BufferedInputStream(conection.getInputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String inputLine = "";
                while ((inputLine = br.readLine()) != null) {
                    sb.append(inputLine);
                }
                result = sb.toString();
                return result;
            }
            else
            {
                Log.d("Error", "Code400");
            }
            return result;
        }
        catch (Exception e)
        {
            Log.d("Exception in Loading",e.toString());
        }

        return null;
    }

    private byte[] getBytesFromBitmap(Bitmap bitmap)
    {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    public String DeleteConnection(String url) throws IOException
    {
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).delete().build();
        try
        {

            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            Log.d(TAG," DeleteConnection: Code - "+ String.valueOf(responseCode));
            if (responseCode == 200)
            {
                Log.d(TAG, "DeleteConnection: Successful");
                return response.body().string();
            }
            else
            {
                Log.d(TAG, "DeleteConnection: Unsuccessful");
                if (hmStatusCodes.containsKey(responseCode))
                    return hmStatusCodes.get(responseCode);
                else
                    return mContext.getString(R.string.internal_server_error);
            }
        }
        catch(Exception e)
        {
            Log.d(TAG, " DeleteConnection : Exception -  "+ e.getMessage());
            return mContext.getString(R.string.internal_server_error);
        }
    }

    public String deleteCrewMember(String url) throws IOException
    {
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).delete().build();
        try
        {

            Response response = okHttpClient.newCall(request).execute();
            int responsecode = response.code();
            Log.d("Code", String.valueOf(responsecode));
            if (responsecode == 200)
            {
                return response.body().string();
            }
            else
            {
                Log.d("DeleteException","Exception1");
                return null;
            }
        }
        catch(Exception e)
        {
            Log.d("DeleteException","Exception");
            return null;
        }
    }

    public String insertCrewNameCrewCode(String url, String table)
    {
        okHttpClient.setConnectTimeout(90, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(90, TimeUnit.SECONDS);
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, table);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            if (responseCode == 200){
                Log.d(TAG,"InsertCrewNameCrewCode: Successful");
                return response.body().string();
            }
            else {
                Log.d(TAG, "InsertCrewNameCrewCode: Unsuccessful");
                if (hmStatusCodes.containsKey(responseCode))
                    return hmStatusCodes.get(responseCode);
                else
                    return mContext.getString(R.string.internal_server_error);
            }
        } catch (Exception e) {
            return mContext.getString(R.string.internal_server_error);
        }
    }

    public String connectionPutEmployee(String url, String crewOraSeq, ArrayList<User> selectedEmployees) throws UnsupportedEncodingException
    {
        String strJSON = null;
        okHttpClient.setConnectTimeout(60, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(60, TimeUnit.SECONDS);
        try
        {
            strJSON = jsonForLinkingRequest(crewOraSeq, selectedEmployees);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
            Log.e(TAG, "Error in JSON while Linking Employee: "+e.getMessage());
            return mContext.getString(R.string.internal_server_error);
        }
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON,strJSON);
        Log.d(TAG,"Linking Json: "+ strJSON);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        try
        {
            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            if (responseCode == 200)
            {
                Log.d(TAG,"Linking Successful");
                String s = response.body().string();
                return s;
            }
            else {
                Log.d(TAG, "Linking: Unsuccessful");
                if (hmStatusCodes.containsKey(responseCode))
                    return hmStatusCodes.get(responseCode);
                else
                    return mContext.getString(R.string.internal_server_error);
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, "Linking Unsuccessful. Error: "+e.toString());
            return mContext.getString(R.string.internal_server_error);
        }
    }


    public String submitTimeSheet(String url, String parameters)
    {
        okHttpClient.setConnectTimeout(90, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(90,TimeUnit.SECONDS);
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, parameters);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        Log.d(TAG, " SubmitTimeSheet: Request JSON - " + parameters);
        try
        {
            Response response = okHttpClient.newCall(request).execute();
            int responseCode = response.code();
            Log.d(TAG, " SubmitTimeSheet: Response Code - " + responseCode);
            Log.d(TAG," SubmitTimeSheet: Response - " + response.toString());
            switch (responseCode) {
                case 200: {
                    Log.d(TAG,"Submit Timesheet Successful");
                    return response.body().string();
                }
                default:
                    Log.d(TAG,"Submit Timesheet UnSuccessful");
                    if (hmStatusCodes.containsKey(responseCode))
                        return hmStatusCodes.get(responseCode);
                    else
                        return mContext.getString(R.string.internal_server_error);
            }
        } catch (Exception e) {
            return mContext.getString(R.string.internal_server_error);
        }
    }

    public String json (BigInteger selectedCrewOraseq , BigInteger[] selectedEmployeeOraseq) throws JSONException
    {
        JSONObject mainJsonObj = new JSONObject();
        mainJsonObj.put("table","PycrewempsView");
        JSONObject rowDefinitionObj = new JSONObject();
        JSONArray attrNames = new JSONArray();
        attrNames.put("PyceCrewOraseq");
        attrNames.put("PyceEmpOraseq");
        rowDefinitionObj.put("attrNames",attrNames);
        mainJsonObj.put("rowDefinition",rowDefinitionObj);
        JSONArray rows = new JSONArray();
        for(int i = 0; i<selectedEmployeeOraseq.length;i++)
        {
            JSONObject insideRows = new JSONObject();
            JSONArray attrValues = new JSONArray();
            attrValues.put(selectedCrewOraseq);
            attrValues.put(selectedEmployeeOraseq[i]);
            insideRows.put("attrValues",attrValues);
            rows.put(insideRows);
        }
        mainJsonObj.put("rows",rows);
        return String.valueOf(mainJsonObj);
    }

    String jsonForLinkingRequest(String  selectedCrewOraseq, ArrayList<User> selectedEmployees)throws JSONException{
        JSONObject mainJsonObj = new JSONObject();
        mainJsonObj.put("table","PycrewempsView");
        JSONObject rowDefinitionObj = new JSONObject();
        JSONArray attrNames = new JSONArray();
        attrNames.put("PyceCrewOraseq");
        attrNames.put("PyceEmpOraseq");
        rowDefinitionObj.put("attrNames",attrNames);
        mainJsonObj.put("rowDefinition",rowDefinitionObj);
        JSONArray rows = new JSONArray();
        for(int i = 0; i<selectedEmployees.size();i++)
        {
            User user = selectedEmployees.get(i);
            JSONObject insideRows = new JSONObject();
            JSONArray attrValues = new JSONArray();
            attrValues.put(selectedCrewOraseq);
            attrValues.put(user.getEmployeeOraseq());
            insideRows.put("attrValues",attrValues);
            rows.put(insideRows);
        }
        mainJsonObj.put("rows",rows);
        return String.valueOf(mainJsonObj);
    }
}
