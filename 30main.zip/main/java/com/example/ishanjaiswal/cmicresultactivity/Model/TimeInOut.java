package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.io.Serializable;

/**
 * Created by ishan.jaiswal on 4/16/2018.
 */

public class TimeInOut implements Serializable {
    private String employeeNumber;
    private int index;
    private String  timeIn;
    private String timeOut;
    private double total;

    public TimeInOut(){}

    public TimeInOut(int index, String timeIn, String timeOut, double total) {
        this.index = index;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.total = total;
    }

    public TimeInOut(String employeeNumber, int index, String timeIn, String timeOut, double total) {
        this.employeeNumber = employeeNumber;
        this.index = index;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.total = total;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
