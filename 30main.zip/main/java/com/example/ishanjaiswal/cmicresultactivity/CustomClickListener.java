package com.example.ishanjaiswal.cmicresultactivity;

import android.view.View;

/**
 * Created by ishan.jaiswal on 2/19/2018.
 */

public interface CustomClickListener {
    public void activityHeaderClicked(int position);
    public void activityHeaderLongPressed(View v, int position);
    public void rowItemClicked(int listPosition, int activityPosition);
    public void crewMemberLongClicked(View v, int position);
}
