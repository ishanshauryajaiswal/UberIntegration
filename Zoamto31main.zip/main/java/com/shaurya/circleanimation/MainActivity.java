package com.shaurya.circleanimation;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {


    private static final int CHOICE_AVATAR_FROM_GALLERY = 1;
    private static final int CHOICE_AVATAR_FROM_CAMERA_CROP = 2;
    private static final int CHOICE_AVATAR_FROM_CAMERA = 3;

    private static final String DOWNLOAD_IMAGE_PATH = "pappu";
    EditText etName, etId;
    CheckBox dealFood, dealDrinks;
    Button spank;
    boolean food = false, drinks = false;
    private Uri image;
    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
    SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
    SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    private void initViews() {
        etName = findViewById(R.id.et_name);
        etId = findViewById(R.id.et_id);
        dealFood = findViewById(R.id.cb_food);
        dealDrinks = findViewById(R.id.cb_drinks);
        spank = findViewById(R.id.btn_spank);

        getSupportActionBar().setTitle(getString(R.string.app_name));

        dealFood.setOnClickListener(v ->{
                dealFood.setChecked(true);
                food = true;
                drinks = !food;
                dealDrinks.setChecked(false);
        });

        dealDrinks.setOnClickListener(v ->{
                dealDrinks.setChecked(true);
                drinks = true;
                food = !drinks;
                dealFood.setChecked(false);
        });

        spank.setOnClickListener(v->{
                hideKeyboard(MainActivity.this);
                if (validateInput()){
                    Details.RESTAURANT_NAME = "at " + etName.getText().toString();
                    Details.VISIT_ID = "Visit ID is " + etId.getText().toString();
                    if (food)
                        Details.DEAL ="Please show this to your server and enjoy 1 + 1 on any dish on the menu";
                    else
                        Details.DEAL = "Please show this to your server and enjoy 2 + 2 on any drink on the menu";
                    getTimeStamp();
                    Intent intent = new Intent(MainActivity.this, GoldActivity.class);
                    intent.putExtra("bitmap",image);
                    startActivity(intent);
                }
        });

        findViewById(R.id.btn_upload_image).setOnClickListener(v ->{
            choiceAvatarFromGallery();
        });

    }

    public void choiceAvatarFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(getCropIntent(intent), CHOICE_AVATAR_FROM_GALLERY);
    }

    private Intent getCropIntent(Intent intent) {
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 320);
        intent.putExtra("outputY", 320);
        intent.putExtra("return-data", true);
        return intent;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CHOICE_AVATAR_FROM_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {
                image = data.getData();
                /*try {
                    image = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }*/
            } else if (requestCode == CHOICE_AVATAR_FROM_CAMERA_CROP) {
                Intent intent = new Intent("com.android.camera.action.CROP");
                Uri uri = Uri.fromFile(new File(cameraFileName));
                intent.setDataAndType(uri, "image/*");
                startActivityForResult(getCropIntent(intent), CHOICE_AVATAR_FROM_CAMERA);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public static Bitmap getBitmapFromData(Intent data) {
        Bitmap photo = null;
        Uri photoUri = data.getData();
        if (photoUri != null) {
            String path = photoUri.getPath();
            try {
                photo = BitmapFactory.decodeFile(path);
            }
            catch (Exception e){
                Log.e(MainActivity.class.getSimpleName(), e.getMessage());
                e.printStackTrace();
            }
        }
        if (photo == null) {
            Bundle extra = data.getExtras();
            if (extra != null) {
                photo = (Bitmap) extra.get("data");
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                photo.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            }
        }

        return photo;
    }

    private String cameraFileName;
    public void choiceAvatarFromCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraFileName = DOWNLOAD_IMAGE_PATH + System.currentTimeMillis();
        File file = new File(DOWNLOAD_IMAGE_PATH);
        if(!file.exists()){
            file.mkdirs();
        }
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(cameraFileName)));
        intent.putExtra("return-data", true);
        startActivityForResult(intent, CHOICE_AVATAR_FROM_CAMERA_CROP);
    }

    private boolean validateInput(){

        String name = etName.getText().toString();
        String id = etId.getText().toString();
        boolean flag = true;
        if (TextUtils.isEmpty(name)){
            flag = false;
            showSnackbar("Feed me Outlet Name you  IDIOT");
        }
        else if (TextUtils.isEmpty(id)){
            flag = false;
            showSnackbar("Feed me Visit ID  CHUTIYE");
        }
        else if(food == drinks){
            flag = false;
            showSnackbar("Select a Deal  PAPPU");
        }
        else
            flag = true;
        return flag;
    }

    private void getTimeStamp(){
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, -15);
        String time = sdf.format(calendar.getTime());
        String date = dayFormat.format(calendar.getTime());
        String month = monthFormat.format(calendar.getTime());
        String year = yearFormat.format(calendar.getTime());
        Details.DATE = "Unlocked at "+time+" on "+date+"-"+month+"-"+year;
    }

    private void showSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT).show();
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
