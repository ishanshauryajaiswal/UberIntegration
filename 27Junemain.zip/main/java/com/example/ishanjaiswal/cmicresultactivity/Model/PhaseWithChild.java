package com.example.ishanjaiswal.cmicresultactivity.Model;

public class PhaseWithChild
{
    public String  JcatJobCode ,JcatCode,CatName,JcatPhsCode,JcatCompCode;

    public PhaseWithChild(String JcatJobCode, String JcatCode, String CatName, String JcatPhsCode, String JcatCompCode)
    {
        this.JcatJobCode = JcatJobCode;
        this.JcatCode = JcatCode;
        this.CatName = CatName;
        this.JcatPhsCode = JcatPhsCode;
        this.JcatCompCode = JcatCompCode;
    }

    public PhaseWithChild(){}


    public void setJcatCompCode(String JcatCompCode)
    {
        this.JcatCompCode = JcatCompCode;
    }
    public void setJcatPhsCode(String JcatPhsCode)
    {
        this.JcatPhsCode = JcatPhsCode;
    }
    public void setJcatCode(String JcatCode)
    {
        this.JcatCode = JcatCode;
    }
    public void setJcatJobCode(String JcatJobCode)
    {
        this.JcatJobCode = JcatJobCode;
    }
    public void setCatName(String CatName)
    {
        this.CatName = CatName;
    }

    public String getJcatCompCode()
    {
        return JcatCompCode;
    }
    public String getJcatPhsCode()
    {
        return JcatPhsCode;
    }
    public String getJcatJobCode()
    {
        return JcatJobCode;
    }

    public String getJcatCode()
    {
        return JcatCode;
    }
    public String getCatName(){
        return CatName;
    }

    public String CatName()
    {
        return CatName;
    }
}
