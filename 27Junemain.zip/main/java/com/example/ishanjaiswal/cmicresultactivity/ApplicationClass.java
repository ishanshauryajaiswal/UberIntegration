package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

//import com.bugsee.library.Bugsee;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.facebook.stetho.Stetho;

/**
 * Created by ishan.jaiswal on 5/28/2018.
 */

public class ApplicationClass extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Stetho.initializeWithDefaults(this);
        //Bugsee.launch(this, getString(R.string.key_bugsee));
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sp.edit();
        String server = sp.getString(getString(R.string.settings_key_server),getString(R.string.settings_server_default));
        String environment = sp.getString(getString(R.string.settings_key_environment),null);
        if (environment!=null) {
            if (server.contains(environment))
                editor.remove(getString(R.string.settings_key_environment));
            else {
                server = server.concat("/").concat(environment);
                editor.putString(getString(R.string.settings_key_server), server);
                editor.remove(getString(R.string.settings_key_environment));
            }
            editor.commit();
        }
    }
}
