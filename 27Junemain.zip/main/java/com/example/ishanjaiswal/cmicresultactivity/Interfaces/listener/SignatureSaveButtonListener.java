package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

public interface SignatureSaveButtonListener {
    void enableSaveButton(Signature enumSignature);
}
