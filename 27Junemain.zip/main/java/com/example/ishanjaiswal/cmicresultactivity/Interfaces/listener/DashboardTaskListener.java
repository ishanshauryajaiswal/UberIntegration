package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

import android.graphics.Bitmap;

import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface DashboardTaskListener {

    void beforeDashboardTaskStarted(String displayMessage);

    void onDashboardTaskComplete(String response);

    void onTaskCancelled();

    void onDashboard2TaskComplete(String response);

    void onDashboard3TaskComplete(String response);

    void onGetSignatureOraSeqStarted(String displayMessage);

    void onGetSignatureOraSeqCompleted(String response);

    void onGetSignatureStarted();

    void onGetSignatureCompleted(Bitmap bitmap, GetSignature enumSignature);

    void onPostSignatureTaskStarted(String displayMessage);

    void onPostSignatureTaskCompleted(String response, Signature enumSignature);

    void onDeleteSignatureTaskStarted(String displayMessage);

    void onDeleteSignatureTaskCompleted(String response, Signature enumSignature);
}
