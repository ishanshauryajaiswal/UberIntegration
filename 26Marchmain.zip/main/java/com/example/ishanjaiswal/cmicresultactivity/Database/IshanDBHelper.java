package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */


public class IshanDBHelper extends SQLiteOpenHelper {
    private static IshanDBHelper mInstance;
    private static final String DBName="DATABASE";
    private static final int DBVersion = 1;
    private static IshanDBConstants D = new IshanDBConstants();
    private static final String TAG = IshanDBHelper.class.getSimpleName();

    private static final String CREATE_TABLE_EMPLOYEE_DATA = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_EMPLOYEE_DATA_FOR_CREW + "(" +
            D.EmployeeName_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeNumber_EmployeeDataForCrew + " INTEGER PRIMARY KEY,"+
            D.EmployeeOraseq_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeCode_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeName_EmployeeDataForCrew + " TEXT,"+
            D.JobCode_EmployeeDataForCrew+ " TEXT,"+
            D.PeriodFlag_EmployeeDataForCrew+ " TEXT,"+
            D.RowNumber_EmployeeDataForCrew+ " TEXT,"+
            D.WorkDate_EmployeeDataForCrew+ " TEXT,"+
            D.CrewCode_EmployeeDataForCrew + " TEXT)";

    private static final String CREATE_TABLE_ACTIVITY_TIME_FOR_CREW = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_ACTIVITY_TIME_FOR_CREW + "(" +
            D.EmployeeNumber_EmployeeDataForCrew+ " INTEGER PRIMARY KEY,"+
            D.rtSeqNumber+ " TEXT,"+
            D.rtHours+ " TEXT,"+
            D.otseqNumber+ " TEXT,"+
            D.otHour+ " TEXT,"+
            D.dotSeqNumber+ " TEXT,"+
            D.dothour+ " TEXT)";

    private static final String CREATE_TABLE_ACTIVITY_FOR_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+ D.TABLE_ACTIVITY_FOR_TIMESHEET+"("+
            D.ActivityName_ActivityForTimeSheet+ " TEXT,"+
            D.CategoryCode_ActivityForTimeSheet+ " TEXT,"+
            D.ColoumnNumber_ActivityForTimeSheet+ " INTEGER PRIMARY KEY,"+
            D.CrewCode_ActivityForTimeSheet+ " TEXT,"+
            D.JobCode_ActivityForTimeSheet+ " TEXT,"+
            D.JobCompCode_ActivityForTimeSheet+ " TEXT,"+
            D.PciLineOraseq_ActivityForTimeSheet+ " TEXT,"+
            D.PhaseCode_ActivityForTimeSheet+ " TEXT,"+
            D.SeqNumber_ActivityForTimeSheet+ " TEXT,"+
            D.WbsCode_ActivityForTimeSheet+ " TEXT,"+
            D.WorkDate_ActivityForTimeSheet+ " TEXT)";

    private IshanDBHelper(Context context) {
        super(context, DBName, null, DBVersion);
    }

    public static synchronized IshanDBHelper getInstance(Context context){
        if (mInstance == null)
            mInstance = new IshanDBHelper(context);
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
            db.execSQL(CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
            db.execSQL(CREATE_TABLE_EMPLOYEE_DATA);
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_EMPLOYEE_DATA);
        onCreate(db);
    }

    public void insertEmployeeInDatabase(EmployeeDataForCrew employee){
        try {
            SQLiteDatabase db = mInstance.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(D.CrewCode_EmployeeDataForCrew, "");
            values.put(D.EmployeeName_EmployeeDataForCrew, employee.getEmpName());
            values.put(D.EmployeeNumber_EmployeeDataForCrew, Integer.parseInt(employee.getEmpNo()));
            values.put(D.EmployeeTradeCode_EmployeeDataForCrew, employee.getTradeCode());
            values.put(D.EmployeeTradeName_EmployeeDataForCrew, employee.getTradeName());
            values.put(D.PeriodFlag_EmployeeDataForCrew, employee.getPeriodFlag());
            values.put(D.RowNumber_EmployeeDataForCrew, employee.getRowNo());
            values.put(D.JobCode_EmployeeDataForCrew, employee.getJobCode());
            values.put(D.WorkDate_EmployeeDataForCrew, employee.getWorkDate());
            int id = (int) db.insertWithOnConflict(D.TABLE_EMPLOYEE_DATA_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_EMPLOYEE_DATA_FOR_CREW,values, D.EmployeeNumber_EmployeeDataForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeNumber_EmployeeDataForCrew)+""});
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }

    public void insertActivityTimeForEmployee(String employeeNumber, ActivityTimeForCrew activityTimeForCrew){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.EmployeeNumber_ActivityTimeForCrew, Integer.parseInt(employeeNumber));
            values.put(D.rtSeqNumber, activityTimeForCrew.getStandardTimeSeqNumber());
            values.put(D.rtHours, activityTimeForCrew.getStandardTime());
            values.put(D.otseqNumber, activityTimeForCrew.getOverTimeSeqNumber());
            values.put(D.otHour, activityTimeForCrew.getOverTime());
            values.put(D.dotSeqNumber, activityTimeForCrew.getDoubleOverTimeSeqNumber());
            values.put(D.dothour, activityTimeForCrew.getDoubleOverTime());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_TIME_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_TIME_FOR_CREW,values, D.EmployeeNumber_ActivityTimeForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeNumber_ActivityTimeForCrew)+""});
            }
        }

        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }

    public void insertActivityForTimesheet(SubmittedActivityFromCrewModal activity) {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.ActivityName_ActivityForTimeSheet, activity.getActivityName());
            values.put(D.CategoryCode_ActivityForTimeSheet, activity.getCatCode());
            values.put(D.ColoumnNumber_ActivityForTimeSheet, Integer.parseInt(activity.getColoumnNo()));
            values.put(D.CrewCode_ActivityForTimeSheet, activity.getCrewCode());
            values.put(D.JobCode_ActivityForTimeSheet, activity.getJobCode());
            values.put(D.JobCompCode_ActivityForTimeSheet, activity.getJobCompCode());
            values.put(D.PciLineOraseq_ActivityForTimeSheet, activity.getPciLineOraseq());
            values.put(D.PhaseCode_ActivityForTimeSheet, activity.getPhaseCode());
            values.put(D.SeqNumber_ActivityForTimeSheet, activity.getSeqNo());
            values.put(D.WbsCode_ActivityForTimeSheet, activity.getWbsCode());
            values.put(D.WorkDate_ActivityForTimeSheet, activity.getWorkDate());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_FOR_TIMESHEET, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_FOR_TIMESHEET,values, D.ColoumnNumber_ActivityForTimeSheet+"=?",new String [] {values.getAsInteger(D.ColoumnNumber_ActivityForTimeSheet)+""});
            }
        } catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }

    public ArrayList<EmployeeDataForCrew> getEmployeeDataForCrewFromDatabase(){
        try {
            ArrayList<EmployeeDataForCrew> employeeDataForCrews = new ArrayList<>();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_EMPLOYEE_DATA_FOR_CREW, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    EmployeeDataForCrew e = new EmployeeDataForCrew();
                    e.setEmpName(cursor.getString(0));
                    e.setEmpNo(cursor.getString(1)+"");
                    e.setEmployeeOraseq(cursor.getString(2));
                    e.setTradeCode(cursor.getString(3));
                    e.setTradeName(cursor.getString(4));
                    e.setJobCode(cursor.getString(5));
                    e.setPeriodFlag(cursor.getString(6));
                    e.setRowNo(cursor.getString(7));
                    e.setWorkDate(cursor.getString(8));
                    employeeDataForCrews.add(e);
                    cursor.moveToNext();
                }
            }
            return employeeDataForCrews;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        return null;
    }

    public ArrayList<ActivityTimeForCrew> getActivityTimeForCrewFromDatabase(String empNo){
        try {
            ArrayList<ActivityTimeForCrew> activityTimeForCrews = new ArrayList<>();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_TIME_FOR_CREW +
                    " WHERE "+ D.EmployeeNumber_ActivityTimeForCrew + " = " + Integer.parseInt(empNo), null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    ActivityTimeForCrew a = new ActivityTimeForCrew();
                    a.setStandardTimeSeqNumber(cursor.getString(0));
                    a.setStandardTimeSeqNumber(cursor.getString(1));
                    a.setStandardTimeSeqNumber(cursor.getString(2));
                    a.setStandardTimeSeqNumber(cursor.getString(3));
                    a.setStandardTimeSeqNumber(cursor.getString(4));
                    a.setStandardTimeSeqNumber(cursor.getString(5));
                    activityTimeForCrews.add(a);
                    cursor.moveToNext();
                }
            }
            return activityTimeForCrews;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        return null;
    }

    public ArrayList<SubmittedActivityFromCrewModal> getActivityForTimesheet(){
        try {
            ArrayList<SubmittedActivityFromCrewModal> submittedActivityFromCrewModals = new ArrayList<>();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_FOR_TIMESHEET, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    SubmittedActivityFromCrewModal s = new SubmittedActivityFromCrewModal();
                    s.setActivityName(cursor.getString(0));
                    s.setCatCode(cursor.getString(1));
                    s.setColoumnNo(cursor.getString(2));
                    s.setCrewCode(cursor.getString(3));
                    s.setJobCode(cursor.getString(4));
                    s.setJobCompCode(cursor.getString(5));
                    s.setPciLineOraseq(cursor.getString(6));
                    s.setPhaseCode(cursor.getString(7));
                    s.setSeqNo(cursor.getString(8));
                    s.setWbsCode(cursor.getString(9));
                    s.setWorkDate(cursor.getString(10));
                    submittedActivityFromCrewModals.add(s);
                    cursor.moveToNext();
                }
            }
            return submittedActivityFromCrewModals;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        return null;
    }

    public void insertTimeSheetInDatabase(CrewTimeSheet crewTimeSheet){
        ArrayList<SubmittedActivityFromCrewModal> activityFromCrewModals = crewTimeSheet.getCrewActivity();
        for (SubmittedActivityFromCrewModal s : activityFromCrewModals)
            this.insertActivityForTimesheet(s);
        ArrayList<EmployeeDataForCrew> employeeDataForCrews = crewTimeSheet.getEmpTimeSheet();
        for (EmployeeDataForCrew e : employeeDataForCrews){
            this.insertEmployeeInDatabase(e);
            ArrayList<ActivityTimeForCrew> activityTimeForCrews = e.getTimeSheet();
            for (ActivityTimeForCrew a: activityTimeForCrews)
                this.insertActivityTimeForEmployee(e.getEmpNo(),a);
        }
    }

    public void getTimeSheetFromDatabase(){
        CrewTimeSheet crewTimeSheet = new CrewTimeSheet();
        crewTimeSheet.setCrewActivity(this.getActivityForTimesheet());
        ArrayList<EmployeeDataForCrew> employeeDataForCrews;
        employeeDataForCrews = this.getEmployeeDataForCrewFromDatabase();
        crewTimeSheet.setEmpTimeSheet(employeeDataForCrews);
        for (EmployeeDataForCrew e : employeeDataForCrews){
            ArrayList<ActivityTimeForCrew> activityTimeForCrew = this.getActivityTimeForCrewFromDatabase(e.getEmpNo());
            e.setTimeSheet(activityTimeForCrew);
        }
        Log.d("delete","delete");
    }
}
