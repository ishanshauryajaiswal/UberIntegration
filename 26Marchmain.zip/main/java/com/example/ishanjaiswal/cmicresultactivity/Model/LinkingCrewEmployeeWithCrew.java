package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class LinkingCrewEmployeeWithCrew
{
    public String tableName;
    public int numberOfRemainingRecords;
    public ArrayList<AttributeValuesForCrewceModal> attributeValuesForCrewceModals;

    public LinkingCrewEmployeeWithCrew(String tableName,int numberOfRemainingRecords,ArrayList<AttributeValuesForCrewceModal>attributeValuesForCrewceModals)
    {
        this.tableName = tableName;
        this.numberOfRemainingRecords = numberOfRemainingRecords;
        this.attributeValuesForCrewceModals = attributeValuesForCrewceModals;
    }

}
