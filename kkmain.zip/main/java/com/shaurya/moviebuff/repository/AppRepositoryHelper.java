package com.shaurya.moviebuff.repository;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;

import com.shaurya.moviebuff.model.Movie;
import com.shaurya.moviebuff.repository.local.db.AppDbHelper;
import com.shaurya.moviebuff.repository.remote.AppRemoteHelper;

import java.util.List;


public class AppRepositoryHelper {

    private MutableLiveData<List<Movie>> movieList = new MutableLiveData<>();

    private AppRemoteHelper remoteHelper;
    private AppDbHelper dbHelper;

    public AppRepositoryHelper() {
        remoteHelper = new AppRemoteHelper();
    }

    public LiveData<List<Movie>> fetchMovieFromRemote(int page){
        return remoteHelper.fetchMovieFromRemote(page);
    }




    public MutableLiveData<List<Movie>> getMovieList() {
        return movieList;
    }
}
