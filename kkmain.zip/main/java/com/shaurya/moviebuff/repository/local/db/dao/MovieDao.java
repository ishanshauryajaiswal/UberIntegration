package com.shaurya.moviebuff.repository.local.db.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.shaurya.moviebuff.model.Movie;

import java.util.List;

@Dao
public interface MovieDao {

    @Insert
    void insert(Movie movie);

    @Insert
    void insertAll(List<Movie> movieList);

    @Query("SELECT * from movie ORDER BY id ASC")
    LiveData<List<Movie>> getAllWords();

}
