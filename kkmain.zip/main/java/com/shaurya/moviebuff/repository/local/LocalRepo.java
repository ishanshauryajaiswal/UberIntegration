package com.shaurya.moviebuff.repository.local;

public class LocalRepo {
}
