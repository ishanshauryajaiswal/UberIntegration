package com.shaurya.moviebuff.repository.remote;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;

import com.shaurya.moviebuff.model.Movie;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AppRemoteHelper {

    private MovieService movieService;

    private MutableLiveData<List<Movie>> movieList = new MutableLiveData<>();

    public AppRemoteHelper() {
        movieService = RetrofitInstance.getInstance().create(MovieService.class);
    }

    public LiveData<List<Movie>> fetchMovieFromRemote(int page){
        movieService.fetchPopularMovies(ApiConstants.BASE_URL, page).enqueue(new Callback<List<Movie>>() {
            @Override
            public void onResponse(Call<List<Movie>> call, Response<List<Movie>> response) {
                int statusCode = response.code();
                if (statusCode == 200){
                    movieList.postValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<Movie>> call, Throwable t) {

            }
        });

        return movieList;
    }

}
