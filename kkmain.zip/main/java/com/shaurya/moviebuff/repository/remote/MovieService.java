package com.shaurya.moviebuff.repository.remote;

import com.shaurya.moviebuff.model.Movie;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MovieService {

    @GET(ApiConstants.POPULAR_URL)
    Call<List<Movie>> fetchPopularMovies(@Query(ApiConstants.API_KEY) String apiKey, @Query(ApiConstants.PAGE)int page);

}
