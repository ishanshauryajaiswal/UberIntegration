package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by parneet.singh on 9/15/2016.
 */
public interface CategoryInterface {

    public void onEndCat(String response);
}
