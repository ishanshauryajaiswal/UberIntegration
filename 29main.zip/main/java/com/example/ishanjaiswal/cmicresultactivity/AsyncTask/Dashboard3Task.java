package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard3;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/26/2018.
 */

public class Dashboard3Task extends AsyncTask<Void,Void,String > {
    private Context context;
    private String mDate,employeeNumber;
    private DashboardTaskListener mListener;
    private String TAG = Dashboard3.class.getSimpleName();

    public Dashboard3Task(Context context, String mDate, String employeeNumber, DashboardTaskListener mListener) {
        this.context = context;
        this.mDate = mDate;
        this.employeeNumber = employeeNumber;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute()
    {
        mListener.beforeDashboardTaskStarted("Fetching");
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        try
        {
            RequestCall requestCall = new RequestCall();
            result = requestCall.dashboardCrewMemberDetails(context,employeeNumber,mDate);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,e.getMessage());
        }
        return result;
    }
    protected void onPostExecute(String result)
    {
        mListener.onDashboard3TaskComplete(result);
    }
}
