package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

/**
 * Created by ishan.jaiswal on 2/28/2018.
 */

public class SubmittingTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private String request;
    private SubmittingTimeSheetInterface submittingTimeSheetInterface;

    public SubmittingTask(Context context,String request, SubmittingTimeSheetInterface submittingTimeSheetInterface)
    {
        this.context = context;
        this.request = request;
        this.submittingTimeSheetInterface = submittingTimeSheetInterface;
    }

    @Override
    protected void onPreExecute()
    {
        submittingTimeSheetInterface.BeforeCompleted();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        try
        {
            RequestCall requestCall = new RequestCall();
            result = requestCall.submitTask(context,  request);
        }
        catch(Exception e)
        {
            Log.d("error in submitting",e.toString());
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        if (response!=null) {
            Log.d("parneet", response);
            submittingTimeSheetInterface.SubmittingTimeSheetInterface(response);
        }
        else
            Log.d("IshanLog SubmittingTask", "Failied to Submit");
        // /RetrieveTimeSheetInterface.RetrieveTimeSheetInterface(response);
    }

}