package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/1/2018.
 */
public class Event {
    public int dx, dy;

    public Event(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    public Event getMessage() {
        return new Event(dx,dy);
    }
}