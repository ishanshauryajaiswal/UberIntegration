package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;

import java.util.ArrayList;
import java.util.List;


public class ActivityPciListAdapter extends BaseAdapter implements Filterable
{

    private ArrayList<PciModal> pciModals;
    private Context context;
    private LayoutInflater mInflater;
    private List<PciModal> filteredData = null;
    private ItemFilter mFilter = new ItemFilter();
    public ActivityPciListAdapter(Context context, ArrayList<PciModal> pciModals)
    {
        this.context = context;
        this.pciModals = pciModals;
    }

    @Override
    public int getCount()
    {
        if(pciModals!=null)
            return pciModals.size();
        return 0;
    }

    @Override
    public PciModal getItem(int position)
    {
        return pciModals.get(position);
    }
    public  void  setList(ArrayList<PciModal> list)
    {
        pciModals = list;
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        PciModal pciModal = getItem(position);
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listViewItem = inflater.inflate(R.layout.activity_pci_details, null);
        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtpcidetails);
        // final EditText search =(EditText) listViewItem.findViewById(R.id.search);
      /*  search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setFocusableInTouchMode(true);
                search.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        context.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);

            }
        });*/
        txt_project.setText("("+pciModal.getPciCode()+") - "+pciModal.getPciName());
        return listViewItem;
    }



    @Override
    public Filter getFilter()
    {
        return mFilter;
    }

    // Searching On basis of every property Of PhaseDetails
    private class ItemFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterString = constraint.toString().toLowerCase();
            FilterResults results = new FilterResults();
            final List<PciModal> list = pciModals;
            int count = list.size();
            final ArrayList<PciModal> nlist = new ArrayList<PciModal>(count);
            PciModal pciModal ;
            for (int i = 0; i < count; i++)
            {
                pciModal = list.get(i);
                if (pciModal.getPciCode().equals(filterString)||pciModal.getPciName().equals(filterString))
                {
                    nlist.add(pciModal);
                }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }
        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredData = (ArrayList<PciModal>) results.values;
            notifyDataSetChanged();

        }
    }
}
