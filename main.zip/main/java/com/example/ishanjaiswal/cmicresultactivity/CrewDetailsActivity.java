package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.LinkingEmployeeWithCrewTask;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanAllEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanSelectedEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.LinkingCrewEmployeeWithCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */

public class CrewDetailsActivity extends ListActivity {
    private static final String TAG = CrewDetailsActivity.class.getSimpleName();
    TextView txtCrewName, txtNext, txtSelect;
    EditText editText;
    CheckBox checkbox;
    DialogInterface dialog;
    ArrayList<User> CrewMemberDetails, selectedUsers;
    ArrayList<String> chckd;
    ArrayList<EmployeeDataForCrew> newCrewList = null;
    public String  crewCode, auth;
    ImageButton btn;
    public Button btnSaved, btnAll;
    SparseBooleanArray checkedItems = new SparseBooleanArray();
    ListView crewMembersList;
    ArrayList<String> previouslyCheckedEmployeeList = new ArrayList<>();
    String employeeNumber;
    String SelectedCrewOraseq, SelectedCrewCode, SelectedCrewName;
    private boolean isFromTimesheet, showOrHideCheckbox;
    private SharedPreferences ishanSharedPreference;
    private SharedPreferences.Editor ishanPreferenceEditor;
    IshanSelectedEmployeeDBHelper ishanSelectedEmployeeDBHelper;
    IshanAllEmployeeDBHelper allEmployeeDBHelper;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crewmembers_list);
        ishanSelectedEmployeeDBHelper = new IshanSelectedEmployeeDBHelper(CrewDetailsActivity.this);
        ValuesFromSharedPrefrence();
        getValueFromIntent();
        init();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }

        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setFocusableInTouchMode(true);
                editText.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
            }
        });

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                s = s.toString().toLowerCase();
                ArrayList<User> filteredListName = new ArrayList<User>();
                for (int i = 0; i < CrewMemberDetails.size(); i++){
                    String txtCrewName = CrewMemberDetails.get(i).getName().toLowerCase();
                    String txtCrewCode = CrewMemberDetails.get(i).getUniCode().toLowerCase();
                    String txtCrewTradeName = CrewMemberDetails.get(i).getTradeName().toLowerCase();
                    String txtCrewTradeCode = CrewMemberDetails.get(i).getTradeCode().toLowerCase();
                    if (txtCrewName.contains(s) || txtCrewCode.contains(s) || txtCrewTradeName.contains(s) || txtCrewTradeCode.contains(s))
                        filteredListName.add(CrewMemberDetails.get(i));
                }
                final CrewMemberAdapter crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, filteredListName, chckd, true);
                crewMembersList.setAdapter(crewMemberAdapter);
                handleList(crewMemberAdapter);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CrewDetailsActivity.this, CrewListActivity.class);
                startActivity(intent);

            }
        });
        btnSaved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSaved.setEnabled(false);
                btnAll.setEnabled(true);
                btnAll.setBackgroundResource(R.drawable.deselected_all_button_background);
                btnAll.setTextColor(Color.parseColor("#1780FB"));
                btnSaved.setBackgroundResource(R.drawable.saved_button_background);
                btnSaved.setTextColor(Color.parseColor("#ffffff"));
                CrewMemberDetails = ishanSelectedEmployeeDBHelper.selectAllEmployeesFromDatabase();
                fillEmployeeList();
            }
        });

        btnAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSaved.setEnabled(true);
                btnAll.setEnabled(false);
                btnAll.setBackgroundResource(R.drawable.all_button_background);
                btnAll.setTextColor(Color.parseColor("#ffffff"));
                btnSaved.setBackgroundResource(R.drawable.deselected_save_button_background);
                btnSaved.setTextColor(Color.parseColor("#1780FB"));
                webServiceForEmployeeData();
            }
        });
    }

    public void webServiceForEmployeeData()
    {
        new GetEmployees(getApplicationContext(), auth, new FillEmployeeListener() {
            @Override
            public void afterCompleted(String result) {
                dialog.dismiss();
                if (result == null)
                {
                    final android.app.AlertDialog.Builder alertBox = new android.app.AlertDialog.Builder(CrewDetailsActivity.this);
                    alertBox.setTitle("CMiC Mobile Crew Time");
                    alertBox.setMessage("No Crew Members Found");
                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alertBox.setCancelable(true);
                            webServiceForEmployeeData();
                        }
                    });
                    alertBox.show();
                }
                if (result != null)
                {
                    EmployeeDataParser EmployeeDataParser = new EmployeeDataParser();
                    CrewMemberDetails = EmployeeDataParser.parseEmployeeData(result, getApplicationContext());
                    fillEmployeeList();
                }
            }

            @Override
            public void beforeCompleted() {
                dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Fetching Crew Members...");
            }
        }).execute();
    }

    private void fillEmployeeList()
    {
        final CrewMemberAdapter userAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, CrewMemberDetails, chckd, showOrHideCheckbox);
        crewMembersList.setAdapter(userAdapter);
        handleList(userAdapter);

    }

    private void handleList(final CrewMemberAdapter crewMemberAdapter){
        crewMembersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                checkbox = (CheckBox) view.findViewById(R.id.chkbox);
                if (showOrHideCheckbox)
                {
                    if (checkbox.isChecked()) {
                        checkbox.setChecked(false);
                        checkedItems.put(position, false);
                    } else {
                        checkedItems.put(position, true);
                        checkbox.setChecked(true);
                    }
                }
                //To Change Responsible Person
                else {
                    String responsiblePerson = crewMemberAdapter.getItem(position).getName();
                        ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_responsible_person),responsiblePerson);
                    ishanPreferenceEditor.commit();
                    ishanSelectedEmployeeDBHelper.insertSelectedEmployeeInDatabase((User) crewMemberAdapter.getItem(position));
                    Intent intent = new Intent(CrewDetailsActivity.this,MainActivity.class);
                    if (isFromTimesheet){
                        setResult(Activity.RESULT_OK);
                        finish();
                    }
                    else {
                        startActivity(intent);
                        finish();
                    }
                }
            }
        });

        txtNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedUsers = new ArrayList<User>();
                boolean noCheckBoxSelected = false;
                for (int i = 0; i<= checkedItems.size(); i++){
                    if (checkedItems.valueAt(i))
                        noCheckBoxSelected = true;
                }
                if (!noCheckBoxSelected){
                    AlertDialog.Builder alertActivity = new  AlertDialog.Builder(CrewDetailsActivity.this);
                    alertActivity.setTitle("CMiC Mobile Crew Time");
                    alertActivity.setMessage("Please select atleast one crew member to continue");
                    alertActivity.setPositiveButton("OK", null);
                    alertActivity.show();
                }
                else {
                    //unchecking members already in the crew
                    ArrayList<String> temp = new ArrayList<>();
                    for (User user:CrewMemberDetails){
                        temp.add(user.getEmployeeNo());
                    }
                    for (String s:previouslyCheckedEmployeeList){
                        int position = temp.indexOf(s);
                        checkedItems.put(position, false);
                    }
                    for (int i = 0; i < checkedItems.size(); i++) {
                        User currentUser = new User();
                        int position = checkedItems.keyAt(i);
                        if (checkedItems.valueAt(i)) {
                            currentUser = crewMemberAdapter.getItem(position);
                            selectedUsers.add(currentUser);
                        }
                        ishanSelectedEmployeeDBHelper.insertSelectedEmployeeInDatabase(currentUser);
                        }
                    if (showOrHideCheckbox)
                    {
                        newCrewList = new ArrayList<EmployeeDataForCrew>();
                        Log.d(TAG, "IshanLog Linking Employee");
                        LinkingEmployeeWithCrewTask linkingEmployeeWithCrewTask = new LinkingEmployeeWithCrewTask(CrewDetailsActivity.this,
                                SelectedCrewOraseq, selectedUsers,
                                new LinkingEmployeeWithCrewTask.LinkingEmployeeInterface() {
                            @Override
                            public void onPostExecute(String response) {
                                if (response != null) {
                                    dialog.dismiss();
                                    FetchEmployeesOfCrew fetchEmployeesOfCrew = new FetchEmployeesOfCrew(CrewDetailsActivity.this, SelectedCrewCode, new FetchEmployeesOfCrewInterface() {
                                        @Override
                                        public void preTask() {
                                            dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Inserting Crew Members in Database...");
                                        }

                                        @Override
                                        public void postTask(String data) {
                                            if (data.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                                            } else {
                                                LinkingCrewEmployeeWithCrew employeeCrew = new FetchedCrewEmployeeParser().parseFetchedCrewEmployeeData(data);
                                                if (employeeCrew != null) {
                                                    ArrayList<AttributeValuesForCrewModal> employeesInCrew = employeeCrew.getAttributeValuesForCrewModals();
                                                    allEmployeeDBHelper = new IshanAllEmployeeDBHelper(CrewDetailsActivity.this);
                                                    allEmployeeDBHelper.insertAllEmployeeInDatabase(employeesInCrew);
                                                    setResult(Activity.RESULT_OK);
                                                    finish();
                                                }
                                            }
                                    }});
                                    fetchEmployeesOfCrew.execute();
                                    if (isFromTimesheet) {
                                        //Insert selected employees in timesheet database and make timesheet edited true
                                        IshanDBHelper mInstance = IshanDBHelper.getInstance(CrewDetailsActivity.this);
                                        CrewTimeSheet crewTimeSheet = mInstance.getTimeSheetFromDatabase();
                                        ArrayList<ActivityTimeForCrew> a = new ArrayList<ActivityTimeForCrew>();
                                        for (User crewMember : selectedUsers) {
                                            a = new ArrayList<ActivityTimeForCrew>();
                                            for (int i = 0; i < crewTimeSheet.getCrewActivity().size(); i++) {
                                                ActivityTimeForCrew activity = new ActivityTimeForCrew(null, 0, null, 0, null, 0, crewTimeSheet.getCrewCode()
                                                        , crewTimeSheet.getWorkDate(), crewMember.getEmployeeNo());
                                                a.add(activity);
                                            }
                                            EmployeeDataForCrew e = new EmployeeDataForCrew("null", crewMember.getEmployeeNo(), crewMember.getEmployeeOraseq(),
                                                    crewMember.getName(), crewMember.getTradeCode(), crewMember.getTradeName(),
                                                    crewTimeSheet.getEmpTimeSheet().size() + "", "",
                                                    a, null);
                                            crewTimeSheet.getEmpTimeSheet().add(e);
                                            mInstance.insertEmployeeInDatabase(e);
                                        }
                                        mInstance.setTimeSheetStateInDatabase(true, crewTimeSheet.getWorkDate());
                                    }
                                }
                                else {
                                    Toast.makeText(getApplicationContext(),"Error in Adding Crew",Toast.LENGTH_SHORT).show();
                                }
                            }

                                    @Override
                                    public void onPreExecute() {
                                        dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Linking Crew Members With Crew...");
                                    }
                                });
                        linkingEmployeeWithCrewTask.execute();
                    }
                }
                }
            }
        );

        txtSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtSelect.getText().toString().trim().equals("Select All")) {
                    txtSelect.setText("Clear All");

                    for (int i = 0; i < CrewMemberDetails.size(); i++) {
                        checkedItems.put(i, true);
                        crewMemberAdapter.addCheckItem(CrewMemberDetails.get(i).getEmployeeNo());

                    }
                    crewMemberAdapter.notifyDataSetChanged();
                } else {
                    txtSelect.setText("Select All");
                    for (int i = 0; i < CrewMemberDetails.size(); i++) {
                        checkedItems.put(i, false);
                        crewMemberAdapter.removeAllCheckedItems(CrewMemberDetails.get(i).getEmployeeNo());
                    }
                    crewMemberAdapter.notifyDataSetChanged();
                }
            }
        });


    }

    public void onBackPressed()
    {
    }

    public void ValuesFromSharedPrefrence ()
    {
        ishanSharedPreference = getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        SelectedCrewOraseq = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_ora_seq), getString(R.string.cmic_shared_preference_no_crew_oraseq));
        SelectedCrewCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_code), getString(R.string.cmic_shared_preference_no_crew_code));
        SelectedCrewName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_name),getString(R.string.cmic_shared_preference_no_crew_name));
    }

    public void init()
    {
        crewMembersList = (ListView) findViewById(android.R.id.list);
        btnSaved = (Button) findViewById(R.id.btnSave);
        btnAll = (Button) findViewById(R.id.btnAll);
        txtCrewName = (TextView) findViewById(R.id.txtName);
        editText = (EditText) findViewById(R.id.inputSearch);
        txtNext = (TextView) findViewById(R.id.txtDone);
        txtSelect = (TextView) findViewById(R.id.txtSelected);
        btn = (ImageButton) findViewById(R.id.btnback);
        //Disable Next Button if List for Responsible Person
        if (!showOrHideCheckbox){
            txtNext.setVisibility(View.INVISIBLE);
            txtSelect.setVisibility(View.INVISIBLE);
        }
    }

    public void getValueFromIntent()
    {
        isFromTimesheet = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_timesheet),false);
        if (isFromTimesheet){
            CrewTimeSheet mCrewTimeSheet = (CrewTimeSheet) getIntent().getSerializableExtra(getString(R.string.cmic_intent_extras_timesheet));
            if (mCrewTimeSheet != null) {
                for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                    employeeNumber = mCrewTimeSheet.getEmpTimeSheet().get(i).getEmpNo();
                    previouslyCheckedEmployeeList.add(employeeNumber);
                }
            }
        }
        showOrHideCheckbox = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_show_checkbox),true);
    }
}
