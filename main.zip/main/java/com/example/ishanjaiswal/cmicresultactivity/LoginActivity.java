package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

/*
import com.cmic.multiselectionmodal.Database.DBHelper;
import com.cmic.multiselectionmodal.Database.DatabaseConstants;
import com.cmic.multiselectionmodal.Modal.LoginModal;
import com.cmic.multiselectionmodal.Parser.LoginParser;
import com.cmic.multiselectionmodal.RequestCalls.RequestCall;
*/

import com.facebook.stetho.Stetho;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    EditText txtUsername;
    EditText txtPassword;
    Button btnSubmit;
    Button btnoffline;
    ImageButton btnvision;
    String username;
    boolean firstTimeCrewList,firstTimeProjectList;
    String password,selectedCrewCode,selectedCrewName,selectedProjectName,selectedProjectCode,selectedProjectCompCode;
    SharedPreferences sharedPreferencesCrewList,sharedPreferencesProject,sharedPreferencesLoginCredentials,isLoginFirstTimeCrew,isLoginFirstTimeJob;
    SharedPreferences.Editor toEditCrewList,toEditProject,toEdit;
    //ProgressBar progress;
    ProgressDialog progress;
    Boolean LoginFlag;
    SharedPreferences ishanSharedPreferences;
    SharedPreferences.Editor ishanEditor;
    boolean ishanFirstTimeCrewList,ishanFirstTimeProjectList;
    String crewCodefromPreferences, projectCodefromPreferences;
    // SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Log.d("query", DBHelper.TABLE_DASHBOARD_CREW_MEMBERS);
        setContentView(R.layout.activity_login);
        Stetho.initializeWithDefaults(this);
        getValuesFromSharedPreference();
        ishanFirstTimeCrewList = ishanSharedPreferences.getBoolean(getString(R.string.is_first_time_crew_list), true);
        ishanFirstTimeProjectList = ishanSharedPreferences.getBoolean(getString(R.string.is_first_time_project_list), true);

        isLoginFirstTimeCrew = getSharedPreferences("IsFirstTimeCrewList", MODE_PRIVATE);
        firstTimeCrewList = isLoginFirstTimeCrew.getBoolean("IsFirstTimeCrewList", false);
        toEdit = isLoginFirstTimeCrew.edit();
        isLoginFirstTimeJob = getSharedPreferences("IsFirstTimeProjectList", MODE_PRIVATE);
        firstTimeProjectList = isLoginFirstTimeJob.getBoolean("IsFirstTimeProjectList",false);
        toEdit = isLoginFirstTimeJob.edit();



        sharedPreferencesLoginCredentials = getSharedPreferences("LoginCredentials",MODE_PRIVATE);
        toEdit = sharedPreferencesLoginCredentials.edit();
        SharedPreferences sharedPreferences_crew_code = getSharedPreferences("CrewDetails", MODE_PRIVATE);
        selectedCrewCode = sharedPreferences_crew_code.getString("SelectedCrewCode", "");
        Log.d("SelectedCrewCode", selectedCrewCode);
        selectedCrewName = sharedPreferences_crew_code.getString("SelectedCrewName", "");
        Log.d("selectedCrewName", selectedCrewName);
        SharedPreferences sharedPreferences_Project = getSharedPreferences("ProjectDetails", MODE_PRIVATE);
        selectedProjectName = sharedPreferences_Project.getString("ProjectName", "");
        Log.d("selectedProjectName", selectedProjectName);
        selectedProjectCode = sharedPreferences_Project.getString("ProjectCode", "");
        Log.d("selectedProjectCode", selectedProjectCode);
        selectedProjectCompCode = sharedPreferences_Project.getString("ProjectCompCode", "");
        Log.d("selectedProjectCompCode", selectedProjectCompCode);

        txtUsername = (EditText)findViewById(R.id.txtUserName);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        btnvision = (ImageButton)findViewById(R.id.btnvision);
        btnSubmit = (Button)findViewById(R.id.btnlogin);
        btnoffline = (Button)findViewById(R.id.btnoffline);
        final LoginAccess loginAccess = LoginAccess.getInstance();

        txtUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                txtUsername.setFocusable(true);
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(txtUsername, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                loginAccess.flaglogin = 1;
                username = txtUsername.getText().toString();
                password = txtPassword.getText().toString();
                loginAccess.setUsername(username);
                loginAccess.setPassword(password);
                ishanEditor.putString("Username", username);
                ishanEditor.putString("Password", password);
                ishanEditor.commit();
                new AsyncAuthetnicate().execute();

            }
        });
        btnvision.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                        break;
                    case MotionEvent.ACTION_UP:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        break;
                }
                return true;

            }
        });
        btnoffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                int width=getResources().getDimensionPixelOffset(R.dimen.width);
                Log.d("width", String.valueOf(width));
                LoginAccess loginAccess = LoginAccess.getInstance();
                loginAccess.flaglogin = 0;

            }
        });

        btnSubmit.callOnClick();

    }

    private void getValuesFromSharedPreference() {
        ishanSharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), 0);
        ishanEditor = ishanSharedPreferences.edit();
        crewCodefromPreferences = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_crew_code),
                getString(R.string.cmic_shared_preference_no_crew));
        projectCodefromPreferences = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_project_code),
                getString(R.string.cmic_shared_preference_no_project));
    }


    public class AsyncAuthetnicate extends AsyncTask<Void, Void, String>
    {

        @Override
        protected void onPreExecute()
        {
            progress=ProgressDialog.show(LoginActivity.this,null,"      Authenticating...");
            super.onPreExecute();

        }
        String auth = "";
        String authEncoded = "";
        @Override
        protected String doInBackground(Void... params)
        {
            String response="";
            try
            {

                auth = username + ":" + password;
                //DatabaseConstants databaseConstants = new DatabaseConstants();
                //DBHelper dbHelper = new DBHelper(MainActivity.this);
                //ArrayList<String> name= new ArrayList();
                //name=dbHelper.getAllCotacts();
                LoginAccess loginAccess = LoginAccess.getInstance();
                authEncoded = new String(Base64.encode(auth.getBytes("UTF-8"), Base64.NO_WRAP));
                Log.d("authEncoded",authEncoded);
                loginAccess.header = authEncoded;

                ishanEditor.putString("authcode", authEncoded);
                ishanEditor.commit();
                toEdit.putString("authcode", authEncoded);
                toEdit.apply();
                toEdit.commit();
                RequestCall requestCall = new RequestCall();
                Log.e("Auth Login : ", auth);
                response = requestCall.requestAuthenticate(getApplicationContext());
            }
            catch (Exception e)
            {
            }
            return response;
        }

        @Override
        protected void onPostExecute(String response)
        {

            super.onPostExecute(response);
            progress.dismiss();
            if (response == null)
            {
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(LoginActivity.this);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("Invalid Login Details");
                alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                    }
                });
                alertBox.show();

            }
            else
            {
                if (!crewCodefromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_crew))
                        && !projectCodefromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_project))){
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else if (!crewCodefromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_crew))
                        && projectCodefromPreferences.equalsIgnoreCase(getString(R.string.cmic_shared_preference_no_project))){
                    Intent intent = new Intent(LoginActivity.this, ProjectListActivity.class);
                    startActivity(intent);
                }
                else {
                    LoginParser loginParser = new LoginParser();
                    ArrayList<LoginModal> arrayList = loginParser.parseLoginData(response);
                    for (int i = 0; i < arrayList.size(); i++)
                    {
                        String hrtTradeName = arrayList.get(i).getHrtTrdName();
                        String hrtName = arrayList.get(i).getHrtFirstName() + arrayList.get(i).getHrtLastName();
                        ishanEditor.putString(getString(R.string.cmic_shared_preference_hrt_trade_name), hrtTradeName);
                        ishanEditor.putString(getString(R.string.cmic_shared_preference_hrt_name), hrtName);
                        ishanEditor.commit();
                        toEdit.putString("hrttradename", hrtTradeName);
                        Log.d("IshanSharedPref",hrtTradeName);
                        toEdit.putString("hrtname", hrtName);
                        toEdit.apply();
                    }
                    Intent intent = new Intent(LoginActivity.this, CrewListActivity.class);
                    startActivity(intent);
                }
                //remove below code 22-feb-18
                /*
                if(ishanFirstTimeProjectList && ishanFirstTimeCrewList )
                {
                    LoginParser loginParser = new LoginParser();
                    ArrayList<LoginModal> arrayList = loginParser.parseLoginData(response);
                    for (int i = 0; i < arrayList.size(); i++)
                    {
                        String hrtTradeName = arrayList.get(i).getHrtTrdName();
                        String hrtName = arrayList.get(i).getHrtFirstName() + arrayList.get(i).getHrtLastName();
                        ishanEditor.putString("hrttradename", hrtTradeName);
                        ishanEditor.putString("hrtname", hrtName);
                        ishanEditor.commit();
                        toEdit.putString("hrttradename", hrtTradeName);
                        Log.d("IshanSharedPref",hrtTradeName);
                        toEdit.putString("hrtname", hrtName);
                        toEdit.apply();
                    }
                    Intent intent = new Intent(LoginActivity.this, CrewListActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                */
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        finish();
        super.onBackPressed();
    }
}