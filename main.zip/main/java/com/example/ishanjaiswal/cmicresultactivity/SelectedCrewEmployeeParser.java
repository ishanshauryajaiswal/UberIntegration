package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Database.DBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewceModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.LinkingCrewEmployeeWithCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class SelectedCrewEmployeeParser {

    List<String> PyceEmpNo = new ArrayList<>();
    List<String> PyceEmpName = new ArrayList<>();//
    List<String> PyceCrewCode = new ArrayList<>();//
    List<String> PyceCrewName = new ArrayList<>();//
    List<String> PyceCrewOraseq = new ArrayList<>();//
    List<String> PyceEmpOraseq = new ArrayList<>();//
    List<String> PyceOraseq = new ArrayList<>();//
    List<String> PyceTrdCode = new ArrayList<>();
    List<String> PyceTrdName = new ArrayList<>();
    ArrayList<User> selectedEmployeesCrew = new ArrayList<>();
    ArrayList<AttributeValuesForCrewceModal> attributeValuesForCrewceModals = new ArrayList<>();
    LinkingCrewEmployeeWithCrew linkingCrewEmployeeWithCrew;
    String tableName;
    int numberOfRemainingRecords;
    String[] empOraseq;
    DBHelper dbHelper;
    LoginAccess loginAccess;

    public LinkingCrewEmployeeWithCrew parseSelectedCrewEmployeeData(final String response, Context context) {

        try {
            Log.d("response selectedCrew", response);
            loginAccess = LoginAccess.getInstance();
            dbHelper = new DBHelper(context);
            JSONObject jsonObject = new JSONObject(response);
            tableName = jsonObject.getString("table");
            numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
            JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray Rows = jsonObject.getJSONArray("rows");
            JSONArray attributes = RowDefinition.getJSONArray("attrNames");
            Set<String> requiredAttributes = new HashSet<>();
            requiredAttributes.add("PyceEmpNo");
            requiredAttributes.add("PyceEmpName");
            requiredAttributes.add("PyceCrewCode");
            requiredAttributes.add("PyceCrewName");
            requiredAttributes.add("PyceCrewOraseq");
            requiredAttributes.add("PyceEmpOraseq");
            requiredAttributes.add("PyceOraseq");
            requiredAttributes.add("PyceTrdCode");
            requiredAttributes.add("PyceTrdName");
            HashMap<String, Integer> attributeIndex = new HashMap<>();

            for (int i = 0; i < attributes.length(); i++) {
                String strAttribute = attributes.getString(i);


                if (requiredAttributes.contains(strAttribute)) {
                    attributeIndex.put(strAttribute, i);
                }
            }
            ArrayList<JSONArray> attributeValues = new ArrayList();
            if (Rows.length() != 0) {
                for (int j = 0; j < Rows.length(); j++) {
                    Log.d("selected Rows", String.valueOf(Rows.length()));
                    JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                    Log.d("selected attrs", String.valueOf(attributeValues));
                }
            } else {
                return null;
            }

            empOraseq = new String[attributeValues.size()];

            for (int k = 0; k < attributeValues.size(); k++) {
                empOraseq[k] = attributeValues.get(k).getString(attributeIndex.get("PyceEmpOraseq"));

                String strPyceCrewOraseq = attributeValues.get(k).getString(attributeIndex.get("PyceCrewOraseq"));
                String strPyceCrewCode = attributeValues.get(k).getString(attributeIndex.get("PyceCrewCode"));
                String strPyceCrewName = attributeValues.get(k).getString(attributeIndex.get("PyceCrewName"));
                String strPyceEmpOraseq = attributeValues.get(k).getString(attributeIndex.get("PyceEmpOraseq"));
                String strPyceEmpNo = attributeValues.get(k).getString(attributeIndex.get("PyceEmpNo"));
                String strPyceOraseq = attributeValues.get(k).getString(attributeIndex.get("PyceOraseq"));
                String strPyceEmpName = attributeValues.get(k).getString(attributeIndex.get("PyceEmpName"));
                String strPyceTrdCode = attributeValues.get(k).getString(attributeIndex.get("PyceTrdCode"));
                String strPyceTrdName = attributeValues.get(k).getString(attributeIndex.get("PyceTrdName"));
                Log.d("EmployeeName", strPyceEmpName);

                  /*  PyceEmpNo.add(strPyceEmpNo);
                    PyceEmpName.add(strPyceEmpName);
                    PyceCrewCode.add(strPyceCrewCode);
                    PyceCrewName.add(strPyceCrewName);
                    PyceCrewOraseq.add(strPyceCrewOraseq);
                    PyceEmpOraseq.add(strPyceEmpOraseq);
                    PyceOraseq.add(strPyceOraseq);
                    PyceTrdCode.add(strPyceTrdCode);
                    PyceTrdName.add(strPyceTrdName);*/
                AttributeValuesForCrewceModal attributeValuesForCrewceModal = new AttributeValuesForCrewceModal(strPyceCrewOraseq, strPyceCrewCode, strPyceCrewName, strPyceEmpOraseq, strPyceEmpNo, strPyceOraseq, strPyceEmpName, strPyceTrdCode, strPyceTrdName);
                attributeValuesForCrewceModals.add(attributeValuesForCrewceModal);
                linkingCrewEmployeeWithCrew = new LinkingCrewEmployeeWithCrew(tableName, numberOfRemainingRecords, attributeValuesForCrewceModals);
            }
        } catch (SQLiteDatabaseCorruptException e) {
            Log.d("Exception", e.toString());
            return null;
        } catch (JSONException e) {
            Log.d("Json Exception", e.toString());
        }
        for (int i = 0; i < selectedEmployeesCrew.size(); i++) {
            Log.d("selected Employees", selectedEmployeesCrew.get(i).getName());
        }
        //  Log.d("crewEmployees",linkingCrewEmployeeWithCrew.toString());
        return linkingCrewEmployeeWithCrew;
    }

}