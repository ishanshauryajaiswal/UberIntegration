package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.InsertCrewInterface;
import com.example.ishanjaiswal.cmicresultactivity.LoginAccess;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class InsertingCrewTask extends AsyncTask<Void, Void, String > {

    String authEncoded;
    String insertedCrewCode;
    private Context mContext;
    String table;
    InsertCrewInterface insertCrewListner;

    public InsertingCrewTask(String authEncoded, String insertedCrewCode, Context mContext, String table, InsertCrewInterface insertCrewListner) {
        this.authEncoded = authEncoded;
        this.insertedCrewCode = insertedCrewCode;
        this.mContext = mContext;
        this.table = table;
        this.insertCrewListner = insertCrewListner;
    }

    @Override
    protected void onPreExecute()
    {
        insertCrewListner.BeforeCompletion();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(Void... params) {
        Log.d("inserted crew code",insertedCrewCode);
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall();
            response = requestCall.insertCrew(mContext,authEncoded, table);
            Log.d("Response1 -> ", response);
        }
        catch (Exception e)
        {
            Log.d("error in inserting ",e.toString());
        }
        return response;
    }

    protected void onPostExecute(String response)
    {
        new SelectCrewOnCrewCodeBasis(insertedCrewCode).execute();
    }

    private class SelectCrewOnCrewCodeBasis extends AsyncTask<Void, Void, String>{
        String authEncoded;
        String insertedCrewCode;
        String username = LoginAccess.getInstance().getUsername();
        String password = LoginAccess.getInstance().getPassword();
        public SelectCrewOnCrewCodeBasis(String insertedCrewCode) {
            this.insertedCrewCode = insertedCrewCode;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = "";
            try
            {
                String auth = username + ":" + password;
                Log.d("auth",auth);
                authEncoded = new String(Base64.encode(auth.getBytes("UTF-8"), Base64.NO_WRAP));

                RequestCall requestCall = new RequestCall();
                response = requestCall.selectCrewOnCrewCodeBasis(mContext,authEncoded,insertedCrewCode);
                Log.d("Response -> ", response);
            }
            catch (Exception e)
            {
                Log.d("error",e.toString());

            }
            return response;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            insertCrewListner.getCrews(response);
        }
    }
}
