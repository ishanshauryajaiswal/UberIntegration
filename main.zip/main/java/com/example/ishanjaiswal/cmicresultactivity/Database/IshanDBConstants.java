package com.example.ishanjaiswal.cmicresultactivity.Database;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */

public class IshanDBConstants {


    public static final String TABLE_EMPLOYEE_DATA_FOR_CREW = "EmployeeDataForCrew";
    public static final String TABLE_ACTIVITY_TIME_FOR_CREW = "ActivityTimeForCrew";
    public static final String TABLE_ACTIVITY_FOR_TIMESHEET = "ActivityForTimesheet";
    public static final String TABLE_TIMESHEET = "Timesheet";
    public static final String TABLE_CREW_LIST = "CrewList";
    public static final String TABLE_PROJECT_LIST = "ProjectList";
    public static final String TABLE_SELECTED_EMPLOYEES = "SelectedEmployees";

    //TABLE EMPLOYEE DATA FOR CREW
    public static final String CrewCode_EmployeeDataForCrew = "CrewCode";
    public static final String EmployeeName_EmployeeDataForCrew  = "EmployeeName";
    public static final String EmployeeNumber_EmployeeDataForCrew  = "EmployeeNumber";
    public static final String EmployeeOraseq_EmployeeDataForCrew = "EmployeeOraseq";
    public static final String EmployeeTradeCode_EmployeeDataForCrew  = "EmployeeTradeCode";
    public static final String EmployeeTradeName_EmployeeDataForCrew  = "EmployeeTradeName";
    public static final String JobCode_EmployeeDataForCrew  = "JobCode";
    public static final String PeriodFlag_EmployeeDataForCrew  = "PeriodFlag";
    public static final String RowNumber_EmployeeDataForCrew  = "RowNumber";
    public static final String WorkDate_EmployeeDataForCrew  = "WorkDate";
    public static final String DeleteFlag_EmployeeDataForCrew  = "DeleteFlag";

    //TABLE ActivtyTimeForCrew
    public static final String EmployeeOraSeq_ActivityTimeForCrew = "EmployeeOraseq";
    public static final String otseqNumber = "OtSeqNumber";
    public static final String dothour = "DotHour";
    public static final String rtSeqNumber = "RtSeqNumber";
    public static final String rtHours = "Rthours";
    public static final String dotSeqNumber = "DotSeqNumber";
    public static final String otHour = "OtHour";

    //TABLE ACTIVITY FOR TIMESHEET
    public static final String ActivityName_ActivityForTimeSheet = "ActivityName";
    public static final String CategoryCode_ActivityForTimeSheet  = "CategoryCode";
    public static final String ColoumnNumber_ActivityForTimeSheet = "ColoumnNumber";
    public static final String JobCode_ActivityForTimeSheet = "JobCode";
    public static final String PciLineOraseq_ActivityForTimeSheet  = "PciLineOraseq";
    public static final String PhaseCode_ActivityForTimeSheet = "PhaseCode";
    public static final String SeqNumber_ActivityForTimeSheet  = "SeqNumber";
    public static final String WbsCode_ActivityForTimeSheet = "WbsCode";
    public static final String DeleteFlag_ActivityForTimeSheet = "DeleteFlag";

    //TABLE TIMESHEET
    public static final String Timesheet_CrewCode = "CrewCode";
    public static final String Timesheet_JobCode = "JobCode";
    public static final String Timesheet_JobCompCode = "JobCompCode";
    public static final String Timesheet_SeqNumber = "SequenceNumber";
    public static final String Timesheet_WorkDate = "WorkDate";
    public static final String Timesheet_SubmitStatus = "SubmitStatus";
    public static final String TimesheetState = "State";

    //TABLE CREWLIST
    public static final String CrewList_PycrCode = "CrewCode";
    public static final String CrewList_PycrName = "CrewName";
    public static final String CrewList_PycrOraseq = "CrewOraseq";

    //TABLE PROJECTLIST
    public static final String ProjectList_Jobcode = "JobCode";
    public static final String ProjectList_Jobcompcode = "JobCompCode";
    public static final String ProjectList_Jobname = "JobName";

    //TABLE Selected Employees
    public static final String Selected_EmpNumber = "PyelEmpNo";
    public static final String Selected_EmpOraseq ="PyelEmpOraseq";
    public static final String Selected_EmpName ="PyelEmpName";
    public static final String Selected_AccessCode = "PyelAccessCode";
    public static final String Selected_CompName ="PyelCompName";
    public static final String Selected_PrnCode ="PyelPrnCode";
    public static final String Selected_PrnName ="PyelPrnName";
    public static final String Selected_CompCode = "PyelCompCode";
    public static final String Selected_TrdCode = "PyelTrdCode";
    public static final String Selected_TrdName = "PyelTrdName";
    public static final String Selected_UniCode = "PyelUniCode";
    public static final String Selected_UniName = "PyelUniName";
}
