package com.example.ishanjaiswal.cmicresultactivity.Database;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */

public class IshanDBConstants {


    public static final String TABLE_EMPLOYEE_DATA_FOR_CREW = "EmployeeDataForCrew";
    public static final String TABLE_ACTIVITY_TIME_FOR_CREW = "ActivityTimeForCrew";
    public static final String TABLE_ACTIVITY_FOR_TIMESHEET = "ActivityForTimesheetw";

    //TABLE EMPLOYEE DATA FOR CREW
    public static final String CrewCode_EmployeeDataForCrew = "CrewCode";
    public static final String EmployeeName_EmployeeDataForCrew  = "EmployeeName";
    public static final String EmployeeNumber_EmployeeDataForCrew  = "EmployeeNumber";
    public static final String EmployeeOraseq_EmployeeDataForCrew = "EmployeeOraseq";
    public static final String EmployeeTradeCode_EmployeeDataForCrew  = "EmployeeTradeCode";
    public static final String EmployeeTradeName_EmployeeDataForCrew  = "EmployeeTradeName";
    public static final String JobCode_EmployeeDataForCrew  = "JobCode";
    public static final String PeriodFlag_EmployeeDataForCrew  = "PeriodFlag";
    public static final String RowNumber_EmployeeDataForCrew  = "RowNumber";
    public static final String WorkDate_EmployeeDataForCrew  = "WorkDate";

    //TABLE ActivtyTimeForCrew
    public static final String EmployeeNumber_ActivityTimeForCrew = "EmployeeNumber";
    public static final String otseqNumber = "OtSeqNumber";
    public static final String dothour = "DotHour";
    public static final String rtSeqNumber = "RtSeqNumber";
    public static final String rtHours = "Rthours";
    public static final String dotSeqNumber = "DotSeqNumber";
    public static final String otHour = "OtHour";

    //TABLE ACTIVITY FOR TIMESHEET
    public static final String ActivityName_ActivityForTimeSheet = "ActivityName";
    public static final String CategoryCode_ActivityForTimeSheet  = "CategoryCode";
    public static final String ColoumnNumber_ActivityForTimeSheet = "ColoumnNumber";
    public static final String CrewCode_ActivityForTimeSheet  = "CrewCode";
    public static final String JobCode_ActivityForTimeSheet = "JobCode";
    public static final String JobCompCode_ActivityForTimeSheet = "JobCompCode";
    public static final String PciLineOraseq_ActivityForTimeSheet  = "PciLineOraseq";
    public static final String PhaseCode_ActivityForTimeSheet = "PhaseCode";
    public static final String SeqNumber_ActivityForTimeSheet  = "SeqNumber";
    public static final String WbsCode_ActivityForTimeSheet = "WbsCode";
    public static final String WorkDate_ActivityForTimeSheet  = "WorkDate";

    //TABLE TIMESHEET
    public static final String Timesheet_CrewCode = "CrewCode";
    public static final String Timesheet_JobCode = "JobCode";
    public static final String Timesheet_JobCompCode = "JobCompCode";
    public static final String Timesheet_SeqNumber = "SequenceNumber";
    public static final String Timesheet_WorkDate = "WorkDate";
    public static final String Timesheet_SubmitStatus = "SubmitStatus";
    public static final String TimesheetState = "State";

}
