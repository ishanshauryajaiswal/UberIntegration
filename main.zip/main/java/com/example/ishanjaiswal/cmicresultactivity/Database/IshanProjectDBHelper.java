package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import java.util.ArrayList;

public class IshanProjectDBHelper
{
    private static final String TAG = IshanProjectDBHelper.class.getSimpleName();
    private static IshanDBConstants D = new IshanDBConstants();
    SQLiteDatabase db;
    public IshanProjectDBHelper(Context context)
    {
        IshanDBHelper mInstance = IshanDBHelper.getInstance(context);
        db = mInstance.getWritableDatabase();
    }

    public void insertProjectInDatabase(String jobCode,String jobCompCode,String jobName)
    {
        try {

            ContentValues values = new ContentValues();
            values.put(D.ProjectList_Jobcode, jobCode);
            values.put(D.ProjectList_Jobcompcode, jobCompCode);
            values.put(D.ProjectList_Jobname, jobName);
            int id = (int) db.insertWithOnConflict(D.TABLE_PROJECT_LIST, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1)
                db.update(D.TABLE_PROJECT_LIST,values, D.ProjectList_Jobcode+"=?",new String [] {values.get(D.ProjectList_Jobcode)+""});
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Inserting Project: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Inserting Project: "+e.getMessage());
        }
    }

    public ArrayList<JobData> selectAllProjectsFromDatabase()
    {
        ArrayList<JobData> array_list = new ArrayList();
        try
        {
            Cursor res =  db.rawQuery("SELECT * FROM " + D.TABLE_PROJECT_LIST, null);
            res.moveToFirst();
            while(res.isAfterLast() == false){
                JobData jobData=new JobData();
                jobData.setJobname(res.getString(res.getColumnIndex(D.ProjectList_Jobname)));
                jobData.setJobcode(res.getString(res.getColumnIndex(D.ProjectList_Jobcode)));
                jobData.setJobcompcode(res.getString(res.getColumnIndex(D.ProjectList_Jobcompcode)));
                array_list.add(jobData);
                res.moveToNext();
            }
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        return array_list;
    }

    public boolean isProjectInDatabase(String selectedJobCode)
    {
        boolean exist = false;
        try {
            Cursor cur = db.rawQuery("SELECT * FROM " + D.TABLE_PROJECT_LIST + " WHERE "+ D.ProjectList_Jobcode+ " = '" + selectedJobCode + "'" , null);
            exist = (cur.getCount() > 0);
            cur.close();
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        return exist;
    }
}
