package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import java.util.ArrayList;

/**
 * Created by parneet.singh on 8/31/2016.
 */
public class JobDBHelper
{

    SQLiteDatabase db;
    Context context;

    DBHelper a;
    public JobDBHelper(Context context)
    {
        this.context=context;
        a = new DBHelper(context);
        db = a.getWritableDatabase();
    }
    public boolean insertSelectedJobs(String jobCode,String jobCompCode,String jobName)
    {

        {
            Log.d("crewCode", jobCode);
            Log.d("jobcompcode", jobCompCode);
            Log.d("jobName", jobName);
            try
            {
                ContentValues contentValues = new ContentValues();
                contentValues.put(DatabaseConstants.jobcode, jobCode);
                contentValues.put(DatabaseConstants.jobcompcode, jobCompCode);
                contentValues.put(DatabaseConstants.jobname, jobName);
                db.insertOrThrow(DatabaseConstants.TABLE_SELECTED_JOBS, null, contentValues);
                Log.d("InsertedCrewList", "Successfull");
                // onCreate(db);
            }
            catch (SQLiteException e)
            {
                Log.d("insertedError",e.toString());
                return false;

            }
            catch (Exception e){
                Log.d("InsertedError",e.toString());
                return false;
            }

            return true;
        }

    }

    public boolean dropSelectedJobs()
    {
        try
        {
           // SQLiteDatabase db = this.getReadableDatabase();
            db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SELECTED_JOBS);
            return true;
        }
        catch(Exception e)
        {
            Log.d("error",e.toString());
            return false;
        }
    }

    public ArrayList<JobData> selectallSelectedJobs()
    {
       //insertSelectedJobs("2","23","demo");
        ArrayList<JobData> array_list = new ArrayList();
        try
        {
           // SQLiteDatabase db = this.getReadableDatabase();
            Cursor res =  db.rawQuery("SELECT * FROM " + DatabaseConstants.TABLE_SELECTED_JOBS, null);
            res.moveToFirst();
            while(res.isAfterLast() == false){
                JobData jobData=new JobData();
                jobData.setJobname(res.getString(res.getColumnIndex(DatabaseConstants.jobname)));
                jobData.setJobcode(res.getString(res.getColumnIndex(DatabaseConstants.jobcode)));
                jobData.setJobcompcode(res.getString(res.getColumnIndex(DatabaseConstants.jobcompcode)));
                array_list.add(jobData);
                //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
                res.moveToNext();
            }

            for (int i=0;i<array_list.size();i++){
                Log.d("jobdataDB",array_list.get(i).getJobname());
                Log.d("jobcompcodeDB",array_list.get(i).getJobcompcode());
                Log.d("jobcodeDB",array_list.get(i).getJobcode());
            }
            return array_list;
        }
        catch(Exception e)
        {
            Log.d("error in jobdata",e.toString());
            return null;
        }
    }

    public boolean selectedJobCode(String selectedJobCode)
    {
        try {
            Log.d("selectedOraseq",selectedJobCode);
            // db = this.getReadableDatabase();
            Cursor cur = db.rawQuery("SELECT * FROM " + DatabaseConstants.TABLE_SELECTED_JOBS + " WHERE jobcode = '" + selectedJobCode + "'", null);
            boolean exist = (cur.getCount() > 0);
            cur.close();
            return exist;
        }
        catch (Exception e)
        {
            Log.d("Exception","database");
            return false;
        }

    }


}
