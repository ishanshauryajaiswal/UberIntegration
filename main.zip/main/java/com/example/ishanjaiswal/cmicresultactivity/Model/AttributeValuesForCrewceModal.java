package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/6/2018.
 */

public class AttributeValuesForCrewceModal
{
    public String PyceCrewOraseq, PyceCrewCode, PyceCrewName, PyceEmpOraseq,PyceEmpNo,PyceOraseq,PyceEmpName,PyceTrdCode,PyceTrdName;
    boolean selected;
    public AttributeValuesForCrewceModal (String PyceCrewOraseq,String PyceCrewCode,String PyceCrewName, String PyceEmpOraseq,String PyceEmpNo,String PyceOraseq,String PyceEmpName,String PyceTrdCode,String PyceTrdName )
    {
        this.PyceCrewOraseq=PyceCrewOraseq;
        this.PyceCrewCode = PyceCrewCode;
        this.PyceCrewName = PyceCrewName;
        this.PyceEmpOraseq = PyceEmpOraseq;
        this.PyceEmpNo = PyceEmpNo;
        this.PyceOraseq = PyceOraseq;
        this.PyceEmpName = PyceEmpName;
        this.PyceTrdCode = PyceTrdCode;
        this.PyceTrdName = PyceTrdName;
    }
    public AttributeValuesForCrewceModal(int Position,boolean checked)
    {

    }

    public void setSelected(boolean selected)
    {
        this.selected = selected;
    }

    public String getPyceTrdName() {
        return PyceTrdName;
    }

    public String getPyceTrdCode() {
        return PyceTrdCode;
    }

    public String getPyceCrewCode() {
        return PyceCrewCode;
    }

    public String getPyceCrewName() {
        return PyceCrewName;
    }

    public String getPyceCrewOraseq() {
        return PyceCrewOraseq;
    }

    public String getPyceEmpName() {
        return PyceEmpName;
    }

    public String getPyceEmpNo() {
        return PyceEmpNo;
    }

    public String getPyceEmpOraseq() {
        return PyceEmpOraseq;
    }

    public String getPyceOraseq() {
        return PyceOraseq;
    }

    public void setPyceCrewCode(String pyceCrewCode) {
        PyceCrewCode = pyceCrewCode;
    }

    public void setPyceCrewName(String pyceCrewName) {
        PyceCrewName = pyceCrewName;
    }

    public void setPyceCrewOraseq(String pyceCrewOraseq) {
        PyceCrewOraseq = pyceCrewOraseq;
    }

    public void setPyceEmpName(String pyceEmpName) {
        PyceEmpName = pyceEmpName;
    }

    public void setPyceEmpNo(String pyceEmpNo) {
        PyceEmpNo = pyceEmpNo;
    }

    public void setPyceEmpOraseq(String pyceEmpOraseq) {
        PyceEmpOraseq = pyceEmpOraseq;
    }

    public void setPyceOraseq(String pyceOraseq) {
        PyceOraseq = pyceOraseq;
    }

    public void setPyceTrdCode(String pyceTrdCode) {
        PyceTrdCode = pyceTrdCode;
    }

    public void setPyceTrdName(String pyceTrdName) {
        PyceTrdName = pyceTrdName;
    }

}
