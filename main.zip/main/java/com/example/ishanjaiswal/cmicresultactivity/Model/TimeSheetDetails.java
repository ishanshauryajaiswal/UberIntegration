package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 3/27/2018.
 */

public class TimeSheetDetails {
    private String crewCode;
    private String joCode;
    private String jobCompCode;
    private String seqNo;
    private String workDate;
    private String submitStatus;
    //state means isEdited
    private boolean state = false;

    public TimeSheetDetails(){}

    public TimeSheetDetails(String crewCode, String joCode, String jobCompCode, String seqNo, String workDate, String submitStatus, boolean state) {

        this.crewCode = crewCode;
        this.joCode = joCode;
        this.jobCompCode = jobCompCode;
        this.seqNo = seqNo;
        this.workDate = workDate;
        this.submitStatus = submitStatus;
        this.state = state;
    }

    public String getCrewCode() {
        return crewCode;
    }

    public void setCrewCode(String crewCode) {
        this.crewCode = crewCode;
    }

    public String getJoCode() {
        return joCode;
    }

    public void setJoCode(String joCode) {
        this.joCode = joCode;
    }

    public String getJobCompCode() {
        return jobCompCode;
    }

    public void setJobCompCode(String jobCompCode) {
        this.jobCompCode = jobCompCode;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getWorkDate() {
        return workDate;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }

    public String getSubmitStatus() {
        return submitStatus;
    }

    public void setSubmitStatus(String submitStatus) {
        this.submitStatus = submitStatus;
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }


}
