package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 1/23/2018.
 */

public class TempModel {

    String crewMemberName;
    double regValue, otValue, dotValue, timeTotal;

    public TempModel(String crewMemberName, double regValue, double otValue, double dotValue, double timeTotal) {
        this.crewMemberName = crewMemberName;
        this.regValue = regValue;
        this.otValue = otValue;
        this.dotValue = dotValue;
        this.timeTotal = timeTotal;
    }

    public String getCrewMemberName() {
        return crewMemberName;
    }

    public void setCrewMemberName(String crewMemberName) {
        this.crewMemberName = crewMemberName;
    }

    public double getRegValue() {
        return regValue;
    }

    public void setRegValue(double regValue) {
        this.regValue = regValue;
    }

    public double getOtValue() {
        return otValue;
    }

    public void setOtValue(double otValue) {
        this.otValue = otValue;
    }

    public double getDotValue() {
        return dotValue;
    }

    public void setDotValue(double dotValue) {
        this.dotValue = dotValue;
    }

    public double getTimeTotal() {
        return timeTotal;
    }

    public void setTimeTotal(double timeTotal) {
        this.timeTotal = timeTotal;
    }
}
