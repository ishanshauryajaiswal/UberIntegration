package com.example.ishanjaiswal.cmicresultactivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class FetchEmployeesOfCrew extends AsyncTask<Void,Void,String> {
    private String authCode;
    private Context context;
    private String crewCode;
    ProgressDialog progressdialog;
    private SelectEmpInterface selectEmpInterface;
    public FetchEmployeesOfCrew(Context context, String crewCode, SelectEmpInterface selectEmpInterface){
        this.context = context;
        this.crewCode = crewCode;
        this.context = context;
        progressdialog = new ProgressDialog(context);
        this.selectEmpInterface = selectEmpInterface;
    }
    @Override
    protected void onPreExecute()
    {
        // progressdialog = ProgressDialog.show(context, "Cmic Mobile Crew Time", "Dowmloading Crew ... ");
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall();
        response = requestCall.fetchCrewEmployee(context, crewCode);
        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        progressdialog.dismiss();
        selectEmpInterface.postTask(response);
        // SelectedCrewEmployeeParser selectedCrewEmployeeParser = new SelectedCrewEmployeeParser();
        // ArrayList<LinkingCrewEmployeeWithCrew> employeeWithCrews =   selectedCrewEmployeeParser.parseSelectedCrewEmployeeData(response);
        //Log.d("responsegetEmp",employeeWithCrews);

    }
}
