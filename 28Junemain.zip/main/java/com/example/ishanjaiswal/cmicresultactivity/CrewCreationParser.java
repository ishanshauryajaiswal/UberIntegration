package com.example.ishanjaiswal.cmicresultactivity;

import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CrewCreationParser {

    List<String> PycrCode = new ArrayList<>();
    List<String> PycrName = new ArrayList<>();
    List<String> PycrOraseq = new ArrayList<>();
    String[] names;
    String tableName;
    int numberOfRemainingRecords;
    ArrayList<InsertCrew> insertedcrew = new ArrayList();


    public ArrayList<InsertCrew> parseInsertCrewData(final String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            // tableName = jsonObject.getString("table");
            numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
            JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray attrNames = RowDefinition.getJSONArray("attrNames");

            JSONArray attributes = RowDefinition.getJSONArray("attrNames");
            names = new String[attrNames.length()];
            Set<String> requiredAttributes = new HashSet<>();
            requiredAttributes.add("PycrCode");
            requiredAttributes.add("PycrName");
            requiredAttributes.add("PycrOraseq");
            requiredAttributes.add("PycrResponsibleEmpOraseq");
            requiredAttributes.add("PycrResponsibleEmpNo");
            requiredAttributes.add("PycrResponsibleEmpName");

            HashMap<String, Integer> attributeIndex = new HashMap<>();

            for (int i = 0; i < attributes.length(); i++) {
                String strAttribute = attributes.getString(i);

                if (requiredAttributes.contains(strAttribute)) {
                    attributeIndex.put(strAttribute, i);
                }
            }

            ArrayList<JSONArray> attributeValues = new ArrayList<>();

            JSONArray rows = jsonObject.getJSONArray("rows");
            for (int j = 0; j < rows.length(); j++) {
                JSONArray values = rows.getJSONObject(j).getJSONArray("attrValues");
                attributeValues.add(values);
            }

            for (int k = 0; k < attributeValues.size(); k++) {
                InsertCrew insert = new InsertCrew();
                ;
                insert.PycrCode(attributeValues.get(k).getString(attributeIndex.get("PycrCode")));
                insert.PycrName(attributeValues.get(k).getString(attributeIndex.get("PycrName")));
                insert.PycrOraseq(attributeValues.get(k).getString(attributeIndex.get("PycrOraseq")));
                insert.PycrResponsibleEmpOraseq(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpOraseq")));
                insert.PycrResponsibleEmpNo(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpNo")));
                if(attributeIndex.get("PycrResponsibleEmpName") == null)
                {
                    insert.PycrResponsibleEmpName("null");
                }
                else {
                    insert.PycrResponsibleEmpName(attributeValues.get(k).getString(attributeIndex.get("PycrResponsibleEmpName")));
                }
                //  names[k]=attributeValues.get(k).getString(attributeIndex.get("JobName"));
                insertedcrew.add(insert);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Log.e("error", e.toString());
        }
        return insertedcrew;
    }

    public String getCrewOraSeq(String response)
    {
        ArrayList<InsertCrew> data = parseInsertCrewData(response);
        String arrayOraseq = new String();
        for (int i = 0; i < data.size(); i++) {
            arrayOraseq = data.get(i).PycrOraseq;
            Log.d("Oraseqqq", arrayOraseq);
        }
        return arrayOraseq;
    }

    public String getCrewName(String response) {
        ArrayList<InsertCrew> data = parseInsertCrewData(response);
        String arrayCrewName = new String();
        for (int i = 0; i < data.size(); i++) {
            arrayCrewName = data.get(i).PycrOraseq;
        }
        return arrayCrewName;
    }

    public String getCrewCode(String response) {
        ArrayList<InsertCrew> data = parseInsertCrewData(response);
        String arrayCrewCode = new String();
        for (int i = 0; i < data.size(); i++) {
            arrayCrewCode = data.get(i).PycrOraseq;
        }
        return arrayCrewCode;
    }

}
