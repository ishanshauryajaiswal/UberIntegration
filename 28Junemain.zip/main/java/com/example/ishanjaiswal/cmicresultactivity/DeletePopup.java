package com.example.ishanjaiswal.cmicresultactivity;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

/**
 * Created by ishan.jaiswal on 3/12/2018.
 */

public class DeletePopup extends AppCompatActivity implements View.OnClickListener {

    protected WindowManager mWindowManager;

    protected Context mContext;
    protected PopupWindow mWindow;
    private TextView mHelpTextView;
    private ImageView mUpImageView;
    private DeletePopupInterface deletePopupInterface;
    private ImageView mDownImageView;
    protected View mView;
    protected Drawable mBackgroundDrawable = null;
    protected ShowListener showListener;

    // private OnActivityEditTextClickListner mOnActivityEditTextClickListner;


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public DeletePopup(final Context context, final int viewResource, final int j, final String employeeName, final DeletePopupInterface deletePopupInterface1)
    {
        mContext = context;
        mWindow = new PopupWindow(context);
        this.deletePopupInterface = deletePopupInterface1;
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        final LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        setContentView(layoutInflater.inflate(viewResource, null));
        mHelpTextView = (TextView)mView.findViewById(R.id.txtdelete);
        mUpImageView = (ImageView) mView.findViewById(R.id.up_arrow);
        mDownImageView = (ImageView) mView.findViewById(R.id.down_arrow);
        mHelpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                mWindow.dismiss();
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("Do you want to delete Time for " + employeeName);
                alertBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        deletePopupInterface1.deleteValues(j);
                    }
                });
                alertBox.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.dismiss();
                    }
                });
                alertBox.show();
            }

        });}
    //Positioning of the popup
    public void show(View anchor) {
        preShow();

        int[] location = new int[2];

        anchor.getLocationOnScreen(location);

        Rect anchorRect = new Rect(location[0], location[1], location[0]
                + anchor.getWidth(), location[1] + anchor.getHeight());

        mView.measure(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        int rootHeight = mView.getMeasuredHeight();
        int rootWidth = mView.getMeasuredWidth();

        final int screenWidth = mWindowManager.getDefaultDisplay().getWidth();
        final int screenHeight = mWindowManager.getDefaultDisplay().getHeight();

        int yPos = (anchorRect.top - rootHeight);

        boolean onTop = true;

        if (anchorRect.top < screenHeight / 2) {
            yPos = anchorRect.bottom - 10;
            onTop = false;
        }

        int whichArrow, requestedX;

        whichArrow = ((onTop) ? R.id.down_arrow : R.id.up_arrow);
        requestedX = anchorRect.centerX();

        View arrow = whichArrow == R.id.up_arrow ? mUpImageView
                : mDownImageView;
        View hideArrow = whichArrow == R.id.up_arrow ? mDownImageView
                : mUpImageView;

        final int arrowWidth = arrow.getMeasuredWidth();

        arrow.setVisibility(View.VISIBLE);

        ViewGroup.MarginLayoutParams param = (ViewGroup.MarginLayoutParams) arrow
                .getLayoutParams();

        hideArrow.setVisibility(View.INVISIBLE);

        int xPos = 0;

        // ETXTREME RIGHT CLIKED
        if (anchorRect.left + rootWidth > screenWidth) {
            //   mWindow.setWidth(900);
            xPos = (screenWidth - rootWidth);
        }
        // ETXTREME LEFT CLIKED
        else if (anchorRect.left - (rootWidth / 2) < 0) {
            xPos = anchorRect.left+40;
        }
        // INBETWEEN
        else {
            xPos = (anchorRect.centerX() - (rootWidth / 2));
        }

        // param.leftMargin = (requestedX - xPos) - (arrowWidth / 2);
        //     param.leftMargin = requestedX - xPos;

        if (onTop) {
            mHelpTextView.setMaxHeight(anchorRect.top - anchorRect.height());

        } else {
            mHelpTextView.setMaxHeight(screenHeight - yPos);
        }

        mWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, xPos, yPos);

      /*  mView.setAnimation(AnimationUtils.loadAnimation(mContext,
                R.anim.float_anim));*/
    }

    protected void preShow() {
        if (mView == null)
            throw new IllegalStateException("view undefined");


        if (showListener != null) {
            showListener.onPreShow();
            showListener.onShow();
        }

        if (mBackgroundDrawable == null)
            mWindow.setBackgroundDrawable(new BitmapDrawable());
        else
            mWindow.setBackgroundDrawable(mBackgroundDrawable);

        mWindow.setWidth(200);
        mWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        mWindow.setTouchable(true);
        mWindow.setFocusable(false);
        mWindow.setOutsideTouchable(true);

        mWindow.setContentView(mView);
    }

    public void setBackgroundDrawable(Drawable background) {
        mBackgroundDrawable = background;
    }

    public void setContentView(View root) {
        mView = root;

        mWindow.setContentView(root);
    }

    public void setContentView(int layoutResID) {
        LayoutInflater inflator = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        setContentView(inflator.inflate(layoutResID, null));
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener listener) {
        mWindow.setOnDismissListener(listener);
    }

    public void dismiss() {
        mWindow.dismiss();
        if (showListener != null) {
            showListener.onDismiss();
        }
    }
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.toolbar:
                System.out.println("clicked");
                Log.d("done", "Clicked");
                break;
        }

    }

    public static interface ShowListener {
        void onPreShow();

        void onDismiss();

        void onShow();
    }

    public void setShowListener(ShowListener showListener) {
        this.showListener = showListener;
    }

    public interface OnActivityEditTextClickListner {

        void onEditTextClicked(EditText v);
    }
}
