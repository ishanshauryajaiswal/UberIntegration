package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
 * Created by parneet.singh on 9/14/2016.
 */
public interface PhaseInterface {

    public void onTaskComplete(String response);
    public void onTaskStarted();
}
