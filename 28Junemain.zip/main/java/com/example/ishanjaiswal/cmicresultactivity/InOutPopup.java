package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CustomClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOut;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


/**
 * Created by ishan.jaiswal on 4/12/2018.
 */

public class InOutPopup extends Dialog {

    public interface Callback{
        void inOutPopUpSubmittedForAllEmployees(List<TimeInOut> timeInOutList);
        void inOutPopUpSubmittedForIndividualEmployee(List<TimeInOut> timeInOutList, int employeePosition);

    }

    private Context mContext;
    private Callback mCallback;
    private boolean mIsPopUpGlobal;
    private int mEmployeePosition;
    public TextView cancel, clearData;
    public TextView breakTime1, breakTime2, breakTime3, breakTime4;
    public TextView timeIn1, timeIn2, timeIn3, timeIn4, timeIn5;
    public TextView timeOut1, timeOut2, timeOut3, timeOut4, timeOut5;
    public TextView total1, total2, total3, total4, total5;
    public TextView tvCheckIn, tvBreak;
    public Button btnDone;
    TextView[] arrayTextViews;
    TextView[] arrayBreakTime;
    TextView[] arrayTotalTime;
    private Calendar cal;
    private SharedPreferences defaultSharedPreference;
    private double breakTimeFromSettings;

    public InOutPopup(@NonNull Context context, Callback callback, boolean isPopUpGlobal, int employeePosition) {
        super(context);
        this.mContext = context;
        this.mCallback = callback;
        this.mIsPopUpGlobal = isPopUpGlobal;
        this.mEmployeePosition = employeePosition;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.timein_timeout);
        initViews();
        defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(mContext);
        breakTimeFromSettings = Double.parseDouble(defaultSharedPreference.getString(mContext.getString(R.string.settings_key_break_time), mContext.getString(R.string.settings_break_time_default)));
    }

    private void initViews() {
        Typeface typeface = Typeface.createFromAsset(mContext.getAssets(),"fonts/cmic_icons.ttf");
        breakTime1 = (TextView) this.findViewById(R.id.breaktime1);
        breakTime2 = (TextView) findViewById(R.id.breaktime2);
        breakTime3 = (TextView) findViewById(R.id.breaktime3);
        breakTime4 = (TextView) findViewById(R.id.breaktime4);
        timeIn1 = (TextView) findViewById(R.id.timein1);
        timeIn2 = (TextView) findViewById(R.id.timein2);
        timeIn3 = (TextView) findViewById(R.id.timein3);
        timeIn4 = (TextView) findViewById(R.id.timein4);
        timeIn5 = (TextView) findViewById(R.id.timein5);
        timeOut1 = (TextView) findViewById(R.id.timeout1);
        timeOut2 = (TextView) findViewById(R.id.timeout2);
        timeOut3 = (TextView) findViewById(R.id.timeout3);
        timeOut4 = (TextView) findViewById(R.id.timeout4);
        timeOut5 = (TextView) findViewById(R.id.timeout5);
        total1 = (TextView) findViewById(R.id.total1);
        total2 = (TextView) findViewById(R.id.total2);
        total3 = (TextView) findViewById(R.id.total3);
        total4 = (TextView) findViewById(R.id.total4);
        total5 = (TextView) findViewById(R.id.total5);
        cancel = (TextView) findViewById(R.id.cancel);
        clearData = (TextView) findViewById(R.id.cleardata);
        cancel.setTypeface(typeface); clearData.setTypeface(typeface);
        tvCheckIn = (TextView)findViewById(R.id.tvCheckIn);
        tvBreak = (TextView)findViewById(R.id.tvBreak);
        btnDone = (Button) findViewById(R.id.btndone);
        arrayTextViews = new TextView[]{timeIn1, timeOut1, timeIn2, timeOut2, timeIn3, timeOut3, timeIn4, timeOut4, timeIn5, timeOut5};
        arrayBreakTime = new TextView[]{breakTime1, breakTime2, breakTime3, breakTime4};
        arrayTotalTime = new TextView[]{total1, total2, total3, total4, total5};

        for (int i = 0; i < arrayTextViews.length; i++) {
            final int finalI = i;
            arrayTextViews[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    enterTime(finalI);
                }
            });
        }
        clearData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvCheckIn.setText("Check In");
                tvBreak.setVisibility(View.INVISIBLE);
                for (int i = 0; i < arrayTextViews.length; i++)
                    arrayTextViews[i].setText("");
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSubmit();
            }
        });
        final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        cal = Calendar.getInstance();
        tvCheckIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cal = Calendar.getInstance();
                String currentTime = sdf.format(cal.getTime());
                String[] time = currentTime.split(":");
                int hours = Integer.parseInt(time[0]);int minutes = Integer.parseInt(time[1]);
                String timeForeTextView;
                String hourForTextView = String.valueOf(hours), minutesForTextView = String.valueOf(minutes);
                if (hours < 10)
                    hourForTextView = "0" + hours;
                if (minutes < 10)
                    minutesForTextView = "0" + minutes;
                timeForeTextView = hourForTextView + ":" + minutesForTextView;


                for (int i=0; i<arrayTextViews.length; i++){
                    if (arrayTextViews[i].getText().toString().equalsIgnoreCase("")) {
                        if (i == 0) {
                            checkIn = !checkIn;
                            arrayTextViews[i].setText(timeForeTextView);
                            setVisibilityForCheckInAndBreak();
                        }
                        else {
                            int currentMinutes = hours * 60 + minutes;
                            String[] oldTime = arrayTextViews[i-1].getText().toString().split(":");
                            int oldMinutes = Integer.parseInt(oldTime[0]) * 60 + Integer.parseInt(oldTime[1]);
                            int nextMinutes = Integer.MAX_VALUE;
                            if (i+1<arrayTextViews.length) {
                                if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                                    String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                                    nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                                }
                            }
                            if (currentMinutes > oldMinutes && currentMinutes < nextMinutes) {
                                arrayTextViews[i].setText(timeForeTextView);
                                int difference = currentMinutes-oldMinutes;
                                if (i%2==0) {
                                    arrayBreakTime[i / 2 - 1].setText(String.format("%.2f", (double) difference / 60));
                                    setVisibilityForCheckInAndBreak();
                                }
                                else {
                                    arrayTotalTime[i / 2].setText(String.format("%.2f", (double) difference / 60));
                                    setVisibilityForCheckInAndBreak();
                                }
                            } else
                                Toast.makeText(mContext, "Enter correct time", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    }
                }
            }
        });
        tvBreak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cal = Calendar.getInstance();
                String currentTime = sdf.format(cal.getTime());
                String[] time = currentTime.split(":");
                int hours = Integer.parseInt(time[0]);int minutes = Integer.parseInt(time[1]);
                String timeForeTextView;
                String hourForTextView = String.valueOf(hours), minutesForTextView = String.valueOf(minutes);
                if (hours < 10)
                    hourForTextView = "0" + hours;
                if (minutes < 10)
                    minutesForTextView = "0" + minutes;
                timeForeTextView = hourForTextView + ":" + minutesForTextView;
                int hoursAfterBreak = (int) (hours + breakTimeFromSettings);
                String timeAfterBreak, hourAfterBreak = String.valueOf(hoursAfterBreak);
                if (hoursAfterBreak < 10)
                    hourAfterBreak = "0" + hoursAfterBreak;
                timeAfterBreak = hourAfterBreak+":"+minutesForTextView;

                if (arrayTextViews[0].getText().toString().equalsIgnoreCase(""))
                    Toast.makeText(mContext, "CheckIn First", Toast.LENGTH_SHORT).show();
                else {
                    for (int i = 1; i < arrayTextViews.length; i += 2) {
                        if (arrayTextViews[i].getText().toString().equalsIgnoreCase("")) {
                            if (!arrayTextViews[i-1].getText().toString().equalsIgnoreCase("")){

                                //get previous and next textView time if exist
                                int currentMinutes = hours * 60 + minutes;
                                String[] oldTime = arrayTextViews[i-1].getText().toString().split(":");
                                int oldMinutes = Integer.parseInt(oldTime[0]) * 60 + Integer.parseInt(oldTime[1]);
                                int nextMinutes = Integer.MAX_VALUE;
                                if (i+1<arrayTextViews.length) {
                                    if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                                        String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                                        nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                                    }
                                }
                                if (currentMinutes > oldMinutes && currentMinutes < nextMinutes) {
                                    arrayTextViews[i].setText(timeForeTextView);
                                    arrayTextViews[i+1].setText(timeAfterBreak);
                                    int difference = currentMinutes-oldMinutes;
                                    arrayTotalTime[i / 2].setText(String.format("%.2f", (double) difference / 60));
                                    arrayBreakTime[i / 2].setText(String.format("%.2f", breakTimeFromSettings));
                                    break;
                                } else
                                    Toast.makeText(mContext, "Enter correct time", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        });
    }

    private void onSubmit() {
        boolean flag = true;
        for (int i=1;i<arrayTextViews.length;i+=2){
            if (arrayTextViews[i].getText().toString().equalsIgnoreCase("") && !arrayTextViews[i-1].getText().toString().equalsIgnoreCase(""))
                flag = false;
        }
        if (flag){
            double total=0;
            if (defaultSharedPreference.getBoolean(mContext.getString(R.string.settings_key_switch_break_time),false)) {
                for (int i = 0; i < arrayTotalTime.length; i++) {
                    if (!arrayTotalTime[i].getText().toString().equalsIgnoreCase(""))
                        total += Double.parseDouble(arrayTotalTime[i].getText().toString());
                    if (!arrayBreakTime[i].getText().toString().equalsIgnoreCase(""))
                        total += Double.parseDouble(arrayBreakTime[i].getText().toString());
                }
            }
            else {
                for (int i = 0; i < arrayTotalTime.length; i++)
                    if (!arrayTotalTime[i].getText().toString().equalsIgnoreCase(""))
                        total += Double.parseDouble(arrayTotalTime[i].getText().toString());
            }
            List<TimeInOut> timeInOutList = new ArrayList<>();
            for (int i=0;i<arrayTextViews.length;i+=2) {
                if (!arrayTextViews[i].getText().toString().equalsIgnoreCase("")) {
                    int index = i;
                    String timeIn = arrayTextViews[i].getText().toString();
                    timeIn = timeIn.substring(0,2)+timeIn.substring(3);
                    String timeOut = arrayTextViews[i + 1].getText().toString();
                    timeOut = timeOut.substring(0,2)+timeOut.substring(3);
                    TimeInOut timeInOut = new TimeInOut(index, timeIn, timeOut, total);
                    timeInOutList.add(timeInOut);
                }
                else
                    break;
            }
            dismiss();
            if (mIsPopUpGlobal)
                mCallback.inOutPopUpSubmittedForAllEmployees(timeInOutList);
            else
                mCallback.inOutPopUpSubmittedForIndividualEmployee(timeInOutList, mEmployeePosition);
        }
    }

    private void enterTime(int i) {
        if (i > 0) {
            if (arrayTextViews[i - 1].getText().toString().equals(""))
                Toast.makeText(mContext, "Enter Previous Time First", Toast.LENGTH_SHORT).show();
            else {
                showTimePickerDialog(i);
            }
        } else {
            showTimePickerDialog(0);
        }
    }

    private void showTimePickerDialog(final int i) {
        cal = Calendar.getInstance();
        int mHour = cal.get(Calendar.HOUR_OF_DAY);
        int mMinute = cal.get(Calendar.MINUTE);
        final TimePickerDialog timePickerDialog = new TimePickerDialog(mContext, R.style.DatePickerDailog,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        String timeForeTextView;
                        String hourForTextView = String.valueOf(hourOfDay), minutesForTextView = String.valueOf(minutes);
                        if (hourOfDay < 10)
                            hourForTextView = "0" + hourOfDay;
                        if (minutes < 10)
                            minutesForTextView = "0" + minutes;
                        timeForeTextView = hourForTextView + ":" + minutesForTextView;
                        if(i!=0) {
                            int currentMinutes = hourOfDay * 60 + minutes;
                            String[] oldTime = arrayTextViews[i-1].getText().toString().split(":");
                            int oldMinutes = Integer.parseInt(oldTime[0]) * 60 + Integer.parseInt(oldTime[1]);
                            int nextMinutes = Integer.MAX_VALUE;
                            if (i+1<arrayTextViews.length) {
                                if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                                    String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                                    nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                                }
                            }
                            if (currentMinutes > oldMinutes && currentMinutes < nextMinutes) {
                                arrayTextViews[i].setText(timeForeTextView);
                                int difference = currentMinutes-oldMinutes;
                                if (i%2==0){
                                    arrayBreakTime[i / 2 - 1].setText(String.format("%.2f", (double) difference / 60));
                                    setVisibilityForCheckInAndBreak();
                                }
                                else {
                                    arrayTotalTime[i / 2].setText(String.format("%.2f", (double) difference / 60));
                                    setVisibilityForCheckInAndBreak();
                                }
                            } else
                                Toast.makeText(mContext, "Enter correct time", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            int currentMinutes = hourOfDay * 60 + minutes;
                            int nextMinutes = Integer.MAX_VALUE;
                            if (i+1<arrayTextViews.length) {
                                if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                                    String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                                    nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                                }
                            }
                            if (currentMinutes < nextMinutes) {
                                arrayTextViews[i].setText(timeForeTextView);
                                setVisibilityForCheckInAndBreak();
                            }
                            else
                                Toast.makeText(mContext, "Enter correct time", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }

    private boolean checkIn = true;
    private void setTime(int i,String time){

        String[] s = time.split(":");
        int hours = Integer.parseInt(s[0]);
        int minutes = Integer.parseInt(s[1]);
        String timeForeTextView;
        String hourForTextView = String.valueOf(hours), minutesForTextView = String.valueOf(minutes);
        if (hours < 10)
            hourForTextView = "0" + hours;
        if (minutes < 10)
            minutesForTextView = "0" + minutes;
        timeForeTextView = hourForTextView + ":" + minutesForTextView;


        if (i==0){
            checkIn = !checkIn;
            arrayTextViews[i].setText(timeForeTextView);
        }
        else {
            int currentMinutes = hours * 60 + minutes;

            //getTime From Previous TxtView
            String[] oldTime = arrayTextViews[i-1].getText().toString().split(":");
            int oldMinutes = Integer.parseInt(oldTime[0]) * 60 + Integer.parseInt(oldTime[1]);
            int nextMinutes = Integer.MAX_VALUE;

            //getTime From Next TxtView
            if (i+1<arrayTextViews.length) {
                if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                    String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                    nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                }
            }

            if (currentMinutes > oldMinutes && currentMinutes < nextMinutes) {
                checkIn = !checkIn;
                arrayTextViews[i].setText(timeForeTextView);
                int difference = currentMinutes-oldMinutes;
                if (i%2==0)
                    arrayBreakTime[i/2 - 1].setText(String.format("%.2f",(double)difference/60));
                else
                    arrayTotalTime[i/2].setText(String.format("%.2f",(double)difference/60));
            } else
                Toast.makeText(mContext, "Enter Valid Time", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateTime(int i, int hours, int minutes){
        if (arrayTextViews[i-1].getText().toString().equalsIgnoreCase(""))
            return false;
        else {
            int currentMinutes = hours * 60 + minutes;
            String[] oldTime = arrayTextViews[i-1].getText().toString().split(":");
            int oldMinutes = Integer.parseInt(oldTime[0]) * 60 + Integer.parseInt(oldTime[1]);
            int nextMinutes = Integer.MAX_VALUE;

            //getTime From Next TxtView
            if (i+1<arrayTextViews.length) {
                if (!arrayTextViews[i + 1].getText().toString().equalsIgnoreCase("")) {
                    String[] nextTime = arrayTextViews[i + 1].getText().toString().split(":");
                    nextMinutes = Integer.parseInt(nextTime[0]) * 60 + Integer.parseInt(nextTime[1]);
                }
            }

            if (currentMinutes > oldMinutes && currentMinutes < nextMinutes)
                return true;
            return false;
        }
    }

    private void setVisibilityForCheckInAndBreak(){
        for (int i=0;i<arrayTextViews.length-1;i++){
            if (arrayTextViews[i+1].getText().toString().equalsIgnoreCase("")){
                if ((i+1)%2==0){
                    tvCheckIn.setText("Check In");
                    tvBreak.setVisibility(View.INVISIBLE);
                }
                else {
                    tvCheckIn.setText("Check Out");
                    tvBreak.setVisibility(View.VISIBLE);
                }
                break;
            }
        }
    }
}
