package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.Dashboard2Task;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.Dashboard3Task;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DashboardPersonTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DashboardJobTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DeleteSignatureTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetEmployeesTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetSignatureOraSeqTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetSignatureTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.JobDataTask2;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.PostSignatureTask;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CrewMemberDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class HeadlessFragment1 extends Fragment {
    private DashboardTaskListener mDashboardTaskListener;
    private CrewMemberDataListener mCrewMemberDataListener;
    private JobDataListener mJobdDataTaskListener;
    private DashboardJobTask mDashboardJobTask;
    private DashboardPersonTask mDashboardPersonTask;
    private Dashboard2Task mDashboard2Task;
    private Dashboard3Task mDashboard3Task;
    private GetEmployeesTask mGetEmployeesTask;
    private JobDataTask2 mJobListTask;
    private GetSignatureOraSeqTask mSignatureOraSeqTask;
    private GetSignatureTask mGetForemanSignatureTask;
    private GetSignatureTask mGetEmployeeSignatureTask;
    private PostSignatureTask mPostSignatureTask;
    private DeleteSignatureTask mDeleteSignatureTask;
    public boolean isTaskExecuting = false;
    private List<User> crewMemberList;
    private List<JobData> jobDataList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }


    public void getDashboardData(Context context, String jobCompCode, String jobCode, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboardJobTask = new DashboardJobTask(context, jobCompCode, jobCode, date, mListener);
            mDashboardJobTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mDashboardJobTask = new DashboardJobTask(context, jobCompCode, jobCode, date, mListener);
            mDashboardJobTask.execute();
        }
    }

    public void getDashboardData(Context context, String empOraSeq, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboardPersonTask = new DashboardPersonTask(context, empOraSeq, date, mListener);
            mDashboardPersonTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mDashboardPersonTask = new DashboardPersonTask(context, empOraSeq, date, mListener);
            mDashboardPersonTask.execute();
        }
    }

    public void getDashboard2Data(Context context, String crewCode, String date,DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboard2Task = new Dashboard2Task(context, crewCode, date, mListener, false);
            mDashboard2Task.execute();
        }
        else {
            cancelAllRunningTasks();
            mDashboard2Task = new Dashboard2Task(context, crewCode, date, mListener, false);
            mDashboard2Task.execute();
        }
    }

    public void getDashboard2Data(Context context, String jobCompCode, String jobCode, String crewCode, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboard2Task = new Dashboard2Task(context, jobCompCode, jobCode, crewCode, date, mListener, true);
            mDashboard2Task.execute();
        }
        else {
            cancelAllRunningTasks();
            mDashboard2Task = new Dashboard2Task(context, jobCompCode, jobCode, crewCode, date, mListener, true);
            mDashboard2Task.execute();
        }
    }

    public void getDashboard3Data(Context context, String empNumber, String date, DashboardTaskListener mListener){
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboard3Task = new Dashboard3Task(context, date, empNumber, mListener);
            mDashboard3Task.execute();
        }
        else {
            cancelAllRunningTasks();
            mDashboard3Task = new Dashboard3Task(context, date, empNumber, mListener);
            mDashboard3Task.execute();
        }
    }

    public void  getSignatureOraSeq(Context context, DashboardTaskListener mListener, String empOraSeq, String startDate, String endDate){
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mSignatureOraSeqTask = new GetSignatureOraSeqTask(context, mListener, empOraSeq, startDate, endDate);
            mSignatureOraSeqTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mSignatureOraSeqTask = new GetSignatureOraSeqTask(context, mListener, empOraSeq, startDate, endDate);
            mSignatureOraSeqTask.execute();
        }
    }

    public void  getSignature(Context context, DashboardTaskListener mListener, String signatureOraSeq){
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (isTaskExecuting)
            cancelAllRunningTasks();
        mGetForemanSignatureTask = new GetSignatureTask(context, mListener, signatureOraSeq, GetSignature.CREWTIME_EMPLOYEE_SIGNATURE);
        mGetEmployeeSignatureTask = new GetSignatureTask(context, mListener, signatureOraSeq, GetSignature.CREWTIME_FOREMAN_SIGNATURE);
        mGetEmployeeSignatureTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        mGetForemanSignatureTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    public void  postSignature(Context context, DashboardTaskListener mListener, String empOraSeq, String startDate, String endDate, String encodeImage, Signature signatureEnum){
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mPostSignatureTask = new PostSignatureTask(context, mListener, empOraSeq, startDate, endDate, encodeImage, signatureEnum);
            mPostSignatureTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mPostSignatureTask = new PostSignatureTask(context, mListener, empOraSeq, startDate, endDate, encodeImage, signatureEnum);
            mPostSignatureTask.execute();
        }
    }

    public void  deleteSignature(Context context, DashboardTaskListener mListener, String empOraSeq, String startDate, String endDate, Signature signatureEnum){
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDeleteSignatureTask = new DeleteSignatureTask(context, mListener, empOraSeq, startDate, endDate, signatureEnum);
            mDeleteSignatureTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mDeleteSignatureTask = new DeleteSignatureTask(context, mListener, empOraSeq, startDate, endDate, signatureEnum);
            mDeleteSignatureTask.execute();
        }
    }

    public void getCrewMemberData(CrewMemberDataListener crewMemberDataListener ) {
        if (this.mCrewMemberDataListener == null)
            this.mCrewMemberDataListener = crewMemberDataListener;
        if (!isTaskExecuting) {
            mGetEmployeesTask = new GetEmployeesTask(getActivity(), mCrewMemberDataListener);
            mGetEmployeesTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mGetEmployeesTask = new GetEmployeesTask(getActivity(), mCrewMemberDataListener);
            mGetEmployeesTask.execute();
        }
    }

    public void getJobData(JobDataListener jobDataListener) {
        if (this.mJobdDataTaskListener == null)
            this.mJobdDataTaskListener = jobDataListener;
        if (!isTaskExecuting) {
            mJobListTask = new JobDataTask2(getContext(), mJobdDataTaskListener);
            mJobListTask.execute();
        }
        else {
            cancelAllRunningTasks();
            mJobListTask = new JobDataTask2(getContext(), mJobdDataTaskListener);
            mJobListTask.execute();
        }
    }

    public void cancelJobBackgroundTask() {
        if (isTaskExecuting && mDashboardJobTask !=null && mDashboardJobTask.getStatus()== AsyncTask.Status.RUNNING) {
            mDashboardJobTask.cancel(true);
            isTaskExecuting = false;
        }
    }

    public void cancelPersonBackgroundTask() {
        if (isTaskExecuting && mDashboardPersonTask !=null && mDashboardPersonTask.getStatus()== AsyncTask.Status.RUNNING) {
            mDashboardPersonTask.cancel(true);
            isTaskExecuting = false;
        }
    }

    public void updateExecutingStatus(boolean isExecuting) {
        this.isTaskExecuting = isExecuting;
    }

    public List<User> getCrewMemberList() {
        return crewMemberList;
    }

    public void setCrewMemberList(List<User> crewMemberList) {
        this.crewMemberList = crewMemberList;
    }

    public List<JobData> getJobDataList() {
        return jobDataList;
    }

    public void setJobDataList(List<JobData> jobDataList) {
        this.jobDataList = jobDataList;
    }

    public void cancelAllRunningTasks(){
        isTaskExecuting = false;
        if (mDashboard2Task!=null && mDashboard2Task.getStatus()== AsyncTask.Status.RUNNING)
            mDashboard2Task.cancel(true);
        if (mDashboardPersonTask !=null && mDashboardPersonTask.getStatus()== AsyncTask.Status.RUNNING)
            mDashboardPersonTask.cancel(true);
        if (mDashboardJobTask !=null && mDashboardJobTask.getStatus()== AsyncTask.Status.RUNNING)
            mDashboardJobTask.cancel(true);
        if (mDashboard3Task!=null && mDashboard3Task.getStatus()== AsyncTask.Status.RUNNING)
            mDashboard3Task.cancel(true);
        if (mGetEmployeesTask!=null && mGetEmployeesTask.getStatus()== AsyncTask.Status.RUNNING)
            mGetEmployeesTask.cancel(true);
        if (mJobListTask!=null && mJobListTask.getStatus()== AsyncTask.Status.RUNNING)
            mJobListTask.cancel(true);
        if (mSignatureOraSeqTask!=null && mSignatureOraSeqTask.getStatus()== AsyncTask.Status.RUNNING)
            mSignatureOraSeqTask.cancel(true);
        if (mGetForemanSignatureTask!=null && mGetForemanSignatureTask.getStatus()== AsyncTask.Status.RUNNING)
            mGetForemanSignatureTask.cancel(true);
        if (mGetEmployeeSignatureTask!=null && mGetEmployeeSignatureTask.getStatus()== AsyncTask.Status.RUNNING)
            mGetEmployeeSignatureTask.cancel(true);
        if (mPostSignatureTask!=null && mPostSignatureTask.getStatus()== AsyncTask.Status.RUNNING)
            mPostSignatureTask.cancel(true);
        if (mDeleteSignatureTask!=null && mDeleteSignatureTask.getStatus()== AsyncTask.Status.RUNNING)
            mDeleteSignatureTask.cancel(true);
    }

    @Override
    public void onDestroy() {
        cancelAllRunningTasks();
        super.onDestroy();
    }
}
