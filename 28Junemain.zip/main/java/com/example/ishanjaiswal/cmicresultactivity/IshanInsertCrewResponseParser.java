package com.example.ishanjaiswal.cmicresultactivity;

import com.example.ishanjaiswal.cmicresultactivity.Model.IshanInsertCrewResponseModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/5/2018.
 */
public class IshanInsertCrewResponseParser {

    public String getInsertedCrewOraseq(String response, String crewCode, String crewName, String responsibleEmpOraseq) {

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONObject rowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray attrNamesJsonArray = rowDefinition.getJSONArray("attrNames");
            JSONArray rows = jsonObject.getJSONArray("rows");
            List<IshanInsertCrewResponseModel> array = new ArrayList<IshanInsertCrewResponseModel>();
            for (int i = 0; i < rows.length(); i++) {
                IshanInsertCrewResponseModel obj = new IshanInsertCrewResponseModel();
                JSONObject jobj = rows.getJSONObject(i);
                JSONArray j = jobj.getJSONArray("attrValues");
                if (j.getString(0).equalsIgnoreCase(crewCode) && j.getString(1).equalsIgnoreCase(crewName) && j.getInt(3)==Integer.parseInt(responsibleEmpOraseq))
                    return j.getInt(2)+"";
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}