package com.shaurya.room.repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.Observer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;


import com.shaurya.room.model.Movie;
import com.shaurya.room.repository.local.AppLocalHelper;
import com.shaurya.room.repository.remote.AppRemoteHelper;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class AppRepositoryHelper {


    private AppRemoteHelper remoteHelper;
    private AppLocalHelper localHelper;

    public AppRepositoryHelper(Application application) {
        remoteHelper = new AppRemoteHelper();
        localHelper = new AppLocalHelper(application);
    }

    public void fetchMoviesFromRemote(int page){
        remoteHelper.fetchMovieFromRemote(page).observeForever(new Observer<List<Movie>>() {
            @Override
            public void onChanged(@Nullable final List<Movie> movies) {
                Executors.newSingleThreadExecutor().submit(new Runnable() {
                    @Override
                    public void run() {
                        localHelper.insertMovies(movies);
                    }
                });
            }
        });
    }


    public LiveData<List<Movie>> getMovieListFromRoom() {
        return localHelper.getMovieList();
    }
}
