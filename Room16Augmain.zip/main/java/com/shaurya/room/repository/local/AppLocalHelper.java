package com.shaurya.room.repository.local;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.shaurya.room.model.Movie;
import com.shaurya.room.repository.local.db.MovieDatabase;
import com.shaurya.room.repository.local.db.dao.MovieDao;

import java.util.List;

public class AppLocalHelper {

    private MovieDao movieDao;

    public AppLocalHelper(Application context){
        movieDao = MovieDatabase.getInstance(context).movieDao();
    }

    public void insertMovies(List<Movie> list){
        movieDao.insertAll(list);
    }

    public LiveData<List<Movie>> getMovieList(){
        return movieDao.getAllWords();
    }

}
