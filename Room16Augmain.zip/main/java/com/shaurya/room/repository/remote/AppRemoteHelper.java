package com.shaurya.room.repository.remote;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.util.Log;

import com.shaurya.room.model.Movie;
import com.shaurya.room.model.MovieResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AppRemoteHelper {

    private MovieService movieService;

    private MutableLiveData<List<Movie>> movieList = new MutableLiveData<>();

    public AppRemoteHelper() {
        movieService = RetrofitInstance.getInstance().create(MovieService.class);
    }

    public LiveData<List<Movie>> fetchMovieFromRemote(int page){
        movieService.fetchPopularMovies("ab5aee0b18da89dd9e026d35754c24f1", page).enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                int statusCode = response.code();
                if (statusCode == 200){
                    MovieResponse movieResponse = response.body();
                    movieList.postValue(movieResponse.getResult());
                }
            }

            @Override
            public void onFailure(Call<MovieResponse> call, Throwable t) {
                Log.e("tatti",t.getMessage());
            }
        });

        return movieList;
    }

}
