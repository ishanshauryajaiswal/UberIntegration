package com.shaurya.room.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.shaurya.room.model.Movie;
import com.shaurya.room.repository.AppRepositoryHelper;

import java.util.List;

public class MovieViewModel extends AndroidViewModel {

    private AppRepositoryHelper repository;

    private MutableLiveData<List<Movie>> movieList = new MutableLiveData<>();

    public MovieViewModel(@NonNull Application application) {
        super(application);
        repository = new AppRepositoryHelper(application);
    }

    public void fetchMovies(int page){
        repository.fetchMoviesFromRemote(page);
    }

    public LiveData<List<Movie>> getMovieList() {
        return repository.getMovieListFromRoom();
    }
}
