package com.shaurya.room.model;

import java.util.List;

public class MovieResponse {

    public List<Movie> results;

    public List<Movie> getResult() {
        return results;
    }

    public void setResult(List<Movie> result) {
        this.results = result;
    }
}
