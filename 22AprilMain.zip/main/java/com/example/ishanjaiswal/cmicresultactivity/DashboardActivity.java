package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ProgressBar;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.parsers.DashboardParser;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class DashboardActivity extends AppCompatActivity implements FragmentClickListener,DashboardTaskListener,JobDataListener,CrewMemberDataListener {

    FragmentManager fragmentManager;
    private FragmentOne fragmentOne;
    private HeadlessFragment1 headlessFragment1;
    private boolean isAnyTaskRunning = false;
    private ProgressDialog progressDialog;
    String jobCompCode = "10", jobCode = "0001D", date = "2018-04-19";
    String mjobCompCode = "10", mjobCode = "0001D", mdate = "2018-04-19", mTradeName, mTrade;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getValuesFromSharedPreference();
        fragmentManager = getSupportFragmentManager();
        fragmentOne = FragmentOne.getInstance();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer,fragmentOne,FragmentOne.class.getSimpleName())
                .commit();
    }

    void getValuesFromSharedPreference(){
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        mjobCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_code),null);
        mjobCompCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_comp_code),null);
        mTradeName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_trade_name),null);
        mTradeName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_name), null);
    }


    @Override
    public void retrieveDashboardData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getDashboardData(DashboardActivity.this,jobCompCode, jobCode, date,DashboardActivity.this);
    }

    @Override
    public void retrieveCrewMemberData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (headlessFragment1.getCrewMemberList()!=null&& headlessFragment1.getCrewMemberList().size()>0)
            fragmentOne.populateCrewMemberList(headlessFragment1.getCrewMemberList());
        else
            if (!headlessFragment1.isTaskExecuting)
                headlessFragment1.getCrewMemberData(DashboardActivity.this);
            else {}
    }

    @Override
    public void retrieveJobData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (headlessFragment1.getJobDataList()!=null&& headlessFragment1.getJobDataList().size()>0)
            fragmentOne.populateJobData(headlessFragment1.getJobDataList());
        else
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getJobData(DashboardActivity.this);
        else {}
    }

    @Override
    public void beforeDashboardTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        progressDialog = ProgressDialog.show(DashboardActivity.this,displayMessage,displayMessage);
    }

    @Override
    public void onDashboardTaskComplete(String response) {
        progressDialog.dismiss();
        headlessFragment1.isTaskExecuting = false;
        DashboardParser dashboardParser = new DashboardParser();
        List<Dashboard> dashboardList = dashboardParser.parseDashboardData(response);
        if (fragmentOne!=null)
            fragmentOne.setUpUI(dashboardList);
    }

    @Override
    public void beforeJobDataTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        //ProgressBar progressBar = (ProgressBar) findViewById(R.id.pb_popup_dashboard);
        //progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void onJobDataTaskComplete(String response) {
        headlessFragment1.isTaskExecuting = false;
        //ProgressBar progressBar = (ProgressBar) findViewById(R.id.pb_popup_dashboard);
        //progressBar.setVisibility(View.VISIBLE);
        if (response!=null && !response.equalsIgnoreCase(getString(R.string.internal_server_error)))
            headlessFragment1.setJobDataList(new JobDataParser().parseJobData(response));
        else
            makeErrorAlert();
    }

    @Override
    public void onCrewMemberDataTaskStarted() {
        headlessFragment1.isTaskExecuting = true;
        //ProgressBar progressBar = (ProgressBar) findViewById(R.id.pb_popup_dashboard);
        //progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void onCrewMemberDataTaskCompleted(String result) {
        headlessFragment1.isTaskExecuting = false;
        //ProgressBar progressBar = (ProgressBar) findViewById(R.id.pb_popup_dashboard);
        //progressBar.setVisibility(View.VISIBLE);
        if (result!=null && !result.equalsIgnoreCase(getString(R.string.internal_server_error)))
            headlessFragment1.setCrewMemberList(new EmployeeDataParser().parseEmployeeData(result, DashboardActivity.this));
        else
            makeErrorAlert();
    }


    private void makeErrorAlert(){
        final AlertDialog.Builder alertBox = new AlertDialog.Builder(DashboardActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        alertBox.setMessage("Some Error Occurred. Please Try Again.");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }
}
