package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface DashboardTaskListener {
    public void beforeDashboardTaskStarted(String displayMessage);
    public void onDashboardTaskComplete(String response);
}
