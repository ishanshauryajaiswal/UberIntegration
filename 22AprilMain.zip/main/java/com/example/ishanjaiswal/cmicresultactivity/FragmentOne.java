package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class FragmentOne extends Fragment {

    private TextView tvDesignation, tvSelectedName, tvArrow, tvDate, tvCalendar;
    private TextView tvWeek1Heading, tvWeek2Heading;
    private TextView tvRegTotal1, tvOtTotal1, tvDotTotal1;
    private TextView tvRegTotal2, tvOtTotal2, tvDotTotal2;
    private TextView tvPerson, tvJob;
    private RelativeLayout rlSelectedJob;
    private RecyclerView rvDashboard;
    private PopupWindow popup;
    private ListView lvPopup;
    private RvDashboardAdapter rvDashboardAdapter;
    private FragmentClickListener mListener;
    static FragmentOne fragmentOne;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_one,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        mListener.retrieveDashboardData();
    }

    private void initView(View view) {
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        tvDesignation = (TextView)view.findViewById(R.id.tv_designation_dashboard);
        rlSelectedJob = (RelativeLayout)view.findViewById(R.id.rl_selected_dashboard);
        tvSelectedName = (TextView)view.findViewById(R.id.tv_selected_name_dashboard);
        tvArrow = (TextView)view.findViewById(R.id.tv_arrow_dashboard);
        tvDate = (TextView)view.findViewById(R.id.tv_date_dashboard);
        tvCalendar = (TextView)view.findViewById(R.id.tv_calendar_dashboard);
        tvArrow.setTypeface(typeface);
        tvCalendar.setTypeface(typeface);
        tvWeek1Heading = (TextView)view.findViewById(R.id.tv_week1_dashboard);
        tvWeek2Heading = (TextView)view.findViewById(R.id.tv_week2_dashboard);
        tvRegTotal1 = (TextView)view.findViewById(R.id.tv_reg_total_1_dashboard);
        tvOtTotal1 = (TextView)view.findViewById(R.id.tv_ot_total_1_dashboard);
        tvDotTotal1 = (TextView)view.findViewById(R.id.tv_dot_total_1_dashboard);
        tvRegTotal2 = (TextView)view.findViewById(R.id.tv_reg_total_2_dashboard);
        tvOtTotal2 = (TextView)view.findViewById(R.id.tv_ot_total_2_dashboard);
        tvDotTotal2 = (TextView)view.findViewById(R.id.tv_dot_total_2_dashboard);
        rvDashboard = (RecyclerView)view.findViewById(R.id.rv_dashboard);
        rvDashboardAdapter = new RvDashboardAdapter(getContext(), new ArrayList());
        rvDashboard.setAdapter(rvDashboardAdapter);
        rvDashboard.setLayoutManager(new LinearLayoutManager(getContext()));
        rlSelectedJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopup(view);
            }
        });
    }

    public void setUpUI(List<Dashboard> dashboardList){
        rvDashboardAdapter.setmList(dashboardList);
        rvDashboardAdapter.notifyDataSetChanged();
    }

    public void populateCrewMemberList(List<User> list){
        CrewMemberAdapter crewMemberAdapter = new CrewMemberAdapter(getContext(),(ArrayList<User>) list,new HashMap<String, Boolean>(),false);
        lvPopup.setAdapter(crewMemberAdapter);
    }

    public void populateJobData(List<JobData> list){
        ProjectListAdapter jobDataAdapter = new ProjectListAdapter(getActivity(),(ArrayList<JobData>)list);
        lvPopup.setAdapter(jobDataAdapter);
        lvPopup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                JobData jobData = (JobData)adapterView.getItemAtPosition(i);
                mListener.retrieveDashboardData();
            }
        });
    }

    private void showPopup(View view){
        LayoutInflater lInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View popup_view = lInflater.inflate(R.layout.popup_dashboard, null);
        popup = new PopupWindow(popup_view,800,ViewGroup.LayoutParams.WRAP_CONTENT,true);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable());
        popup_view.measure(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        //popup.setAnimationStyle(R.style.popup_window_fade_out);
        WindowManager w = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = w.getDefaultDisplay();
        Point size = new Point(); display.getSize(size); int width = size.x; int height = size.y;
        float y = rlSelectedJob.getY()+rlSelectedJob.getHeight()+120;

        popup.showAtLocation(popup_view,Gravity.NO_GRAVITY,width/4,(int)y);
        //popup.showAsDropDown(rlSelectedJob, (int) (width/4 - rlSelectedJob.getX()),0,Gravity.CENTER_HORIZONTAL);
        tvPerson = (TextView) popup_view.findViewById(R.id.tv_person_popup_dashboard);
        tvJob = (TextView) popup_view.findViewById(R.id.tv_job_popup_dashboard);
        lvPopup = (ListView) popup_view.findViewById(R.id.lv_popup_dashboard);
        tvPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.retrieveCrewMemberData();
            }
        });
        tvJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.retrieveJobData();
            }
        });
        tvPerson.callOnClick();
    }

    public static Rect locateView(View v) {
        int[] loc_int = new int[2];
        if (v == null)
            return null;
        try {
            v.getLocationOnScreen(loc_int);
        } catch (NullPointerException npe) {
            return null;
        }
        Rect location = new Rect();
        location.left = loc_int[0];
        location.top = loc_int[1];
        location.right = loc_int[0] + v.getWidth();
        location.bottom = loc_int[1] + v.getHeight();
        return location;
    }

    public static FragmentOne getInstance(){
        if (fragmentOne==null)
            fragmentOne = new FragmentOne();
        return fragmentOne;
    }
}
