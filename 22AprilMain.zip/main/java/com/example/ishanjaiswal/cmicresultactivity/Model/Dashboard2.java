package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.util.List;

/**
 * Created by shaurya on 21/04/18.
 */

public class Dashboard2 {
    String crewMemberName, crewMemberDesignation;
    List<AllTimes> timesList;

    public String getCrewMemberName() {
        return crewMemberName;
    }

    public void setCrewMemberName(String crewMemberName) {
        this.crewMemberName = crewMemberName;
    }

    public String getCrewMemberDesignation() {
        return crewMemberDesignation;
    }

    public void setCrewMemberDesignation(String crewMemberDesignation) {
        this.crewMemberDesignation = crewMemberDesignation;
    }

    public List<AllTimes> getTimesList() {
        return timesList;
    }

    public void setTimesList(List<AllTimes> timesList) {
        this.timesList = timesList;
    }
}
