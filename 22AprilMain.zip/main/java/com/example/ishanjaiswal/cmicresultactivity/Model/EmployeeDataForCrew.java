package com.example.ishanjaiswal.cmicresultactivity.Model;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */

public class EmployeeDataForCrew implements Serializable,Cloneable
{
    private String DeleteFlag = null;
    private String EmpName = null;
    private String TradeCode = null;
    private String TradeName = null;
    private String EmpNo = null;
    private String RowNo = null;
    private String employeeOraseq = null;
    private double totalTimeInOut;
    private ArrayList<ActivityTimeForCrew> TimeSheet;
    private List<TimeInOut> timeInOuts;
    private double totalRtHour, totalOtHour, totalDotHour ;
    public String jobCode = null;
    public String periodFlag = null;
    public String workDate = null;


    public List<TimeInOut> getTimeInOuts() {
        return timeInOuts;
    }

    public void setTimeInOuts(List<TimeInOut> timeInOuts) {
        this.timeInOuts = timeInOuts;
        if (timeInOuts!=null && timeInOuts.size()>0)
            setTotalTimeInOut(timeInOuts.get(0).getTotal());
    }

    public String getJobCode() {
        return jobCode;
    }

    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    public String getPeriodFlag() {
        return periodFlag;
    }

    public void setPeriodFlag(String periodFlag) {
        this.periodFlag = periodFlag;
    }

    public String getWorkDate() {
        return workDate;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }

    public EmployeeDataForCrew(String deleteFlag, String empNo, String employeeOraseq, String empName , String tradeCode, String tradeName, String rowNo, String periodFlag, ArrayList<ActivityTimeForCrew> timeSheet)
    {
        this.DeleteFlag = deleteFlag;
        this.EmpNo = empNo;
        this.employeeOraseq = employeeOraseq;
        this.EmpName = empName;
        this.RowNo = rowNo;
        this.TimeSheet = timeSheet;
        this.TradeCode = tradeCode;
        this.TradeName = tradeName;
        this.periodFlag = periodFlag;
    }
    public EmployeeDataForCrew()
    {
    }

    public double getTotalTimeInOut() {
        return totalTimeInOut;
    }

    public void setTotalTimeInOut(double totalTimeInOut) {
        this.totalTimeInOut = totalTimeInOut;
    }

    public String getDeleteFlag() {
        return DeleteFlag;
    }

    public ArrayList<ActivityTimeForCrew> getTimeSheet()
    {
        return TimeSheet;
    }


    public String getEmpNo() {
        return EmpNo;
    }

    public String getRowNo()
    {
        return RowNo;
    }

    public String getEmpName() {
        return EmpName;
    }

    public String getTradeCode() {
        return TradeCode;
    }

    public String getTradeName() {
        return TradeName;
    }

    public String setEmpName(String empName)
    {
        EmpName = empName;
        return EmpName;
    }

    public void setTradeCode(String tradeCode) {
        TradeCode = tradeCode;
    }

    public void setTradeName(String tradeName) {
        TradeName = tradeName;
    }

    public void setDeleteFlag(String deleteFlag) {
        DeleteFlag = deleteFlag;
    }

    public void setEmpNo(String empNo) {
        EmpNo = empNo;
    }

    public void setRowNo(String rowNo) {
        RowNo = rowNo;
    }
    public void setTimeSheet(ArrayList<ActivityTimeForCrew> TimeSheet)
    {
        this.TimeSheet = TimeSheet;
    }

    public Double getTotalRtHour() {
        return totalRtHour;
    }

    public void setTotalRtHour(Double totalRtHour) {
        this.totalRtHour = totalRtHour;
    }

    public Double getTotalDotHour() {
        return totalDotHour;
    }

    public void setTotalDotHour(Double totalDotHour) {
        this.totalDotHour = totalDotHour;
    }

    public Double getTotalOtHour() {
        return totalOtHour;
    }

    public void setTotalOtHour(Double totalOtHour) {
        this.totalOtHour = totalOtHour;
    }

    public void setTotalOtHour(double totalOtHour) {
        this.totalOtHour = totalOtHour;
    }

    public void setTotalDotHour(double totalDotHour) {
        this.totalDotHour = totalDotHour;
    }

    public void setTotalRtHour(double totalRtHour) {
        this.totalRtHour = totalRtHour;
    }

    public String getEmployeeOraseq() {
        return employeeOraseq;
    }

    public void setEmployeeOraseq(String employeeOraseq) {
        this.employeeOraseq = employeeOraseq;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}