package com.shaurya.room.repository.remote;

public interface RepoService {
}
