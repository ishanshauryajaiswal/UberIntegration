package com.shaurya.room.repository.remote;

public class RetrofitInstance {
}
