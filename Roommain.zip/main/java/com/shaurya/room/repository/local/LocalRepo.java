package com.shaurya.room.repository.local;

public class LocalRepo {
}
