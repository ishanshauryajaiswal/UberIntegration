package com.shaurya.room.repository.local.db;

public class RepoDatabase  {
}
