package com.shaurya.room.repository.local.db.dao;

public interface RepoDao {
}
