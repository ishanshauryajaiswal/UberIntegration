package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 3/12/2018.
 */

public interface DeletePopupInterface
{
    public void deleteValues(int deletePosition);
    public void dismiss();

    //For Refreshing DashboardWebService
    public void refreshWebserviceCall(String compCode,String jobCode);

    //For PersonWebService
    public  void personWebServiceCall(String employeeOraseq);
}