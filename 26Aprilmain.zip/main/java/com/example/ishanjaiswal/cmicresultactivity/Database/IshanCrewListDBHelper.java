package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

public class IshanCrewListDBHelper
{
    private static String TAG = IshanCrewListDBHelper.class.getSimpleName();
    private static IshanDBConstants D = new IshanDBConstants();
    IshanDBHelper mInstance;
    public IshanCrewListDBHelper(Context context)
    {
        mInstance = IshanDBHelper.getInstance(context);
    }
    public void insertCrew(String crewCode,String crewName,String crewOraseq)
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try
        {
            ContentValues values = new ContentValues();
            values.put(D.CrewList_PycrCode, crewCode);
            values.put(D.CrewList_PycrName, crewName);
            values.put(D.CrewList_PycrOraseq, crewOraseq);
            int id = (int) db.insertWithOnConflict(D.TABLE_CREW_LIST, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1)
                db.update(D.TABLE_CREW_LIST,values, D.CrewList_PycrCode+"=?",new String [] {values.get(D.CrewList_PycrCode)+""});
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Inserting Crew: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Inserting Crew: "+e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public ArrayList<InsertCrew> selectAllCrewList()
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        ArrayList<InsertCrew> array_list = new ArrayList();
        try
        {
            Cursor cursor =  db.rawQuery("SELECT * FROM " + D.TABLE_CREW_LIST, null);
            if(cursor.moveToFirst()) {
                while (cursor.isAfterLast() == false) {
                    InsertCrew insertCrew = new InsertCrew();
                    insertCrew.setPycrName(cursor.getString(cursor.getColumnIndex(D.CrewList_PycrName)));
                    insertCrew.setPycrCode(cursor.getString(cursor.getColumnIndex(D.CrewList_PycrCode)));
                    insertCrew.setPycrOraseq(cursor.getString(cursor.getColumnIndex(D.CrewList_PycrOraseq)));
                    array_list.add(insertCrew);
                    cursor.moveToNext();
                }
            }
            return array_list;
        }
        catch(SQLiteException e)
        {
            Log.d(TAG, "Error in Fetching From CrewList Database: "+e.getMessage());
            return null;
        }
        finally {
            db.close();
        }
    }
    public boolean selectedCrewOraseq(String selectedOraseq)
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            Cursor cur = db.rawQuery("SELECT * FROM " + D.TABLE_CREW_LIST + " WHERE crewOraseq = '" + selectedOraseq + "'", null);
            boolean exist = (cur.getCount() > 0);
            cur.close();

            return exist;
        }
        catch (Exception e)
        {
            Log.d(TAG, "Error in Validating CrewOraSeq in CrewList Database: "+e.getMessage());
            return false;
        }
        finally {
            db.close();
        }
    }
}
