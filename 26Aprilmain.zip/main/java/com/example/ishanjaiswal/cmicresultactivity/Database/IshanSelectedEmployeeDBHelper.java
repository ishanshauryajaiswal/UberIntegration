package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 3/29/2018.
 */

public class IshanSelectedEmployeeDBHelper {
    private static final String TAG = IshanSelectedEmployeeDBHelper.class.getSimpleName();
    private static IshanDBConstants D = new IshanDBConstants();
    IshanDBHelper mInstance;
    public IshanSelectedEmployeeDBHelper(Context context)
    {
        mInstance = IshanDBHelper.getInstance(context);
    }

    public void insertSelectedEmployeeInDatabase(User user)
    {
        if (user!=null && user.getEmployeeNo()!=null     && user.getEmployeeNo().length()>0) {
            SQLiteDatabase db = mInstance.getWritableDatabase();
            try {
                ContentValues contentValues = new ContentValues();
                contentValues.put(D.Selected_EmpNumber, user.getEmployeeNo());
                contentValues.put(D.Selected_EmpOraseq, user.getEmployeeOraseq());
                contentValues.put(D.Selected_EmpName, user.getName());
                contentValues.put(D.Selected_AccessCode, user.getAccessCode());
                contentValues.put(D.Selected_CompName, user.getCompName());
                contentValues.put(D.Selected_PrnCode, user.getPrnCode());
                contentValues.put(D.Selected_PrnName, user.getPrnName());
                contentValues.put(D.Selected_CompCode, user.getCompCode());
                contentValues.put(D.Selected_TrdCode, user.getTradeCode());
                contentValues.put(D.Selected_TrdName, user.getTradeName());
                contentValues.put(D.Selected_UniCode, user.getUniCode());
                contentValues.put(D.Selected_UniName, user.getUniName());
                int id = (int) db.insertWithOnConflict(D.TABLE_SELECTED_EMPLOYEES, null, contentValues, SQLiteDatabase.CONFLICT_IGNORE);
                if (id == -1)
                    db.update(D.TABLE_SELECTED_EMPLOYEES, contentValues, D.Selected_EmpOraseq + "=?", new String[]{contentValues.get(D.Selected_EmpOraseq) + ""});
            }
            catch (SQLiteException e) {
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
            }
            catch (Exception e) {
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
            } finally {
                db.close();
            }
        }
    }

    public ArrayList<User> selectAllEmployeesFromDatabase()
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        ArrayList<User> array_list = new ArrayList();
        try
        {
            Cursor cursor =  db.rawQuery("SELECT * FROM " + D.TABLE_SELECTED_EMPLOYEES, null);
            cursor.moveToFirst();
            while(cursor.isAfterLast() == false){
                User user=new User();
                user.setEmployeeOraseq(cursor.getString(cursor.getColumnIndex(D.Selected_EmpOraseq)));
                user.setEmployeeNo(cursor.getString(cursor.getColumnIndex(D.Selected_EmpNumber)));
                user.setName(cursor.getString(cursor.getColumnIndex(D.Selected_EmpName)));
                user.setAccessCode(cursor.getString(cursor.getColumnIndex(D.Selected_AccessCode)));
                user.setCompName(cursor.getString(cursor.getColumnIndex(D.Selected_CompName)));
                user.setCompCode(cursor.getString(cursor.getColumnIndex(D.Selected_CompCode)));
                user.setPrnName(cursor.getString(cursor.getColumnIndex(D.Selected_PrnName)));
                user.setPrnCode(cursor.getString(cursor.getColumnIndex(D.Selected_PrnCode)));
                user.setTradeName(cursor.getString(cursor.getColumnIndex(D.Selected_TrdName)));
                user.setTradeCode(cursor.getString(cursor.getColumnIndex(D.Selected_TrdCode)));
                user.setUniName(cursor.getString(cursor.getColumnIndex(D.Selected_UniName)));
                user.setUniCode(cursor.getString(cursor.getColumnIndex(D.Selected_UniCode)));
                array_list.add(user);
                cursor.moveToNext();
            }
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Project: "+e.getMessage());
        }
        finally {
            db.close();
        }
        return array_list;
    }

    public void deleteEmployeeFromSelectedEmployeesTable(String employeeNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.delete(D.TABLE_SELECTED_EMPLOYEES, D.Selected_EmpNumber + "=" + employeeNumber, null);
        }
        catch (SQLiteException e) {
            Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        }
        catch (Exception e) {
            Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        } finally {
            db.close();
        }
    }
}
