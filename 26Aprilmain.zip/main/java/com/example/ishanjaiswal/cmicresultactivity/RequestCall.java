package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

public class RequestCall {
    private final String TAG = RequestCall.class.getSimpleName();
    public String requestAuthenticate(Context context, String authCode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.url_Login);
            Log.d(TAG,"Login URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Login(url, authCode);
            Log.d(TAG, "Login Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public String requestJobData(Context context)
    {
        String url;
        try
        {
            url = WebConstants.baseURL +"/" + WebConstants.jobDataEndPoint;
            Log.d(TAG,"Job Data URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Job Data Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d(TAG, "Job Data Error: "+ e.toString());
            return null;
        }
    }
    public String personData(Context context,String employeeOraseq ,String date)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.person_webservice) + "responsibleEmpOraseq=" + employeeOraseq + "&timesheetDate=" + date;
            Log.d("url person",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d("personWebserviceError", e.toString());
            return e.toString();
        }
    }

    public String personDashboardMembers(Context context,String crewCode,String date)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.dashboard_fetching_members_person) + "crewCode=" + crewCode + "&timesheetDate=" + date;
            Log.d("url person",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d("personWebserviceError", e.toString());
            return e.toString();
        }
    }

    public String getAllEmployees(Context context)
    {
        String url;
        try
        {

            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.employee_data);
            Log.d(TAG,"Get Employees URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Get Employees Response: "+url);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d("employee",e.toString());
            return null;


        }
    }
    public String insertCrew( Context context,String header,String parameters)
    {
        String url;
        try
        {
            url= context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.insert_crew);
            Log.d(TAG,"Inserting Crew URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.insertCrewNameCrewCode(url, header, parameters);
            return strResponse;

        }
        catch (Exception e)
        {
            return null;
        }

    }

    public String selectCrewOnCrewCodeBasis( Context context,String crewcode)
    {
        String url;
        try
        {

            url= context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.select_inserted_crew_on_crewcode)+"?crewCode="+crewcode;
            Log.d("url selected crew",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            return null;
        }

    }
    public String selectCrewList( Context context)
    {
        String url;
        try
        {
            url= context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.crew_list);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;

        }
        catch (Exception e)
        {
            Log.d("Error",e.toString());
            return null;
        }
    }

    public String insertCrewEmployee(Context context,String crewOraseqForNewCrewInserted, ArrayList<User> selectedEmployees)
    {
        String url;
        try
        {
            url= context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.insert_crew_employee);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.connectionPutEmployee(url, crewOraseqForNewCrewInserted,
                    selectedEmployees);
            return strResponse;

        }
        catch (Exception e)
        {
            Log.d("error in call",e.toString());
            return null;
        }

    }
    public String retrievingTimeSheet(Context context,String crewCode,String workDate, String jobCode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.retrieve_time_sheet)+"?crewCode="+crewCode+"&workDate="+workDate+"&jobCode="+jobCode;
            Log.d(TAG,"Retrieve TimeSheet URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve TimeSheet Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d("Exception Retrieving TS", e.getMessage());
            return null;
        }
    }
    public String fetchCrewEmployee(Context context, String crewcode ){
        String url;
        String result;
        try {
            url = context.getString(R.string.url) + "/" + context.getString(R.string.fetch_emp)+"crewCode="+crewcode;
            Log.d(TAG,"Fetch Crew Employee URL: "+url);
            ServerConnection serverConnection = new ServerConnection(context);
            String response = serverConnection.Connection(url);
            if (response!=null)
                Log.d(TAG,"Fetch Crew Employee Successful");
            else
                Log.d(TAG,"Fetch Crew Employee Unsuccessful");
            result = response;
        }
        catch (Exception ex){
            Log.e(TAG,"Fetch Crew Employee Error: "+ex.toString());
            return  null;
        }
        return result;
    }
    public String deleteCrewMember(Context context, String pyceOraSeq){
        String url;
        String result;
        try {
            url = context.getString(R.string.url) + "/" + context.getString(R.string.delete_crew_member_url)+"?pyceOraseq="+pyceOraSeq;
            Log.d("url get emp",url);
            ServerConnection serverConnection = new ServerConnection(context);
            String response = serverConnection.DeleteConnection(url);
            result = response;
        }
        catch (Exception ex){
            Log.e("exception SelectCrewEmp",ex.toString());
            return  null;
        }
        return result;
    }

    public String requestHourData(Context context, String header)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.job_data);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            return e.toString();
        }
    }
    public String phaseWithChild(Context context,String compcode,String jobcode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.Phase_with_child)+"etimeCompCode="+compcode+"&etimeJobCode="+jobcode+"&childViews=EtimeJcjobcatView";
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d("PhaseWithChild",url);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d("Error",e.toString());
            return e.toString();
        }
    }

    public String submitTask(Context context, String requestString)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.crew_sheet_updation);
            Log.d(TAG,"Submit Time Sheet URL: "+url);
            Log.d(TAG,"Submit Time Sheet Request: "+requestString);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.submitTimeSheet(url, requestString);
            Log.d(TAG,"Submit Time Sheet Response: "+strResponse);
            return strResponse;
        }
        catch (Exception e)
        {
            Log.d(TAG,"Submit Time Sheet Error: "+e.toString());
            return null;
        }
    }
    public String pciTask(Context context,String phaseCode,String categoryCode,String jobCode ,String compcode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.pci_webservice)+"compCode="+compcode+"&jobCode="+jobCode+"&phsCode="+phaseCode+"&catCode="+categoryCode;
            Log.d("pciUrl url",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            return strResponse;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public String updateResponsiblePerson(Context context, String crewCode, String requestJson){
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.update_responsible_person_webservice)+"crewCode="+crewCode;
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.putRequestConnection(url, requestJson);
            return strResponse;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e(TAG,"UpdateResponsiblePerson: Error - " + e.getMessage());
            return context.getString(R.string.internal_server_error);
        }
    }
    public String deleteAllTask(Context context ,String crewCode,String workDate,String jobCode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.delete_entire_timesheet)+"?crewCode="+crewCode+"&workDate=" +workDate+"&jobCode="+jobCode;
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.DeleteConnection(url);
            Log.d("deleteAllTask",strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("Deleteerror","Caught");
            return null;
        }

    }
    public String dashboardTask(Context context ,String compCode,String jobCode,String workDate)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.dashboard)+"?compCode="+compCode+"&jobCode=" +jobCode+"&timesheetDate="+workDate;
            Log.d(TAG,"Retrieve Dashboard URL: "+url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d(TAG,"Retrieve Dashboard Response: "+strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.e(TAG,"Retrieve Dashboard Exception: "+e.getMessage());
            return null;
        }

    }
    public String dashboardMembers(Context context ,String compCode,String jobCode,String workDate,String selectedcrewCode)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.dashboard_fetching_members)+"?compCode="+compCode+"&jobCode=" +jobCode+"&timesheetDate="+workDate+"&crewCode="+selectedcrewCode;
            Log.d("Dashboard members url",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d("Dashboard member",strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("DashboardMembers","Caught");
            return null;
        }

    }
    public String dashboardCrewMemberDetails(Context context ,String empNumber,String workDate)
    {
        String url;
        try
        {
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.dashboard_fetching_members_details)+"?empNo="+empNumber+"&timesheetDate="+workDate;
            Log.d("Dashboard detail url",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.Connection(url);
            Log.d("Dashboard",strResponse);
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("DashboardMemberDetails","Caught");
            return null;
        }

    }

    public String uploadSignatureEmployee(Context context ,String empOraseq , String fromDate , String toDate,String fileName,Bitmap bitmap)
    {

        String url;
        try
        {
            Log.d("filename",fileName);
            Log.d("BidMapLog", String.valueOf(bitmap));
            url = context.getResources().getString(R.string.url)+"/"+context.getResources().getString(R.string.upload_signature_employee)+"empOraseq="+empOraseq+"&tshFromDate="+fromDate+"&tshToDate="+toDate;
            Log.d("uploadEmployee url",url);
            ServerConnection createServerConnection = new ServerConnection(context);
            String strResponse = createServerConnection.ConnectionUploadSignature(url,fileName,bitmap );
            return strResponse;
        }

        catch(Exception e)
        {
            Log.d("DashboardMemberDetails",e.toString());
            return null;
        }

    }

    }

