package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/10/2018.
 */

public class UpdateResponsiblePersonTask extends AsyncTask<Void,Void,String> {
    private UpdateResponsiblePersonTaskInterface mListener;
    private Context mContext;
    private String mCrewCode, mRequestJson;

    public UpdateResponsiblePersonTask(Context mContext, String mCrewCode, String mRequestJson, UpdateResponsiblePersonTaskInterface mListener) {
        this.mListener = mListener;
        this.mContext = mContext;
        this.mCrewCode = mCrewCode;
        this.mRequestJson = mRequestJson;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mListener.onTaskStartedListener();
    }
    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        RequestCall requestCall = new RequestCall();
        response = requestCall.updateResponsiblePerson(mContext, mCrewCode, mRequestJson);
        return response;
    }
    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        mListener.onTaskFinishedListener(result);
    }


    public interface UpdateResponsiblePersonTaskInterface{
        void onTaskStartedListener();
        void onTaskFinishedListener(String result);
    }
}
