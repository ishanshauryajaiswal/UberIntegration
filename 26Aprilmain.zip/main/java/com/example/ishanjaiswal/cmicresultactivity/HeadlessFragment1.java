package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.Dashboard2Task;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DashboardPersonTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DashboardTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.JobDataTask2;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class HeadlessFragment1 extends Fragment {
    private DashboardTaskListener mDashboardTaskListener;
    private CrewMemberDataListener mCrewMemberDataListener;
    private JobDataListener mJobdDataTaskListener;
    private DashboardTask mJobBackgroundTask;
    private DashboardPersonTask mPersonBackgroundTask;
    private Dashboard2Task mDashboard2Task;
    public boolean isTaskExecuting = false;
    private List<User> crewMemberList;
    private List<JobData> jobDataList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }


    public void getDashboardData(Context context, String jobCompCode, String jobCode, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mJobBackgroundTask = new DashboardTask(context, jobCompCode, jobCode, date, mListener);
            mJobBackgroundTask.execute();
            isTaskExecuting = true;
        }
    }

    public void getDashboardData(Context context, String empOraSeq, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mPersonBackgroundTask = new DashboardPersonTask(context, empOraSeq, date, mListener);
            mPersonBackgroundTask.execute();
            isTaskExecuting = true;
        }
    }

    public void getDashboard2Data(Context context, String crewCode, String date,DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboard2Task = new Dashboard2Task(context, crewCode, date, mListener, false);
            mDashboard2Task.execute();
            isTaskExecuting = true;
        }
    }

    public void getDashboard2Data(Context context, String jobCompCode, String jobCode, String crewCode, String date, DashboardTaskListener mListener) {
        if (this.mDashboardTaskListener == null)
            this.mDashboardTaskListener = mListener;
        if (!isTaskExecuting) {
            mDashboard2Task = new Dashboard2Task(context, jobCompCode, jobCode, crewCode, date, mListener, true);
            mDashboard2Task.execute();
            isTaskExecuting = true;
        }
    }

    public void cancelJobBackgroundTask() {
        if (isTaskExecuting) {
            mJobBackgroundTask.cancel(true);
            isTaskExecuting = false;
        }
    }

    public void cancelPersonBackgroundTask() {
        if (isTaskExecuting) {
            mPersonBackgroundTask.cancel(true);
            isTaskExecuting = false;
        }
    }

    public void updateExecutingStatus(boolean isExecuting) {
        this.isTaskExecuting = isExecuting;
    }

    public void getCrewMemberData(CrewMemberDataListener crewMemberDataListener ) {
        if (this.mCrewMemberDataListener == null)
            this.mCrewMemberDataListener = crewMemberDataListener;
        if (!isTaskExecuting)
            new GetEmployees(getActivity(),mCrewMemberDataListener).execute();
    }

    public List<User> getCrewMemberList() {
        return crewMemberList;
    }

    public void setCrewMemberList(List<User> crewMemberList) {
        this.crewMemberList = crewMemberList;
    }

    public List<JobData> getJobDataList() {
        return jobDataList;
    }

    public void setJobDataList(List<JobData> jobDataList) {
        this.jobDataList = jobDataList;
    }

    public void getJobData(JobDataListener jobDataListener) {
        if (this.mJobdDataTaskListener == null)
            this.mJobdDataTaskListener = jobDataListener;
        if (!isTaskExecuting)
            new JobDataTask2(getContext(), mJobdDataTaskListener).execute();
    }

}
