package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface FragmentClickListener {
    public void retrieveDashboardData(String date);
    public void retrieveCrewMemberData();
    public void retrieveJobData();
    public void onCrewMemberSelected(String crewCode, String date);
    public void retrieveDashboard2Data();
    void onBackPressed();
    void setFlag(boolean flagJobSelected);
    void setJob(String jobcCompCode, String jobCode);
    void setEmpOraseq(String employeeOraseq);
}
