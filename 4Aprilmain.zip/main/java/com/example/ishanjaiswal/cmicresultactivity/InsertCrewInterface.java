package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public interface InsertCrewInterface {
    public void getCrews(String result);
    public void BeforeCompletion();
}
