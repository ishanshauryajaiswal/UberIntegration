package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;

//import com.cmic.multiselectionmodal.Modal.LoginModal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class LoginParser {
    String[] names;
    String tableName;
    Context context;
    int numberOfRemainingRecords;
    ArrayList<LoginModal> loginModals = new ArrayList();

    public ArrayList<LoginModal> parseLoginData(final String response) {
        try {
            if (response != null) {
                Log.d("ResponseLoginData", response);
                JSONObject jsonObject = new JSONObject(response);
                tableName = jsonObject.getString("table");
                numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
                JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
                JSONArray Rows = jsonObject.getJSONArray("rows");

                JSONArray attributes = RowDefinition.getJSONArray("attrNames");
                names = new String[Rows.length()];
                Set<String> requiredAttributes = new HashSet<>();
                requiredAttributes.add("Type");
                requiredAttributes.add("Description");
                requiredAttributes.add("HrtFirstName");
                requiredAttributes.add("HrtLastName");
                requiredAttributes.add("HrtEmpNo");
                requiredAttributes.add("HrtTrdCode");
                requiredAttributes.add("HrtTrdName");


                HashMap<String, Integer> attributeIndex = new HashMap<>();

                for (int i = 0; i < attributes.length(); i++) {
                    String strAttribute = attributes.getString(i);

                    if (requiredAttributes.contains(strAttribute)) {
                        attributeIndex.put(strAttribute, i);
                    }
                }

                ArrayList<JSONArray> attributeValues = new ArrayList<>();


                for (int j = 0; j < Rows.length(); j++) {
                    JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                }

                for (int k = 0; k < attributeValues.size(); k++) {
                    LoginModal loginModal = new LoginModal();
                    loginModal.setType(attributeValues.get(k).getString(attributeIndex.get("Type")));
                    loginModal.setDescription(attributeValues.get(k).getString(attributeIndex.get("Description")));
                    loginModal.setHrtFirstName(attributeValues.get(k).getString(attributeIndex.get("HrtFirstName")));
                    loginModal.setHrtLastName(attributeValues.get(k).getString(attributeIndex.get("HrtLastName")));
                    loginModal.setHrtEmpNo(attributeValues.get(k).getString(attributeIndex.get("HrtEmpNo")));
                    loginModal.setHrtTrdCode(attributeValues.get(k).getString(attributeIndex.get("HrtTrdCode")));
                    loginModal.setHrtTrdName(attributeValues.get(k).getString(attributeIndex.get("HrtTrdName")));
                    loginModals.add(loginModal);

                }
            } else {
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("error in fetching Projects");
                alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertBox.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loginModals;
    }

}