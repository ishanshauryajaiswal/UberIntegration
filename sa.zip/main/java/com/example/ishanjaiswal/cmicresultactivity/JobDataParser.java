package com.example.ishanjaiswal.cmicresultactivity;



import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class JobDataParser {
    String[] names;
    String tableName;
    Context context;
    int numberOfRemainingRecords;
    ArrayList<JobData> job = new ArrayList();

    public ArrayList<JobData> parseJobData(final String response) {
        try {
            if (response != null) {
                Log.d("ResponseJobData", response);
                JSONObject jsonObject = new JSONObject(response);
                tableName = jsonObject.getString("table");
                numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
                JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
                JSONArray Rows = jsonObject.getJSONArray("rows");

                JSONArray attributes = RowDefinition.getJSONArray("attrNames");
                names = new String[Rows.length()];
                Set<String> requiredAttributes = new HashSet<>();
                requiredAttributes.add("JobCompCode");
                requiredAttributes.add("CompName");
                requiredAttributes.add("JobCode");
                requiredAttributes.add("JobName");

                HashMap<String, Integer> attributeIndex = new HashMap<>();

                for (int i = 0; i < attributes.length(); i++) {
                    String strAttribute = attributes.getString(i);

                    if (requiredAttributes.contains(strAttribute)) {
                        attributeIndex.put(strAttribute, i);
                    }
                }

                ArrayList<JSONArray> attributeValues = new ArrayList<>();


                for (int j = 0; j < Rows.length(); j++) {
                    JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                }

                for (int k = 0; k < attributeValues.size(); k++) {
                    JobData jobData = new JobData();
                    jobData.setJobcompcode(attributeValues.get(k).getString(attributeIndex.get("JobCompCode")));
                    jobData.setCompname(attributeValues.get(k).getString(attributeIndex.get("CompName")));
                    jobData.setJobcode(attributeValues.get(k).getString(attributeIndex.get("JobCode")));
                    jobData.setJobname(attributeValues.get(k).getString(attributeIndex.get("JobName")));
                    job.add(jobData);
                    names[k] = attributeValues.get(k).getString(attributeIndex.get("JobName"));

                }
            } else {
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(context);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("error in fetching Projects");
                alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertBox.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return job;
    }

}