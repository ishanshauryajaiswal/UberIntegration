package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */
public interface SelectEmpInterface
{
    public void preTask();
    public void postTask(String data);
}
