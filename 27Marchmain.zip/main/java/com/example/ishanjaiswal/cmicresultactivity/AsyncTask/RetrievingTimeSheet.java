package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;
import com.example.ishanjaiswal.cmicresultactivity.RetrieveTimeSheetInterface;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/15/2018.
 */

public class RetrievingTimeSheet extends AsyncTask<Void,Void,String>
{
    //    private String authCode;
    private Context context;
    private String crewCode;
    private String jobCode;
    private ProgressDialog progressDialog;
    private ArrayList<CrewTimeSheet> result;
    private RetrieveTimeSheetInterface RetrieveTimeSheetInterface;
    private String workDate;
    public RetrievingTimeSheet(Context context,String crewCode,String workDate,String jobCode,RetrieveTimeSheetInterface RetrieveTimeSheetInterface)
    {
        //   this.authCode = authCode;
        this.context = context;
        this.crewCode = crewCode;
        this.jobCode = jobCode;
        this.workDate = workDate;
        this.RetrieveTimeSheetInterface = RetrieveTimeSheetInterface;
    }
    @Override
    protected void onPreExecute()
    {
        RetrieveTimeSheetInterface.BeforeCompletion();
        // progressDialog = ProgressDialog.show(context, "Cmic Mobile Crew Time", ".....Fetching Crew");
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response="";
        try
        {
            RequestCall requestCall = new RequestCall();
            response = requestCall.retrievingTimeSheet(context, crewCode, workDate, jobCode);
        }
        catch(Exception e)
        {
            Log.d("error in retrieving",e.toString());
        }
        return response;
    }
    protected void onPostExecute(String response)
    {
        // Log.d("parneet", response);
        RetrieveTimeSheetInterface.RetrieveTimeSheetInterface(response);
    }

}
