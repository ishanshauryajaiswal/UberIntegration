package com.example.ishanjaiswal.cmicresultactivity.Model;

import android.util.Log;

import java.io.Serializable;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */

public class TimeInOutModal implements Serializable
{
    String  timeIn1,
            timeIn2,
            timeIn3,
            timeIn4,
            timeIn5,
            timeOut1,
            timeOut2,
            timeOut3,
            timeOut4,
            timeOut5,
            total1,
            total2,
            total3,
            total4,
            total5,
            breakTime1,
            breakTime2,
            breakTime3,
            breakTime4;

    String timeIn,
            timeOut;
    double Total;

    String columnTotal;
    public TimeInOutModal(String timeIn1, String timeIn2 , String timeIn3 ,String timeIn4,String timeIn5, String timeOut1,String timeOut2,String timeOut3,String timeOut4,String timeOut5,String breakTime1,String breakTime2,String breakTime3,String breakTime4)
    {
        this.timeIn1 = timeIn1;
        this.timeIn2 = timeIn2;
        this.timeIn3 = timeIn3;
        this.timeIn4 = timeIn4;
        this.timeIn5 = timeIn5;
        this.timeOut1 = timeOut1;
        this.timeOut2 = timeOut2;
        this.timeOut3 = timeOut3;
        this.timeOut4 = timeOut4;
        this.timeOut5 = timeOut5;
        this.breakTime1 = breakTime1;
        this.breakTime2 = breakTime2;
        this.breakTime3 = breakTime3;
        this.breakTime4 = breakTime4;
        // calculating Totals
        this.total1 = getTotalFrom(timeIn1,timeOut1);
        this.total2 = getTotalFrom(timeIn2, timeOut2);
        this.total3 = getTotalFrom(timeIn3, timeOut3);
        this.total4 = getTotalFrom(timeIn4, timeOut4);
        this.total5 = getTotalFrom(timeIn5, timeOut5);
        this.columnTotal = getColumnTotalValue();

    }
    public TimeInOutModal(){

    }


    private String getTotalFrom(String timeIn, String timeOut) {
        String total = "0";
        //change it with time diffrence method
        if (!timeIn.equals("") && !timeOut.equals(""))
        {
            String timeInMinutes[] = timeIn.split(":");
            String timeOutMinutes[] = timeOut.split(":");
            float timeInMinute = Float.valueOf(timeInMinutes[0])*60;
            float timeOutMinute = Float.valueOf(timeOutMinutes[0])*60;
            float totalTimeInMinute = timeInMinute + Float.valueOf(timeInMinutes[1]);
            float totalTimeOutMinute = timeOutMinute + Float.valueOf(timeOutMinutes[1]);
            float differenceInMinutes = totalTimeOutMinute - totalTimeInMinute ;
            int hours = (int)(differenceInMinutes/60);
            int minutes = (int)(differenceInMinutes%60);
            total = String.valueOf((int)differenceInMinutes);
            Log.d("Total",total);
        }
        return total;
    }

    public String getColumnTotalValue()
    {
        //change it with time sum method

        if(total1.equals(""))
        {
            total1 = "0";
        }
        if( total2.equals(""))
        {
            total2 = "0";
        }
        if(total3.equals(""))
        {
            total3 = "0";
        }
        if( total4.equals(""))
        {
            total4 = "0";
        }
        if(total5.equals(""))
        {
            total5 = "0";
        }
        String totalVal = String.valueOf(Integer.valueOf(total1) + Integer.valueOf(total2) + Integer.valueOf(total3) + Integer.valueOf(total4) + Integer.valueOf(total5));

        return totalVal;
    }

    public String getColumnTotal() {
        return columnTotal;
    }

    public String getBreakTime1() {
        return breakTime1;
    }

    public String getBreakTime2() {
        return breakTime2;
    }

    public String getBreakTime3() {
        return breakTime3;
    }

    public String getBreakTime4() {
        return breakTime4;
    }

    public void setBreakTime1(String breakTime1) {
        this.breakTime1 = breakTime1;
    }

    public void setBreakTime2(String breakTime2) {
        this.breakTime2 = breakTime2;
    }

    public void setBreakTime3(String breakTime3) {
        this.breakTime3 = breakTime3;
    }

    public void setBreakTime4(String breakTime4) {
        this.breakTime4 = breakTime4;
    }


    public double getTotal() {
        return Total;
    }

    public void setTotal(double total) {
        Total = total;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }


    public String getTimeIn1() {
        return timeIn1;
    }

    public String getTimeIn2() {
        return timeIn2;
    }

    public String getTimeIn3() {
        return timeIn3;
    }

    public String getTimeIn4() {
        return timeIn4;
    }

    public String getTimeIn5() {
        return timeIn5;
    }

    public String getTimeOut1() {
        return timeOut1;
    }

    public String getTimeOut2() {
        return timeOut2;
    }

    public String getTimeOut3() {
        return timeOut3;
    }

    public String getTimeOut4() {
        return timeOut4;
    }

    public String getTimeOut5() {
        return timeOut5;
    }

    public String getTotal1() {
        return total1;
    }

    public String getTotal2() {
        return total2;
    }

    public String getTotal3() {
        return total3;
    }

    public String getTotal4() {
        return total4;
    }

    public String getTotal5() {
        return total5;
    }

    public void setTimeOut1(String timeOut1) {
        this.timeOut1 = timeOut1;
    }

    public void setTimeIn1(String timeIn1) {
        this.timeIn1 = timeIn1;
    }

    public void setTimeIn2(String timeIn2) {
        this.timeIn2 = timeIn2;
    }

    public void setTimeIn3(String timeIn3) {
        this.timeIn3 = timeIn3;
    }

    public void setTimeIn4(String timeIn4) {
        this.timeIn4 = timeIn4;
    }

    public void setTimeIn5(String timeIn5) {
        this.timeIn5 = timeIn5;
    }

    public void setTimeOut2(String timeOut2) {
        this.timeOut2 = timeOut2;
    }

    public void setTimeOut3(String timeOut3) {
        this.timeOut3 = timeOut3;
    }

    public void setTimeOut4(String timeOut4) {
        this.timeOut4 = timeOut4;
    }

    public void setTimeOut5(String timeOut5) {
        this.timeOut5 = timeOut5;
    }

    public void setTotal1(String total1) {
        this.total1 = total1;
    }

    public void setTotal2(String total2) {
        this.total2 = total2;
    }

    public void setTotal3(String total3) {
        this.total3 = total3;
    }

    public void setTotal4(String total4) {
        this.total4 = total4;
    }

    public void setTotal5(String total5) {
        this.total5 = total5;
    }
}
