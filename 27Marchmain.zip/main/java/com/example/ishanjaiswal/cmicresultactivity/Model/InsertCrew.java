package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/5/2018.
 */

public class InsertCrew
{
    public String PycrCode;
    public String PycrName;
    public String PycrOraseq;
    public String PycrResponsibleEmpOraseq;
    public  String PycrResponsibleEmpNo;
    public  String PycrResponsibleEmpName;
    public String getPycrCode() {
        return PycrCode;
    }

    public String getPycrName()
    {
        return PycrName;
    }

    public String getPycrOraseq() {
        return PycrOraseq;
    }

    public void PycrCode(String PycrCode)
    {
        this.PycrCode = PycrCode;
    }


    public void PycrName(String PycrName)
    {
        this.PycrName = PycrName;
    }

    public void PycrOraseq(String PycrOraseq)
    {
        this.PycrOraseq = PycrOraseq;
    }

    public void setPycrCode(String pycrCode)
    {
        PycrCode = pycrCode;
    }

    public void setPycrName(String pycrName)
    {
        PycrName = pycrName;
    }

    public void setPycrOraseq(String pycrOraseq) {
        PycrOraseq = pycrOraseq;
    }

    public String getPycrResponsibleEmpName() {
        return PycrResponsibleEmpName;
    }

    public String getPycrResponsibleEmpNo() {
        return PycrResponsibleEmpNo;
    }

    public String getPycrResponsibleEmpOraseq() {
        return PycrResponsibleEmpOraseq;
    }

    public void setPycrResponsibleEmpName(String pycrResponsibleEmpName) {
        PycrResponsibleEmpName = pycrResponsibleEmpName;
    }

    public void setPycrResponsibleEmpNo(String pycrResponsibleEmpNo) {
        PycrResponsibleEmpNo = pycrResponsibleEmpNo;
    }

    public void setPycrResponsibleEmpOraseq(String pycrResponsibleEmpOraseq) {
        PycrResponsibleEmpOraseq = pycrResponsibleEmpOraseq;
    }
    public void PycrResponsibleEmpOraseq(String PycrResponsibleEmpOraseq)
    {
        this.PycrResponsibleEmpOraseq = PycrResponsibleEmpOraseq;
    }
    public void PycrResponsibleEmpNo(String PycrResponsibleEmpNo)
    {
        this.PycrResponsibleEmpNo = PycrResponsibleEmpNo;
    }
    public void PycrResponsibleEmpName(String PycrResponsibleEmpName)
    {
        this.PycrResponsibleEmpName = PycrResponsibleEmpName;
    }
}
