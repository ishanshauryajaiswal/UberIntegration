package com.example.ishanjaiswal.cmicresultactivity;

import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOutModal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/15/2018.
 */

public class RetrieveTimeSheetParser {

    // SingletonData singletonData = SingletonData.getInstance();
    // main keys
    private String KEY_CREW_CODE = "CrewCode";
    private String KEY_CREW_ACTIVITY = "CrewActivity";
    private String KEY_SEQ_NO = "SeqNo";
    private String KEY_WORK_DATE = "WorkDate";
    private String KEY_JOB_CODE = "JobCode";
    private String KEY_EMP_TIMESHEET = "EmpTimesheet";
    private String KEY_JOB_COMPANY_CODE = "JobCompCode";

    //Crew Activity Keys
    private String KEY_CREW_ACTIVITY_DELETE_FLAG = "DeleteFlag";
    private String KEY_CREW_ACTIVITY_SEQ_NO = "SeqNo";
    private String KEY_CREW_ACTIVITY_COLOUMN_NO = "ColumnNo";
    private String KEY_CREW_ACTIVITY_ACTIVITYNAME = "ActivityName";
    private String KEY_CREW_ACTIVITY_PHASECODE = "PhaseCode";
    private String KEY_CREW_ACTIVITY_CATEGORYCODE = "CatCode";
    private String KEY_CREW_ACTIVITY_WBS_CODE = "WbsCode";
    private String KEY_CREW_ACTIVITY_PCIORASEQ = "PciLineOraseq";
    private String KEY_CREW_ACTIVITY_JOB_CODE = "JobCode";

    //Employee TimeSheet Keys
    private String KEY_EMPLOYEE_DELETE_FLAG = "DeleteFlag";
    private String KEY_EMPLOYEE_EMP_NO = "EmpNo";
    private String KEY_EMPLOYEE_EMP_NAME = "EmpName";
    private String KEY_EMPLOYEE_TRD_CODE = "TrdCode";
    private String KEY_EMPLOYEE_TRD_NAME = "TrdName";
    private String KEY_EMPLOYEE_ROW_NUM = "RowNum";
    private String KEY_EMPLOYEE_TIME_SHEET = "Timesheet";
    private String KEY_EMPLOYEE_EMP_ORASEQ = "EmpOraseq";
    private String KEY_EMPLOYEE_PERIOD_FLAG = "PeriodClosedFlag";

    //TimeSheet Keys
    private String KEY_TIMESHEET_STANDARD_SEQ_NO = "rtSeqNo";
    private String KEY_TIMESHEET_STANDARD_HOUR = "rtHour";
    private String KEY_TIMESHEET_OVERTIME_SEQ_NO = "otSeqNo";
    private String KEY_TIMESHEET_OVERTIME_HOUR = "otHour";
    private String KEY_TIMESHEET_DOUBLE_OVERTIME_SEQ_NO = "dotSeqNo";
    private String KEY_TIMESHEET_DOUBLE_OVERTIME_HOUR = "dotHour";
    private String KEY_TIMESHEET_IN_OUT_TIME = "InOutTime";
    private String KEY_TIMESHEET_TIME_IN = "timeIn";
    private String KEY_TIMESHEET_TIME_OUT = "timeOut";


    private int timeSheetSize;


    public CrewTimeSheet parseCrewTimesheetData(String response)
    {

        CrewTimeSheet crewTimeSheet = null;
        //DBHelper dbHelper = new DBHelper();
        try {
            LoginAccess loginAccess = LoginAccess.getInstance();
            String colNo = null;
            String deleteFlag = null;
            String crewActivitySeqNo = null;
            String activityName = null;
            String phaseCode = null;
            String catCode = null;
            String wbsCode = null;
            String pciLineOraseq = null;
            String activityJobCode;

            Log.d("response in parser", response);
            ArrayList<SubmittedActivityFromCrewModal> crewActivityList = new ArrayList<SubmittedActivityFromCrewModal>();
            ArrayList<EmployeeDataForCrew> empTimesheetList = new ArrayList<EmployeeDataForCrew>();

            String seqNo,crewCode,workDate,jobCode,jobCompanyCode;
            JSONObject jsonObject = new JSONObject(response);
            if(jsonObject.getString(KEY_SEQ_NO) == null || jsonObject.getString(KEY_SEQ_NO).equals("") || jsonObject.getString(KEY_SEQ_NO).equals("null"))
            {
                seqNo = "";
            }
            else
            {
                seqNo = jsonObject.getString(KEY_SEQ_NO);
            }

            if(jsonObject.getString(KEY_CREW_CODE) == null || jsonObject.getString(KEY_CREW_CODE).equals("") ||jsonObject.getString(KEY_CREW_CODE).equals("null"))
            {
                crewCode = "";
            }
            else
            {
                crewCode = jsonObject.getString(KEY_CREW_CODE);
            }


            if(jsonObject.getString(KEY_WORK_DATE) == null || jsonObject.getString(KEY_WORK_DATE).equals("") || jsonObject.getString(KEY_WORK_DATE).equals("null"))
            {
                workDate = "";
            }
            else
            {
                workDate = jsonObject.getString(KEY_WORK_DATE);
            }

            if(jsonObject.getString(KEY_JOB_CODE) == null || jsonObject.getString(KEY_JOB_CODE).equals("") || jsonObject.getString(KEY_JOB_CODE).equals("null"))
            {
                jobCode = "";
            }
            else
            {
                jobCode = jsonObject.getString(KEY_JOB_CODE);
            }

            if(jsonObject.getString(KEY_JOB_COMPANY_CODE) == null || jsonObject.getString(KEY_JOB_COMPANY_CODE).equals("") || jsonObject.getString(KEY_JOB_COMPANY_CODE).equals("null") )
            {
                jobCompanyCode = "";
            }
            else
            {
                jobCompanyCode = jsonObject.getString(KEY_JOB_COMPANY_CODE);
            }

            JSONArray crewActivityJsonArray = jsonObject.getJSONArray(KEY_CREW_ACTIVITY);
            timeSheetSize = crewActivityJsonArray.length();
            // getTimesheetSize
            SingletonData singletonData = SingletonData.getInstance();
            singletonData.crewActivitySizeFromServer = crewActivityJsonArray.length();
            if (seqNo != null && !seqNo.equals("null") && !seqNo.equals(""))
            {
                loginAccess.MainSeqNo = seqNo;
                if (timeSheetSize != 0)
                {
                    for (int i = 0; i < crewActivityJsonArray.length(); i++) {
                        JSONObject crewActivityJsonObject = crewActivityJsonArray.getJSONObject(i);

                        deleteFlag = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_DELETE_FLAG);
                        crewActivitySeqNo = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_SEQ_NO);
                        colNo = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_COLOUMN_NO);
                        activityName = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_ACTIVITYNAME);
                        phaseCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_PHASECODE);
                        catCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_CATEGORYCODE);
                        wbsCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_WBS_CODE);
                        pciLineOraseq = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_PCIORASEQ);
                        activityJobCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_JOB_CODE);

                        SubmittedActivityFromCrewModal submittedActivityFromCrewModal = new SubmittedActivityFromCrewModal(deleteFlag, crewActivitySeqNo, colNo, activityName, activityJobCode, phaseCode, wbsCode, pciLineOraseq, catCode);
                        crewActivityList.add(submittedActivityFromCrewModal);
                    }
                }

            }
            else
            {
                if (timeSheetSize != 0)
                {
                    for (int i = 0; i < crewActivityJsonArray.length(); i++)
                    {
                        JSONObject crewActivityJsonObject = crewActivityJsonArray.getJSONObject(i);

                        deleteFlag = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_DELETE_FLAG);
                        crewActivitySeqNo = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_SEQ_NO);
                        colNo = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_COLOUMN_NO);
                        activityName = "Activity " + i;
                        phaseCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_PHASECODE);
                        catCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_CATEGORYCODE);
                        wbsCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_WBS_CODE);
                        pciLineOraseq = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_PCIORASEQ);
                        activityJobCode = crewActivityJsonObject.getString(KEY_CREW_ACTIVITY_JOB_CODE);

                        SubmittedActivityFromCrewModal submittedActivityFromCrewModal = new SubmittedActivityFromCrewModal(deleteFlag, crewActivitySeqNo, colNo, activityName, activityJobCode, phaseCode, wbsCode, pciLineOraseq, catCode);
                        crewActivityList.add(submittedActivityFromCrewModal);
                    }
                }
                else
                {

                    for (int j = 0; j < 6; j++)
                    {
                        activityName = "Activity " + (j + 1);
                        SubmittedActivityFromCrewModal submittedActivityFromCrewModal = new SubmittedActivityFromCrewModal(" ", String.valueOf(j+1), "", "", activityName, "", "", "", crewCode, workDate);
                        crewActivityList.add(submittedActivityFromCrewModal);
                    }
                }
            }


            JSONArray employeeTimesheetJsonArray = jsonObject.getJSONArray(KEY_EMP_TIMESHEET);
            timeSheetSize = employeeTimesheetJsonArray.length();

            if (timeSheetSize != 0)
            {
                JSONObject employeeTimesheetJsonObjectForCalculatingSize = employeeTimesheetJsonArray.getJSONObject(0);
                JSONArray timesheetJsonArrayForCalculatingSize = employeeTimesheetJsonObjectForCalculatingSize.getJSONArray(KEY_EMPLOYEE_TIME_SHEET);
                double[] rtHourActivityTotal = new double[timesheetJsonArrayForCalculatingSize.length()];
                double[] otHourActivityTotal = new double[timesheetJsonArrayForCalculatingSize.length()];
                double[] dotHourActivityTotal = new double[timesheetJsonArrayForCalculatingSize.length()];
                //
                for (int i = 0; i < employeeTimesheetJsonArray.length(); i++) {
                    JSONObject employeeTimesheetJsonObject = employeeTimesheetJsonArray.getJSONObject(i);

                    deleteFlag = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_DELETE_FLAG);
                    String empNo = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_EMP_NO);
                    String empOraSeq = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_EMP_ORASEQ);
                    String empName = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_EMP_NAME);
                    String trdCode = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_TRD_CODE);
                    String trdName = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_TRD_NAME);
                    String rowNum = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_ROW_NUM);
                    String periodClosedFlag = employeeTimesheetJsonObject.getString(KEY_EMPLOYEE_PERIOD_FLAG);

                    JSONArray timesheetJsonArray = employeeTimesheetJsonObject.getJSONArray(KEY_EMPLOYEE_TIME_SHEET);
                    ArrayList<ActivityTimeForCrew> activityTimeForCrewArrayList = new ArrayList<ActivityTimeForCrew>();

                    if (timesheetJsonArray != null && timesheetJsonArray.length() > 0)
                    {
                        for (int j = 0; j < timesheetJsonArray.length(); j++) {

                            JSONObject timesheetJsonObject = timesheetJsonArray.getJSONObject(j);

                            String rtSeqNo = timesheetJsonObject.getString(KEY_TIMESHEET_STANDARD_SEQ_NO);
                            String rtHour = timesheetJsonObject.getString(KEY_TIMESHEET_STANDARD_HOUR);
                            String otSeqNo = timesheetJsonObject.getString(KEY_TIMESHEET_OVERTIME_SEQ_NO);
                            String otHour = timesheetJsonObject.getString(KEY_TIMESHEET_OVERTIME_HOUR);
                            String dotSeqNo = timesheetJsonObject.getString(KEY_TIMESHEET_DOUBLE_OVERTIME_SEQ_NO);
                            String dotHour = timesheetJsonObject.getString(KEY_TIMESHEET_DOUBLE_OVERTIME_HOUR);
                            Double OtHour, RtHour, DotHour;
                            try {
                                OtHour = Double.parseDouble(otHour);
                            } catch (Exception e) {
                                OtHour = 0.0;
                            }

                            try {
                                RtHour = Double.parseDouble(rtHour);
                            } catch (Exception e) {
                                RtHour = 0.0;
                            }

                            try {
                                DotHour = Double.parseDouble(dotHour);
                            } catch (Exception e) {
                                DotHour = 0.0;
                            }

                            ActivityTimeForCrew activityTimeForCrew = new ActivityTimeForCrew(otSeqNo, OtHour, rtSeqNo, RtHour, dotSeqNo, DotHour, crewCode, workDate, empNo);
                            activityTimeForCrew.setStandardTime(RtHour);
                            activityTimeForCrew.setOverTime(OtHour);
                            activityTimeForCrew.setDoubleOverTime(DotHour);
                            activityTimeForCrew.setStandardTimeSeqNumber(rtSeqNo);
                            activityTimeForCrew.setOverTimeSeqNumber(otSeqNo);
                            activityTimeForCrew.setDoubleOverTimeSeqNumber(dotSeqNo);
                            activityTimeForCrewArrayList.add(activityTimeForCrew);
                        }
                    }
                    else
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            ActivityTimeForCrew ActivityTimeForCrew = new ActivityTimeForCrew("null", 0.0, "null", 0.0, "null", 0.0, crewCode, workDate, empNo);
                            activityTimeForCrewArrayList.add(ActivityTimeForCrew);
                        }
                        singletonData.EmployeeCrewActivitySize = 6;
                    }
                    EmployeeDataForCrew employeeDataForCrew = new EmployeeDataForCrew(deleteFlag, empNo,  empOraSeq, empName, trdCode, trdName, rowNum, periodClosedFlag, activityTimeForCrewArrayList,null);
                    empTimesheetList.add(employeeDataForCrew);


                    JSONArray timeInOutArray = employeeTimesheetJsonObject.getJSONArray(KEY_TIMESHEET_IN_OUT_TIME);
                    if (timeInOutArray != null && timeInOutArray.length() > 0) {
                        TimeInOutModal timeInOutModal = null;
                        for (int k = 0; k < timeInOutArray.length(); k++) {
                            JSONObject timeInOutObject = timeInOutArray.getJSONObject(k);
                            String timeIn = timeInOutObject.getString(KEY_TIMESHEET_TIME_IN);
                            timeIn = timeIn.substring(0, 2) + ":" + timeIn.substring(2, 4);
                            String timeOut = timeInOutObject.getString(KEY_TIMESHEET_TIME_OUT);
                            timeOut = timeOut.substring(0, 2) + ":" + timeOut.substring(2, 4);
                            switch (k) {
                                case 0:
                                    timeInOutModal = new TimeInOutModal(timeIn, "", "", "", "", timeOut, "", "", "", "","","","","");
                                    break;
                                case 1:
                                    timeInOutModal = new TimeInOutModal("", timeIn, "", "", "", "", timeOut, "", "", "" ,"","","","");
                                    break;
                                case 2:
                                    timeInOutModal = new TimeInOutModal("", "", timeIn, "", "", "", "", timeOut, "", "" , "","","","");
                                    break;
                                case 3:
                                    timeInOutModal = new TimeInOutModal("", "", "", timeIn, "", "", "", "", timeOut, "","","","","");
                                    break;
                                case 4:
                                    timeInOutModal = new TimeInOutModal("", "", "", "", timeIn, "", "", "", "", timeOut,"","","","");
                                    break;
                                default:
                                    timeInOutModal = new TimeInOutModal("", "", "", "", "", "", "", "", "", "","","","","");
                                    break;
                            }
                            Log.d("timeIn", timeIn);
                            Log.d("timeOut", timeOut);
                            // timeInOutModal
                        }
                        employeeDataForCrew.setTimeInOutModals(timeInOutModal);
                    } else {
                        employeeDataForCrew.setTimeInOutModals(new TimeInOutModal("", "", "", "", "", "", "", "", "", "","","","",""));
                        //Log.d("timeIn","NULL");
                        //Log.d("timeOut","NULL");
                    }
                }


                //    Log.d("ss",String.valueOf(rtHourActivityTotal[0]) + String.valueOf(otHourActivityTotal[0]) + String.valueOf(dotHourActivityTotal));
            }
            crewTimeSheet = new CrewTimeSheet(seqNo, crewCode, workDate, jobCode, jobCompanyCode, crewActivityList, empTimesheetList);
//            return crewTimeSheet;
        } catch (JSONException e) {
            Log.d("Exception", e.toString());
        }
        return crewTimeSheet;
    }
    public int getTimesheetSize() {
        if (timeSheetSize == 0) {
            return 6;
        } else {
            return timeSheetSize;
        }
    }
}


