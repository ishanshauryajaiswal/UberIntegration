package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.InsertingCrewTask;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanAllEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanCrewListDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.LinkingCrewEmployeeWithCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/5/2018.
 */

public class CrewListActivity extends ListActivity{

    Context context;
    Button btnSaveCrewList, btnAllCrewList;
    EditText etSearch;
    ArrayList<User> crewMemberList;
    CrewMemberAdapter crewMemberAdapter;
    ProgressDialog dialogFetchingCrew, progressInseringCrew;
    ListView lv_All, listview;
    Typeface tf;
    Boolean flagSaveListSelected = true, flagAllListSelected = false;
    String selectedCrewName,selectedResponsiblePerson, selectedCrewCode, selectedCrewOraseq, authEncode, auth;
    ImageButton addCrew;
    CrewListAdapter crewListAdapter;
    ArrayList<InsertCrew> crewListFromWeb = new ArrayList<>();
    SharedPreferences ishanSharedPreference;
    SharedPreferences.Editor ishanPreferenceEditor;
    private static final int REQUEST_CODE_CREW_DETAILS = 0;
    boolean isFromTimesheet = false, IsForNewCreatedCrew = false,IsNewCrewSelected = false;
    IshanCrewListDBHelper crewListDBHelper;
    IshanAllEmployeeDBHelper allEmployeeDBHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crew_list);
        valueFromSharedPreference();
        isFromTimesheet = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_timesheet), false);
        crewListDBHelper = new IshanCrewListDBHelper(CrewListActivity.this);

        //if crew code already exists in shared pref and not from timesheet activity
        if (!ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_code), "NOCREW").equalsIgnoreCase("NOCREW")
                && !isFromTimesheet) {
            //startNewActivity(ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_name), "NOCREW"),
            //        ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_code), "NOCREW"),
            //        ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_ora_seq), "NOCREW"));
            Intent intent = new Intent(CrewListActivity.this, ProjectListActivity.class);
            startActivity(intent);
        }
        else {
            initView();
            setUpUI();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initView();
        setUpUI();
    }

    private void initView() {
        etSearch = (EditText) findViewById(R.id.inputSearch);
        btnAllCrewList = (Button) findViewById(R.id.btnAll_crewList);
        btnSaveCrewList = (Button) findViewById(R.id.btnSave_crewList);
        lv_All = (ListView) findViewById(android.R.id.list);
        addCrew = (ImageButton) findViewById(R.id.addcrew);
        tf = Typeface.createFromAsset(getAssets(),"fonts/cmic_icons.ttf");
        setStatusBarColorForLollipop();
        btnSaveCrewList.callOnClick();
    }

    private void setUpUI(){
        etSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSearch.setFocusableInTouchMode(true);
                etSearch.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        etSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });

        btnAllCrewList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard(v);
                etSearch.setText("");
                flagAllListSelected = true;
                flagSaveListSelected = false;
                btnAllCrewList.setEnabled(false);
                btnSaveCrewList.setEnabled(true);
                addCrew.setVisibility(View.VISIBLE);
                btnAllCrewList.setBackgroundResource(R.drawable.all_button_background);
                btnAllCrewList.setTextColor(Color.parseColor("#ffffff"));
                btnSaveCrewList.setTextColor(Color.parseColor("#ffffff"));
                btnSaveCrewList.setBackgroundResource(R.drawable.deselected_save_button_background);
                btnSaveCrewList.setTextColor(Color.parseColor("#1780FB"));
                CrewListWebService();
            }
        });

        btnSaveCrewList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard(v);
                etSearch.setText("");
                flagSaveListSelected = true;
                flagAllListSelected = false;
                btnAllCrewList.setEnabled(true);
                btnSaveCrewList.setEnabled(false);
                btnSaveCrewList.setTextColor(Color.parseColor("#ffffff"));
                btnSaveCrewList.setBackgroundResource(R.drawable.saved_button_background);
                btnAllCrewList.setBackgroundResource(R.drawable.deselected_all_button_background);
                btnAllCrewList.setTextColor(Color.parseColor("#1780FB"));
                ArrayList<InsertCrew> list = new ArrayList<InsertCrew>();
                list = crewListDBHelper.selectAllCrewList();
                if (list!=null) {
                    crewListAdapter = new CrewListAdapter(CrewListActivity.this, list);
                    lv_All.setAdapter(crewListAdapter);
                    Search();
                }
            }
        });

        lv_All.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                hideKeyboard(view);
                IsNewCrewSelected = false;
                ishanPreferenceEditor.putBoolean(getString(R.string.is_first_time_crew_list), false);
                ishanPreferenceEditor.commit();
                InsertCrew insertCrew = (InsertCrew) parent.getItemAtPosition(position);
                selectedCrewCode = insertCrew.getPycrCode();
                selectedCrewName = insertCrew.getPycrName();
                selectedResponsiblePerson = insertCrew.getPycrResponsibleEmpName();
                selectedCrewOraseq = insertCrew.getPycrOraseq();
                etSearch.setText("");

                if (flagAllListSelected) {
                    //check if crew already exists in database
                    if (crewListDBHelper.selectedCrewOraseq(selectedCrewOraseq)) {
                        android.app.AlertDialog.Builder alertActivity1 = new android.app.AlertDialog.Builder(CrewListActivity.this);
                        alertActivity1.setTitle("Data for " + selectedCrewName + " already exists. Do you want to download again ?");
                        alertActivity1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                startNewActivity(selectedCrewName, selectedCrewCode, selectedCrewOraseq);
                            }

                        });
                        alertActivity1.show();
                    } else {
                        //insert crew in database
                        android.app.AlertDialog.Builder alertActivity1 = new android.app.AlertDialog.Builder(CrewListActivity.this);
                        alertActivity1.setTitle("Data for Crew " + selectedCrewName + "  Do you want to download?");
                        alertActivity1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                {
                                    //insert crew in database
                                    crewListDBHelper.insertCrew(selectedCrewCode, selectedCrewName, selectedCrewOraseq);
                                    startNewActivity(selectedCrewName, selectedCrewCode, selectedCrewOraseq);
                                }
                            }

                        });
                        alertActivity1.show();
                    }
                } else {
                    startNewActivity(selectedCrewName, selectedCrewCode, selectedCrewOraseq);
                }
            }
        });
        addCrew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddingNewCrew();
            }
        });
        btnSaveCrewList.callOnClick();
    }

    private void setStatusBarColorForLollipop(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }
    }

    public void Search()
    {
        if (flagSaveListSelected) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    s = s.toString().toLowerCase();
                    final ArrayList<InsertCrew> filteredList = new ArrayList<>();
                    ArrayList<InsertCrew> list = new ArrayList<InsertCrew>();
                    list = crewListDBHelper.selectAllCrewList();
                    for (int i = 0; i < list.size(); i++) {
                        final String txtCrewName = list.get(i).getPycrName().toLowerCase();
                        final String txtCrewCode = list.get(i).getPycrCode().toLowerCase();
                        if (txtCrewName.contains(s) || txtCrewCode.contains(s)) {
                            filteredList.add(list.get(i));
                        }
                    }
                        crewListAdapter = new CrewListAdapter(CrewListActivity.this, filteredList);
                        lv_All.setAdapter(crewListAdapter);
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        } else {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    s = s.toString().toLowerCase();
                    final ArrayList<InsertCrew> filteredList = new ArrayList<>();
                    for (int i = 0; i < crewListFromWeb.size(); i++) {
                        final String txtCrewName = crewListFromWeb.get(i).getPycrName().toLowerCase();
                        final String txtCrewCode = crewListFromWeb.get(i).getPycrCode().toLowerCase();
                        if (txtCrewName.contains(s) || txtCrewCode.contains(s)) {
                            filteredList.add(crewListFromWeb.get(i));
                        }
                    }
                        crewListAdapter = new CrewListAdapter(CrewListActivity.this, filteredList);
                        lv_All.setAdapter(crewListAdapter);
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        }
    }

    public void CrewListWebService() {
        new CrewListActivityTask(authEncode, getApplicationContext(), new CrewListInterface() {
            @Override
            public void onPostCrewListTask(ArrayList<InsertCrew> result) {
                dialogFetchingCrew.dismiss();
                crewListFromWeb = result;
                if (crewListFromWeb.size() == 0) {
                    final android.app.AlertDialog.Builder alertBox = new android.app.AlertDialog.Builder(CrewListActivity.this);
                    alertBox.setTitle("CMiC Mobile Crew Time");
                    alertBox.setMessage("Unable to fetch CrewList");
                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    alertBox.show();
                }
                crewListAdapter = new CrewListAdapter(CrewListActivity.this, crewListFromWeb);
                lv_All.setAdapter(crewListAdapter);
                Search();
            }
            @Override
            public void onPreCrewListTask() {
                dialogFetchingCrew = ProgressDialog.show(CrewListActivity.this, null, "         Fetching Crew ...");
            }
        }).execute();
    }

    ProgressBar progressBar;
    public void AddingNewCrew()
    {
        final String[] crewName = new String[1];
        final String[] crewCode = new String[1];
        final String[] responsiblePerson = new String[2];
        IsForNewCreatedCrew = true;
        final Dialog activityPopup = new Dialog(CrewListActivity.this);
        activityPopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        activityPopup.setContentView(R.layout.adding_new_crew);
        final EditText textcrewname = (EditText) activityPopup.findViewById(R.id.etcrewname);
        final EditText textcrewcode = (EditText) activityPopup.findViewById(R.id.etcrewcode);
        final TextView textresponsibleperson = (TextView) activityPopup.findViewById(R.id.txtresponsibleperson);
        listview = (ListView) activityPopup.findViewById(R.id.list_view);
        TextView arrowimgphase = (TextView) activityPopup.findViewById(R.id.imageView1);
        TextView arrowimgcategory = (TextView) activityPopup.findViewById(R.id.imageView2);
        TextView imgcross = (TextView) activityPopup.findViewById(R.id.imgcross);
        TextView imgbtnback = (TextView) activityPopup.findViewById(R.id.back);
        Button btndone = (Button) activityPopup.findViewById(R.id.btnok);
        final RelativeLayout r1 = (RelativeLayout) activityPopup.findViewById(R.id.relativeLayout1);
        final RelativeLayout r2 = (RelativeLayout) activityPopup.findViewById(R.id.relativeLayout2);
        arrowimgcategory.setTypeface(tf);
        arrowimgphase.setTypeface(tf);
        imgcross.setTypeface(tf);
        imgbtnback.setTypeface(tf);
        progressBar = (ProgressBar)activityPopup.findViewById(R.id.progressbar_new_crew_popup);
        //Cross button
        imgcross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activityPopup.dismiss();
                hideKeyboard(v);
            }
        });
        //Back button
        imgbtnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.VISIBLE);
                r2.setVisibility(View.INVISIBLE);
                crewMemberList = new ArrayList<>();
                crewMemberAdapter = new CrewMemberAdapter(CrewListActivity.this,crewMemberList, new ArrayList<String>(),false);
                listview.setAdapter(crewMemberAdapter);
                listview.setVisibility(View.GONE);
            }
        });

        textresponsibleperson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.INVISIBLE);
                r2.setVisibility(View.VISIBLE);
                listview.setVisibility(View.VISIBLE);
                webServiceGetResponsiblePerson(context);
                listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        User user = (User)parent.getItemAtPosition(position);
                        listview.setVisibility(View.GONE);
                        responsiblePerson[0] = user.getName();
                        responsiblePerson[1] = user.getEmployeeOraseq();
                        if (responsiblePerson[0] != null && !responsiblePerson[0].equals(""))
                            textresponsibleperson.setText(responsiblePerson[0]);
                        r1.setVisibility(View.VISIBLE);
                    }
                });
            }
        });

        btndone.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                crewName[0] = textcrewname.getText().toString();
                crewCode[0] = textcrewcode.getText().toString();
                responsiblePerson[0] = textresponsibleperson.getText().toString();

                if (crewName[0].equals("") || crewName[0].equals("") || crewCode[0].equals("") || crewCode[0].equals("null") || responsiblePerson[0].equals("") || responsiblePerson[0].equals("null") || responsiblePerson[0].equals(getString(R.string.default_textview_text_select_respomsible_person))) {
                    Toast.makeText(CrewListActivity.this, "Please enter Crew Details to be inserted", Toast.LENGTH_SHORT).show();
                } else
                {
                    final boolean[] closeDialog = {false};
                    String table = "{\"table\":\"PycrewView\",\"rowDefinition\":{\"attrNames\":[\"PycrCode\",\"PycrName\",\"PycrResponsibleEmpOraseq\"]},\"rows\":[{\"attrValues\":[\"" + crewCode[0] + "\",\"" + crewName[0] + "\",\"" + responsiblePerson[1] + "\"]}]}";
                    InsertingCrewTask insertingCrew = new InsertingCrewTask(authEncode, crewCode[0],  getApplicationContext(), table, new InsertCrewInterface() {
                        @Override
                        public void onPostTask(String result) {
                            progressInseringCrew.dismiss();
                            switch (result) {
                                case "response code 401":
                                    closeDialog[0] = false;
                                    break;
                                case "Already inserted":
                                    closeDialog[0] = false;
                                    break;
                                default:
                                    closeDialog[0] = true;
                                    IsNewCrewSelected = true;
                                    String crewOraSeq = new IshanInsertCrewResponseParser().getInsertedCrewOraseq(result,crewCode[0],crewName[0],responsiblePerson[1]);
                                    selectedCrewCode = crewCode[0];
                                    selectedCrewName = crewName[0];
                                    selectedResponsiblePerson = responsiblePerson[0];
                                    selectedCrewOraseq = crewOraSeq;
                                    startNewActivity(crewName[0], crewCode[0], crewOraSeq);
                                    break;
                            }
                        }

                        @Override
                        public void onPreTask() {
                            progressInseringCrew = ProgressDialog.show(CrewListActivity.this, null, "      inserting...");
                        }
                    });
                    insertingCrew.execute();
                }
            }

        });
        activityPopup.show();
    }

    public void webServiceGetResponsiblePerson(Context mContext) {
        new GetEmployees(CrewListActivity.this, auth, new FillEmployeeListener() {
            @Override
            public void afterCompleted(String result) {
                progressBar.setVisibility(View.GONE);
                if (result == null) {
                    final android.app.AlertDialog.Builder alertBox = new android.app.AlertDialog.Builder(CrewListActivity.this);
                    alertBox.setTitle("CMiC Mobile Crew Time");
                    alertBox.setMessage("No Crew Members Found");
                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alertBox.setCancelable(true);
                        }
                    });
                    alertBox.show();
                }
                if (result != null) {
                    EmployeeDataParser EmployeeDataParser = new EmployeeDataParser();
                    crewMemberList = EmployeeDataParser.parseEmployeeData(result, getApplicationContext());
                    crewMemberAdapter = new CrewMemberAdapter(getApplication(), crewMemberList, new ArrayList<String>(), false);
                    listview.setAdapter(crewMemberAdapter);
                }
            }
            @Override
            public void beforeCompleted() {
                progressBar.setVisibility(View.VISIBLE);
            }
        }).execute();
    }

    public void startNewActivity(final String crewName, final String crewCode, final String crewOraSeq)
    {
        if (IsNewCrewSelected)
        {
            Intent intent = new Intent(CrewListActivity.this, CrewDetailsActivity.class);
            intent.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), true);
            intent.putExtra(getString(R.string.cmic_intent_extras_from_crew_list), true);
            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_code), crewCode);
            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_name), crewName);
            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq), crewOraSeq);
            startActivityForResult(intent,REQUEST_CODE_CREW_DETAILS);
        }
        else
        {
            FetchEmployeesOfCrew fetchEmployeesOfCrew = new FetchEmployeesOfCrew(CrewListActivity.this, crewCode, new FetchEmployeesOfCrewInterface() {
                @Override
                public void preTask() {
                    dialogFetchingCrew = ProgressDialog.show(CrewListActivity.this, null, "         Checking if Crew Is Empty ...");
                }

                @Override
                public void postTask(String data) {
                    if (data.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                    } else {
                        LinkingCrewEmployeeWithCrew employeeCrew = new FetchedCrewEmployeeParser().parseFetchedCrewEmployeeData(data);
                        //Insert All employees of selected crew in local database table AllEmployee
                        if (employeeCrew!=null) {
                            ArrayList<AttributeValuesForCrewModal> employeesInCrew = employeeCrew.getAttributeValuesForCrewModals();
                            allEmployeeDBHelper = new IshanAllEmployeeDBHelper(CrewListActivity.this);
                            allEmployeeDBHelper.insertAllEmployeeInDatabase(employeesInCrew);
                            for (AttributeValuesForCrewModal a : employeesInCrew)
                                Log.d("hurray", allEmployeeDBHelper.getPyceOraSeqOfEmployee(a.getPyceEmpNo()));
                            dialogFetchingCrew.dismiss();
                        }
                        if (employeeCrew!=null) {
                            putValuesInSharedPreference();
                            if (isFromTimesheet) {
                                setResult(Activity.RESULT_OK);
                                finish();
                            }
                            else {
                                Intent intent = new Intent(CrewListActivity.this, ProjectListActivity.class);
                                startActivity(intent);
                            }
                        } else {
                            Intent intent = new Intent(CrewListActivity.this, CrewDetailsActivity.class);
                            intent.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), true);
                            intent.putExtra(getString(R.string.cmic_intent_extras_from_crew_list), true);
                            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_code), crewCode);
                            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_name), crewName);
                            intent.putExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq), crewOraSeq);
                            startActivityForResult(intent, REQUEST_CODE_CREW_DETAILS);
                        }
                    }
                }
            });
            fetchEmployeesOfCrew.execute();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            putValuesInSharedPreference();
            if (isFromTimesheet){
                setResult(Activity.RESULT_OK);
                finish();
            }
            else {
                Intent intent = new Intent(CrewListActivity.this, ProjectListActivity.class);
                startActivity(intent);
            }
        }
    }

    public void valueFromSharedPreference()
    {
        ishanSharedPreference = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), 0);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        authEncode = ishanSharedPreference.getString("authcode", null);
    }

    private void putValuesInSharedPreference(){
        ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_crew_name), selectedCrewName);
        ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_crew_code), selectedCrewCode);
        ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_responsible_person), selectedResponsiblePerson);
        ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_crew_ora_seq), selectedCrewOraseq);
        ishanPreferenceEditor.commit();
    }
    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
