package com.shaurya.room.repository.local.db;

import android.app.Application;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.shaurya.room.model.Movie;
import com.shaurya.room.repository.local.db.dao.MovieDao;


@Database(entities = {Movie.class}, version = 1)
public abstract class MovieDatabase extends RoomDatabase {

    public abstract MovieDao movieDao();
    private static MovieDatabase INSTANCE;

    public static MovieDatabase getInstance(Application context){
        if (INSTANCE == null) {
            synchronized (MovieDatabase.class) {
                if (INSTANCE == null)
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), MovieDatabase.class, "movie_databse")
                            .build();
            }
        }
        return INSTANCE;
    }

}
