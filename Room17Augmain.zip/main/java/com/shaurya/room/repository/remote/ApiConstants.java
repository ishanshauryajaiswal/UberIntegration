package com.shaurya.room.repository.remote;

public class ApiConstants {

    public static final String BASE_URL = "http://api.themoviedb.org/3/movie/";

    public static final String POPULAR_URL = "popular";

    public static final String API_KEY = "api_key";
    public static final String PAGE = "page";
}
