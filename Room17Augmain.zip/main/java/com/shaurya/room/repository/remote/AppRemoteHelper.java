package com.shaurya.room.repository.remote;

import android.arch.lifecycle.MutableLiveData;
import android.util.Log;

import com.shaurya.room.model.MovieResponse;
import com.shaurya.room.model.NetworkStatus;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AppRemoteHelper {

    private MovieService movieService;

    private MutableLiveData<MovieResponse> movieResponseLiveData = new MutableLiveData<>();

    public AppRemoteHelper() {
        movieService = RetrofitInstance.getInstance().create(MovieService.class);
    }

    public MutableLiveData<MovieResponse> fetchMovieFromRemote(int page){
        final MovieResponse movieResponse = new MovieResponse();
        movieResponse.setStatus(NetworkStatus.LOADING);
        movieResponseLiveData.postValue(movieResponse);
        movieService.fetchPopularMovies("ab5aee0b18da89dd9e026d35754c24f1", page).enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                movieResponseLiveData.postValue(movieResponse);
                int statusCode = response.code();
                if (statusCode == 200){
                    movieResponse.setResult(response.body().getResult());
                    movieResponse.setStatus(NetworkStatus.SUCCESS);
                    movieResponseLiveData.postValue(movieResponse);
                }
            }

            @Override
            public void onFailure(Call<MovieResponse> call, Throwable t) {
                movieResponse.setStatus(NetworkStatus.FAILURE);
                movieResponseLiveData.postValue(movieResponse);
                Log.e("tatti",t.getMessage());
            }
        });

        return movieResponseLiveData;
    }

}
