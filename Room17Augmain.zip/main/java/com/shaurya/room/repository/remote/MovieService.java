package com.shaurya.room.repository.remote;


import com.shaurya.room.model.Movie;
import com.shaurya.room.model.MovieResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MovieService {

    @GET(ApiConstants.POPULAR_URL)
    Call<MovieResponse> fetchPopularMovies(@Query(ApiConstants.API_KEY) String apiKey, @Query(ApiConstants.PAGE) int page);

}
