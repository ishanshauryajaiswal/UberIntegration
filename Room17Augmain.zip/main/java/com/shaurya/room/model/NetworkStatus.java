package com.shaurya.room.model;

public enum  NetworkStatus {
    LOADING,
    SUCCESS,
    FAILURE
}
