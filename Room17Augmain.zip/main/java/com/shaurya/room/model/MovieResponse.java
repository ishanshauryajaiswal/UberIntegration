package com.shaurya.room.model;

import java.util.List;

public class MovieResponse {

    private List<Movie> results;
    private NetworkStatus status;


    public List<Movie> getResult() {
        return results;
    }

    public void setResult(List<Movie> result) {
        this.results = result;
    }

    public NetworkStatus getStatus() {
        return status;
    }

    public void setStatus(NetworkStatus status) {
        this.status = status;
    }
}
