package com.shaurya.room.model;

public class PublicRepo {

    private String html_url;

    private String id;

    private String fork;

    private String description;

    private String name;

    private Owner owner;

    private String url;


    private String full_name;

    public String getHtml_url ()
    {
        return html_url;
    }

    public void setHtml_url (String html_url)
    {
        this.html_url = html_url;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getFork ()
    {
        return fork;
    }

    public void setFork (String fork)
    {
        this.fork = fork;
    }

    public String getDescription ()
    {
        return description;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public Owner getOwner ()
    {
        return owner;
    }

    public void setOwner (Owner owner)
    {
        this.owner = owner;
    }

    public String getUrl ()
    {
        return url;
    }

    public void setUrl (String url)
    {
        this.url = url;
    }

    public String getFull_name ()
    {
        return full_name;
    }

    public void setFull_name (String full_name)
    {
        this.full_name = full_name;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [html_url = "+html_url+", id = "+id+", fork = "+fork+", description = "+description+", name = "+name+", owner = "+owner+", url = "+url+", full_name = "+full_name+"]";
    }

}
