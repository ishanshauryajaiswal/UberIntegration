package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */


public class IshanDBHelper extends SQLiteOpenHelper {
    private static IshanDBHelper mInstance;
    private static final String DBName="";
    private static final int DBVersion = 1;
    private static IshanDBConstants D = new IshanDBConstants();

    private static final String CREATE_TABLE_EMPLOYEE_DATA = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_EMPLOYEE_DATA_FOR_CREW + "(" +
            D.CrewCode_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeName_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeNumber_EmployeeDataForCrew + " TEXT PRIMARY KEY,"+
            D.EmployeeOraseq_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeCode_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeName_EmployeeDataForCrew + " TEXT,"+
            D.JobCode_EmployeeDataForCrew+ " TEXT,"+
            D.PeriodFlag_EmployeeDataForCrew+ " TEXT,"+
            D.RowNumber_EmployeeDataForCrew+ " TEXT,"+
            D.WorkDate_EmployeeDataForCrew+ " TEXT)";


    private static final String CREATE_TABLE_ACTIVITY_TIME_FOR_CREW = "CREATE TABEL IF NOT EXISTS "+
            D.EmployeeNumber_EmployeeDataForCrew+ " TEXT,"+
            D.rtSeqNumber+ " TEXT,"+
            D.rtHours+ " TEXT,"+
            D.otseqNumber+ " TEXT,"+
            D.otHour+ " TEXT,"+
            D.dotSeqNumber+ " TEXT,"+
            D.dothour+ " TEXT)";

    private static final String CREATE_TABLE_ACTIVITY_FOR_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+
            D.ActivityName_ActivityForTimeSheet+ " TEXT,"+
            D.CategoryCode_ActivityForTimeSheet+ " TEXT,"+
            D.ColoumnNumber_ActivityForTimeSheet+ " TEXT,"+
            D.CrewCode_ActivityForTimeSheet+ " TEXT,"+
            D.JobCode_ActivityForTimeSheet+ " TEXT,"+
            D.JobCompCode_ActivityForTimeSheet+ " TEXT,"+
            D.PciLineOraseq_ActivityForTimeSheet+ " TEXT,"+
            D.PhaseCode_ActivityForTimeSheet+ " TEXT,"+
            D.SeqNumber_ActivityForTimeSheet+ " TEXT,"+
            D.WbsCode_ActivityForTimeSheet+ " TEXT,"+
            D.WorkDate_ActivityForTimeSheet+ " TEXT)";







    private IshanDBHelper(Context context) {
        super(context, DBName, null, DBVersion);
    }

    public static synchronized IshanDBHelper getInstance(Context context){
        if (mInstance == null)
            mInstance = new IshanDBHelper(context.getApplicationContext());
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
