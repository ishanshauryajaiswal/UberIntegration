package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/1/2018.
 */

public interface MyListner {
    void yoNigga(String message);
}
