package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Database.DBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.JobDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */

public class ProjectListActivity extends ListActivity {
    public String name;
    Boolean flagSaveListSelected = true,IsFromCrewList;
    Boolean flagAllListSelected = false;
    ListView lv_All;
    String selectedCrewNameFromCrewDetails,selectedCrewCodeFromCrewDetails;
    EditText editText;
    CrewTimeSheet mCrewTimesheet = null ;
    String[] listname, listJobCode, listProjectCode;
    ArrayList<com.example.ishanjaiswal.cmicresultactivity.Model.JobData> JobData;
    ProjectListAdapter projectListAdapter;
    LoginAccess loginAccess = LoginAccess.getInstance();
    Button btnSave, btnAll;
    ProgressDialog dialog;
    DBHelper dbHelper = new DBHelper(this);
    ArrayList<JobData> list;
    SharedPreferences ishanSharedPreference;
    SharedPreferences.Editor ishanPreferenceEditor;
    boolean isFromTimesheet = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_list);
        ishanSharedPreference = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), 0);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        isFromTimesheet = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_timesheet), false);
        //if project exists in shared pref and activity not from timesheet
        if (!ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_code)
                , getString(R.string.cmic_shared_preference_no_project)).equalsIgnoreCase("NOPROJECT") && !isFromTimesheet) {
            Intent intent = new Intent(ProjectListActivity.this, MainActivity.class);
            startActivity(intent);
        }
        //if project doesn't exists OR it exists but activity is from timesheet
        else {
            mCrewTimesheet = (CrewTimeSheet) getIntent().getSerializableExtra("mCrewTimeSheet");
            initialize();
            getValueFromIntent();
            changeColor();
            Search();
            listViewItemClick();
            btnSave.setEnabled(false);
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    populateSavedList();
                    flagSaveListSelected = true;
                    flagAllListSelected = false;
                    editText.setText("");
                    editText.setFocusable(false);
                    btnSave.setEnabled(false);
                    btnAll.setEnabled(true);
                    Search();
                }
            });
            btnAll.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    {
                        flagSaveListSelected = false;
                        flagAllListSelected = true;
                        new JobDataTask().execute();
                        //editText.setText("");
                        editText.setFocusable(false);
                        btnAll.setEnabled(false);
                        btnSave.setEnabled(true);
                        btnAll.setBackgroundResource(R.drawable.all_button_background);
                        btnAll.setTextColor(Color.parseColor("#ffffff"));
                        btnSave.setBackgroundResource(R.drawable.deselected_save_button_background);
                        btnSave.setTextColor(Color.parseColor("#1780FB"));
                    }
                }
            });

            editText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editText.setFocusableInTouchMode(true);
                    editText.requestFocus();
                    final InputMethodManager inputMethodManager = (InputMethodManager)
                            getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);

                }
            });
            btnSave.callOnClick();
        }
    }

    public class JobDataTask extends AsyncTask<Void, Void, String>
    {
        @Override
        protected void onPreExecute()
        {
            dialog = ProgressDialog.show(ProjectListActivity.this, null, "         Fetching Projects...");
        }
        @Override
        protected String doInBackground(Void... params)
        {
            String response = "";
            try {
                RequestCall requestCall = new RequestCall();
                response = requestCall.requestJobData(getApplicationContext());
            } catch (Exception e) {
                Log.d("error in ", e.toString());
            }
            return response;
        }
        protected void onPostExecute(String response)
        {
            dialog.dismiss();
            Search();
            if (response != null)
            {

                final JobDataParser jobDataParser = new JobDataParser();
                JobData = jobDataParser.parseJobData(response);
                if (JobData != null)
                {
                    listname = new String[JobData.size()];
                    listProjectCode = new String[JobData.size()];
                    listJobCode = new String[JobData.size()];
                    for (int i = 0; i < JobData.size(); i++) {
                        listname[i] = JobData.get(i).getJobname();
                        listProjectCode[i] = JobData.get(i).getJobcode();
                    }
                    for (int i = 0; i < JobData.size(); i++)
                    {
                        listJobCode[i] = JobData.get(i).getJobcode();
                    }
                    projectListAdapter = new ProjectListAdapter(ProjectListActivity.this, JobData,true);
                    lv_All.setAdapter(projectListAdapter);
                    dialog.dismiss();
                }
                else
                {
                    final AlertDialog.Builder alertBox = new AlertDialog.Builder(ProjectListActivity.this);
                    alertBox.setTitle("CMiC Mobile Crew Time");
                    alertBox.setMessage("No GetPhaseTask Associated");
                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    alertBox.show();
                }
            }
            else
            {
                final AlertDialog.Builder alertBox = new AlertDialog.Builder(ProjectListActivity.this);
                alertBox.setTitle("CMiC Mobile Crew Time");
                alertBox.setMessage("Error occured while fetching the projects");
                alertBox.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        cancel(true);
                        new JobDataTask().execute();
                    }
                });
                alertBox.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertBox.setCancelable(true);
                    }
                });
                alertBox.show();
            }
        }
    }


    private void initialize() {
        btnAll = (Button) findViewById(R.id.btnAll);
        btnSave = (Button) findViewById(R.id.btnSave);
        lv_All = (ListView) findViewById(android.R.id.list);
        editText = (EditText) findViewById(R.id.inputSearch);
    }


    public void populateSavedList()
    {
        btnAll.setEnabled(true);
        btnAll.setBackgroundResource(R.drawable.deselected_all_button_background);
        btnAll.setTextColor(Color.parseColor("#1780FB"));
        btnSave.setBackgroundResource(R.drawable.saved_button_background);
        btnSave.setTextColor(Color.parseColor("#ffffff"));
        JobDBHelper jobDBHelper = new JobDBHelper(ProjectListActivity.this);
        list = jobDBHelper.selectallSelectedJobs();
        projectListAdapter = new ProjectListAdapter(ProjectListActivity.this,list,true);
        lv_All.setAdapter(projectListAdapter);
    }

    public void Search()
    {
            editText.addTextChangedListener(new TextWatcher()
            {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after)
                {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    s = s.toString().toLowerCase();
                    final ArrayList<JobData> filteredList = new ArrayList<>();

                    ArrayList<JobData> list = new ArrayList<JobData>();
                    if (flagSaveListSelected == true) {
                        JobDBHelper jobDBHelper = new JobDBHelper(ProjectListActivity.this);
                        list = jobDBHelper.selectallSelectedJobs();
                    } else {
                        list = JobData;
                    }
                    if (list != null) {
                        for (int i = 0; i < list.size(); i++) {
                            final String txtCrewName = list.get(i).getJobname().toLowerCase();
                            final String txtCrewCode = list.get(i).getJobcode().toLowerCase();
                            if (txtCrewName.contains(s) || txtCrewCode.contains(s)) {
                                filteredList.add(list.get(i));
                            }
                        }
                        if (projectListAdapter == null) {
                            projectListAdapter = new ProjectListAdapter(ProjectListActivity.this, filteredList, true);
                            lv_All.setAdapter(projectListAdapter);
                        } else {
                            projectListAdapter.setList(filteredList);
                        }
                    } else {
                        Toast.makeText(ProjectListActivity.this, "No Projects Available", Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void afterTextChanged(Editable s)
                {
                }
            });
    }
    public void getValueFromIntent()
    {
        isFromTimesheet = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_timesheet), false);
        selectedCrewNameFromCrewDetails = getIntent().getStringExtra("SelectedCrewName");
        selectedCrewCodeFromCrewDetails = getIntent().getStringExtra("SelectedCrewCode");
        IsFromCrewList = getIntent().getBooleanExtra("IsFromCrewListActivity",true);
    }

    public void putValuesInSharedPreference()
    {
        ishanPreferenceEditor.putBoolean("IsFirstTimeProjectList",true);
        ishanPreferenceEditor.commit();
    }

    private void changeColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }
    }

    public void listViewItemClick()
    {
        lv_All.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int i, long l)
            {
                final JobData itemAtPosition = (JobData) parent.getItemAtPosition(i);
                Log.d("selectedJobName", itemAtPosition.getJobname());
                Log.d("selectedJobCode", itemAtPosition.getJobcode());
                ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_project_name), itemAtPosition.getJobname());
                ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_project_code), itemAtPosition.getJobcode());
                ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_project_comp_code), itemAtPosition.getJobcompcode());
                ishanPreferenceEditor.commit();
                final JobDBHelper jobDBHelper = new JobDBHelper(ProjectListActivity.this);
                final Intent intentForTimeSheet = new Intent(ProjectListActivity.this,MainActivity.class);
                intentForTimeSheet.putExtra(getString(R.string.cmic_intent_extras_selected_project_name),
                        itemAtPosition.getJobname());
                intentForTimeSheet.putExtra(getString(R.string.cmic_intent_extras_selected_project_code),
                        itemAtPosition.getJobcode());
                intentForTimeSheet.putExtra(getString(R.string.cmic_intent_extras_selected_project_comp_code),
                        itemAtPosition.getJobcompcode());
                if (flagAllListSelected)
                {
                    if (jobDBHelper.selectedJobCode(itemAtPosition.jobcode))
                    {
                        AlertDialog.Builder alertActivity1 = new AlertDialog.Builder(ProjectListActivity.this);
                        alertActivity1.setTitle("Data for " + itemAtPosition.getJobname() + " already exists. Do you want to download again ?");
                        alertActivity1.setPositiveButton("OK", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                putValuesInSharedPreference();
                                jobDBHelper.insertSelectedJobs(itemAtPosition.getJobcode(), itemAtPosition.getJobcompcode(), itemAtPosition.getJobname());
                                loginAccess.projectNamesloginaccess.add(listname[i]);
                                if (isFromTimesheet) {
                                    setResult(Activity.RESULT_OK,intentForTimeSheet);
                                    finish();
                                }
                                else
                                    startActivity(intentForTimeSheet);
                            }

                        });
                        alertActivity1.show();
                    }
                    else
                    {
                        AlertDialog.Builder alertActivity1 = new AlertDialog.Builder(ProjectListActivity.this);
                        alertActivity1.setTitle("Data for " + itemAtPosition.getJobname() + "  Do you want to download?");
                        alertActivity1.setPositiveButton("OK", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                putValuesInSharedPreference();
                                jobDBHelper.insertSelectedJobs(itemAtPosition.getJobcode(),itemAtPosition.getJobcompcode(),itemAtPosition.getJobname());
                                loginAccess.projectNamesloginaccess.add(listname[i]);
                                if (isFromTimesheet){
                                    setResult(Activity.RESULT_OK,intentForTimeSheet);
                                    finish();
                                }
                                else
                                    startActivity(intentForTimeSheet);
                            }
                        });
                        alertActivity1.show();
                    }
                }
                else
                {
                    putValuesInSharedPreference();
                    Intent intent = new Intent(ProjectListActivity.this,MainActivity.class);
                    if (isFromTimesheet){
                        setResult(Activity.RESULT_OK,intentForTimeSheet);
                        finish();
                    }
                    else
                        startActivity(intent);
                }
            }

        });
    }
}
