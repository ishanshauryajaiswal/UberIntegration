package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 Created by parneet.singh on 8/8/2016.
 */
public class ServerConnection
{
    OkHttpClient okHttpClient = new OkHttpClient();
    //SharedPreferences sharedPreferences;
    String username,password;
    Context mContext;
    SharedPreferences ishanSharedPreferences;
    SharedPreferences.Editor ishanEditor;
    public ServerConnection(Context context){
        mContext=context;
        //=mContext.getSharedPreferences("LoginCredentials", Context.MODE_PRIVATE);
        ishanSharedPreferences = mContext.getSharedPreferences(mContext.getString(R.string.cmic_shared_preference), 0);
    }


    public String Connection(String url) throws IOException
    {
        /*
        username = sharedPreferences.getString("Username", null);
        Log.d("userName",username);
        password = sharedPreferences.getString("Password", null);
        */
        username = ishanSharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_username), null);
        Log.d("userName",username);
        password = ishanSharedPreferences.getString(mContext.getString(R.string.cmic_shared_preference_password), null);
        String header = username + ":" + password;
        Log.d("username retry",username);
        Log.d("Password retry",password);
        String authEncoded = new String(Base64.encode(header.getBytes("UTF-8"), Base64.NO_WRAP));

        okHttpClient.setConnectTimeout(7000, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(7000, TimeUnit.SECONDS);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).build();
        Log.d("header", header);
        Log.d("connection request", String.valueOf(request));;
        try
        {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]
                    {
                            new X509TrustManager() {
                                @Override
                                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                                }

                                @Override
                                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                    return null;
                                }
                            }
                    };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient okHttpClient = new OkHttpClient();
            okHttpClient.setSslSocketFactory(sslSocketFactory);
            okHttpClient.setHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
            Response response = okHttpClient.newCall(request).execute();
            int responsecode = response.code();
            Log.d("Code", String.valueOf(responsecode));
            if (responsecode == 200)
            {
                return response.body().string();
            }
            else
            {

                return null;
            }
        }
        catch (Exception e)
        {
            Log.d("Exception",e.toString());
            return null;
        }

    }

    public String ConnectionUploadSignature(String url ,String fileName,Bitmap bitmap) throws Exception
    {
        String result = null;
        DataOutputStream wr=null;
        StringBuffer sb = new StringBuffer();
        InputStream is = null;
        username = ishanSharedPreferences.getString("Username", null);
        Log.d("userName",username);
        password = ishanSharedPreferences.getString("Password", null);
        String header = username + ":" + password;
        String authEncoded = new String(Base64.encode(header.getBytes("UTF-8"), Base64.NO_WRAP));

        String boundary = "-------------------------acebdf13572468";
        String contentType = "multipart/form-data; boundary=";
        contentType = contentType + boundary;
        Log.d("ContentType",contentType);
        byte[] byteArray = getBytesFromBitmap(bitmap);
        Log.d("ByteArray", String.valueOf(byteArray));


        String encodedImage = Base64.encodeToString(byteArray , Base64.DEFAULT);

        URL fileurl = null;
        fileurl = new URL(url);
        Log.d("Upload Signature", String.valueOf(fileurl));

        try {
            HttpURLConnection conection = null;
    /*Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).build();*/
            conection = (HttpURLConnection) fileurl.openConnection();

            conection.setRequestProperty("Content-Type", contentType);

            // conection.setRequestProperty("charset", "utf-8");
            conection.setRequestProperty("Authorization", "Basic " + authEncoded);
            conection.setInstanceFollowRedirects(false);
            conection.setUseCaches(true);
            conection.setDoInput(true);
            conection.setDoOutput(true);
            conection.setChunkedStreamingMode(0);

            conection.setDefaultUseCaches(true);
            conection.setRequestMethod("PUT");

            String upperBoundry = "---------------------------acebdf13572468" +

                    "\r\n" +

                    "Content-Disposition: form-data; name=\"file\"; filename=\""
                    + fileName + ".jpg " +

                    "\r\n" +

                    "Content-Type: " + contentType +

                    "\r\n" +

                    "\r\n";

            String lowerBoundry = "\r\n" +

                    "---------------------------acebdf13572468--" +

                    "\r\n";

            String postData = upperBoundry + encodedImage + lowerBoundry;
            byte[] byteData = new byte[0];
            byteData = postData.getBytes("UTF-8");
            conection.getOutputStream().write(byteData);
            // wr.write(byteData);
            conection.connect();
            int status = conection.getResponseCode();
            Log.d("PUTRequest", status + "");
            if (status == 200)
            {
                is = new BufferedInputStream(conection.getInputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String inputLine = "";
                while ((inputLine = br.readLine()) != null) {
                    sb.append(inputLine);
                }
                result = sb.toString();
                return result;
            }
            else
            {
                Log.d("Error", "Code400");
            }
            return result;
        }
        catch (Exception e)
        {
            Log.d("Exception in Loading",e.toString());
        }

        return null;
    }

    private byte[] getBytesFromBitmap(Bitmap bitmap)
    {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    public String DeleteConnection(String url) throws IOException
    {
        username = ishanSharedPreferences.getString("Username", null);
        Log.d("userName", username);
        password = ishanSharedPreferences.getString("Password", null);
        String header = username + ":" + password;
        String authEncoded = new String(Base64.encode(header.getBytes("UTF-8"), Base64.NO_WRAP));
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).delete().build();
        try
        {

            Response response = okHttpClient.newCall(request).execute();
            int responsecode = response.code();
            Log.d("Code", String.valueOf(responsecode));
            if (responsecode == 200)
            {
                return response.body().string();
            }
            else
            {
                Log.d("DeleteException","Exception1");
                return null;
            }
        }
        catch(Exception e)
        {
            Log.d("DeleteException","Exception");
            return null;
        }
    }

    public String deleteCrewMember(String url) throws IOException
    {
        username = ishanSharedPreferences.getString("Username", null);
        Log.d("userName", username);
        password = ishanSharedPreferences.getString("Password", null);
        String header = username + ":" + password;
        String authEncoded = new String(Base64.encode(header.getBytes("UTF-8"), Base64.NO_WRAP));
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).delete().build();
        try
        {

            Response response = okHttpClient.newCall(request).execute();
            int responsecode = response.code();
            Log.d("Code", String.valueOf(responsecode));
            if (responsecode == 200)
            {
                return response.body().string();
            }
            else
            {
                Log.d("DeleteException","Exception1");
                return null;
            }
        }
        catch(Exception e)
        {
            Log.d("DeleteException","Exception");
            return null;
        }
    }

    public String insertCrewNameCrewCode(String url, String header, String table)
    {
        okHttpClient.setConnectTimeout(90, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(90, TimeUnit.SECONDS);
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        Log.d("header", header);
        RequestBody requestBody = RequestBody.create(JSON, table);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + header).put(requestBody).build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String response1 = "";
            int responseCode = response.code();

            switch (responseCode) {
                case 200:
                    response1 = response.body().string();
                    break;
                case 401:
                    response1 = "response code 401";
                    break;
                case 500:
                    response1 = "Already inserted";
                    break;
            }
            Log.d(String.valueOf(responseCode), response1);
            return response1;
        } catch (Exception e) {
            return "error";
        }
    }

    public String connectionPutEmployee(String url, String crewOraSeq, ArrayList<User> selectedEmployees) throws UnsupportedEncodingException
    {
        String strJSON = null;
        username = ishanSharedPreferences.getString("Username", null);
        Log.d("userName",username);
        password = ishanSharedPreferences.getString("Password", null);
        Log.d("password",password);
        String auth = username + ":" + password;
        Log.d("username retry",username);
        Log.d("Password retry",password);
        String authEncoded = new String(Base64.encode(auth.getBytes("UTF-8"), Base64.NO_WRAP));
        Log.d("header in connection",auth);
        okHttpClient.setConnectTimeout(60, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(60, TimeUnit.SECONDS);
        BigInteger Intcreworaseq = BigInteger.valueOf(Long.parseLong(crewOraSeq));
        // BigInteger selectedEmployeeOraseq = BigInteger.valueOf(Long.parseLong(selectedEmployeeOraseq));
        try
        {
            strJSON = jsonForLinkingRequest(crewOraSeq, selectedEmployees);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        // String creworaseq1 = crewOraSeq;
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        // Log.d("header",header);
      /*  String str = "{\"table\":\"PycrewempsView\",\"numberOfRemainingRecords\":\"0\",\"rowDefinition\":{\"attrNames\":[\"PyceCrewOraseq\",\"PyceEmpOraseq\"]},\"rows\":[";
       // Log.d("str ",str);
        String[] array_checked_items = new String[selectedEmployeeOraseq.length];
        for (int i = 0; i < selectedEmployeeOraseq.length - 1; i++)
        {
            array_checked_items[i] = "{\"attrValues\":[" + creworaseq + ",\"" + selectedEmployeeOraseq[i] + "\"]},";
        }
        array_checked_items[selectedEmployeeOraseq.length - 1] = "{\"attrValues\":[" + creworaseq + "," + selectedEmployeeOraseq[selectedEmployeeOraseq.length - 1] + "]}]}";

        for (int i = 0; i < array_checked_items.length; i++)
        {
            str = str + array_checked_items[i];
            Log.d("JSON Str",str);
        }*/

        //Log.d("Onkar",str);
        RequestBody requestBody = RequestBody.create(JSON,strJSON);
        Log.d("IshanLog Link Request", strJSON);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        try
        {
            Response response = okHttpClient.newCall(request).execute();
            Log.d("IshanLog Link Response", String.valueOf(response));
            int responsecode = response.code();
            if (responsecode == 401)
            {
                return "error response code 401";
            }
            else
            {
                String s = response.body().toString();
                return s;
            }

        }
        catch (Exception e)
        {
            return "error";
        }
    }

    private void bigIntegersArray(int i, BigInteger bigIntegers) {
    }

    public String putConnection(String url, String parameters)
    {

        Log.d("parameters",parameters);
        username = ishanSharedPreferences.getString("Username", null);
        password = ishanSharedPreferences.getString("Password", null);
        String header = username + ":" + password;
        String authEncoded = null;
        try
        {
            authEncoded = new String(Base64.encode(header.getBytes("UTF-8"), Base64.NO_WRAP));
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        okHttpClient.setConnectTimeout(90, TimeUnit.SECONDS);
        okHttpClient.setReadTimeout(90,TimeUnit.SECONDS);
        final MediaType JSON = MediaType.parse("text/plain; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, parameters);
        Request request = new Request.Builder().url(url).header("Authorization", "Basic " + authEncoded).put(requestBody).build();
        try
        {
            Response response = okHttpClient.newCall(request).execute();
            Log.e("REsponse Submit : ", response.toString());
            int responseCode = response.code();
            switch (responseCode) {
                case 200:
                    return response.body().string();

                default:
                    return null;

//                case 401:
//                    return "response code 401";
//
//                case 500:
//                    return "Already inserted";

            }


        } catch (Exception e) {
            return String.valueOf(e);
        }
    }

    public String json (BigInteger selectedCrewOraseq , BigInteger[] selectedEmployeeOraseq) throws JSONException
    {
        JSONObject mainJsonObj = new JSONObject();
        mainJsonObj.put("table","PycrewempsView");
        JSONObject rowDefinitionObj = new JSONObject();
        JSONArray attrNames = new JSONArray();
        attrNames.put("PyceCrewOraseq");
        attrNames.put("PyceEmpOraseq");
        rowDefinitionObj.put("attrNames",attrNames);
        mainJsonObj.put("rowDefinition",rowDefinitionObj);
        JSONArray rows = new JSONArray();
        for(int i = 0; i<selectedEmployeeOraseq.length;i++)
        {
            JSONObject insideRows = new JSONObject();
            JSONArray attrValues = new JSONArray();
            attrValues.put(selectedCrewOraseq);
            attrValues.put(selectedEmployeeOraseq[i]);
            insideRows.put("attrValues",attrValues);
            rows.put(insideRows);
        }
        mainJsonObj.put("rows",rows);
        return String.valueOf(mainJsonObj);
    }

    String jsonForLinkingRequest(String  selectedCrewOraseq, ArrayList<User> selectedEmployees)throws JSONException{
        JSONObject mainJsonObj = new JSONObject();
        mainJsonObj.put("table","PycrewempsView");
        JSONObject rowDefinitionObj = new JSONObject();
        JSONArray attrNames = new JSONArray();
        attrNames.put("PyceCrewOraseq");
        attrNames.put("PyceEmpOraseq");
        rowDefinitionObj.put("attrNames",attrNames);
        mainJsonObj.put("rowDefinition",rowDefinitionObj);
        JSONArray rows = new JSONArray();
        for(int i = 0; i<selectedEmployees.size();i++)
        {
            User user = selectedEmployees.get(i);
            JSONObject insideRows = new JSONObject();
            JSONArray attrValues = new JSONArray();
            attrValues.put(selectedCrewOraseq);
            attrValues.put(user.getEmployeeOraseq());
            insideRows.put("attrValues",attrValues);
            rows.put(insideRows);
        }
        mainJsonObj.put("rows",rows);
        return String.valueOf(mainJsonObj);
    }
}
