package com.example.ishanjaiswal.cmicresultactivity.Model;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */

public class EmployeeDataForCrew implements Serializable
{
    private String DeleteFlag = null;
    private String EmpName = null;
    private String TradeCode = null;
    private String TradeName = null;
    private String EmpNo = null;
    private String RowNo = null;
    private String employeeOraseq = null;
    private String TotalTimeInOut;
    private ArrayList<ActivityTimeForCrew> TimeSheet;
    private TimeInOutModal timeInOutModals;
    private double totalRtHour, totalOtHour, totalDotHour ;
    ArrayList<Double> totalColoumnREG,totalColoumnOT,totalColoumnDOT;

    public EmployeeDataForCrew(String DeleteFlag, String EmpNo,String EmpName ,String tradeCode,String tradeName,String RowNo,ArrayList<ActivityTimeForCrew> TimeSheet,double totalRtHour,double totalOtHour,double totalDotHour,ArrayList totalColoumnREG,ArrayList totalColoumnOT,ArrayList totalColoumnDOT)
    {
        this.DeleteFlag = DeleteFlag;
        this.EmpNo = EmpNo;
        this.RowNo = RowNo;
        this.TimeSheet = TimeSheet;
        this.EmpName = EmpName;
        this.TradeCode = tradeCode;
        this.TradeName = tradeName;
        this.totalRtHour = totalRtHour;
        this.totalOtHour = totalOtHour;
        this.totalDotHour = totalDotHour;
        this.totalColoumnREG = totalColoumnREG;
        this.totalColoumnOT = totalColoumnOT;
        this.totalColoumnDOT = totalColoumnDOT;
    }
    public EmployeeDataForCrew()
    {
    }

    public EmployeeDataForCrew(String EmpNo,String EmpName ,String tradeCode,String tradeName)
    {
        this.DeleteFlag = DeleteFlag;
        this.EmpNo = EmpNo;
        this.RowNo = RowNo;
        this.TimeSheet = TimeSheet;
        this.EmpName = EmpName;
        this.TradeCode = tradeCode;
        this.TradeName = tradeName;
    }

    public TimeInOutModal getTimeInOutModals() {
        return timeInOutModals;
    }

    public void setTimeInOutModals(TimeInOutModal timeInOutModals) {
        this.timeInOutModals = timeInOutModals;
    }



    public String getTotalTimeInOut() {
        return TotalTimeInOut;
    }

    public void setTotalTimeInOut(String totalTimeInOut) {
        TotalTimeInOut = totalTimeInOut;
    }


    public void setTotalColoumnDOT(ArrayList<Double> totalColoumnDOT) {
        this.totalColoumnDOT = totalColoumnDOT;
    }

    public void setTotalColoumnOT(ArrayList<Double> totalColoumnOT) {
        this.totalColoumnOT = totalColoumnOT;
    }

    public String getEmployeeOraseq() {
        return employeeOraseq;
    }

    public void setEmployeeOraseq(String employeeOraseq) {
        this.employeeOraseq = employeeOraseq;
    }

    public void setTotalColoumnREG(ArrayList<Double> totalColoumnREG) {
        this.totalColoumnREG = totalColoumnREG;
    }

    public ArrayList<Double> getTotalColoumnDOT() {
        return totalColoumnDOT;
    }

    public ArrayList<Double> getTotalColoumnOT() {
        return totalColoumnOT;
    }

    public ArrayList<Double> getTotalColoumnREG() {
        return totalColoumnREG;
    }

    public String getDeleteFlag() {
        return DeleteFlag;
    }

    public ArrayList<ActivityTimeForCrew> getTimeSheet()
    {
        return TimeSheet;
    }


    public String getEmpNo() {
        return EmpNo;
    }

    public String getRowNo()
    {
        Log.d("RowNUmber : ", RowNo);
        return RowNo;
    }

    public String getEmpName() {
        return EmpName;
    }

    public String getTradeCode() {
        return TradeCode;
    }

    public String getTradeName() {
        return TradeName;
    }

    public String setEmpName(String empName)
    {
        EmpName = empName;
        return EmpName;
    }

    public void setTradeCode(String tradeCode) {
        TradeCode = tradeCode;
    }

    public void setTradeName(String tradeName) {
        TradeName = tradeName;
    }

    public void setDeleteFlag(String deleteFlag) {
        DeleteFlag = deleteFlag;
    }

    public void setEmpNo(String empNo) {
        EmpNo = empNo;
    }

    public void setRowNo(String rowNo) {
        RowNo = rowNo;
    }
    public void setTimeSheet(ArrayList<ActivityTimeForCrew> TimeSheet)
    {
        this.TimeSheet = TimeSheet;
    }

    public Double getTotalRtHour() {
        return totalRtHour;
    }

    public void setTotalRtHour(Double totalRtHour) {
        this.totalRtHour = totalRtHour;
    }

    public Double getTotalDotHour() {
        return totalDotHour;
    }

    public void setTotalDotHour(Double totalDotHour) {
        this.totalDotHour = totalDotHour;
    }

    public Double getTotalOtHour() {
        return totalOtHour;
    }

    public void setTotalOtHour(Double totalOtHour) {
        this.totalOtHour = totalOtHour;
    }

    public void setTotalOtHour(double totalOtHour) {
        this.totalOtHour = totalOtHour;
    }

    public void setTotalDotHour(double totalDotHour) {
        this.totalDotHour = totalDotHour;
    }

    public void setTotalRtHour(double totalRtHour) {
        this.totalRtHour = totalRtHour;
    }

}