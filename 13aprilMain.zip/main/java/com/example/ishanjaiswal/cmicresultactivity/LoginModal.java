package com.example.ishanjaiswal.cmicresultactivity;

public class LoginModal
{
    public String Type, Description, HrtFirstName, HrtLastName,HrtEmpNo,HrtTrdCode,HrtTrdName;


    public String getDescription() {
        return Description;
    }

    public String getHrtEmpNo() {
        return HrtEmpNo;
    }

    public String getHrtFirstName() {
        return HrtFirstName;
    }

    public String getHrtLastName() {
        return HrtLastName;
    }

    public String getHrtTrdCode() {
        return HrtTrdCode;
    }

    public String getHrtTrdName() {
        return HrtTrdName;
    }

    public String getType() {
        return Type;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public void setHrtEmpNo(String hrtEmpNo) {
        HrtEmpNo = hrtEmpNo;
    }

    public void setHrtFirstName(String hrtFirstName) {
        HrtFirstName = hrtFirstName;
    }

    public void setHrtLastName(String hrtLastName) {
        HrtLastName = hrtLastName;
    }

    public void setHrtTrdCode(String hrtTrdCode) {
        HrtTrdCode = hrtTrdCode;
    }

    public void setHrtTrdName(String hrtTrdName) {
        HrtTrdName = hrtTrdName;
    }

    public void setType(String type) {
        Type = type;
    }

}
