package com.example.ishanjaiswal.cmicresultactivity.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ishan.jaiswal on 2/20/2018.
 */

public class CollectionUtils {
    private CollectionUtils(){
    }

    public static HashMap<String, Integer> dayConverter(){
        HashMap<String , Integer> hashMap = new HashMap<>();
        hashMap.put("Sunday",1);
        hashMap.put("Monday",2);
        hashMap.put("Tuesday",3);
        hashMap.put("Wednesday",4);
        hashMap.put("Thursday",5);
        hashMap.put("Friday",6);
        hashMap.put("Saturday",7);
        return hashMap;
    }


    public static ArrayList<String> getWeek(String day){
        ArrayList<String> list = new ArrayList<>();
        ArrayList<String> week = new ArrayList<>();
        week.add("NULL");
        week.add("Sunday");
        week.add("Monday");
        week.add("Tuesday");
        week.add("Wednesday");
        week.add("Thursday");
        week.add("Friday");
        week.add("Saturday");
        HashMap<String , Integer> hashMap = dayConverter();
        int dayNum = hashMap.get(day).intValue();
        for (int i = dayNum; i<=7; i++)
            list.add(week.get(i));
        for (int i = 1; i<dayNum; i++)
            list.add(week.get(i));
        return list;
    }

    public static final HashMap<Integer,String> hashMapStatusCodes = new HashMap<Integer, String>()
    {{
        put(400,"Bad Request");
        put(401,"Unauthorized");
        put(403,"Forbidden");
        put(404,"Not Found");
        put(500,"Internal Server Error");
    }};

    public static final HashMap<String ,Integer> reverseHashMapStatusCodes = new HashMap<String, Integer>()
    {{
        put("Bad Request",400);
        put("Unauthorized",401);
        put("Forbidden",403);
        put("Not Found",404);
        put("Internal Server Error",500);
    }};
}
