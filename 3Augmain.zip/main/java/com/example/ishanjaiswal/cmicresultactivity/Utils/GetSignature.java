package com.example.ishanjaiswal.cmicresultactivity.Utils;

/**
 * Created by ishan.jaiswal on 5/7/2018.
 */

public enum GetSignature {
    CREWTIME_FOREMAN_SIGNATURE,
    CREWTIME_EMPLOYEE_SIGNATURE
}
