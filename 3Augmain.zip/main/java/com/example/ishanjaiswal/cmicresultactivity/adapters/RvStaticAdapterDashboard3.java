package com.example.ishanjaiswal.cmicresultactivity.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard3;
import com.example.ishanjaiswal.cmicresultactivity.R;

import java.util.List;

/**
 * Created by ishan.jaiswal on 1/30/2018.
 */

public class RvStaticAdapterDashboard3 extends RecyclerView.Adapter<RvStaticAdapterDashboard3.ViewHolder> {

    private List<Dashboard3> mList;
    private Context mContext;

    public RvStaticAdapterDashboard3(List<Dashboard3> mList, Context mContext) {
        this.mList = mList;
        this.mContext = mContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_static_dashboard2,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Dashboard3 dashboard3 = mList.get(position);
        AllTimes allTimesTotal = dashboard3.getTotalTime();
        holder.tvCrewMemberName.setText(dashboard3.getTshJobName());
        holder.tvRegTotal.setText(String.valueOf(allTimesTotal.getReg()));
        holder.tvOtTotal.setText(String.valueOf(allTimesTotal.getOt()));
        holder.tvDotTotal.setText(String.valueOf(allTimesTotal.getDot()));
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(List<Dashboard3> mList) {
        this.mList = mList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCrewMemberName,crewMemberCode, tvRegTotal, tvOtTotal, tvDotTotal;

        public ViewHolder(View itemView) {
            super(itemView);
            tvCrewMemberName = (TextView)itemView.findViewById(R.id.tvCrewMemberNameDashboard2);
            tvRegTotal = (TextView)itemView.findViewById(R.id.tvREGValue);
            tvOtTotal = (TextView)itemView.findViewById(R.id.tvOTValue);
            tvDotTotal = (TextView)itemView.findViewById(R.id.tvDOTValue);
        }
    }
}