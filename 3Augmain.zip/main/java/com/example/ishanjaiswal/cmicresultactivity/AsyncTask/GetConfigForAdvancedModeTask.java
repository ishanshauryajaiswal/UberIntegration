package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

public class GetConfigForAdvancedModeTask extends AsyncTask<Void,Void,String > {

    private BasicTaskListenerInterface mTaskListener;
    private Context mContext;
    private String progressMessage;

    public GetConfigForAdvancedModeTask(Context mContext, String progressMessage, BasicTaskListenerInterface taskListener) {
        this.mTaskListener = taskListener;
        this.mContext = mContext;
        this.progressMessage = progressMessage;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mTaskListener.onTaskStarted(progressMessage);
        }
    }

    @Override
    protected String doInBackground(Void... voids) {
        String response = "";
        RequestCall requestCall = new RequestCall(mContext);
        response = requestCall.getConfig(mContext);
        return response;
    }

    @Override
    protected void onPostExecute(String response) {
        super.onPostExecute(response);
        mTaskListener.onTaskComplete(response);
    }
}
