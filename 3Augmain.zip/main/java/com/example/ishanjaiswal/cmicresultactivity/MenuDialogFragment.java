package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Utils.ScreenUtil;

/**
 * Created by ishan.jaiswal on 5/30/2018.
 */

public class MenuDialogFragment extends DialogFragment {

    public interface MenuDialogListener{
        void addCrewMember();
        void switchCrew();
        void addActivity();
        void notifyApprover();
        void switchRegularAdvancedMode();
        void switchInOutMode();
        void clearData();
        void logout();
        void settings();
        void cancel();
    }
    private Context mContext;
    private MenuDialogListener mListener;
    private TextView tvCancel, tvClearData, tvNotifyApprover, tvAddActivity, tvSwitchRegularAdvancedMode
            ,tvAddCrewMember, tvLogout, tvSwitchCrew, tvSwitchInOutMode, tvSettingsScreen;
    private boolean isRegularModeSelected, isInOutModeSelected;

    public void setListener(MenuDialogListener mListener) {
        this.mListener = mListener;
    }

    public static MenuDialogFragment newInstance(MenuDialogListener listener){
        MenuDialogFragment menuDialogFragment = new MenuDialogFragment();
        menuDialogFragment.setListener(listener);
        return menuDialogFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        return  inflater.inflate(R.layout.dialog_menu,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getValuesFromSharedPreference();
        initView(view);
    }

    public void onResume()
    {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout(getResources().getDimensionPixelSize(R.dimen.dialog_menu_width),
                getResources().getDimensionPixelSize(R.dimen.dialog_menu_height));
        window.setGravity(Gravity.CENTER);
    }

    private void getValuesFromSharedPreference() {
        SharedPreferences defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(mContext);
        isRegularModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_regular_mode),false);
        isInOutModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_inout_mode),false);
    }

    private void initView(View view) {
        tvCancel = (TextView) view.findViewById(R.id.cancel);
        tvClearData = (TextView) view.findViewById(R.id.cleardata);
        tvNotifyApprover = (TextView) view.findViewById(R.id.notifyapprover);
        tvAddActivity = (TextView) view.findViewById(R.id.addactivity);
        tvSwitchRegularAdvancedMode = (TextView) view.findViewById(R.id.switchtoregularmode);
        tvAddCrewMember = (TextView) view.findViewById(R.id.addcrewmember);
        tvSettingsScreen = (TextView) view.findViewById(R.id.txtsettingscreen);
        tvLogout = (TextView) view.findViewById(R.id.txtlogout);
        tvSwitchCrew = (TextView) view.findViewById(R.id.switchcrew);
        tvSwitchInOutMode = (TextView) view.findViewById(R.id.inOutmode);
        if (isRegularModeSelected)
            tvSwitchRegularAdvancedMode.setText("Switch To Advanced Mode");
        else
            tvSwitchRegularAdvancedMode.setText("Switch to Regular Mode");
        if (isInOutModeSelected)
            tvSwitchInOutMode.setText("Switch To TimeSheet Mode");
        else
            tvSwitchInOutMode.setText("Switch To In/Out Mode");

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
               mListener.cancel();
            }
        });

        tvClearData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.clearData();
            }
        });
        tvNotifyApprover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.notifyApprover();
            }
        });
        tvLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.logout();
            }
        });
        tvSwitchCrew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.switchCrew();
            }
        });
        tvAddActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.addActivity();
            }
        });
        tvSettingsScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.settings();
            }
        });
        tvAddCrewMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.addCrewMember();
            }
        });
        tvSwitchInOutMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.switchInOutMode();
            }
        });
        tvSwitchRegularAdvancedMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.switchRegularAdvancedMode();
            }
        });
    }
}
