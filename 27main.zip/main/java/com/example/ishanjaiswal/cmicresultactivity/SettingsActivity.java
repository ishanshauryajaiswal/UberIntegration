package com.example.ishanjaiswal.cmicresultactivity;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.util.Log;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

public class SettingsActivity extends AppCompatPreferenceActivity {
    private static final String TAG = SettingsActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction().replace(android.R.id.content,new MainPreferenceFragment()).commit();
        getSupportActionBar().setTitle("Settings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    public static class MainPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(final Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_main);
            changeColor();
            initViews();
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_server)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_environment)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_public_cloud)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_switch_regular_mode)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_switch_inout_mode)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_switch_auto_login)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_switch_phase_name_mode)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_normal_time)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_over_time)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_max_normal_time)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_start_day)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_approver_contact)));
            bindPreferenceSummaryToValue(findPreference(getString(R.string.settings_key_approver_email)));

        }
        private void changeColor() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Window window = getActivity().getWindow();
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(getResources().getColor(R.color.colorRed));
            }
        }

        private void initViews(){
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
            findPreference(getString(R.string.settings_key_server)).setSummary(sp.getString(getString(R.string.settings_key_server),
                    getString(R.string.settings_server_default)));
            findPreference(getString(R.string.settings_key_environment)).setSummary(sp.getString(getString(R.string.settings_key_environment),
                    getString(R.string.settings_environment_default)));
            findPreference(getString(R.string.settings_key_normal_time)).setSummary(sp.getString(getString(R.string.settings_key_normal_time),
                    getString(R.string.settings_normal_time_default)));
            findPreference(getString(R.string.settings_key_over_time)).setSummary(sp.getString(getString(R.string.settings_key_over_time),
                    getString(R.string.settings_over_time_default)));
            findPreference(getString(R.string.settings_key_max_normal_time)).setSummary(sp.getString(getString(R.string.settings_key_max_normal_time),
                    getString(R.string.settings_max_normal_time_default)));
            findPreference(getString(R.string.settings_key_approver_contact)).setSummary(sp.getString(getString(R.string.settings_key_approver_contact),
                    ""));
            findPreference(getString(R.string.settings_key_approver_email)).setSummary(sp.getString(getString(R.string.settings_key_approver_email),
                    ""));
            findPreference(getString(R.string.settings_key_start_day)).setSummary(sp.getString(getString(R.string.settings_key_start_day),
                    getString(R.string.settings_start_day_default)));
            SwitchPreference switchPublicCloud = (SwitchPreference) findPreference(getString(R.string.settings_key_public_cloud));
            SwitchPreference switchRegularMode = (SwitchPreference) findPreference(getString(R.string.settings_key_switch_regular_mode));
            SwitchPreference switchInOutMode = (SwitchPreference) findPreference(getString(R.string.settings_key_switch_inout_mode));
            SwitchPreference switchAutoLogin = (SwitchPreference) findPreference(getString(R.string.settings_key_switch_auto_login));
            SwitchPreference switchPhaseNameMode = (SwitchPreference) findPreference(getString(R.string.settings_key_switch_phase_name_mode));
            boolean bool = sp.getBoolean(getString(R.string.settings_key_public_cloud),false);
            switchPublicCloud.setChecked(bool);
            bool = sp.getBoolean(getString(R.string.settings_key_switch_regular_mode),true);
            switchRegularMode.setChecked(bool);
            bool = sp.getBoolean(getString(R.string.settings_key_switch_inout_mode),false);
            switchInOutMode.setChecked(bool);
            bool = sp.getBoolean(getString(R.string.settings_key_switch_auto_login),false);
            switchAutoLogin.setChecked(bool);
            bool = sp.getBoolean(getString(R.string.settings_key_switch_phase_name_mode),false);
            switchPhaseNameMode.setChecked(bool);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private static void bindPreferenceSummaryToValue(Preference preference) {
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);
        /*sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));*/
    }

    private static Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            int a=10;
            int c = ++a;
            //String stringValue = newValue.toString();

            if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                String stringValue = newValue.toString();
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            } else if (preference instanceof EditTextPreference) {
                Log.d(TAG,"Summary "+preference.getSummary().toString());
                String stringValue = newValue.toString();
                //SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(preference.getContext());
                //String s = preferences.getString(preference.getKey(),"0");
                //Log.d(TAG,"previous "+s);
                preference.setSummary(stringValue);
                preference.setDefaultValue(stringValue);
                //preferences.edit().putString(preference.getKey(),stringValue).commit();
                //s = preferences.getString(preference.getKey(),"0");
                //Log.d(TAG,"final "+s);
            } else {
                Log.d(TAG,"Switch fired");
            }
            return true;
        }
    };

}
