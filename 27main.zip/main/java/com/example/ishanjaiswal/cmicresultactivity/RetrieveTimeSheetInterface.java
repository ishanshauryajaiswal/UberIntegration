package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by ishan.jaiswal on 2/15/2018.
 */

public interface RetrieveTimeSheetInterface
{
    public void RetrieveTimeSheetInterface(String result);
    public void BeforeCompletion();
}