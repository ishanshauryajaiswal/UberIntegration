package com.example.ishanjaiswal.cmicresultactivity.Model;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */
public class CrewTimeSheet implements Serializable
{
    private String SeqNo;
    private boolean edited;
    private String CrewCode = null;
    private String WorkDate = null;
    private String JobCode = null;
    private String JobCompCode = null;
    private ArrayList<SubmittedActivityFromCrewModal> CrewActivity;
    private ArrayList<EmployeeDataForCrew> EmpTimeSheet;
    private double totalOfTimeInOut;


    public CrewTimeSheet(String SeqNo, String CrewCode, String WorkDate, String JobCode,String JobCompCode, ArrayList<SubmittedActivityFromCrewModal> CrewActivity, ArrayList<EmployeeDataForCrew> EmpTimeSheet) {
        this.edited = false;
        this.SeqNo = SeqNo;
        this.CrewCode = CrewCode;
        this.WorkDate = WorkDate;
        this.JobCode = JobCode;
        this.JobCompCode = JobCompCode;
        this.CrewActivity = CrewActivity;
        this.EmpTimeSheet = EmpTimeSheet;
    }

    public CrewTimeSheet() {

    }

    public String getJobCompCode() {
        return JobCompCode;
    }

    public void setJobCompCode(String jobCompCode) {
        JobCompCode = jobCompCode;
    }

    public ArrayList<SubmittedActivityFromCrewModal> getCrewActivity() {
        return CrewActivity;
    }

    public ArrayList<EmployeeDataForCrew> getEmpTimeSheet() {
        return EmpTimeSheet;
    }

    public String getCrewCode() {
        return CrewCode;
    }

    public String getJobCode() {
        return JobCode;
    }

    public String getSeqNo() {
        return SeqNo;
    }

    public String getWorkDate() {
        return WorkDate;
    }

    public void setCrewActivity(ArrayList CrewActivity) {
        this.CrewActivity = CrewActivity;
    }

    public void setCrewCode(String crewCode) {
        CrewCode = crewCode;
    }

    public void setEmpTimeSheet(ArrayList<EmployeeDataForCrew> empTimeSheet) {
        EmpTimeSheet = empTimeSheet;
    }

    public void setJobCode(String jobCode) {
        JobCode = jobCode;
    }

    public void setSeqNo(String seqNo) {
        Log.d("set sq no", seqNo);
        SeqNo = seqNo;
    }

    public void setWorkDate(String workDate) {
        WorkDate = workDate;
    }

    public EmployeeDataForCrew getEmployeeWithEmpNo(String empNo){
        for (EmployeeDataForCrew e : EmpTimeSheet){
            if (e.getEmpNo().equalsIgnoreCase(empNo))
                return e;
        }
        return null;
    }
    public boolean isEdited() {return edited;}

    public void setEdited(boolean edited) {this.edited = edited;}
}
