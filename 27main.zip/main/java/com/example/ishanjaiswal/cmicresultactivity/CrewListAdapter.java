package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by parneet.singh on 10/21/2016.
 */

public class CrewListAdapter extends ArrayAdapter {
    private Activity context;
    private List<InsertCrew> originalData = null;
    Typeface tf;
    private LayoutInflater mInflater;

    private ArrayList<InsertCrew> insertCrews;

    public CrewListAdapter(Activity context, ArrayList<InsertCrew> insertCrews) {

        super(context, R.layout.item_user, insertCrews);
        //     this.filteredData = insertCrews;
        this.context = context;
        this.insertCrews = insertCrews;
        mInflater = LayoutInflater.from(context);

    }

    public void setList(ArrayList<InsertCrew> list) {
        insertCrews = list;
        notifyDataSetChanged();
    }

    public int getCount() {
        return insertCrews.size();
    }

    public InsertCrew getItem(int position) {
        return insertCrews.get(position);
    }

    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.crew_list_item_cell, null);
        TextView txtresponsiblename = (TextView) listViewItem.findViewById(R.id.txtresponsiblename);
        TextView textViewName = (TextView) listViewItem.findViewById(R.id.crewname);
        TextView textViewCode = (TextView) listViewItem.findViewById(R.id.crewcode);
        TextView textarrow = (TextView) listViewItem.findViewById(R.id.txtarrow);
        //tf = Typeface.createFromAsset(getContext().getAssets(), "cmic_icons.ttf");
        textarrow.setTypeface(tf);
        textViewName.setText("- " + insertCrews.get(position).getPycrName());
        textViewCode.setText("(" + insertCrews.get(position).getPycrCode() + ")");
        //!insertCrews.get(position).getPycrResponsibleEmpName().equals("") || !insertCrews.get(position).getPycrResponsibleEmpName().equals("null") ||
        if ( insertCrews.get(position).getPycrResponsibleEmpName() == null ||insertCrews.get(position).getPycrResponsibleEmpName().equals("null") || insertCrews.get(position).getPycrResponsibleEmpName().equals(""))
        {
            txtresponsiblename.setText(" Not Assigned ");
        }
        else
        {
            txtresponsiblename.setText(insertCrews.get(position).getPycrResponsibleEmpName());
        }
        return listViewItem;
    }

}