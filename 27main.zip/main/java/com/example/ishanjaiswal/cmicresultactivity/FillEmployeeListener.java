package com.example.ishanjaiswal.cmicresultactivity;

/**
  Created by parneet.singh on 10/20/2016.
 */
public interface FillEmployeeListener {

    public void afterCompleted(String result);
    void beforeCompleted();
}
