package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */

public class ProjectListAdapter extends BaseAdapter
{
    private ArrayList<JobData> jobDataArrayList;
    private Activity context;
    Typeface tf;
    boolean flag;
    public ProjectListAdapter(Activity context, ArrayList<JobData> jobDataArrayList,boolean flag)
    {
        this.context = context;
        this.flag = flag;
        this.jobDataArrayList = jobDataArrayList;
    }
    @Override
    public int getCount()
    {
        if (jobDataArrayList != null)
            return jobDataArrayList.size();
        return 0;
    }
    public  void  setList(ArrayList<JobData> list)
    {
        jobDataArrayList = list;
        notifyDataSetChanged();
    }
    @Override
    public JobData getItem(int position)
    {
        return jobDataArrayList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        TextView txtarrow ;
        JobData jobData = getItem(position);
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.project_list_row, null);
        ImageView imglist = (ImageView) listViewItem.findViewById(R.id.imglist);

        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtProject);
        txtarrow= (TextView) listViewItem.findViewById(R.id.imgarrow);
//        tf = Typeface.createFromAsset(context.getAssets(), "cmic_icons.ttf");
//        txtarrow.setTypeface(tf);
        if(flag)
        {
            imglist.setVisibility(View.VISIBLE);
            txtarrow.setVisibility(View.VISIBLE);
        }
        else
        {
            imglist.setVisibility(View.GONE);
            txtarrow.setVisibility(View.GONE);
        }
        txt_project.setText(jobData.getJobcode() + " - " + jobData.getJobname());
        return listViewItem;
    }

}