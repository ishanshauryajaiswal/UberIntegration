package com.example.ishanjaiswal.cmicresultactivity; /**
 * Created by ishan.jaiswal on 2/6/2018.
 */

import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

/**
 Created by parneet.singh on 10/26/2016.
 */
public interface CrewListInterface
{
    public void selectCrewList(ArrayList<InsertCrew> result);
    public void Beforecompletion();
}
