package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class DashboardTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private String compCode,jobCode,workDate;
    private DashboardTaskListener mLisetener;

    public DashboardTask(Context context,String compCode,String jobCode,String workDate, DashboardTaskListener mListener)
    {

        this.context = context;
        this.compCode = compCode;
        this.jobCode = jobCode;
        this.workDate = workDate;
        this.mLisetener = mListener;
    }

    @Override
    protected void onPreExecute()
    {
        mLisetener.beforeDashboardTaskStarted("Fetching");
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        try
        {
            RequestCall requestCall = new RequestCall(context);
            result = requestCall.dashboardTask(context,compCode,jobCode,workDate );
        }
        catch(Exception e)
        {
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        mLisetener.onDashboardTaskComplete(response);
    }

}