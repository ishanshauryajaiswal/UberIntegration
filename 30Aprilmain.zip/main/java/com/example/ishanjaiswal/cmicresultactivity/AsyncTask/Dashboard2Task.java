package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/23/2018.
 */

public class Dashboard2Task extends AsyncTask<Void,Void,String> {

    private Context mContext;
    String jobCompCode, jobCode;
    String crewCode,date;
    private boolean flagJobSelected;
    private DashboardTaskListener mListener;

    public Dashboard2Task(Context mContext, String crewCode, String date, DashboardTaskListener mListener, boolean flagJobSelected) {
        this.mContext = mContext;
        this.crewCode = crewCode;
        this.date = date;
        this.mListener = mListener;
        this.flagJobSelected = flagJobSelected;
    }

    public Dashboard2Task(Context mContext, String jobCompCode, String jobCode, String crewCode, String date, DashboardTaskListener mListener,boolean flagJobSelected) {
        this.mContext = mContext;
        this.jobCompCode = jobCompCode;
        this.jobCode = jobCode;
        this.crewCode = crewCode;
        this.date = date;
        this.flagJobSelected = flagJobSelected;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mListener.beforeDashboardTaskStarted("Fetching");
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try {
            RequestCall requestCall = new RequestCall(mContext);
            if (flagJobSelected)
                response = requestCall.dashboardMembers(mContext, jobCompCode, jobCode, date, crewCode);
            else
                response = requestCall.personDashboardMembers(mContext, crewCode, date);
            return response;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(String response) {
        super.onPostExecute(response);
        mListener.onDashboard2TaskComplete(response);
    }
}
