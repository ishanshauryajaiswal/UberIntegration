package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.TempModel;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/1/2018.
 */

public class RvDynamicAdapter extends RecyclerView.Adapter<RvDynamicAdapter.ViewHolder> {
    private ArrayList<EmployeeDataForCrew> mList;
    private Context mContext;
    CustomClickListener customClickListener;

    public RvDynamicAdapter(ArrayList<EmployeeDataForCrew> mList, Context mContext) {
        this.mList = mList;
        this.mContext = mContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout ll = new LinearLayout(mContext);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.WRAP_CONTENT,
                RecyclerView.LayoutParams.WRAP_CONTENT);
        ll.setLayoutParams(layoutParams);
        return new ViewHolder(ll, mContext, mList.get(0).getTimeSheet().size());
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        EmployeeDataForCrew employeeDataForCrew = mList.get(position);
        TextView regValue, otValue, dotValue;
        int size = holder.linearLayoutArray.length;
        ArrayList<ActivityTimeForCrew> activityTimeForCrew = employeeDataForCrew.getTimeSheet();
        for (int i = 0; i < activityTimeForCrew.size(); i++){
            LinearLayout l = holder.linearLayoutArray[i];
            regValue = (TextView) l.getChildAt(0);
            otValue = (TextView) l.getChildAt(1);
            dotValue = (TextView) l.getChildAt(2);
            regValue.setText(activityTimeForCrew.get(i).getStandardTime()+"");
            otValue.setText(activityTimeForCrew.get(i).getOverTime()+"");
            dotValue.setText(activityTimeForCrew.get(i).getDoubleOverTime()+"");
            final int activityPosition = i;
            l.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    customClickListener.rowItemClicked(position, activityPosition);
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(ArrayList<EmployeeDataForCrew> mList) {
        this.mList = mList;
    }

    public void setCustomClickListener(CustomClickListener customClickListener) {
        this.customClickListener = customClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        Context mContext;
        LinearLayout linearLayoutArray[];
        public ViewHolder(View itemView, Context context, int numberOfActivities) {
            super(itemView);
            this.mContext = context;
            numberOfActivities = mList.get(0).getTimeSheet().size();
            linearLayoutArray = new LinearLayout[numberOfActivities];
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            LinearLayout linearLayout = (LinearLayout) itemView;
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setLayoutParams(params);
            linearLayout.removeAllViews();
            for (int i = 0; i < numberOfActivities; i++) {
                linearLayoutArray[i] = addLinearLayout();
                linearLayout.addView(linearLayoutArray[i]);
            }
        }

        private LinearLayout addLinearLayout() {
            LinearLayout linearLayoutRow;
            TextView regValue, otValue, dotValue;
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(dpToPx(180),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            linearLayoutRow = new LinearLayout(mContext);
            linearLayoutRow.removeAllViews();
            linearLayoutRow.setOrientation(LinearLayout.HORIZONTAL);
            linearLayoutRow.setLayoutParams(rowParams);
            int whiteColor = ContextCompat.getColor(mContext,R.color.colorWhite);
            int blueColor = ContextCompat.getColor(mContext,R.color.colorLightBlue);
            //linearLayoutRow.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            LinearLayout.LayoutParams tvSmallParams = new TableRow.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))), 1f);

            regValue = new TextView(mContext);
            regValue.setLayoutParams(tvSmallParams);
            regValue.setGravity(Gravity.CENTER);
            regValue.setTextColor(Color.BLACK);
            regValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            regValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));


            otValue = new TextView(mContext);
            otValue.setLayoutParams(tvSmallParams);
            otValue.setGravity(Gravity.CENTER);
            otValue.setTextColor(Color.BLACK);
            otValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            otValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            dotValue = new TextView(mContext);
            dotValue.setLayoutParams(tvSmallParams);
            dotValue.setGravity(Gravity.CENTER);
            dotValue.setTextColor(Color.BLACK);
            dotValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            dotValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            LinearLayout.LayoutParams viewDividerParams = new LinearLayout.LayoutParams(dpToPx(1),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            LinearLayout viewDivider = new LinearLayout(mContext);
            viewDivider.removeAllViews();
            viewDivider.setLayoutParams(viewDividerParams);
            viewDivider.setBackgroundColor(blueColor);

            linearLayoutRow.addView(regValue); linearLayoutRow.addView(otValue); linearLayoutRow.addView(dotValue);
            linearLayoutRow.addView(viewDivider);
            return linearLayoutRow;
        }

        public int dpToPx(int dp) {
            DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
            return Math.round(dp * displayMetrics.density+0.5f);
        }
    }
}
