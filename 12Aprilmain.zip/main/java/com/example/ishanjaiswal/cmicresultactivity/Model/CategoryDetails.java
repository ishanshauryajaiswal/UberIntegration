package com.example.ishanjaiswal.cmicresultactivity.Model;

public class CategoryDetails
{

    String categoryJobCode, categoryName, phaseCode;
    String categoryCode;
    public CategoryDetails(String categoryJobCode, String categoryCode, String categoryName, String phaseCode)
    {
        this.categoryJobCode = categoryJobCode;
        this.categoryCode = categoryCode;
        this.categoryName = categoryName;
        this.phaseCode = phaseCode;
    }
    public CategoryDetails( String categoryName)
    {
        this.categoryName = categoryName;
    }


    public String getCategoryName()
    {
        return categoryName;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public String getCategoryJobCode() {
        return categoryJobCode;
    }

    public String getPhaseCode() {
        return phaseCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public void setCategoryJobCode(String categoryJobCode) {
        this.categoryJobCode = categoryJobCode;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setPhaseCode(String phaseCode) {
        this.phaseCode = phaseCode;
    }
}