package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;

/**
 * Created by ishan.jaiswal on 4/12/2018.
 */

public class InOutPopup extends Dialog {
    private Context mContext;
    public TextView cancel, clearData;
    public TextView breakTime1, breakTime2, breakTime3, breakTime4;
    public TextView timeIn1, timeIn2, timeIn3, timeIn4, timeIn5;
    public TextView timeOut1, timeOut2, timeOut3, timeOut4, timeOut5;
    public TextView total1, total2, total3, total4, total5;
    public Button btnOk;

    public InOutPopup(@NonNull Context context) {
        super(context);
        this.mContext = context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.timein_timeout);
        initViews();
    }

    private void initViews() {
        breakTime1 = (TextView) this.findViewById(R.id.breaktime1);
        breakTime2 = (TextView) findViewById(R.id.breaktime2);
        breakTime3 = (TextView) findViewById(R.id.breaktime3);
        breakTime4 = (TextView) findViewById(R.id.breaktime4);
        timeIn1 = (TextView) findViewById(R.id.timein1);
        timeIn2 = (TextView) findViewById(R.id.timein2);
        timeIn3 = (TextView) findViewById(R.id.timein3);
        timeIn4 = (TextView) findViewById(R.id.timein4);
        timeIn5 = (TextView) findViewById(R.id.timein5);
        timeOut1 = (TextView) findViewById(R.id.timeout1);
        timeOut2 = (TextView) findViewById(R.id.timeout2);
        timeOut3 = (TextView) findViewById(R.id.timeout3);
        timeOut4 = (TextView) findViewById(R.id.timeout4);
        timeOut5 = (TextView) findViewById(R.id.timeout5);
        total1 = (TextView) findViewById(R.id.total1);
        total2 = (TextView) findViewById(R.id.total2);
        total3 = (TextView) findViewById(R.id.total3);
        total4 = (TextView) findViewById(R.id.total4);
        total5 = (TextView) findViewById(R.id.total5);
        cancel = (TextView) findViewById(R.id.cancel);
        clearData = (TextView) findViewById(R.id.cleardata);
        btnOk = (Button) findViewById(R.id.btndone);

        breakTime1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                int mHour = c.get(Calendar.HOUR_OF_DAY);
                int mMinute = c.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(mContext, R.style.DatePickerDailog,null,mHour,mMinute,false);
                timePickerDialog.show();
            }
        });
    }

}
