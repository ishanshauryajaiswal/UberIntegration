package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.CategoryInterface;
import com.example.ishanjaiswal.cmicresultactivity.PhaseInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


public class GetPhaseTask extends AsyncTask<Void, Void, String> {


    String jobcode, compcode;
    Context context;
    PhaseInterface phaseInterface;
    CategoryInterface categoryInterface;

    public GetPhaseTask(Context context, String compcode, String jobcode, PhaseInterface phaseInterface, CategoryInterface categoryInterface) {
        this.context = context;
        this.jobcode = jobcode;
        this.compcode = compcode;
        this.phaseInterface = phaseInterface;
        this.categoryInterface = categoryInterface;
    }

    public GetPhaseTask(Context context, String authEncode, String compcode, String jobcode) {
        this.context = context;
        this.compcode = compcode;
        this.jobcode = jobcode;
    }

    @Override
    protected void onPreExecute()
    {
        phaseInterface.Dialog();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try {
            RequestCall requestCall = new RequestCall();
            response = requestCall.phaseWithChild(context, compcode, jobcode);
            Log.d("PhaseTask", response);
            return response;
        } catch (Exception e) {
            Log.e("errormainactivity", e.toString());
            return null;
        }


    }

    @Override
    protected void onPostExecute(String response) {

        super.onPostExecute(response);

        if (response == null) {
           //Log.d("Response is null", response);
            if (phaseInterface != null) {
                phaseInterface.onEnd(null);
            }
            if (categoryInterface != null) {
                categoryInterface.onEndCat(null);
            }
        } else
        {
          //  Log.d("GetPhaseTask", response);
            phaseInterface.onEnd(response);
            categoryInterface.onEndCat(response);

        }
    }
}
