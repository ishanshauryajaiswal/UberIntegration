package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */
public class JobData
{
    public String jobcompcode, jobname, jobcode, compname;


    public void setJobcompcode(String jobcompcode)
    {
        this.jobcompcode = jobcompcode;
    }

    public void setJobname(String jobname)
    {
        this.jobname = jobname;
    }

    public void setJobcode(String jobcode)
    {
        this.jobcode = jobcode;
    }

    public void setCompname(String compname)
    {
        this.compname = compname;
    }


    public String getJobcompcode()

    {
        return jobcompcode;
    }
    public String getJobname()

    {
        return jobname;
    }
    public String getJobcode()
    {
        return jobcode;
    }
    public String getCompname()

    {
        return compname;
    }
}
