package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.InsertCrew;

import java.util.ArrayList;

/**
 Created by parneet.singh on 10/26/2016.
 */
public class CrewListActivityTask extends AsyncTask<Void,Void,String>
{
    private static final String TAG = CrewListActivityTask.class.getSimpleName();
    private String authCode;
    private Context context;
    private String crewCode;
    private CrewListInterface crewListInterface;
    public CrewListActivityTask(String authCode,Context context,CrewListInterface crewListInterface)
    {
        this.authCode = authCode;
        this.context = context;
        this.crewCode = crewCode;
        this.crewListInterface = crewListInterface;
    }

    @Override
    protected void onPreExecute()
    {
        crewListInterface.onPreCrewListTask();
        super.onPreExecute();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall();
        response = requestCall.selectCrewList(context,authCode);

        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        if(response!=null)
        {
            CrewCreationParser crewCreationParser = new CrewCreationParser();
            ArrayList<InsertCrew> insertedArrayList = crewCreationParser.parseInsertCrewData(response);
            crewListInterface.onPostCrewListTask(insertedArrayList);
        }
        else
        {
            Log.d(TAG, "Error in Fetching Crews");
        }
    }
}
