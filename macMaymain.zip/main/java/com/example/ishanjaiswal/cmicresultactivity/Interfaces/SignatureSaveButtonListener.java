package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

import com.example.ishanjaiswal.cmicresultactivity.Utils.PostSignature;

public interface SignatureSaveButtonListener {
    void enableSaveButton(PostSignature enumSignature);
}
