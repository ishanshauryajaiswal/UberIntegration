package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by parneet.singh on 8/18/2017.
 */
public class SingletonData
{
    private static SingletonData ourInstance;
    public int EmployeeCrewActivitySize = 0 ;
    public int crewActivitySizeFromServer;
    public static SingletonData getInstance()
    {
        if (ourInstance==null)
        {
            ourInstance = new SingletonData();
        }
        return ourInstance;
    }
}
