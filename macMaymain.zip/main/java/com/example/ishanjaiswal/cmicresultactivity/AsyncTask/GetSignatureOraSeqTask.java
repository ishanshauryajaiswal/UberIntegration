package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.SignatureTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 5/1/2018.
 */

public class GetSignatureOraSeqTask extends AsyncTask<Void,Void,String> {

    Context mContext;
    DashboardTaskListener mListener;
    String empOraSeq;
    String tshFromDate;
    String tshToDate;

    public GetSignatureOraSeqTask(Context mContext, DashboardTaskListener mListener, String empOraSeq, String tshFromDate, String tshToDate) {
        this.mContext = mContext;
        this.mListener = mListener;
        this.empOraSeq = empOraSeq;
        this.tshFromDate = tshFromDate;
        this.tshToDate = tshToDate;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.onGetSignatureStarted("Fetching Signatures");
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(mContext);
                response = requestCall.getSignatureOraSeq(mContext, empOraSeq, tshFromDate, tshToDate);
                return response;
            } catch (Exception e) {
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String response) {
        if (!isCancelled()) {
            super.onPostExecute(response);
            mListener.onGetSignatureCompleted(response);
        }
    }

    @Override
    protected void onCancelled() {
        mListener.onTaskCancelled();
        super.onCancelled();
    }
}
