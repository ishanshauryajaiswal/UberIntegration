package com.example.ishanjaiswal.cmicresultactivity.Database;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */

public class IshanDBConstants {


    public static final String TABLE_EMPLOYEE_DATA_FOR_CREW = "EmployeeDataForCrew";
    public static final String TABLE_ACTIVITY_TIME_FOR_CREW = "ActivityTimeForCrew";
    public static final String TABLE_TIME_IN_OUT = "TimeInOut";
    public static final String TABLE_ACTIVITY_FOR_TIMESHEET = "ActivityForTimesheet";
    public static final String TABLE_TIMESHEET = "Timesheet";
    public static final String TABLE_CREW_LIST = "CrewList";
    public static final String TABLE_PROJECT_LIST = "ProjectList";
    public static final String TABLE_SELECTED_EMPLOYEES = "SelectedEmployees";
    public static final String TABLE_ALL_EMPLOYEES = "AllEmployees";

    //TABLE EMPLOYEE DATA FOR CREW
    public static final String EmployeeName_EmployeeDataForCrew  = "EmployeeName";
    public static final String EmployeeNumber_EmployeeDataForCrew  = "EmployeeNumber";
    public static final String EmployeeOraseq_EmployeeDataForCrew = "EmployeeOraseq";
    public static final String EmployeeTradeCode_EmployeeDataForCrew  = "EmployeeTradeCode";
    public static final String EmployeeTradeName_EmployeeDataForCrew  = "EmployeeTradeName";
    public static final String PeriodFlag_EmployeeDataForCrew  = "PeriodFlag";
    public static final String RowNumber_EmployeeDataForCrew  = "RowNumber";
    public static final String DeleteFlag_EmployeeDataForCrew  = "DeleteFlag";

    //TABLE ActivityTimeForCrew
    public static final String EmployeeOraSeq_ActivityTimeForCrew = "EmployeeOraseq";
    public static final String otseqNumber = "OtSeqNumber";
    public static final String dothour = "DotHour";
    public static final String rtSeqNumber = "RtSeqNumber";
    public static final String rtHours = "Rthours";
    public static final String dotSeqNumber = "DotSeqNumber";
    public static final String otHour = "OtHour";

    //TABLE Time In-Out For EMPLOYEE
    public static final String TIMEINOUT_EMPLOYEE_NUMBER  = "EmployeeNumber";
    public static final String TIMEINOUT_INDEX  = "IndexNumber";
    public static final String TIMEINOUT_TIME_IN = "TimeIn";
    public static final String TIMEINOUT_TIME_OUT  = "TimeOut";
    public static final String TIMEINOUT_TOTAL  = "Total";

    //TABLE ACTIVITY FOR TIMESHEET
    public static final String ActivityName_ActivityForTimeSheet = "ActivityName";
    public static final String CategoryCode_ActivityForTimeSheet  = "CategoryCode";
    public static final String ColoumnNumber_ActivityForTimeSheet = "ColoumnNumber";
    public static final String JobCode_ActivityForTimeSheet = "JobCode";
    public static final String PciLineOraseq_ActivityForTimeSheet  = "PciLineOraseq";
    public static final String PhaseCode_ActivityForTimeSheet = "PhaseCode";
    public static final String SeqNumber_ActivityForTimeSheet  = "SeqNumber";
    public static final String WbsCode_ActivityForTimeSheet = "WbsCode";
    public static final String DeleteFlag_ActivityForTimeSheet = "DeleteFlag";

    //TABLE TIMESHEET
    public static final String Timesheet_CrewCode = "CrewCode";
    public static final String Timesheet_JobCode = "JobCode";
    public static final String Timesheet_JobCompCode = "JobCompCode";
    public static final String Timesheet_SeqNumber = "SequenceNumber";
    public static final String Timesheet_WorkDate = "WorkDate";
    public static final String Timesheet_SubmitStatus = "SubmitStatus";
    public static final String TimesheetState = "State";

    //TABLE CREWLIST
    public static final String CrewList_PycrCode = "CrewCode";
    public static final String CrewList_PycrName = "CrewName";
    public static final String CrewList_PycrOraseq = "CrewOraseq";
    public static final String CrewList_ResponsiblePersonOraSeq = "ResponsiblePersonOraSeq";
    public static final String CrewList_ResponsiblePersonName = "ResponsiblePersonName";

    //TABLE PROJECTLIST
    public static final String ProjectList_Jobcode = "JobCode";
    public static final String ProjectList_Jobcompcode = "JobCompCode";
    public static final String ProjectList_Jobname = "JobName";

    //TABLE Selected Employees
    public static final String Selected_EmpNumber = "PyelEmpNo";
    public static final String Selected_EmpOraseq ="PyelEmpOraseq";
    public static final String Selected_EmpName ="PyelEmpName";
    public static final String Selected_AccessCode = "PyelAccessCode";
    public static final String Selected_CompName ="PyelCompName";
    public static final String Selected_PrnCode ="PyelPrnCode";
    public static final String Selected_PrnName ="PyelPrnName";
    public static final String Selected_CompCode = "PyelCompCode";
    public static final String Selected_TrdCode = "PyelTrdCode";
    public static final String Selected_TrdName = "PyelTrdName";
    public static final String Selected_UniCode = "PyelUniCode";
    public static final String Selected_UniName = "PyelUniName";

    //TABLE All Employees
    public static final String All_EmpNumber = "PyceEmpNo";
    public static final String All_EmpOraseq ="PyceEmpOraseq";
    public static final String All_EmpName ="PyceEmpName";
    public static final String All_EmpCrewCode ="PyceCrewCode";
    public static final String All_EmpCrewOraseq ="PyceCrewOraseq";
    public static final String All_EmpCrewName ="PyceCrewName";
    public static final String All_PyceOraseq ="PyceOraseq";
    public static final String All_TrdCode = "PyceTrdCode";
    public static final String All_TrdName = "PyceTrdName";

    static final String CREATE_TABLE_EMPLOYEE_DATA_FOR_CREW = "CREATE TABLE IF NOT EXISTS "+
            TABLE_EMPLOYEE_DATA_FOR_CREW + "(" +
            EmployeeOraseq_EmployeeDataForCrew + " INTEGER PRIMARY KEY,"+
            DeleteFlag_EmployeeDataForCrew + " TEXT,"+
            EmployeeNumber_EmployeeDataForCrew + " TEXT,"+
            EmployeeName_EmployeeDataForCrew + " TEXT,"+
            EmployeeTradeCode_EmployeeDataForCrew + " TEXT,"+
            EmployeeTradeName_EmployeeDataForCrew + " TEXT,"+
            RowNumber_EmployeeDataForCrew+ " TEXT,"+
            PeriodFlag_EmployeeDataForCrew+ " TEXT)";

    static final String CREATE_TABLE_ACTIVITY_TIME_FOR_CREW = "CREATE TABLE IF NOT EXISTS "+
            TABLE_ACTIVITY_TIME_FOR_CREW + "(" +
            EmployeeOraseq_EmployeeDataForCrew+ " INTEGER,"+
            ColoumnNumber_ActivityForTimeSheet+ " INTEGER,"+
            rtSeqNumber+ " TEXT,"+
            rtHours+ " TEXT,"+
            otseqNumber+ " TEXT,"+
            otHour+ " TEXT,"+
            dotSeqNumber+ " TEXT,"+
            dothour+ " TEXT," +
            "PRIMARY KEY("+EmployeeOraseq_EmployeeDataForCrew+","+ColoumnNumber_ActivityForTimeSheet+ "))";

    static final String CREATE_TABLE_TIME_IN_OUT = "CREATE TABLE IF NOT EXISTS "+
            TABLE_TIME_IN_OUT + "(" +
            TIMEINOUT_EMPLOYEE_NUMBER+ " TEXT,"+
            TIMEINOUT_INDEX+ " INTEGER,"+
            TIMEINOUT_TIME_IN+ " TEXT,"+
            TIMEINOUT_TIME_OUT+ " TEXT,"+
            TIMEINOUT_TOTAL+ " REAL,"+
            "PRIMARY KEY("+TIMEINOUT_EMPLOYEE_NUMBER+","+TIMEINOUT_INDEX+ "))";

    static final String CREATE_TABLE_ACTIVITY_FOR_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+
            TABLE_ACTIVITY_FOR_TIMESHEET+"("+
            DeleteFlag_ActivityForTimeSheet+ " TEXT,"+
            ActivityName_ActivityForTimeSheet+ " TEXT,"+
            CategoryCode_ActivityForTimeSheet+ " TEXT,"+
            ColoumnNumber_ActivityForTimeSheet+ " INTEGER PRIMARY KEY,"+
            JobCode_ActivityForTimeSheet+ " TEXT,"+
            PciLineOraseq_ActivityForTimeSheet+ " TEXT,"+
            PhaseCode_ActivityForTimeSheet+ " TEXT,"+
            SeqNumber_ActivityForTimeSheet+ " TEXT,"+
            WbsCode_ActivityForTimeSheet+ " TEXT)";

    static final String CREATE_TABLE_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+
            TABLE_TIMESHEET+"("+
            Timesheet_CrewCode+ " TEXT, "+
            Timesheet_JobCode+ " TEXT, "+
            Timesheet_JobCompCode+ " TEXT, "+
            Timesheet_SeqNumber+ " TEXT, "+
            Timesheet_WorkDate+ " TEXT PRIMARY KEY, "+
            Timesheet_SubmitStatus+ " TEXT, "+
            TimesheetState+ " INTEGER)";

    static final String CREATE_TABLE_CREW_LIST = "CREATE TABLE IF NOT EXISTS  " + TABLE_CREW_LIST + "(" + CrewList_PycrCode + " TEXT PRIMARY KEY, " + CrewList_PycrName + " TEXT, " + CrewList_PycrOraseq + " TEXT, " + CrewList_ResponsiblePersonName + " TEXT, " + CrewList_ResponsiblePersonOraSeq +" TEXT )";

    static final String CREATE_TABLE_PROJECT_LIST = "CREATE TABLE IF NOT EXISTS  " + TABLE_PROJECT_LIST + "(" + ProjectList_Jobcode + " TEXT PRIMARY KEY , " + ProjectList_Jobcompcode + " TEXT, " + ProjectList_Jobname + " TEXT )";

    static final String CREATE_TABLE_SELECTED_EMPLOYEES = "CREATE TABLE IF NOT EXISTS " +
            TABLE_SELECTED_EMPLOYEES + "(" +
            Selected_EmpNumber + " TEXT, " +
            Selected_EmpOraseq + " TEXT PRIMARY KEY, " +
            Selected_EmpName + " TEXT, " +
            Selected_AccessCode + " TEXT, " +
            Selected_CompName + " TEXT, " +
            Selected_PrnCode + " TEXT, " +
            Selected_PrnName + " TEXT, " +
            Selected_CompCode +" TEXT, " +
            Selected_TrdCode + " TEXT, " +
            Selected_TrdName + " TEXT, " +
            Selected_UniCode + " TEXT, " +
            Selected_UniName + " TEXT)";

    static final String CREATE_TABLE_ALL_EMPLOYEES = "CREATE TABLE IF NOT EXISTS " +
            TABLE_ALL_EMPLOYEES + "(" +
            All_EmpNumber + " TEXT PRIMARY KEY, " +
            All_EmpOraseq + " TEXT , " +
            All_EmpName + " TEXT, " +
            All_EmpCrewCode + " TEXT, " +
            All_EmpCrewOraseq + " TEXT, " +
            All_EmpCrewName +" TEXT, " +
            All_TrdCode + " TEXT, " +
            All_TrdName + " TEXT, " +
            All_PyceOraseq + " TEXT)";
}
