package com.example.ishanjaiswal.cmicresultactivity;

import android.graphics.Bitmap;
import android.util.Log;
import android.util.SparseBooleanArray;

import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

/**
 * Created by parneet.singh on 9/7/2016.
 */
public class LoginAccess
{
    private static LoginAccess ourInstance;
    public String selectedPositionJobCode;
    public String selectedPositionPhaseCode;
    public String selectedCrewCode;
    public String selectedCrewCodeFromSingleton , selectedCrewNameFromSingleton;
    public   Boolean IsFromResultActivity  = false;
    public String name = "" ;
    public String header ="";
    public String MainSeqNo = "" ;
    public String selectedDate;
    public String activityClicked;
    public  String crewOraseqFornewCrewInserted;
    public static String username ="";
    public static String password ="";
    public String crewCode ="";
    public int flaglogin = 0;
    public String selectedCategoryCodeLoginAccess;
    public ArrayList<String> selectedEmployees = new ArrayList<>();
    public ArrayList<User> selectedEmployeesUser = new ArrayList<>();
    //public  SubmittedActivityFromCrewModal submittedActivityFromCrewModal;
    public String currentDate = "";
    public String project = "";
    public String jsonSubmit ;
    public static String selectedEmployeeNameForNewCrew = "";
    public ArrayList<String> projectNamesloginaccess = new ArrayList<>(); //for display in submitted timesheet
    public ArrayList<String> crewNamesloginaccess = new ArrayList<>();  //for display in submitted timesheet
    //public  ArrayList<LinkingCrewEmployeeWithCrew> getAllEmployees=new ArrayList<>();
    public ArrayList<User> employeesAll = new ArrayList<>();
    public static ArrayList<String> empNo = new ArrayList<>();
    public static ArrayList<String> empnumberFromRetrieve;
    public static SparseBooleanArray checkedFinal = new SparseBooleanArray();
    public static Bitmap bitmap;
    public static String jobCodeSelectedInDashboard = "" ;
    public static String compCodeSelectedInDashboard = "" ;
    public static String selectedEmployeeOraseqInDashboard = "" ;


    public static LoginAccess getInstance()
    {
        if (ourInstance==null)
        {
            ourInstance = new LoginAccess();
        }
        return ourInstance;
    }

    public static void LoginAccess()
    {
        Log.d("Singleton","Singleton");
    }
    /*public ArrayList<LinkingCrewEmployeeWithCrew> getUserList()
    {
        return getAllEmployees;
    }*/
    public static void setUsername(String UserName)
    {
       username = UserName;
    }
    public static String getUsername()
    {
        return username;
    }
    public static void setPassword(String PassWord)
    {
        password = PassWord;
    }
    public String getPassword()
    {
        return password;
    }

}
