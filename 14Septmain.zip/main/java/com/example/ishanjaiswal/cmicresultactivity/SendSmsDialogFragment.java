package com.example.ishanjaiswal.cmicresultactivity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.example.ishanjaiswal.cmicresultactivity.Utils.ScreenUtil;

/**
 * Created by ishan.jaiswal on 5/31/2018.
 */

public class SendSmsDialogFragment extends DialogFragment {

    public interface SendSmsDialogListener{
        void sendSmsIntent(String number);
    }
    private SendSmsDialogListener mListener;
    private EditText etPhoneNumber;
    private Button btnSend;
    public void setListener(SendSmsDialogListener mListener) {
        this.mListener = mListener;
    }

    public static SendSmsDialogFragment newInstance(SendSmsDialogListener sendSmsDialogListener){
        SendSmsDialogFragment fragment = new SendSmsDialogFragment();
        fragment.setListener(sendSmsDialogListener);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        return inflater.inflate(R.layout.dialog_send_sms,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout(getResources().getDimensionPixelSize(R.dimen.dialog_send_sms_width),
                getResources().getDimensionPixelSize(R.dimen.dialog_send_sms_height));
        window.setGravity(Gravity.CENTER);
    }

    private void initView(View view) {
        etPhoneNumber = (EditText)view.findViewById(R.id.et_mobile_number);
        btnSend = (Button)view.findViewById(R.id.btn_send_sms);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = etPhoneNumber.getText().toString();
                if (number!=null && number.length()<10)
                    etPhoneNumber.setError("Enter 10 digit Number");
                else {
                    dismiss();
                    mListener.sendSmsIntent(number);
                }
            }
        });
    }
}
