package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.ishanjaiswal.cmicresultactivity.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ishan.jaiswal on 6/7/2018.
 */

public class DateUtil {

    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public static SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");

    public static Date getLastDateOfWeek(String date, Context context){
        String firstDayOfWeek = PreferenceManager.getDefaultSharedPreferences(context)
                .getString(context.getString(R.string.settings_key_start_day),context.getString(R.string.settings_start_day_default));
        Calendar cal = null;
        if (date!=null && date.length()>0){
            int year = Integer.parseInt(date.split("\\-")[0]);
            int month = Integer.parseInt(date.split("\\-")[1]);
            int day = Integer.parseInt(date.split("\\-")[2]);
            cal = Calendar.getInstance();
            cal.set(year, month-1, day);
        }
        int firstDayNum = CollectionUtils.dayConverter().get(firstDayOfWeek).intValue();
        String currentDay = sdfDay.format(cal.getTime());
        int currentDayNum = CollectionUtils.dayConverter().get(currentDay).intValue();
        int difference = calculateDifference(currentDayNum,firstDayNum)-1;
        cal.add(Calendar.DATE,difference);
        date = sdf.format(cal.getTime());
        Date lastDateOfWeek = new Date();
        try {
            lastDateOfWeek = sdf.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return lastDateOfWeek;
    }

    public static Date getFirstDateOfWeek(String date, Context context) {
        Date last = getLastDateOfWeek(date, context);
        date = sdf.format(last);
        Calendar cal = null;
        int year = Integer.parseInt(date.split("\\-")[0]);
        int month = Integer.parseInt(date.split("\\-")[1]);
        int day = Integer.parseInt(date.split("\\-")[2]);
        cal = Calendar.getInstance();
        cal.set(year, month - 1, day);
        cal.add(Calendar.DATE, -6);
        String firstDate = sdf.format(cal.getTime());
        Date firstDateOfWeek = new Date();
        try {
            firstDateOfWeek = sdf.parse(firstDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return firstDateOfWeek;
    }


    private static int calculateDifference(int first, int selected){
        int difference = 0;
        while (first!=selected){
            if (first==7) {difference++;first = 1;}
            else {difference++; first++;}
        }
        if (difference == 0) return 7;
        else return difference;
    }
    
}
