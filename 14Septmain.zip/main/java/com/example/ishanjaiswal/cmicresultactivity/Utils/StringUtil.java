package com.example.ishanjaiswal.cmicresultactivity.Utils;

/**
 * Created by ishan.jaiswal on 6/7/2018.
 */

public class StringUtil {

    public static boolean isStringNull(String s){
        return (s==null || s.equalsIgnoreCase("") || s.equalsIgnoreCase("null"));
    }

    public static String checkForNullAndInitialize(String s){
        if (isStringNull(s))
            return "";
        else
            return s;
    }
}
