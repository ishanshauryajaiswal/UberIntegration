package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

public interface BasicTaskListenerInterface {

    void onTaskStarted(String progressDialogMessage);

    void onTaskComplete(String response);
}
