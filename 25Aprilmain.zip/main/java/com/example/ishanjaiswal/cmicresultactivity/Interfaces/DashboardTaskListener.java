package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface DashboardTaskListener {
    void beforeDashboardTaskStarted(String displayMessage);
    void onDashboardTaskComplete(String response);
    void onDashboard2TaskComplete(String response);
}
