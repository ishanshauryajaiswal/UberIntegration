package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/23/2018.
 */

public interface RecyclerViewClickListener {
    public void onRecyclerViewRowClicked(String crewCode, int week);
}
