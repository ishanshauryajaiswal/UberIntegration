package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;
import com.example.ishanjaiswal.cmicresultactivity.parsers.Dashboard2Parser;
import com.example.ishanjaiswal.cmicresultactivity.parsers.DashboardParser;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class DashboardActivity extends AppCompatActivity implements FragmentClickListener,DashboardTaskListener,JobDataListener,CrewMemberDataListener {

    FragmentManager fragmentManager;
    private FragmentOne fragmentOne;
    private FragmentTwo fragmentTwo;
    private HeadlessFragment1 headlessFragment1;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        fragmentManager = getSupportFragmentManager();
        fragmentOne = FragmentOne.getInstance();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer,fragmentOne,FragmentOne.class.getSimpleName())
                .commit();
    }

    @Override
    public void retrieveDashboardData(String jobCompCode, String jobCode, String date) {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getDashboardData(DashboardActivity.this,jobCompCode, jobCode, date,DashboardActivity.this);
    }

    @Override
    public void retrieveDashboardData(String empOraSeq, String date) {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getDashboardData(DashboardActivity.this,empOraSeq, date,DashboardActivity.this);
    }

    @Override
    public void retrieveCrewMemberData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (headlessFragment1.getCrewMemberList()!=null&& headlessFragment1.getCrewMemberList().size()>0)
            fragmentOne.populateCrewMemberList(headlessFragment1.getCrewMemberList());
        else
            if (!headlessFragment1.isTaskExecuting)
                headlessFragment1.getCrewMemberData(DashboardActivity.this);
            else {}
    }

    @Override
    public void retrieveJobData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (headlessFragment1.getJobDataList()!=null&& headlessFragment1.getJobDataList().size()>0)
            fragmentOne.populateJobData(headlessFragment1.getJobDataList());
        else
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getJobData(DashboardActivity.this);
        else {}
    }

    @Override
    public void retrieveDashboard2Data(String crewCode, String date, boolean isJobSelected) {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!headlessFragment1.isTaskExecuting)
            headlessFragment1.getDashboard2Data(DashboardActivity.this,crewCode, date,DashboardActivity.this);
    }


    @Override
    public void beforeDashboardTaskStarted(String displayMessage) {
        headlessFragment1.isTaskExecuting = true;
        progressDialog = ProgressDialog.show(DashboardActivity.this,displayMessage,displayMessage);
    }

    @Override
    public void onDashboardTaskComplete(String response) {
        progressDialog.dismiss();
        if (response != null && !response.equalsIgnoreCase(getString(R.string.internal_server_error))) {
            headlessFragment1.isTaskExecuting = false;
            DashboardParser dashboardParser = new DashboardParser();
            List<Dashboard> dashboardList = dashboardParser.parseDashboardData(response);
            if (fragmentOne != null)
                fragmentOne.setUpUI(dashboardList);
        }
        else
            Toast.makeText(getApplicationContext(),"Internal Server Error",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDashboard2TaskComplete(String response) {
        progressDialog.dismiss();
        if (response != null && !response.equalsIgnoreCase(getString(R.string.internal_server_error))) {
            Dashboard2Parser parser = new Dashboard2Parser(false,DashboardActivity.this);
            List<Dashboard2> dashboard2List = parser.parseDashboard2Data(response);
            fragmentTwo.setUpDashboard(dashboard2List);
        }
        else
            Toast.makeText(getApplicationContext(),"Internal Server Error",Toast.LENGTH_SHORT).show();

    }

    @Override
    public void beforeJobDataTaskStarted(String displayMessage) {
        fragmentOne.showPopUpProgressbar();
        headlessFragment1.isTaskExecuting = true;
    }

    @Override
    public void onJobDataTaskComplete(String response) {
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.isTaskExecuting = false;
        if (response!=null && !response.equalsIgnoreCase(getString(R.string.internal_server_error))) {
            headlessFragment1.setJobDataList(new JobDataParser().parseJobData(response));
            fragmentOne.populateJobData(headlessFragment1.getJobDataList());
        }
        else
            makeErrorAlert();
    }

    @Override
    public void onCrewMemberDataTaskStarted() {
        fragmentOne.showPopUpProgressbar();
        headlessFragment1.isTaskExecuting = true;
    }

    @Override
    public void onCrewMemberDataTaskCompleted(String result) {
        fragmentOne.hidePopUpProgressbar();
        headlessFragment1.isTaskExecuting = false;
        if (result!=null && !result.equalsIgnoreCase(getString(R.string.internal_server_error))) {
            headlessFragment1.setCrewMemberList(new EmployeeDataParser().parseEmployeeData(result, DashboardActivity.this));
            fragmentOne.populateCrewMemberList(headlessFragment1.getCrewMemberList());
        }
        else
            makeErrorAlert();
    }


    @Override
    public void onCrewMemberSelected(String crewCode, String date, boolean isJobSelected) {
        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.cmic_fragment_extras_crew_code_from_dashboard),crewCode);
        bundle.putString(getString(R.string.cmic_fragment_extras_date_from_dashboard),date);
        bundle.putBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),isJobSelected);
        fragmentTwo = FragmentTwo.getInstance(bundle);
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,fragmentTwo,FragmentTwo.class.getSimpleName())
                .addToBackStack(FragmentTwo.class.getSimpleName())
                .commit();
    }
    private void makeErrorAlert(){
        final AlertDialog.Builder alertBox = new AlertDialog.Builder(DashboardActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        alertBox.setMessage("Some Error Occurred. Please Try Again.");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }
}
