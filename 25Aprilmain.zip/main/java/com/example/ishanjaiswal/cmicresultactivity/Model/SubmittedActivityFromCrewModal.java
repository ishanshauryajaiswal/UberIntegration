package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/12/2018.
 */

import java.io.Serializable;

public class SubmittedActivityFromCrewModal implements Serializable,Cloneable {
    public String deleteFlag;
    public String SeqNo;
    public String ColoumnNo;
    public String ActivityName;
    public String PhaseCode;
    public String WbsCode;
    public String PciLineOraseq;
    public String catCode;
    public String crewCode;
    public String jobName;
    public String phaseName;
    public String categoryName;
    public String workDate;
    public String jobCode;
    public String JobCompCode;


    public SubmittedActivityFromCrewModal(String WbsCode, String ColoumnNo, String PhaseCode, String SeqNo, String ActivityName, String deleteFlag, String catCode, String PciLineOraseq, String crewCode, String workDate) {
        this.deleteFlag = deleteFlag;
        this.SeqNo = SeqNo;//""
        this.ColoumnNo = ColoumnNo;
        this.ActivityName = ActivityName;
        this.PhaseCode = PhaseCode;
        this.WbsCode = WbsCode;
        this.PciLineOraseq = PciLineOraseq;
        this.catCode = catCode;
        this.crewCode = crewCode;
        this.workDate = workDate;
    }

    public SubmittedActivityFromCrewModal(String deleteFlag, String seqNo, String columnNo, String activityName, String jobCode, String phaseCode, String wbsCode, String pciLineOraseq, String catCode) {
        this.deleteFlag = deleteFlag;
        this.SeqNo = seqNo;
        this.ColoumnNo = columnNo;
        this.ActivityName = activityName;
        this.jobCode = jobCode;
        this.PhaseCode = phaseCode;
        this.WbsCode = wbsCode;
        this.PciLineOraseq = pciLineOraseq;
        this.catCode = catCode;
    }


    public SubmittedActivityFromCrewModal() {

    }


    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }


    public String getCategoryName() {
        return categoryName;
    }

    public String getPhaseName() {
        return phaseName;
    }

    public String getSeqNo() {
        return SeqNo;
    }

    public String getActivityName() {
        return ActivityName;
    }

    public String getColoumnNo() {
        return ColoumnNo;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public String getPciLineOraseq() {
        return PciLineOraseq;
    }

    public String getPhaseCode() {
        return PhaseCode;
    }

    public String getWbsCode() {
        return WbsCode;
    }

    public String getCatCode() {
        return catCode;
    }

    public String getCrewCode() {
        return crewCode;
    }

    public String getWorkDate() {
        return workDate;
    }

    public void setSeqNo(String seqNo) {
        SeqNo = seqNo;
    }

    public void setActivityName(String activityName) {
        ActivityName = activityName;
    }

    public void setColoumnNo(String coloumnNo) {
        ColoumnNo = coloumnNo;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public void setPciLineOraseq(String pciLineOraseq) {
        PciLineOraseq = pciLineOraseq;
    }

    public void setPhaseCode(String phaseCode) {
        PhaseCode = phaseCode;
    }

    public void setWbsCode(String wbsCode) {
        WbsCode = wbsCode;
    }

    public void setCatCode(String catCode) {
        this.catCode = catCode;
    }

    public void setCrewCode(String crewCode) {
        this.crewCode = crewCode;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setPhaseName(String phaseName) {
        this.phaseName = phaseName;
    }

    public String getjobCode(){return this.jobCode;}

    public String getJobCompCode(){return this.JobCompCode;}

    public void setjobCode(String jobCode){this.jobCode = jobCode;}

    public void setJobCompCode(String jobCompCode){this.JobCompCode = jobCompCode;}

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
