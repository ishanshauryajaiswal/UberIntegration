package com.example.ishanjaiswal.cmicresultactivity;

import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class PciParser
{
    public ArrayList<PciModal> pciDataParser(String response)
    {
        ArrayList<PciModal> pciModalArrayList = new ArrayList<>();
        try {
            Log.d("ResponseParserPci", response);
            JSONObject jsonObject = new JSONObject(response);
            String table = jsonObject.getString("table");
            JSONObject rowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray attrNamesJsonArray = rowDefinition.getJSONArray("attrNames");

            JSONArray mainRows = jsonObject.getJSONArray("rows");
            // JSONArray mainrowsJsonArray = mainRows.getJSONArray()
            for (int i = 0; i < mainRows.length(); i++) {
                JSONObject objectInMainRows = mainRows.getJSONObject(i);
                //JSONObject masterRowObject = objectInMainRows.getJSONObject("masterRow");
                JSONArray attarValuesInMasterRow = objectInMainRows.getJSONArray("attrValues");
                String PciCompCode = attarValuesInMasterRow.getString(0);
                String PciJobCode = attarValuesInMasterRow.getString(1);
                String PciPhsCode = attarValuesInMasterRow.getString(2);
                String PciCatCode = attarValuesInMasterRow.getString(3);
                String PciCode = attarValuesInMasterRow.getString(4);
                String PciName = attarValuesInMasterRow.getString(5);
                String PciBudgetAmt = attarValuesInMasterRow.getString(6);
                String PciLineOraseq = attarValuesInMasterRow.getString(7);

                PciModal pciModal = new PciModal(PciCompCode, PciJobCode, PciPhsCode, PciCatCode,PciCode,PciName,PciBudgetAmt,PciLineOraseq);
                pciModalArrayList.add(pciModal);
            }
        } catch (Exception e)
        {
            Log.d("Error in PciParser", e.toString());
        }
        return pciModalArrayList;
    }
}
