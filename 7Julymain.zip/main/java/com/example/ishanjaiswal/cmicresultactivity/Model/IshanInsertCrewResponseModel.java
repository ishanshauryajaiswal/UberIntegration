package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 4/5/2018.
 */
public class IshanInsertCrewResponseModel {

    String creCode,crewName,crewOraseq,responsibleEmpOraseq,responssibleEmpNo,responsibleEmpName;

    public IshanInsertCrewResponseModel(String creCode, String crewName, String crewOraseq, String responsibleEmpOraseq, String responssibleEmpNo, String responsibleEmpName) {
        this.creCode = creCode;
        this.crewName = crewName;
        this.crewOraseq = crewOraseq;
        this.responsibleEmpOraseq = responsibleEmpOraseq;
        this.responssibleEmpNo = responssibleEmpNo;
        this.responsibleEmpName = responsibleEmpName;
    }

    public IshanInsertCrewResponseModel() {
    }

    public String getCreCode() {
        return creCode;
    }

    public void setCreCode(String creCode) {
        this.creCode = creCode;
    }

    public String getCrewName() {
        return crewName;
    }

    public void setCrewName(String crewName) {
        this.crewName = crewName;
    }

    public String getCrewOraseq() {
        return crewOraseq;
    }

    public void setCrewOraseq(String crewOraseq) {
        this.crewOraseq = crewOraseq;
    }

    public String getResponsibleEmpOraseq() {
        return responsibleEmpOraseq;
    }

    public void setResponsibleEmpOraseq(String responsibleEmpOraseq) {
        this.responsibleEmpOraseq = responsibleEmpOraseq;
    }

    public String getResponssibleEmpNo() {
        return responssibleEmpNo;
    }

    public void setResponssibleEmpNo(String responssibleEmpNo) {
        this.responssibleEmpNo = responssibleEmpNo;
    }

    public String getResponsibleEmpName() {
        return responsibleEmpName;
    }

    public void setResponsibleEmpName(String responsibleEmpName) {
        this.responsibleEmpName = responsibleEmpName;
    }
}