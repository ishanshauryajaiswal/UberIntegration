package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class LinkingCrewEmployeeWithCrew
{
    public String tableName;
    public int numberOfRemainingRecords;
    public ArrayList<AttributeValuesForCrewModal> attributeValuesForCrewModals;

    public LinkingCrewEmployeeWithCrew(String tableName,int numberOfRemainingRecords,ArrayList<AttributeValuesForCrewModal> attributeValuesForCrewModals)
    {
        this.tableName = tableName;
        this.numberOfRemainingRecords = numberOfRemainingRecords;
        this.attributeValuesForCrewModals = attributeValuesForCrewModals;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public int getNumberOfRemainingRecords() {
        return numberOfRemainingRecords;
    }

    public void setNumberOfRemainingRecords(int numberOfRemainingRecords) {
        this.numberOfRemainingRecords = numberOfRemainingRecords;
    }

    public ArrayList<AttributeValuesForCrewModal> getAttributeValuesForCrewModals() {
        return attributeValuesForCrewModals;
    }

    public void setAttributeValuesForCrewModals(ArrayList<AttributeValuesForCrewModal> attributeValuesForCrewModals) {
        this.attributeValuesForCrewModals = attributeValuesForCrewModals;
    }
}
