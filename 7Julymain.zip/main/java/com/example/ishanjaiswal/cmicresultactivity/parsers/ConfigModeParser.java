package com.example.ishanjaiswal.cmicresultactivity.parsers;

import com.example.ishanjaiswal.cmicresultactivity.Model.ConfigMode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class ConfigModeParser {

    public ConfigMode parse(String response){
        ConfigMode configMode = new ConfigMode();
        try {
            String tableName;
            int numberOfRemainingRecords;
            JSONObject jsonObject = new JSONObject(response);
            JSONObject rowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray attrNames = rowDefinition.getJSONArray("attrNames");
            JSONArray rows = jsonObject.getJSONArray("rows");
            Set<String> requiredAttributes = new HashSet<>();
            requiredAttributes.add("ConfigTotalCols");
            requiredAttributes.add("ConfigTotalRows");
            requiredAttributes.add("ConfigShowJob");
            requiredAttributes.add("ConfigShowComp");

            HashMap<String, Integer> attributeIndex = new HashMap<>();

            for (int i = 0; i < attrNames.length(); i++) {
                String strAttribute = attrNames.getString(i);

                if (requiredAttributes.contains(strAttribute))
                    attributeIndex.put(strAttribute, i);
            }

            ArrayList<JSONArray> attributeValues = new ArrayList();
            if (rows.length() != 0) {
                for (int j = 0; j < rows.length(); j++) {
                    JSONArray values = rows.getJSONObject(j).getJSONArray("attrValues");
                    attributeValues.add(values);
                }
            }
            JSONArray configValues = attributeValues.get(0);
            configMode.setShowJob(configValues.getString(2).equalsIgnoreCase("Y") ? true : false);
            configMode.setShowCompany(configValues.getString(3).equalsIgnoreCase("Y") ? true : false);
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            return configMode;
        }
    }

}
