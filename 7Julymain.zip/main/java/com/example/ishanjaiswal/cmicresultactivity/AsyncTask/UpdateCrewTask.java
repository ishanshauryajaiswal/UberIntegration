package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.InsertCrewInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class UpdateCrewTask extends AsyncTask<Void, Void, String > {

    public interface UpdateCrewListener {
        void onTaskComplete(String result);
        void onTaskStarted();
    }


    private Context mContext;
    String table;
    String mCrewCode;
    UpdateCrewListener mListener;
    private final static String TAG = UpdateCrewTask.class.getSimpleName();

    public UpdateCrewTask(Context context, String table, String crewCode, UpdateCrewListener listener) {
        this.mContext = context;
        this.table = table;
        this.mListener = listener;
        this.mCrewCode = crewCode;
    }

    @Override
    protected void onPreExecute()
    {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.onTaskStarted();
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(mContext);
                response = requestCall.updateCrew(mContext, table, mCrewCode);
            } catch (Exception e) {
                Log.d(TAG, "Exception in Updating Crew: " + e.toString());
            }
        }
        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        if (!isCancelled())
            mListener.onTaskComplete(response);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }
}
