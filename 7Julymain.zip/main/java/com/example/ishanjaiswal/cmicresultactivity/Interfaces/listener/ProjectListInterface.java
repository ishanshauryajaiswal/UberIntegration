package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

/**
 * Created by parneet.singh on 1/5/2018.
 */
public interface ProjectListInterface
{
    public void ResultFromProjectListWebservice(String result);
    public void BeforeCompleted();}
