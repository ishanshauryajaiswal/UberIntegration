package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;

import android.view.View;

import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeInOut;

import java.util.List;

/**
 * Created by ishan.jaiswal on 2/19/2018.
 */

public interface CustomClickListener {

    void activityHeaderClicked(int position);

    void activityHeaderLongPressed(View v, int position);

    void rowItemClicked(int listPosition, int activityPosition);

    void enterTimePopUpDone(CrewTimeSheet mCrewTimeSheet);

}
