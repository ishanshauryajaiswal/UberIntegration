package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 3/29/2018.
 */

public class IshanAllEmployeeDBHelper {
    private static final String TAG = IshanAllEmployeeDBHelper.class.getSimpleName();
    private static IshanDBConstants D = new IshanDBConstants();
    IshanDBHelper mInstance;
    public IshanAllEmployeeDBHelper(Context context)
    {
        mInstance = IshanDBHelper.getInstance(context);
    }

    public void insertAllEmployeeInDatabase(ArrayList<AttributeValuesForCrewModal> list)
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            db.beginTransaction();
            for (AttributeValuesForCrewModal employee : list) {
                ContentValues values = new ContentValues();
                values.put(D.All_PyceOraseq, employee.getPyceOraseq());
                values.put(D.All_EmpCrewCode, employee.getPyceCrewCode());
                values.put(D.All_EmpCrewName, employee.getPyceCrewName());
                values.put(D.All_EmpCrewOraseq, employee.getPyceCrewOraseq());
                values.put(D.All_EmpName, employee.getPyceEmpName());
                values.put(D.All_EmpNumber, employee.getPyceEmpNo());
                values.put(D.All_EmpOraseq, employee.getPyceEmpOraseq());
                values.put(D.All_TrdCode, employee.getPyceTrdCode());
                values.put(D.All_TrdName, employee.getPyceTrdName());
                values.put(D.All_EnteredOt, employee.getPyceUserEnteredOt());
                values.put(D.All_EnteredDt, employee.getPyceUserEnteredDt());
                int id = (int) db.insertWithOnConflict(D.TABLE_ALL_EMPLOYEES, null, values, SQLiteDatabase.CONFLICT_IGNORE);
                if (id == -1)
                    db.update(D.TABLE_ALL_EMPLOYEES, values, D.All_EmpNumber + "=?", new String[]{employee.getPyceEmpNo() + ""});
            }
            db.setTransactionSuccessful();
        }
        catch(SQLiteException e) {
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        }
        catch(Exception e){
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        }
        finally {
            db.endTransaction();
        }
    }

    public List<AttributeValuesForCrewModal> getAllSelectedEmployeesFromDatabase(){
        List<AttributeValuesForCrewModal> list = new ArrayList<>();
        return list;
    }

    public String  getPyceOraSeqOfEmployee(String employeeNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cur = null;
        String pyceOraSeq="";
        try {
            db.beginTransaction();
            cur = db.rawQuery("SELECT * FROM " + D.TABLE_ALL_EMPLOYEES + " WHERE "+ D.All_EmpNumber+ " = '" + employeeNumber + "'" , null);
            if (cur.moveToFirst())
                pyceOraSeq = cur.getString(cur.getColumnIndex(D.All_PyceOraseq));
            db.setTransactionSuccessful();
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        finally {
            if (cur!=null)
                cur.close();
            db.endTransaction();
        }
        return pyceOraSeq;
    }

    public boolean  getEmployeeOtFlag(String employeeNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cur = null;
        boolean otFlag = true;
        try {
            db.beginTransaction();
             cur = db.rawQuery("SELECT * FROM " + D.TABLE_ALL_EMPLOYEES + " WHERE "+ D.All_EmpNumber+ " = '" + employeeNumber + "'" , null);
            if (cur.moveToFirst()) {
                String s = cur.getString(cur.getColumnIndex(D.All_EnteredOt));
                if (s.equalsIgnoreCase("Y"))
                    otFlag = true;
                else
                    otFlag = false;
            }
            db.setTransactionSuccessful();
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        finally {
            if (cur!=null)
                cur.close();
            db.endTransaction();
        }
        return otFlag;
    }

    public boolean  getEmployeeDtFlag(String employeeNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        Cursor cur = null;
        boolean dtFlag = true;
        try {
            db.beginTransaction();
            cur = db.rawQuery("SELECT * FROM " + D.TABLE_ALL_EMPLOYEES + " WHERE "+ D.All_EmpNumber+ " = '" + employeeNumber + "'" , null);
            if (cur.moveToFirst()) {
                String s = cur.getString(cur.getColumnIndex(D.All_EnteredDt));
                if (s.equalsIgnoreCase("Y"))
                    dtFlag = true;
                else
                    dtFlag = false;
            }
            db.setTransactionSuccessful();
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        finally {
            if (cur!=null)
                cur.close();
            db.endTransaction();
        }
        return dtFlag;
    }
}
