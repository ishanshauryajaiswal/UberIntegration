package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener; /**
 * Created by ishan.jaiswal on 2/6/2018.
 */

/**
 Created by parneet.singh on 10/26/2016.
 */
public interface CrewListTaskListener
{
    public void onPostCrewListTask(String response);
    public void onPreCrewListTask();
}
