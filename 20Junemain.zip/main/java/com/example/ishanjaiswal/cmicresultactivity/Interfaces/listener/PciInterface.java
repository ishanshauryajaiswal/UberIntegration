package com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener;


import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;

import java.util.ArrayList;

public interface PciInterface
{
    public ArrayList<PciModal> ResultFromPciWebservice(String result);
    public void BeforeCompleted();
}
