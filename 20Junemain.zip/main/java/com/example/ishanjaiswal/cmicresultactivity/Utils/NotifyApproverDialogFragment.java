package com.example.ishanjaiswal.cmicresultactivity.Utils;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.R;

/**
 * Created by ishan.jaiswal on 5/30/2018.
 */

public class NotifyApproverDialogFragment extends DialogFragment {

    public interface NotifyApproverDialogListener{
        void sendSMS();
        void sendMail();
    }
    private NotifyApproverDialogListener mListener;
    private TextView tvCancel, tvSendEmail, tvSendSMS;

    public void setListener(NotifyApproverDialogListener mListener) {
        this.mListener = mListener;
    }

    public static NotifyApproverDialogFragment newInstance(NotifyApproverDialogListener listener){
        NotifyApproverDialogFragment notifyApproverDialogFragment = new NotifyApproverDialogFragment();
        notifyApproverDialogFragment.setListener(listener);
        return notifyApproverDialogFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        return  inflater.inflate(R.layout.dialog_notify_approver,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout(ScreenUtil.dpToPx(getContext(),getResources().getDimension(R.dimen.dialog_notify_approver_width)),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
    }

    private void initView(View view) {
        tvSendSMS = (TextView)view.findViewById(R.id.tv_send_sms);
        tvSendEmail = (TextView)view.findViewById(R.id.tv_send_email);
        tvCancel = (TextView)view.findViewById(R.id.tv_cancel);

        tvSendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.sendSMS();
            }
        });
        tvSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                mListener.sendMail();
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }
}
