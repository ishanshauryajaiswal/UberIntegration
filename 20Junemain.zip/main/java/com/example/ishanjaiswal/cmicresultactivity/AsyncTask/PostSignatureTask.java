package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;
import com.example.ishanjaiswal.cmicresultactivity.Utils.Signature;

/**
 * Created by ishan.jaiswal on 5/1/2018.
 */

public class PostSignatureTask extends AsyncTask<Void,Void,String> {

    Context mContext;
    DashboardTaskListener mListener;
    String empOraSeq;
    String tshFromDate;
    String tshToDate;
    String encodedImage;
    Signature enumSignature;

    public PostSignatureTask(Context mContext, DashboardTaskListener mListener, String empOraSeq, String tshFromDate, String tshToDate, String encodedImage, Signature enumSignature) {
        this.mContext = mContext;
        this.mListener = mListener;
        this.empOraSeq = empOraSeq;
        this.tshFromDate = tshFromDate;
        this.tshToDate = tshToDate;
        this.encodedImage = encodedImage;
        this.enumSignature = enumSignature;
    }

    @Override
    protected void onPreExecute() {
        if (!isCancelled()) {
            super.onPreExecute();
            mListener.onPostSignatureTaskStarted("Fetching Signature");
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(mContext);
                response = requestCall.uploadSignatureEmployee(mContext, empOraSeq, tshFromDate, tshToDate, enumSignature, encodedImage);
                return response;
            } catch (Exception e) {
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String response) {
        if (!isCancelled()) {
            super.onPostExecute(response);
            mListener.onPostSignatureTaskCompleted(response, enumSignature);
        }
    }

    @Override
    protected void onCancelled() {
        mListener.onTaskCancelled();
        super.onCancelled();
    }
}
