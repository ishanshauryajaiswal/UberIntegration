package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.JobDataListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by shaurya on 22/04/18.
 */

public class JobDataTask2 extends AsyncTask<Void, Void, String>
{
    private static final String TAG = JobDataTask2.class.getSimpleName();
    private Context mContext;
    private JobDataListener mListener;

    public JobDataTask2(Context mContext, JobDataListener mListener) {
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute() {mListener.beforeJobDataTaskStarted("Fetching!");}

    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        try {
            RequestCall requestCall = new RequestCall(mContext);
            response = requestCall.getAllJobs(mContext);
        } catch (Exception e)
        {
            Log.d(TAG,"Exception in Fetching Job Data" +
                    ": "+e.toString());
        }
        return response;
    }

    protected void onPostExecute(String response) {
        mListener.onJobDataTaskComplete(response);
    }
}