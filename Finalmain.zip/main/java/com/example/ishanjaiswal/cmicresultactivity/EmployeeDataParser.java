package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by parneet.singh on 8/24/2016.
 */

import android.content.Context;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Database.DBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.TotalHours;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EmployeeDataParser {
    //Attributrs Names
    private String KEY_EMPLOYEE_ORASEQ = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_NUMBER = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_NAME = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_ACCESS_CODE = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_COMP_CODE = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_COMP_NAME = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_PRN_CODE = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_PRN_NAME = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_TRD_CODE = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_TRD_NAME = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_UNI_CODE = "PyelEmpOraseq";
    private String KEY_EMPLOYEE_UNI_NAME = "PyelEmpOraseq";

    List<String> PyelEmpNo = new ArrayList<>();
    List<String> PyelName = new ArrayList<>();
    List<String> PyelAccessCode = new ArrayList<>();
    List<String> PyelTradeName = new ArrayList<>();
    List<String> PyelCompCode = new ArrayList<>();
    List<String> PyelCompName = new ArrayList<>();
    List<String> PyelPrnCode = new ArrayList<>();
    List<String> PyelPrnName = new ArrayList<>();
    List<String> PyelEmpOraseq = new ArrayList<>();
    ArrayList<User> employee;
    String tableName;
    int numberOfRemainingRecords;

    DBHelper dbHelper;




    public ArrayList<User> parseEmployeeData(final String response, Context context) {
        try {
            Log.d("response in parser", response);
            dbHelper = new DBHelper(context);
           /* dbHelper.dropTableAllEmployees();*/
            JSONObject jsonObject = new JSONObject(response);
            tableName = jsonObject.getString("table");
            numberOfRemainingRecords = jsonObject.getInt("numberOfRemainingRecords");
            JSONObject RowDefinition = jsonObject.getJSONObject("rowDefinition");
            JSONArray Rows = jsonObject.getJSONArray("rows");
            JSONArray attributes = RowDefinition.getJSONArray("attrNames");
            employee = new ArrayList();
            Set<String> requiredAttributes = new HashSet<>();
            requiredAttributes.add("PyelEmpOraseq");
            requiredAttributes.add("PyelEmpNo");
            requiredAttributes.add("PyelName");
            requiredAttributes.add("PyelAccessCode");
            requiredAttributes.add("PyelCompCode");
            requiredAttributes.add("PyelCompName");
            requiredAttributes.add("PyelPrnCode");
            requiredAttributes.add("PyelPrnName");
            requiredAttributes.add("PyelTrdCode");
            requiredAttributes.add("PyelTrdName");
            requiredAttributes.add("PyelUniCode");
            requiredAttributes.add("PyelUniName");
            requiredAttributes.add("PyelUserEnteredOt");
            requiredAttributes.add("PyelUserEnteredDt");
            requiredAttributes.add("PyelDfltEmpFlag");

            HashMap<String, Integer> attributeIndex = new HashMap<>();

            for (int i = 0; i < attributes.length(); i++) {
                String strAttribute = attributes.getString(i);
                if (requiredAttributes.contains(strAttribute)) {
                    attributeIndex.put(strAttribute, i);
                }
            }
            ArrayList<JSONArray> attributeValues = new ArrayList();

            //Log.d("test", "ing");
            for (int j = 0; j < Rows.length(); j++) {
                JSONArray values = Rows.getJSONObject(j).getJSONArray("attrValues");
                attributeValues.add(values);
            }

            // employee.add(new User("omi", "Parneet", "nikita"));
            TotalHours[] totalHourses = new TotalHours[attributeValues.size()];
            Log.e("attribute size: ", String.valueOf(attributeValues.size()));
            for (int k = 0; k < attributeValues.size(); k++) {
                String empOraseq = attributeValues.get(k).getString(attributeIndex.get("PyelEmpOraseq"));
                String empNumber = attributeValues.get(k).getString(attributeIndex.get("PyelEmpNo"));
                String empName = attributeValues.get(k).getString(attributeIndex.get("PyelName"));
                String accessCode = attributeValues.get(k).getString(attributeIndex.get("PyelAccessCode"));
                String compCode = attributeValues.get(k).getString(attributeIndex.get("PyelCompCode"));
                String compName = attributeValues.get(k).getString(attributeIndex.get("PyelCompName"));
                String prnCode = attributeValues.get(k).getString(attributeIndex.get("PyelPrnCode"));
                String prnName = attributeValues.get(k).getString(attributeIndex.get("PyelPrnName"));
                String PyelTrdCode = attributeValues.get(k).getString(attributeIndex.get("PyelTrdCode"));
                String PyelTrdName = attributeValues.get(k).getString(attributeIndex.get("PyelTrdName"));
                String PyelUniCode = attributeValues.get(k).getString(attributeIndex.get("PyelUniCode"));
                String PyelUniName = attributeValues.get(k).getString(attributeIndex.get("PyelUniName"));

                PyelEmpNo.add(attributeValues.get(k).getString(attributeIndex.get("PyelEmpNo")));
                PyelName.add(attributeValues.get(k).getString(attributeIndex.get("PyelName")));
                PyelEmpOraseq.add(attributeValues.get(k).getString(attributeIndex.get("PyelEmpOraseq")));
                //  PyelTradeName.add(attributeValues.get(k).getString(attributeIndex.get("PyelTrdName")));
                //       Log.d("PyelNAmeTrade", PyelTradeName.toString());
                String PN = empName;
                String[] array = PN.split(",");
                String Firstname = array[1].trim();
                String Lastname = array[0].trim();
                String completeName = Firstname + " " + Lastname;
                PyelAccessCode.add(attributeValues.get(k).getString(attributeIndex.get("PyelAccessCode")));

                employee.add(new User(attributeValues.get(k).getString(attributeIndex.get("PyelEmpNo")),
                        completeName,
                        attributeValues.get(k).getString(attributeIndex.get("PyelTrdCode")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelTrdName")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelEmpOraseq")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelCompCode")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelCompName")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelPrnCode")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelPrnName")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelAccessCode")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelUniCode")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelUniName")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelUserEnteredOt")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelUserEnteredDt")),
                        attributeValues.get(k).getString(attributeIndex.get("PyelDfltEmpFlag"))));

                // dbHelper.insertAllEmployees(empNumber, empOraseq, sortedarray, accessCode, compName, prnCode, prnName,compCode,PyelTrdCode,PyelTrdName,PyelUniCode,PyelUniName);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Log.d("exception empData", e.toString());
            return null;

        }
        return employee;
    }

}