package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/6/2018.
 */

public class AllEmployeesModel
{

    public String pyelEmpNo,
            pyelEmpOraseq,
            pyelEmpName,
            pyelAccessCode,
            pyelCompName,
            pyelPrnCode,
            pyelPrnName,
            pyelCompCode,
            pyelTrdCode,
            pyelTrdName,
            pyelUniCode,
            pyelUniName
                    ;

    public AllEmployeesModel(String pyelEmpNo, String pyelEmpOraseq, String pyelEmpName, String pyelAccessCode, String pyelCompName, String pyelPrnCode, String pyelPrnName,String pyelCompCode,String pyelTrdCode,String pyelTrdName,String pyelUniCode,String pyelUniName)
    {
        this.pyelEmpNo = pyelEmpNo;
        this.pyelEmpOraseq = pyelEmpOraseq;
        this.pyelEmpName = pyelEmpName;
        this.pyelAccessCode = pyelAccessCode;
        this.pyelCompName = pyelCompName;
        this.pyelPrnCode = pyelPrnCode;
        this.pyelPrnName = pyelPrnName;
        this.pyelCompCode = pyelCompCode;
        this.pyelTrdCode = pyelTrdCode;
        this.pyelTrdName = pyelTrdName;
        this.pyelUniCode = pyelUniCode;
        this.pyelUniName = pyelUniName;
    }

    public String getPyelAccessCode() {
        return pyelAccessCode;
    }

    public String getPyelCompCode() {
        return pyelCompCode;
    }

    public String getPyelCompName() {
        return pyelCompName;
    }

    public String getPyelEmpName() {
        return pyelEmpName;
    }

    public String getPyelEmpNo() {
        return pyelEmpNo;
    }

    public String getPyelEmpOraseq() {
        return pyelEmpOraseq;
    }

    public String getPyelPrnCode() {
        return pyelPrnCode;
    }

    public String getPyelPrnName() {
        return pyelPrnName;
    }

    public String getPyelTrdCode() {
        return pyelTrdCode;
    }

    public String getPyelTrdName() {
        return pyelTrdName;
    }

    public String getPyelUniCode() {
        return pyelUniCode;
    }

    public String getPyelUniName() {
        return pyelUniName;
    }

    public void setPyelAccessCode(String pyelAccessCode) {
        this.pyelAccessCode = pyelAccessCode;
    }

    public void setPyelCompCode(String pyelCompCode) {
        this.pyelCompCode = pyelCompCode;
    }

    public void setPyelCompName(String pyelCompName) {
        this.pyelCompName = pyelCompName;
    }

    public void setPyelEmpName(String pyelEmpName) {
        this.pyelEmpName = pyelEmpName;
    }

    public void setPyelEmpNo(String pyelEmpNo) {
        this.pyelEmpNo = pyelEmpNo;
    }

    public void setPyelEmpOraseq(String pyelEmpOraseq) {
        this.pyelEmpOraseq = pyelEmpOraseq;
    }

    public void setPyelPrnCode(String pyelPrnCode) {
        this.pyelPrnCode = pyelPrnCode;
    }

    public void setPyelPrnName(String pyelPrnName) {
        this.pyelPrnName = pyelPrnName;
    }

    public void setPyelTrdCode(String pyelTrdCode) {
        this.pyelTrdCode = pyelTrdCode;
    }

    public void setPyelTrdName(String pyelTrdName) {
        this.pyelTrdName = pyelTrdName;
    }

    public void setPyelUniCode(String pyelUniCode) {
        this.pyelUniCode = pyelUniCode;
    }

    public void setPyelUniName(String pyelUniName) {
        this.pyelUniName = pyelUniName;
    }
}