package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 5/4/2018.
 */

public class SignatureOraSeqModel {
    private String signOraSeq;
    private String signEmpOraSeq;
    private String signTshFromDate;
    private String signTshToDate;

    public String getSignOraSeq() {
        return signOraSeq;
    }

    public void setSignOraSeq(String signOraSeq) {
        this.signOraSeq = signOraSeq;
    }

    public String getSignEmpOraSeq() {
        return signEmpOraSeq;
    }

    public void setSignEmpOraSeq(String signEmpOraSeq) {
        this.signEmpOraSeq = signEmpOraSeq;
    }

    public String getSignTshFromDate() {
        return signTshFromDate;
    }

    public void setSignTshFromDate(String signTshFromDate) {
        this.signTshFromDate = signTshFromDate;
    }

    public String getSignTshToDate() {
        return signTshToDate;
    }

    public void setSignTshToDate(String signTshToDate) {
        this.signTshToDate = signTshToDate;
    }
}
