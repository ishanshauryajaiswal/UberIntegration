package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.PciInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


/**
 * Created by parneet.singh on 11/28/2016.
 */
public class PciTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private String phaseCode,categoryCode,jobCode,compcode;
    private PciInterface pciInterface;

    public PciTask(Context context,String phaseCode,String categoryCode ,String jobCode,String compcode, PciInterface pciInterface)
    {

        this.context = context;
        this.phaseCode = phaseCode;
        this.categoryCode = categoryCode;
        this.pciInterface = pciInterface;
        this.jobCode = jobCode;
        this.compcode = compcode ;
    }


    @Override
    protected void onPreExecute()
    {
        pciInterface.BeforeCompleted();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        try
        {
            RequestCall requestCall = new RequestCall(context);
            result = requestCall.pciTask(context, phaseCode,categoryCode,jobCode,compcode);
            Log.d(" RESPONSE pci", result);
        }
        catch(Exception e)
        {
            Log.d("error in pci",e.toString());
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        pciInterface.ResultFromPciWebservice(response);
    }
}