package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;


import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by parneet.singh on 2/16/2017.
 */
public class ActivityJobListAdapter extends BaseAdapter implements Filterable
{

    private ArrayList<JobData> jobModal;
    private Context context;
    private LayoutInflater mInflater;
    private List<JobData>filteredData = null;
    private ItemFilter mFilter = new ItemFilter();
    public ActivityJobListAdapter(Context context, ArrayList<JobData> jobModal)
    {
        this.context = context;
        this.jobModal = jobModal;
    }

    @Override
    public int getCount()
    {
        if(jobModal!=null)
            return jobModal.size();
        return 0;
    }

    @Override
    public JobData getItem(int position)
    {
        return jobModal.get(position);
    }
    public  void  setList(ArrayList<JobData> list)
    {
        jobModal = list;
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        JobData jobModal = getItem(position);
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listViewItem = inflater.inflate(R.layout.activity_job_detail, null);
        TextView txt_project = (TextView) listViewItem.findViewById(R.id.txtjobdetails);
        txt_project.setText("("+jobModal.getJobcode()+") - "+jobModal.getJobname());
        return listViewItem;
    }



    @Override
    public Filter getFilter()
    {
        return mFilter;
    }

    // Searching On basis of every property Of PhaseDetails
    private class ItemFilter extends Filter
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterString = constraint.toString().toLowerCase();
            FilterResults results = new FilterResults();
            final List<JobData> list = jobModal;
            int count = list.size();
            final ArrayList<JobData> nlist = new ArrayList<JobData>(count);
            JobData jobModal ;
            for (int i = 0; i < count; i++)
            {
                jobModal = list.get(i);
                if (jobModal.getJobcode().equals(filterString)||jobModal.getJobname().equals(filterString))
                {
                    nlist.add(jobModal);
                }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }
        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            filteredData = (ArrayList<JobData>) results.values;
            notifyDataSetChanged();

        }
    }
}
