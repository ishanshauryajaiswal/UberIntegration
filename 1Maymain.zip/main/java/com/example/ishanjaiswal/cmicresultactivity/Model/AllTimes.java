package com.example.ishanjaiswal.cmicresultactivity.Model;

public class AllTimes {
    double reg,ot,dot;

    public double getReg() {
        return reg;
    }

    public void setReg(double reg) {
        this.reg = reg;
    }

    public double getOt() {
        return ot;
    }

    public void setOt(double ot) {
        this.ot = ot;
    }

    public double getDot() {
        return dot;
    }

    public void setDot(double dot) {
        this.dot = dot;
    }
}
