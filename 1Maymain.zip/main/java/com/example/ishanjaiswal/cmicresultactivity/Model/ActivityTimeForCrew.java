package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.io.Serializable;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */
public class ActivityTimeForCrew implements Serializable
{
    public double standardTime;
    public double overTime;
    public double doubleOverTime;
    public double TotalColoumnBatchREG;  // total from batch reg coloumn wise
    public double TotalColoumnBatchOT;
    public double TotalColoumnBatchDOT;
    public double TotalREG;         // Total from Time entry popup
    public double TotalOT;
    public double TotalDOT;
    public String standardTimeSeqNumber,
            crewCode,
            workDate,
            empNumber,
            overTimeSeqNumber,
            doubleOverTimeSeqNumber;

    public ActivityTimeForCrew(String overTimeSeqNumber,
                               double overTime,
                               String standardTimeSeqNumber,
                               double standardTime,
                               String doubleOverTimeSeqNumber,
                               double doubleOverTime,
                               String crewCode,
                               String workDate,
                               String empNumber)
    {
        this.overTimeSeqNumber = overTimeSeqNumber;
        this.overTime = overTime;
        this.standardTimeSeqNumber = standardTimeSeqNumber;
        this.standardTime = standardTime;
        this.doubleOverTimeSeqNumber = doubleOverTimeSeqNumber;
        this.doubleOverTime = doubleOverTime;
        this.crewCode = crewCode;
        this.workDate = workDate;
        this.empNumber = empNumber;
    }
    public ActivityTimeForCrew()
    {

    }



    public void setTotalDOT(double totalDOT) {
        TotalDOT = totalDOT;
    }

    public void setTotalOT(double totalOT) {
        TotalOT = totalOT;
    }

    public void setTotalREG(double totalREG) {
        TotalREG = totalREG;
    }

    public double getTotalDOT() {
        return TotalDOT;
    }

    public double getTotalOT() {
        return TotalOT;
    }

    public double getTotalREG() {
        return TotalREG;
    }


    public double getStandardTime()
    {
        return this.standardTime;
    }
    public void setStandardTime(double standardTime)
    {
        this.standardTime = standardTime;
    }

    public String getStandardTimeSeqNumber()
    {
        return standardTimeSeqNumber;
    }

    public double getOverTime()
    {
        return this.overTime;
    }

    public void setEmpNumber(String empNumber) {
        this.empNumber = empNumber;
    }

    public void setCrewCode(String crewCode) {
        this.crewCode = crewCode;
    }

    public void setDoubleOverTimeSeqNumber(String doubleOverTimeSeqNumber) {
        this.doubleOverTimeSeqNumber = doubleOverTimeSeqNumber;
    }

    public void setOverTimeSeqNumber(String overTimeSeqNumber) {
        this.overTimeSeqNumber = overTimeSeqNumber;
    }

    public void setStandardTimeSeqNumber(String standardTimeSeqNumber) {
        this.standardTimeSeqNumber = standardTimeSeqNumber;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }


    public void setOverTime(double overTime)
    {
        this.overTime=overTime;
    }

    public String getOverTimeSeqNumber(){
        return overTimeSeqNumber;
    }

    public double getDoubleOverTime()
    {
        return this.doubleOverTime;
    }
    public void setDoubleOverTime(double doubleOverTime)
    {
        this.doubleOverTime=doubleOverTime;
    }

    public String getDoubleOverTimeSeqNumber()
    {
        return  doubleOverTimeSeqNumber;
    }

    public String getCrewCode()
    {
        return crewCode;
    }
    public String getWorkDate()
    {
        return workDate;
    }
    public String getEmpNumber()
    {
        return empNumber;
    }

    public double getTotalColoumnBatchDOT() {
        return TotalColoumnBatchDOT;
    }

    public double getTotalColoumnBatchOT() {
        return TotalColoumnBatchOT;
    }

    public double getTotalColoumnBatchREG() {
        return TotalColoumnBatchREG;
    }

    public void setTotalColoumnBatchDOT(double totalColoumnBatchDOT) {
        TotalColoumnBatchDOT = totalColoumnBatchDOT;
    }

    public void setTotalColoumnBatchOT(double totalColoumnBatchOT) {
        TotalColoumnBatchOT = totalColoumnBatchOT;
    }

    public void setTotalColoumnBatchREG(double totalColoumnBatchREG) {
        TotalColoumnBatchREG = totalColoumnBatchREG;
    }
}
