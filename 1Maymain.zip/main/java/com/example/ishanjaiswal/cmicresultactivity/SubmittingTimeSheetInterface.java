package com.example.ishanjaiswal.cmicresultactivity;

/**
 * Created by parneet.singh on 11/29/2016.
 */
public interface SubmittingTimeSheetInterface {

    public void SubmittingTimeSheetInterface(String result);
    public void BeforeCompleted();
}
