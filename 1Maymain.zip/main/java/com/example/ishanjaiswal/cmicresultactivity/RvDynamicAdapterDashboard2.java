package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.RecyclerViewClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 2/1/2018.
 */

public class RvDynamicAdapterDashboard2 extends RecyclerView.Adapter<RvDynamicAdapterDashboard2.ViewHolder> {
    private List<Dashboard2> mList;
    private Context mContext;
    private int columns = 7;
    private RecyclerViewClickListener mListener;

    public RvDynamicAdapterDashboard2(List<Dashboard2> mList, Context mContext, RecyclerViewClickListener mListener) {
        this.mList = mList;
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout ll = new LinearLayout(mContext);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.WRAP_CONTENT,
                RecyclerView.LayoutParams.WRAP_CONTENT);
        ll.setLayoutParams(layoutParams);
        return new ViewHolder(ll, mContext);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final Dashboard2 dashboard2 = mList.get(position);
        TextView regValue, otValue, dotValue;
        List<AllTimes> allTimesList = dashboard2.getTimesList();
        for (int i = 0; i < dashboard2.getTimesList().size(); i++){
            LinearLayout l = holder.linearLayoutArray[i];
            regValue = (TextView) l.getChildAt(0);
            otValue = (TextView) l.getChildAt(1);
            dotValue = (TextView) l.getChildAt(2);
            regValue.setText(String .valueOf(allTimesList.get(i).getReg()));
            otValue.setText(String .valueOf(allTimesList.get(i).getOt()));
            dotValue.setText(String .valueOf(allTimesList.get(i).getDot()));
            l.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.onRecyclerViewDashboard2RowClicked(dashboard2.getEmpNo(), dashboard2.getEmpFirstName().concat(" ".concat(dashboard2.getEmpLastName())));
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(List<Dashboard2> mList) {
        this.mList = mList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        Context mContext;
        LinearLayout linearLayoutArray[];
        public ViewHolder(View itemView, Context context) {
            super(itemView);
            this.mContext = context;
            linearLayoutArray = new LinearLayout[columns];
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            LinearLayout linearLayout = (LinearLayout) itemView;
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setLayoutParams(params);
            linearLayout.removeAllViews();
            for (int i = 0; i < linearLayoutArray.length; i++) {
                linearLayoutArray[i] = addLinearLayout();
                linearLayout.addView(linearLayoutArray[i]);
            }
        }

        private LinearLayout addLinearLayout() {
            LinearLayout linearLayoutRow;
            TextView regValue, otValue, dotValue;
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(dpToPx(180),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            linearLayoutRow = new LinearLayout(mContext);
            linearLayoutRow.removeAllViews();
            linearLayoutRow.setOrientation(LinearLayout.HORIZONTAL);
            linearLayoutRow.setLayoutParams(rowParams);
            int blueColor = ContextCompat.getColor(mContext,R.color.colorLightBlue);

            LinearLayout.LayoutParams tvSmallParams = new TableRow.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))), 1f);

            regValue = new TextView(mContext);
            regValue.setLayoutParams(tvSmallParams);
            regValue.setGravity(Gravity.CENTER);
            regValue.setTextColor(Color.BLACK);
            regValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            regValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));


            otValue = new TextView(mContext);
            otValue.setLayoutParams(tvSmallParams);
            otValue.setGravity(Gravity.CENTER);
            otValue.setTextColor(Color.BLACK);
            otValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            otValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            dotValue = new TextView(mContext);
            dotValue.setLayoutParams(tvSmallParams);
            dotValue.setGravity(Gravity.CENTER);
            dotValue.setTextColor(Color.BLACK);
            dotValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            dotValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            LinearLayout.LayoutParams viewDividerParams = new LinearLayout.LayoutParams(dpToPx(1),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.header_cell_height))));
            LinearLayout viewDivider = new LinearLayout(mContext);
            viewDivider.removeAllViews();
            viewDivider.setLayoutParams(viewDividerParams);
            viewDivider.setBackgroundColor(blueColor);

            linearLayoutRow.addView(regValue); linearLayoutRow.addView(otValue); linearLayoutRow.addView(dotValue);
            linearLayoutRow.addView(viewDivider);
            return linearLayoutRow;
        }

        public int dpToPx(int dp) {
            DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
            return Math.round(dp * displayMetrics.density+0.5f);
        }
    }
}
