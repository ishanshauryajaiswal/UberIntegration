package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

/**
 * Created by ishan.jaiswal on 2/2/2018.
 */

public class CustomTextViewValues extends android.support.v7.widget.AppCompatTextView {
    Context mContext;
    public CustomTextViewValues(Context mContext) {
        super(mContext);
        this.mContext = mContext;
    }

    TextView getTextView(LinearLayout.LayoutParams tvParams){
        TextView tv = new TextView(mContext);
        tv.setLayoutParams(tvParams);
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setTextSize(20);
        tv.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        return tv;
    }
}
