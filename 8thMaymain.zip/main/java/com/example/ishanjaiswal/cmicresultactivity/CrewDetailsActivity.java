package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.LinkingEmployeeWithCrewTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.UpdateResponsiblePersonTask;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanAllEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanCrewListDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanSelectedEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.LinkingCrewEmployeeWithCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ishan.jaiswal on 2/9/2018.
 */

//This activity is started for result by main activity or by crew list activity
//For Responsible person: tvNext,selectAll are invisible and showhidecheckbox is false
    // crewListActivity uses this activity to link employees with crew only
    //Mainactivity uses this activity to add employees to crew and to select responsible person

public class CrewDetailsActivity extends ListActivity {
    private static final String TAG = CrewDetailsActivity.class.getSimpleName();
    TextView txtCrewName, txtNext, txtSelect;
    EditText editText;
    CheckBox checkbox;
    ProgressDialog dialog;
    ArrayList<User> CrewMemberDetails, selectedUsers;
    ArrayList<EmployeeDataForCrew> newCrewList = null;
    public String  crewCode;
    ImageButton btn;
    public Button btnSaved, btnAll;
    ListView crewMembersList;
    ArrayList<String> previouslyCheckedEmployeeList = new ArrayList<>();
    String employeeNumber;
    String SelectedCrewOraseq, SelectedCrewCode, SelectedCrewName;
    private boolean isFromTimesheet, showOrHideCheckbox;
    private SharedPreferences ishanSharedPreference;
    private SharedPreferences.Editor ishanPreferenceEditor;
    IshanSelectedEmployeeDBHelper ishanSelectedEmployeeDBHelper;
    IshanAllEmployeeDBHelper allEmployeeDBHelper;
    CrewMemberAdapter crewMemberAdapter;
    HashMap<String,Boolean> checkedEmployees = new HashMap<>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crewmembers_list);
        ishanSelectedEmployeeDBHelper = new IshanSelectedEmployeeDBHelper(CrewDetailsActivity.this);
        ishanSharedPreference = getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        SelectedCrewName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_name),getString(R.string.cmic_shared_preference_no_crew_name));
        getValueFromIntent();
        init();
        setUpStatusBar();

        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setFocusableInTouchMode(true);
                editText.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
            }
        });

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                s = s.toString().toLowerCase();
                ArrayList<User> filteredListName = new ArrayList<User>();
                for (int i = 0; i < CrewMemberDetails.size(); i++){
                    String txtCrewName = CrewMemberDetails.get(i).getName().toLowerCase();
                    String txtCrewCode = CrewMemberDetails.get(i).getUniCode().toLowerCase();
                    String txtCrewTradeName = CrewMemberDetails.get(i).getTradeName().toLowerCase();
                    String txtCrewTradeCode = CrewMemberDetails.get(i).getTradeCode().toLowerCase();
                    if (txtCrewName.contains(s) || txtCrewCode.contains(s) || txtCrewTradeName.contains(s) || txtCrewTradeCode.contains(s))
                        filteredListName.add(CrewMemberDetails.get(i));
                }
                crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, filteredListName, checkedEmployees, showOrHideCheckbox);
                crewMembersList.setAdapter(crewMemberAdapter);
                handleList();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CrewDetailsActivity.this, CrewListActivity.class);
                startActivity(intent);

            }
        });
        btnSaved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //select visiblity INVISIBLE temporray for new.Ishan TODO
                txtSelect.setVisibility(View.INVISIBLE);
                btnSaved.setEnabled(false);
                btnAll.setEnabled(true);
                btnAll.setBackgroundResource(R.drawable.deselected_all_button_background);
                btnAll.setTextColor(Color.parseColor("#1780FB"));
                btnSaved.setBackgroundResource(R.drawable.saved_button_background);
                btnSaved.setTextColor(Color.parseColor("#ffffff"));
                CrewMemberDetails = ishanSelectedEmployeeDBHelper.selectAllEmployeesFromDatabase();
                crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, CrewMemberDetails, checkedEmployees, showOrHideCheckbox);
                crewMembersList.setAdapter(crewMemberAdapter);
                handleList();
            }
        });

        btnAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //select all and next should not be visible if responsible person has to be selected
                if (showOrHideCheckbox)
                    txtSelect.setVisibility(View.INVISIBLE);
                btnSaved.setEnabled(true);
                btnAll.setEnabled(false);
                btnAll.setBackgroundResource(R.drawable.all_button_background);
                btnAll.setTextColor(Color.parseColor("#ffffff"));
                btnSaved.setBackgroundResource(R.drawable.deselected_save_button_background);
                btnSaved.setTextColor(Color.parseColor("#1780FB"));
                webServiceForEmployeeData();
            }
        });
        btnSaved.callOnClick();
    }

    public void init()
    {
        crewMembersList = (ListView) findViewById(android.R.id.list);
        btnSaved = (Button) findViewById(R.id.btnSave);
        btnAll = (Button) findViewById(R.id.btnAll);
        txtCrewName = (TextView) findViewById(R.id.txtName);
        editText = (EditText) findViewById(R.id.inputSearch);
        txtNext = (TextView) findViewById(R.id.txtDone);
        txtSelect = (TextView) findViewById(R.id.txtSelected);
        btn = (ImageButton) findViewById(R.id.btnback);
        //Disable Next Button if List for Responsible Person
        if (!showOrHideCheckbox){
            txtNext.setVisibility(View.INVISIBLE);
            txtSelect.setVisibility(View.INVISIBLE);
        }
    }

    public void webServiceForEmployeeData()
    {
        new GetEmployees(getApplicationContext(), new CrewMemberDataListener() {
            @Override
            public void onCrewMemberDataTaskCompleted(String response) {
                dialog.dismiss();
                if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                    EmployeeDataParser EmployeeDataParser = new EmployeeDataParser();
                    CrewMemberDetails = EmployeeDataParser.parseEmployeeData(response, getApplicationContext());
                    crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, CrewMemberDetails, checkedEmployees, showOrHideCheckbox);
                    crewMembersList.setAdapter(crewMemberAdapter);
                    handleList();
                }
                else {
                    final AlertDialog.Builder alertBox = new AlertDialog.Builder(CrewDetailsActivity.this);
                    alertBox.setTitle("CMiC Mobile Crew Time");
                    alertBox.setMessage("No Crew Members Found");
                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alertBox.setCancelable(true);
                            webServiceForEmployeeData();
                        }
                    });
                    alertBox.show();
                }
            }

            @Override
            public void onCrewMemberDataTaskStarted() {
                dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Fetching Crew Members...");
            }

            @Override
            public void onCrewMemberDataTaskCancelled() {

            }
        }).execute();
    }

    private void handleList(){
        crewMembersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                checkbox = (CheckBox) view.findViewById(R.id.chkbox);
                if (showOrHideCheckbox)
                {
                    if (checkbox.isChecked()) {
                        checkbox.setChecked(false);
                        checkedEmployees.put(crewMemberAdapter.getItem(position).getEmployeeNo(),false);
                    } else {
                        checkbox.setChecked(true);
                        checkedEmployees.put(crewMemberAdapter.getItem(position).getEmployeeNo(),true);
                    }
                    crewMemberAdapter.setCheckedEmployees(checkedEmployees);
                }
                //To Change Responsible Person - This is used only when we change responsible person for crew. And that is done only from timesheet
                else {
                    final String responsiblePerson = crewMemberAdapter.getItem(position).getName();
                    final String responsiblePersonOraSeq = crewMemberAdapter.getItem(position).getEmployeeOraseq();
                    ishanSelectedEmployeeDBHelper.insertSelectedEmployeeInDatabase((User) crewMemberAdapter.getItem(position));
                    String table = "{\"table\":\"PycrewView\",\"rowDefinition\":{\"attrNames\":[\"PycrCode\",\"PycrName\",\"PycrResponsibleEmpOraseq\"]},\"rows\":[{\"attrValues\":[\"" + SelectedCrewCode + "\",\"" + SelectedCrewName + "\",\"" + responsiblePersonOraSeq + "\"]}]}";
                    new UpdateResponsiblePersonTask(getApplicationContext(), SelectedCrewCode, table, new UpdateResponsiblePersonTask.UpdateResponsiblePersonTaskInterface() {
                        @Override
                        public void onTaskStartedListener() {
                            dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Updating Responsible Person...");
                        }

                        @Override
                        public void onTaskFinishedListener(String response) {
                            dialog.dismiss();
                            if (response != null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                                ishanPreferenceEditor.putString(getString(R.string.cmic_shared_preference_responsible_person), responsiblePerson);
                                ishanPreferenceEditor.commit();
                                IshanCrewListDBHelper crewListDBHelper = new IshanCrewListDBHelper(getApplicationContext());
                                crewListDBHelper.updateResponsiblePersonForCrew(SelectedCrewCode,responsiblePerson,responsiblePersonOraSeq);
                                setResult(Activity.RESULT_OK);
                                finish();
                            } else {
                                final AlertDialog.Builder alertBox = new AlertDialog.Builder(CrewDetailsActivity.this);
                                alertBox.setTitle("CMiC Mobile Crew Time");
                                alertBox.setMessage("Some Error Occurred While Updating Responsible Person For Crew");
                                alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        alertBox.setCancelable(true);
                                        setResult(Activity.RESULT_CANCELED);
                                        finish();
                                    }
                                });
                                alertBox.show();
                            }
                        }
                    }).execute();
                }
            }
        });

        txtNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedUsers = new ArrayList<User>();
                boolean noCheckBoxSelected = true;
                for (Map.Entry<String ,Boolean> entry: checkedEmployees.entrySet()){
                    if (entry.getValue())
                        noCheckBoxSelected = false;
                }
                if (noCheckBoxSelected){
                    AlertDialog.Builder alertActivity = new  AlertDialog.Builder(CrewDetailsActivity.this);
                    alertActivity.setTitle("CMiC Mobile Crew Time");
                    alertActivity.setMessage("Please select at least one crew member to continue");
                    alertActivity.setPositiveButton("OK", null);
                    alertActivity.show();
                }
                else {
                    //unchecking members already in the crew
                    for (String s:previouslyCheckedEmployeeList){
                        checkedEmployees.put(s,false);
                    }

                    for (User currentUser: CrewMemberDetails)
                        if (checkedEmployees.containsKey(currentUser.getEmployeeNo())) {
                            if (checkedEmployees.get(currentUser.getEmployeeNo())) {
                                selectedUsers.add(currentUser);
                                ishanSelectedEmployeeDBHelper.insertSelectedEmployeeInDatabase(currentUser);
                            }
                        }

                    if (showOrHideCheckbox)
                    {
                        newCrewList = new ArrayList<EmployeeDataForCrew>();
                        LinkingEmployeeWithCrewTask linkingEmployeeWithCrewTask = new LinkingEmployeeWithCrewTask(CrewDetailsActivity.this,
                                SelectedCrewOraseq, selectedUsers,
                                new LinkingEmployeeWithCrewTask.LinkingEmployeeInterface() {
                            @Override
                            public void onPostExecute(String response) {
                                dialog.dismiss();
                                if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                                    FetchEmployeesOfCrew fetchEmployeesOfCrew = new FetchEmployeesOfCrew(CrewDetailsActivity.this, SelectedCrewCode, new FetchEmployeesOfCrewInterface() {
                                        @Override
                                        public void preTask() {
                                            dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Inserting Crew Members in Database...");
                                        }

                                        @Override
                                        public void postTask(String response) {
                                            dialog.dismiss();
                                             if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                                                LinkingCrewEmployeeWithCrew employeeCrew = new FetchedCrewEmployeeParser().parseFetchedCrewEmployeeData(response);
                                                if (employeeCrew != null) {
                                                    //if employeeCrew not null then crew has members
                                                    ArrayList<AttributeValuesForCrewModal> employeesInCrew = employeeCrew.getAttributeValuesForCrewModals();
                                                    allEmployeeDBHelper = new IshanAllEmployeeDBHelper(CrewDetailsActivity.this);
                                                    allEmployeeDBHelper.insertAllEmployeeInDatabase(employeesInCrew);
                                                    setResult(Activity.RESULT_OK);
                                                    finish();
                                                }
                                            }
                                            else {
                                                 final AlertDialog.Builder alertBox = new AlertDialog.Builder(CrewDetailsActivity.this);
                                                 alertBox.setTitle("CMiC Mobile Crew Time");
                                                 alertBox.setMessage("Some Error Occurred Adding Members to the Crew");
                                                 alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                     @Override
                                                     public void onClick(DialogInterface dialog, int which) {
                                                         alertBox.setCancelable(true);
                                                         setResult(Activity.RESULT_CANCELED);
                                                         finish();
                                                     }
                                                 });
                                                 alertBox.show();
                                             }
                                    }});
                                    if (isFromTimesheet) {
                                        //Insert selected employees in timesheet database and make timesheet edited true
                                        IshanDBHelper mInstance = IshanDBHelper.getInstance(CrewDetailsActivity.this);
                                        CrewTimeSheet crewTimeSheet = mInstance.getTimeSheetFromDatabase();
                                        ArrayList<ActivityTimeForCrew> a    ;
                                        for (User crewMember : selectedUsers) {
                                            a = new ArrayList<ActivityTimeForCrew>();
                                            for (int i = 0; i < crewTimeSheet.getCrewActivity().size(); i++) {
                                                ActivityTimeForCrew activity = new ActivityTimeForCrew(null, 0, null, 0, null, 0, crewTimeSheet.getCrewCode()
                                                        , crewTimeSheet.getWorkDate(), crewMember.getEmployeeNo());
                                                a.add(activity);
                                            }
                                            EmployeeDataForCrew e = new EmployeeDataForCrew("null", crewMember.getEmployeeNo(), crewMember.getEmployeeOraseq(),
                                                    crewMember.getName(), crewMember.getTradeCode(), crewMember.getTradeName(),
                                                    crewTimeSheet.getEmpTimeSheet().size() + "", "",
                                                    a);
                                            crewTimeSheet.getEmpTimeSheet().add(e);
                                            mInstance.insertEmployeeInDatabase(e);
                                        }
                                        mInstance.setTimeSheetStateInDatabase(true, crewTimeSheet.getWorkDate());
                                    }
                                    fetchEmployeesOfCrew.execute();
                                }
                                else {
                                    final AlertDialog.Builder alertBox = new AlertDialog.Builder(CrewDetailsActivity.this);
                                    alertBox.setTitle("CMiC Mobile Crew Time");
                                    alertBox.setMessage("Some Error Occurred Adding Members to the Crew");
                                    alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            alertBox.setCancelable(true);
                                            setResult(Activity.RESULT_CANCELED);
                                            finish();
                                        }
                                    });
                                    alertBox.show();
                                }
                            }
                                    @Override
                                    public void onPreExecute() {
                                        dialog = ProgressDialog.show(CrewDetailsActivity.this, null, "         Linking Crew Members With Crew...");
                                    }
                                });
                        linkingEmployeeWithCrewTask.execute();
                    }
                }
                }
            }
        );

        txtSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,Boolean> checked = new HashMap<String, Boolean>();
                if (txtSelect.getText().toString().trim().equals("Select All")) {
                    txtSelect.setText("Clear All");
                    if (CrewMemberDetails.size()>0) {
                        for (int i = 0; i < CrewMemberDetails.size(); i++) {
                            checked.put(CrewMemberDetails.get(i).getEmployeeNo(),true);
                        }
                        crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, CrewMemberDetails, checked,showOrHideCheckbox);
                        crewMembersList.setAdapter(crewMemberAdapter);
                    }
                } else {
                    txtSelect.setText("Select All");
                    for (int i = 0; i < CrewMemberDetails.size(); i++) {
                        checked.put(CrewMemberDetails.get(i).getEmployeeNo(),false);
                    }
                    crewMemberAdapter = new CrewMemberAdapter(CrewDetailsActivity.this, CrewMemberDetails, checked,showOrHideCheckbox);
                    crewMembersList.setAdapter(crewMemberAdapter);
                }
            }
        });
    }

    public void getValueFromIntent()
    {
        isFromTimesheet = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_timesheet),false);
        if (isFromTimesheet){
            SelectedCrewOraseq = getIntent().getStringExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq));
            SelectedCrewCode = getIntent().getStringExtra(getString(R.string.cmic_intent_extras_selected_crew_code));
            CrewTimeSheet mCrewTimeSheet = (CrewTimeSheet) getIntent().getSerializableExtra(getString(R.string.cmic_intent_extras_timesheet));
            if (mCrewTimeSheet != null) {
                for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                    employeeNumber = mCrewTimeSheet.getEmpTimeSheet().get(i).getEmpNo();
                    previouslyCheckedEmployeeList.add(employeeNumber);
                    checkedEmployees.put(employeeNumber,true);
                }
            }
        }
        boolean isFromCrewList;
        isFromCrewList = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_from_crew_list),false);
        if (isFromCrewList){
            SelectedCrewCode = getIntent().getStringExtra(getString(R.string.cmic_intent_extras_selected_crew_code));
            SelectedCrewName = getIntent().getStringExtra(getString(R.string.cmic_intent_extras_selected_crew_name));
            SelectedCrewOraseq = getIntent().getStringExtra(getString(R.string.cmic_intent_extras_selected_crew_oraseq));
        }
        showOrHideCheckbox = getIntent().getBooleanExtra(getString(R.string.cmic_intent_extras_show_checkbox),true);
    }

    private void setUpStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }
    }
}
