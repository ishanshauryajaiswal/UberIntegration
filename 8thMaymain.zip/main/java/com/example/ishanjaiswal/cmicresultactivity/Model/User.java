package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.io.Serializable;

/**
 * Created by ishan.jaiswal on 2/6/2018.
 */

public class User implements Serializable
{


    public String employeeNo;
    public String name;
    public   String total ="";
    public String designation;
    public String tradeCode;
    public String tradeName;
    public String EmployeeOraseq;
    public String CompCode;
    public String CompName;
    public String prnCode;
    public String prnName;
    public String accessCode;
    public String uniCode;
    public String uniName;
    public String enteredOt;
    public String enteredDt;
    public String defaultFlag;

    public void setPrnCode(String prnCode) {
        this.prnCode = prnCode;
    }

    public void setPrnName(String prnName) {
        this.prnName = prnName;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public void setUniCode(String uniCode) {
        this.uniCode = uniCode;
    }

    public void setUniName(String uniName) {
        this.uniName = uniName;
    }

    public String getEnteredOt() {
        return enteredOt;
    }

    public void setEnteredOt(String enteredOt) {
        this.enteredOt = enteredOt;
    }

    public String getEnteredDt() {
        return enteredDt;
    }

    public void setEnteredDt(String enteredDt) {
        this.enteredDt = enteredDt;
    }

    public String getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(String defaultFlag) {
        this.defaultFlag = defaultFlag;
    }



    public User(String employeeNo,String name ,String tradeCode, String tradeName,String EmployeeOraseq,String CompCode,String CompName,String prnCode,String prnName,String accessCode,String uniCode,String uniName, String enteredOt, String enteredDt, String defaultFlag)
    {
        this.employeeNo = employeeNo;
        this.name = name;
        this.tradeName = tradeName;
        this.EmployeeOraseq=EmployeeOraseq;
        this.tradeCode = tradeCode;
        this.CompCode = CompCode;
        this.CompName = CompName;
        this.prnCode = prnCode;
        this.prnName = prnName;
        this.accessCode = accessCode;
        this.uniCode = uniCode;
        this.uniName = uniName;
        this.enteredOt = enteredOt;
        this.enteredDt = enteredDt;
        this.defaultFlag = defaultFlag;
    }
    public User ()
    {

    }

    public String getTradeName() {
        return tradeName;
    }

    public String getCompCode() {
        return CompCode;
    }

    public String getCompName() {
        return CompName;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }


    public String getTotal() {
        return total;
    }

    public String getAccessCode() {
        return accessCode;
    }

    public String getPrnCode() {
        return prnCode;
    }

    public String getPrnName() {
        return prnName;
    }

    public String getUniCode() {
        return uniCode;
    }

    public String getUniName() {
        return uniName;
    }

    public void setCompCode(String compCode) {
        CompCode = compCode;
    }

    public void setCompName(String compName) {
        CompName = compName;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getTradeCode() {
        return tradeCode;
    }

    public void setTradeCode(String tradeCode) {
        this.tradeCode = tradeCode;
    }

    public String getName()
    {
        return name;
    }
    public String getDesignation(){
        return designation;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setDesignation(String designation)
    {
        this.designation=designation;
    }

    public void setEmployeeOraseq(String employeeOraseq) {
        EmployeeOraseq = employeeOraseq;
    }

    public String getEmployeeOraseq() {
        return EmployeeOraseq;
    }
}