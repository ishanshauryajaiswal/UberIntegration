package com.example.ishanjaiswal.cmicresultactivity.Model;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/26/2018.
 */

public class Dashboard3 {
    List<AllTimes> timesList;
    AllTimes totalTime;
    public String  SelectedDate,EmpAcsCode, EmpNo, EmpFirstName,EmpLastName,EmpOraSeq, TshDataType,
            TshWorkCompCode,TshJobCode,TshPhase,TshCategory,TshDeptCode,
            TshGlAccCode,TshTradeCode,TshUnionCode,TshShiftCode,TshJobName,
            TshPhaseName,TshCategoryName,TshDeptName,TshGlAccName,TshTradeName,
            TshUnionName,TshShiftName, otherHrsTot;

    public String getOtherHrsTot() {
        return otherHrsTot;
    }

    public void setOtherHrsTot(String otherHrsTot) {
        this.otherHrsTot = otherHrsTot;
    }

    public String getEmpOraSeq() {
        return EmpOraSeq;
    }

    public void setEmpOraSeq(String empOraSeq) {
        EmpOraSeq = empOraSeq;
    }

    public List<AllTimes> getTimesList() {
        return timesList;
    }

    public void setTimesList(List<AllTimes> timesList) {
        this.timesList = timesList;
    }

    public AllTimes getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(AllTimes totalTime) {
        this.totalTime = totalTime;
    }

    public String getSelectedDate() {
        return SelectedDate;
    }


    public String getEmpAcsCode() {
        return EmpAcsCode;
    }

    public String getEmpFirstName() {
        return EmpFirstName;
    }

    public String getEmpLastName() {
        return EmpLastName;
    }

    public String getEmpNo() {
        return EmpNo;
    }

    public String getTshCategory() {
        return TshCategory;
    }

    public String getTshCategoryName() {
        return TshCategoryName;
    }

    public String getTshDataType() {
        return TshDataType;
    }

    public String getTshDeptCode() {
        return TshDeptCode;
    }

    public String getTshDeptName() {
        return TshDeptName;
    }

    public String getTshGlAccCode() {
        return TshGlAccCode;
    }

    public String getTshGlAccName() {
        return TshGlAccName;
    }

    public String getTshJobCode() {
        return TshJobCode;
    }

    public String getTshJobName() {
        return TshJobName;
    }

    public String getTshPhase() {
        return TshPhase;
    }

    public String getTshPhaseName() {
        return TshPhaseName;
    }

    public String getTshShiftCode() {
        return TshShiftCode;
    }

    public String getTshShiftName() {
        return TshShiftName;
    }

    public String getTshTradeCode() {
        return TshTradeCode;
    }

    public String getTshTradeName() {
        return TshTradeName;
    }

    public String getTshUnionCode() {
        return TshUnionCode;
    }

    public String getTshUnionName() {
        return TshUnionName;
    }

    public String getTshWorkCompCode() {
        return TshWorkCompCode;
    }

    public void setEmpAcsCode(String empAcsCode) {
        EmpAcsCode = empAcsCode;
    }

    public void setEmpFirstName(String empFirstName) {
        EmpFirstName = empFirstName;
    }

    public void setEmpLastName(String empLastName) {
        EmpLastName = empLastName;
    }

    public void setEmpNo(String empNo) {
        EmpNo = empNo;
    }

    public void setTshCategory(String tshCategory) {
        TshCategory = tshCategory;
    }

    public void setTshCategoryName(String tshCategoryName) {
        TshCategoryName = tshCategoryName;
    }

    public void setTshDataType(String tshDataType) {
        TshDataType = tshDataType;
    }

    public void setSelectedDate(String selectedDate) {
        SelectedDate = selectedDate;
    }

    public void setTshDeptCode(String tshDeptCode) {
        TshDeptCode = tshDeptCode;
    }

    public void setTshDeptName(String tshDeptName) {
        TshDeptName = tshDeptName;
    }

    public void setTshGlAccCode(String tshGlAccCode) {
        TshGlAccCode = tshGlAccCode;
    }

    public void setTshGlAccName(String tshGlAccName) {
        TshGlAccName = tshGlAccName;
    }

    public void setTshJobCode(String tshJobCode) {
        TshJobCode = tshJobCode;
    }

    public void setTshJobName(String tshJobName) {
        TshJobName = tshJobName;
    }

    public void setTshPhase(String tshPhase) {
        TshPhase = tshPhase;
    }

    public void setTshPhaseName(String tshPhaseName) {
        TshPhaseName = tshPhaseName;
    }

    public void setTshShiftCode(String tshShiftCode) {
        TshShiftCode = tshShiftCode;
    }

    public void setTshShiftName(String tshShiftName) {
        TshShiftName = tshShiftName;
    }

    public void setTshTradeCode(String tshTradeCode) {
        TshTradeCode = tshTradeCode;
    }

    public void setTshTradeName(String tshTradeName) {
        TshTradeName = tshTradeName;
    }

    public void setTshUnionCode(String tshUnionCode) {
        TshUnionCode = tshUnionCode;
    }

    public void setTshUnionName(String tshUnionName) {
        TshUnionName = tshUnionName;
    }

    public void setTshWorkCompCode(String tshWorkCompCode) {
        TshWorkCompCode = tshWorkCompCode;
    }
}
