package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by shaurya on 22/04/18.
 */

public interface JobDataListener {
    void beforeJobDataTaskStarted(String displayMessage);
    void onJobDataTaskComplete(String response);
    void onJobDataTaskCancelled();
}
