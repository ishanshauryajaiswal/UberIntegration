package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

import android.graphics.Bitmap;

import com.example.ishanjaiswal.cmicresultactivity.Utils.GetSignature;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface DashboardTaskListener {

    void beforeDashboardTaskStarted(String displayMessage);

    void onDashboardTaskComplete(String response);

    void onTaskCancelled();

    void onDashboard2TaskComplete(String response);

    void onDashboard3TaskComplete(String response);

    void onGetSignatureStarted(String displayMessage);

    void onGetSignatureCompleted(String response);

    void onGetSignatureStarted();

    void onGetSignatureCompleted(Bitmap bitmap, GetSignature enumSignature);

    void onPostSignatureTaskStarted(String displayMessage);

    void onPostSignatureTaskCompleted(String response);
}
