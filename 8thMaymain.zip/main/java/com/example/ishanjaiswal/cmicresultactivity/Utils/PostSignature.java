package com.example.ishanjaiswal.cmicresultactivity.Utils;

/**
 * Created by ishan.jaiswal on 5/4/2018.
 */

public enum PostSignature {
    EMPLOYEE,
    FOREMAN
}
