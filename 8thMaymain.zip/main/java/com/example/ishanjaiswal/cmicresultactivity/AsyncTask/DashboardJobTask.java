package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class DashboardJobTask extends AsyncTask<Void,Void,String>
{

    private Context context;
    private String compCode,jobCode,workDate;
    private DashboardTaskListener mListener;

    public DashboardJobTask(Context context, String compCode, String jobCode, String workDate, DashboardTaskListener mListener)
    {

        this.context = context;
        this.compCode = compCode;
        this.jobCode = jobCode;
        this.workDate = workDate;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute()
    {
        if (!isCancelled())
            mListener.beforeDashboardTaskStarted("Fetching");
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String result="";
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(context);
                result = requestCall.dashboardTask(context, compCode, jobCode, workDate);
            } catch (Exception e) {
            }
        }
        return result;
    }
    protected void onPostExecute(String response)
    {
        if (!isCancelled())
            mListener.onDashboardTaskComplete(response);
    }

    @Override
    protected void onCancelled() {
        mListener.onTaskCancelled();
        super.onCancelled();
    }

}