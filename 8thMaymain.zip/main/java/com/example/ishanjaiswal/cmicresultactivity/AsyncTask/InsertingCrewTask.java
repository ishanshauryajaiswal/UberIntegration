package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.InsertCrewInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class InsertingCrewTask extends AsyncTask<Void, Void, String > {

    private Context mContext;
    String table;
    InsertCrewInterface insertCrewListner;
    private final static String TAG = InsertingCrewTask.class.getSimpleName();

    public InsertingCrewTask(Context mContext, String table, InsertCrewInterface insertCrewListner) {
        this.mContext = mContext;
        this.table = table;
        this.insertCrewListner = insertCrewListner;
    }

    @Override
    protected void onPreExecute()
    {
        insertCrewListner.onPreTask();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall(mContext);
            response = requestCall.insertCrew(mContext, table);
        }
        catch (Exception e)
        {
            Log.d(TAG,"Exception in Inserting New Crew: "+e.toString());
        }
        return response;
    }

    protected void onPostExecute(String response)
    {
        insertCrewListner.onPostTask(response);
    }

    private class SelectCrewOnCrewCodeBasis extends AsyncTask<Void, Void, String>{
        String insertedCrewCode;
        public SelectCrewOnCrewCodeBasis(String insertedCrewCode) {
            this.insertedCrewCode = insertedCrewCode;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = "";
            try
            {
                RequestCall requestCall = new RequestCall(mContext);
                response = requestCall.selectCrewOnCrewCodeBasis(mContext,insertedCrewCode);
                Log.d("Response -> ", response);
            }
            catch (Exception e)
            {
                Log.d("error",e.toString());

            }
            return response;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
        }
    }
}
