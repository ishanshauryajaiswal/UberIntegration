package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.AllTimes;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard3;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.example.ishanjaiswal.cmicresultactivity.R.id.btnSave;

/**
 * Created by ishan.jaiswal on 4/25/2018.
 */

public class FragmentThree extends Fragment {

    private static final String TAG = FragmentThree.class.getSimpleName();
    private RelativeLayout rlBack, rlMain;
    private RecyclerView rvStatic, rvDynamic;
    private int mTouchedRvTag;
    private RvDynamicAdapterDashboard3 rvDynamicAdapter;
    private RvStaticAdapterDashboard3 rvStaticAdapter;
    private TextView tvRegTotal, tvOtTotal,tvDotTotal;
    private TextView tvWeek;
    private String mCrewCode, endDate, startDate, firstDayOfWeek;
    private TextView headerViews[];
    private LinearLayout footerViews[];
    private FragmentClickListener mListener;
    private SharedPreferences sp; private SharedPreferences.Editor spEditor;
    private String mJobCode, mJobCompCode, mJobName, mEmpNumber,mEmpName, mEmpOraSeq;
    private List<Dashboard3> mList = new ArrayList<>();
    private boolean flagJobSelected;
    private ImageView ivSignature;
    private LinearLayout llSignatureMain, llSignatureEmployee, llSignatureForeman;
    private Button btnSaveEmployeeSignature, btnSaveForemanSignature, btnClearEmployeeSignature, btnClearForemanSignature;
    private ImageView ivEmployeeSignatureCheck, ivForemanSignatureCheck;
    private boolean signatureBoxVisibility;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getValuesFromSharedPreference();
        Bundle bundle = getArguments();
        endDate = bundle.getString(getString(R.string.cmic_fragment_extras_date_from_dashboard));
        mJobCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_code_from_dashboard));
        mJobCompCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_comp_code_from_dashboard));
        mEmpNumber = bundle.getString(getString(R.string.cmic_fragment_extras_employee_number_from_dashboard));
        mJobName = bundle.getString(getString(R.string.cmic_fragment_extras_job_name_from_dashboard),null);
        mEmpName = bundle.getString(getString(R.string.cmic_fragment_extras_employee_name_from_dashboard), null);
        flagJobSelected = bundle.getBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),true);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_three,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        mListener.retrieveDashboard3Data();
    }

    private void initView(View view){
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        rlMain = (RelativeLayout)view.findViewById(R.id.rlDasboard3);
        rlBack = (RelativeLayout)view.findViewById(R.id.rl_heading_dashboard2);
        TextView tvBack = (TextView)view.findViewById(R.id.tv_back_dashboard2);
        ivSignature = (ImageView)view.findViewById(R.id.iv_signature);
        llSignatureMain = (LinearLayout)view.findViewById(R.id.ll_signature_main);
        configVisibilityOfSignatureLayout();
        ivSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signatureBoxVisibility = !signatureBoxVisibility;
                configVisibilityOfSignatureLayout();
            }
        });
        llSignatureEmployee = (LinearLayout)view.findViewById(R.id.ll_employee_signature);
        llSignatureForeman = (LinearLayout)view.findViewById(R.id.ll_foreman_signature);
        tvBack.setTypeface(typeface);
        TextView tvJob = (TextView)view.findViewById(R.id.tv_job_details_dashboard2);
        if (flagJobSelected)
            tvJob.setText("Job: ".concat(mJobCode).concat("  ").concat(mJobName));
        else
            tvJob.setText("Person: ".concat(mEmpName));
        TextView tvEmployeeName = (TextView)view.findViewById(R.id.tv_crew_name_dashboard2);
        tvEmployeeName.setText("Employee: ".concat(mEmpName));
        tvWeek  = (TextView)view.findViewById(R.id.tv_week_dashboard2);
        rvStatic = (RecyclerView)view.findViewById(R.id.rv_static_dashboard2);rvStatic.setTag(0);
        rvDynamic = (RecyclerView)view.findViewById(R.id.rv_dynamic_dashboard2);rvDynamic.setTag(1);
        tvRegTotal = (TextView)view.findViewById(R.id.tv_footer_reg_dashboard3);
        tvOtTotal = (TextView)view.findViewById(R.id.tv_footer_ot_dashboard3);
        tvDotTotal = (TextView)view.findViewById(R.id.tv_footer_dot_dashboard3);
        TextView[] textViewsHeader = {(TextView) view.findViewById(R.id.tv_day1_dashboard2),(TextView)view.findViewById(R.id.tv_day2_dashboard2),(TextView)view.findViewById(R.id.tv_day3_dashboard2),(TextView)view.findViewById(R.id.tv_day4_dashboard2),(TextView)view.findViewById(R.id.tv_day5_dashboard2),(TextView)view.findViewById(R.id.tv_day6_dashboard2),(TextView)view.findViewById(R.id.tv_day7_dashboard2)};
        headerViews = textViewsHeader;
        LinearLayout[] linearLayoutsFooter = {(LinearLayout) view.findViewById(R.id.ll_footer_dashboard2_day1),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day2),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day3),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day4),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day5),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day6),(LinearLayout)view.findViewById(R.id.ll_footer_dashboard2_day7)};
        footerViews = linearLayoutsFooter;
        rlBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onBackPressed();
            }
        });
        btnSaveEmployeeSignature = (Button)view.findViewById(R.id.btn_save_signature_employee);
        btnSaveForemanSignature = (Button)view.findViewById(R.id.btn_save_signature_foreman);
        btnClearEmployeeSignature = (Button)view.findViewById(R.id.btn_clear_signature_employee);
        btnClearForemanSignature = (Button)view.findViewById(R.id.btn_clear_signature_foreman);
        ivEmployeeSignatureCheck = (ImageView)view.findViewById(R.id.iv_employee_sign_check);
        ivForemanSignatureCheck = (ImageView)view.findViewById(R.id.iv_foreman_sign_check);
        btnClearEmployeeSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initEmployeeSignatureBox();
            }
        });
        /*btnSaveEmployeeSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View mView = llSignatureEmployee;
                mView.setDrawingCacheEnabled(true);
                //v1.save(mView);
                Bitmap bmap = mView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] b = baos.toByteArray();
                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            }
        });*/
        btnClearForemanSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initForemanSignatureBox();
            }
        });
        /*btnSaveForemanSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View mView = llSignatureForeman;
                mView.setDrawingCacheEnabled(true);
                //v1.save(mView);
                Bitmap bmap = mView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] b = baos.toByteArray();
                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            }
        });*/
    }

    private void configVisibilityOfSignatureLayout(){
        spEditor.putBoolean(getString(R.string.cmic_shared_preference_signature_box_visibility),signatureBoxVisibility).commit();
        if (signatureBoxVisibility)
            llSignatureMain.setVisibility(View.VISIBLE);
        else
            llSignatureMain.setVisibility(View.GONE);
    }

    private void initSignatureBoxes() {
        final CanvasView v1, v2;
        v1 = new CanvasView(getContext());
        v2 = new CanvasView(getContext());
        llSignatureEmployee.removeAllViews();llSignatureForeman.removeAllViews();
        llSignatureEmployee.addView(v1, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        llSignatureForeman.addView(v2, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        Log.e("tatti",llSignatureEmployee.getWidth()+"  "+ llSignatureEmployee.getHeight());
        Log.e("tatti",llSignatureForeman.getWidth()+"  "+ llSignatureForeman.getHeight());
        btnClearEmployeeSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v1.clear();
            }
        });
        btnSaveEmployeeSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View mView = llSignatureEmployee;
                mView.setDrawingCacheEnabled(true);
                v1.save(mView);
                Bitmap bmap = mView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] b = baos.toByteArray();
                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            }
        });
        btnClearForemanSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v2.clear();
            }
        });
        btnSaveForemanSignature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View mView = llSignatureForeman;
                mView.setDrawingCacheEnabled(true);
                v1.save(mView);
                Bitmap bmap = mView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] b = baos.toByteArray();
                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            }
        });
    }

    private void initEmployeeSignatureBox() {
        final CanvasView v1;
        v1 = new CanvasView(getContext());
        llSignatureEmployee.removeAllViews();
        llSignatureEmployee.addView(v1, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        ivEmployeeSignatureCheck.setColorFilter(Color.GRAY);
    }

    private void initForemanSignatureBox() {
        final CanvasView v2;
        v2 = new CanvasView(getContext());
        llSignatureForeman.removeAllViews();
        llSignatureForeman.addView(v2, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        ivForemanSignatureCheck.setColorFilter(Color.GRAY);
    }


    public void loadDownloadedSignatures(Bitmap bitmapForeman, Bitmap bitmapEmployee){
        LinearLayout.LayoutParams params = new LinearLayout
                .LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        if (bitmapForeman!=null){
            BitmapDrawable bitmapDrawableForeman = new BitmapDrawable(getResources(), bitmapForeman);
            llSignatureForeman.removeAllViews();
            ImageView ivSignatureForeman = new ImageView(getContext());
            ivSignatureForeman.setLayoutParams(params);
            ivSignatureForeman.setScaleType(ImageView.ScaleType.FIT_XY);
            //ivSignatureForeman.setAdjustViewBounds(true);
            ivSignatureForeman.setBackground(bitmapDrawableForeman);
            llSignatureForeman.addView(ivSignatureForeman);
            ivForemanSignatureCheck.setColorFilter(Color.GREEN);
        }
        else
            initForemanSignatureBox();

        if (bitmapEmployee!=null){
            BitmapDrawable bitmapDrawableEmployee = new BitmapDrawable(getResources(), bitmapEmployee);
            llSignatureEmployee.removeAllViews();
            ImageView ivSignatureEmployee = new ImageView(getContext());
            ivSignatureEmployee.setLayoutParams(params);
            ivSignatureEmployee.setScaleType(ImageView.ScaleType.FIT_XY);
            //ivSignatureEmployee.setAdjustViewBounds(true);
            ivSignatureEmployee.setBackground(bitmapDrawableEmployee);
            llSignatureEmployee.addView(ivSignatureEmployee);
            ivEmployeeSignatureCheck.setColorFilter(Color.GREEN);
        }
        else
            initEmployeeSignatureBox();
    }

    public void  setUpDashboard(List<Dashboard3> mList){
        this.mList = mList;
        if (mList!=null && mList.size()>0) {
            setUpToolbar();
            setUpHeader();
            rvStatic.clearOnScrollListeners();rvDynamic.clearOnScrollListeners();
            rvStaticAdapter = new RvStaticAdapterDashboard3(mList,getContext());
            rvStatic.setAdapter(rvStaticAdapter);
            rvStatic.setLayoutManager(new LinearLayoutManager(getContext()));
            rvDynamicAdapter = new RvDynamicAdapterDashboard3(mList,getContext());
            rvDynamic.setAdapter(rvDynamicAdapter);
            rvDynamic.setLayoutManager(new LinearLayoutManager(getContext()));
            rvStatic.addOnScrollListener(custom_scroll_listner);rvDynamic.addOnScrollListener(custom_scroll_listner);
            rvStatic.addOnItemTouchListener(custom_item_touch_listner);rvDynamic.addOnItemTouchListener(custom_item_touch_listner);
            setUpFooter(mList);
            String empOraSeq="";
            try {
                empOraSeq = mList.get(0).getEmpOraSeq();
            }
            catch (Exception e){
                e.printStackTrace();
                Log.e(TAG, e.getMessage());
            }
            mListener.retrieveSignatures(empOraSeq, endDate, startDate);

        }
        else
            Toast.makeText(getContext(),"Error Occurred",Toast.LENGTH_SHORT).show();
    }
    private void setUpToolbar(){
        int year = Integer.parseInt(endDate.split("\\-")[0]);
        int month = Integer.parseInt(endDate.split("\\-")[1]);
        int day = Integer.parseInt(endDate.split("\\-")[2]);
        --month;
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day);
        cal.add(Calendar.DAY_OF_WEEK, -6);
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        startDate = sdfDate.format(cal.getTime());
        tvWeek.setText(endDate +" TO "+startDate);

    }
    private void setUpHeader(){
        List<String> week = CollectionUtils.getWeek(firstDayOfWeek);
        for (int i=0;i<headerViews.length;i++)
            headerViews[i].setText(week.get(i));
    }
    private void setUpFooter(List<Dashboard3> list){
        List<AllTimes> totalAllTimesList = new ArrayList<>();
        for (int i=0;i<7;i++)
            totalAllTimesList.add(new AllTimes());
        for (int j=0;j<list.size();j++){
            Dashboard3 dashboard3 = list.get(j);
            List<AllTimes> allTimesList = dashboard3.getTimesList();
            for (int i = 0; i < allTimesList.size(); i++){
                totalAllTimesList.get(i).setReg(totalAllTimesList.get(i).getReg()+allTimesList.get(i).getReg());
                totalAllTimesList.get(i).setOt(totalAllTimesList.get(i).getOt()+allTimesList.get(i).getOt());
                totalAllTimesList.get(i).setDot(totalAllTimesList.get(i).getDot()+allTimesList.get(i).getDot());
            }
        }
        for (int j=0;j<totalAllTimesList.size();j++) {
            TextView regTotal = (TextView)footerViews[j].getChildAt(0);
            TextView otTotal = (TextView)footerViews[j].getChildAt(1);
            TextView dotTotal = (TextView)footerViews[j].getChildAt(2);
            regTotal.setText(String .valueOf(totalAllTimesList.get(j).getReg()));
            otTotal.setText(String .valueOf(totalAllTimesList.get(j).getOt()));
            dotTotal.setText(String .valueOf(totalAllTimesList.get(j).getDot()));
        }
        AllTimes allTimesTotalStaticFooter = new AllTimes();
        for (int i=0;i<7;i++){
            allTimesTotalStaticFooter.setReg(allTimesTotalStaticFooter.getReg()+totalAllTimesList.get(i).getReg());
            allTimesTotalStaticFooter.setOt(allTimesTotalStaticFooter.getOt()+totalAllTimesList.get(i).getOt());
            allTimesTotalStaticFooter.setDot(allTimesTotalStaticFooter.getDot()+totalAllTimesList.get(i).getDot());
        }
        tvRegTotal.setText(String.valueOf(allTimesTotalStaticFooter.getReg()));
        tvOtTotal.setText(String.valueOf(allTimesTotalStaticFooter.getOt()));
        tvDotTotal.setText(String.valueOf(allTimesTotalStaticFooter.getDot()));
    }
    void getValuesFromSharedPreference(){
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        firstDayOfWeek = defaultSharedPreferences.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
        sp = getContext().getSharedPreferences(getString(R.string.cmic_shared_preference),Context.MODE_PRIVATE);
        spEditor = sp.edit();
        signatureBoxVisibility = sp.getBoolean(getString(R.string.cmic_shared_preference_signature_box_visibility),false);
    }

    public static FragmentThree getInstance(Bundle bundle){
        FragmentThree fragmentThree = new FragmentThree();
        fragmentThree.setArguments(bundle);
        return fragmentThree;
    }

    private RecyclerView.OnScrollListener custom_scroll_listner = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if ((int) recyclerView.getTag() == mTouchedRvTag) {
                for (int noOfRecyclerView = 0; noOfRecyclerView < 2; noOfRecyclerView++) {
                    if (noOfRecyclerView != (int) recyclerView.getTag()) {
                        RecyclerView tempRecyclerView = (RecyclerView) rlMain.findViewWithTag(noOfRecyclerView);
                        tempRecyclerView.scrollBy(dx, dy);
                    }
                }
            }
        }
    };

    private RecyclerView.OnItemTouchListener custom_item_touch_listner = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            mTouchedRvTag = (int) rv.getTag();
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    };
}
