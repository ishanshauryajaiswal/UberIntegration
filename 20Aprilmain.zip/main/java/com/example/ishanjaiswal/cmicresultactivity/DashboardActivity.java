package com.example.ishanjaiswal.cmicresultactivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.parsers.DashboardParser;

import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class DashboardActivity extends AppCompatActivity implements FragmentClickListener,DashboardTaskListener {

    FragmentManager fragmentManager;
    private HeadlessFragment1 headlessFragment1;
    private boolean isAnyTaskRunning = false;
    private ProgressDialog progressDialog;
    String jobCompCode = "10", jobCode = "0001D", date = "2018-04-19";
    String mjobCompCode = "10", mjobCode = "0001D", mdate = "2018-04-19", mTradeName, mTrade;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getValuesFromSharedPreference();
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer,FragmentOne.getInstance(),FragmentOne.class.getSimpleName())
                .commit();
    }

    void getValuesFromSharedPreference(){
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), MODE_PRIVATE);
        mjobCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_code),null);
        mjobCompCode = sharedPreferences.getString(getString(R.string.cmic_shared_preference_project_comp_code),null);
        mTradeName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_trade_name),null);
        mTradeName = sharedPreferences.getString(getString(R.string.cmic_shared_preference_hrt_name), null);
    }


    @Override
    public void retrieveDashboardData() {
        headlessFragment1 = (HeadlessFragment1) fragmentManager.findFragmentByTag(HeadlessFragment1.class.getSimpleName());
        if (headlessFragment1 == null) {
            headlessFragment1 = new HeadlessFragment1();
            fragmentManager.beginTransaction().add(headlessFragment1, HeadlessFragment1.class.getSimpleName()).commit();
        }
        if (!isAnyTaskRunning)
            headlessFragment1.startBackgroundTask(DashboardActivity.this,jobCompCode, jobCode, date,DashboardActivity.this);
    }

    @Override
    public void beforeTaskStarted(String displayMessage) {
        isAnyTaskRunning = true;
        progressDialog = ProgressDialog.show(DashboardActivity.this,displayMessage,displayMessage);
    }

    @Override
    public void onDashboardTaskComplete(String response) {
        progressDialog.dismiss();
        isAnyTaskRunning = false;
        DashboardParser dashboardParser = new DashboardParser();
        List<Dashboard> dashboardList = dashboardParser.parseDashboardData(response);
        FragmentOne fragmentOne = (FragmentOne)fragmentManager.findFragmentByTag(FragmentOne.class.getSimpleName());
        if (fragmentOne!=null)
            fragmentOne.setUpUI(dashboardList);
    }
}
