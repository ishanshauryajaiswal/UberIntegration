package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class FragmentOne extends Fragment {

    private TextView tvDesignation, tvSelectedName, tvArrow, tvDate, tvCalendar;
    private TextView tvWeek1Heading, tvWeek2Heading;
    private TextView tvRegTotal1, tvOtTotal1, tvDotTotal1;
    private TextView tvRegTotal2, tvOtTotal2, tvDotTotal2;
    private RecyclerView rvDashboard;
    private RvDashboardAdapter rvDashboardAdapter;
    private FragmentClickListener mListener;
    static FragmentOne fragmentOne;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_one,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        mListener.retrieveDashboardData();
    }

    private void initView(View view) {
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        tvDesignation = (TextView)view.findViewById(R.id.tv_designation_dashboard);
        tvSelectedName = (TextView)view.findViewById(R.id.tv_selected_name_dashboard);
        tvArrow = (TextView)view.findViewById(R.id.tv_arrow_dashboard);
        tvDate = (TextView)view.findViewById(R.id.tv_date_dashboard);
        tvCalendar = (TextView)view.findViewById(R.id.tv_calendar_dashboard);
        tvArrow.setTypeface(typeface);
        tvCalendar.setTypeface(typeface);
        tvWeek1Heading = (TextView)view.findViewById(R.id.tv_week1_dashboard);
        tvWeek2Heading = (TextView)view.findViewById(R.id.tv_week2_dashboard);
        tvRegTotal1 = (TextView)view.findViewById(R.id.tv_reg_total_1_dashboard);
        tvOtTotal1 = (TextView)view.findViewById(R.id.tv_ot_total_1_dashboard);
        tvDotTotal1 = (TextView)view.findViewById(R.id.tv_dot_total_1_dashboard);
        tvRegTotal2 = (TextView)view.findViewById(R.id.tv_reg_total_2_dashboard);
        tvOtTotal2 = (TextView)view.findViewById(R.id.tv_ot_total_2_dashboard);
        tvDotTotal2 = (TextView)view.findViewById(R.id.tv_dot_total_2_dashboard);
        rvDashboard = (RecyclerView)view.findViewById(R.id.rv_dashboard);
        rvDashboardAdapter = new RvDashboardAdapter(getContext(), new ArrayList());
        rvDashboard.setAdapter(rvDashboardAdapter);
        rvDashboard.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    public void setUpUI(List<Dashboard> dashboardList){
        rvDashboardAdapter.setmList(dashboardList);
        rvDashboardAdapter.notifyDataSetChanged();
    }

    public static FragmentOne getInstance(){
        if (fragmentOne==null)
            fragmentOne = new FragmentOne();
        return fragmentOne;
    }
}
