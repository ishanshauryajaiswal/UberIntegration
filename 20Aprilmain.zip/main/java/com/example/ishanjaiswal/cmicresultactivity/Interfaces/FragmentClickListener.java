package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface FragmentClickListener {
    public void retrieveDashboardData();
}
