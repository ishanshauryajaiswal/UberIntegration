package com.example.ishanjaiswal.cmicresultactivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.DashboardTask;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.DashboardTaskListener;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class HeadlessFragment1 extends Fragment {
    private DashboardTaskListener mListener;
    private DashboardTask mBackgroundTask;
    private boolean isTaskExecuting = false;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof  DashboardTaskListener)
            mListener = (DashboardTaskListener) getActivity();
        else
            throw new ClassCastException("Activity should implement DashboardTaskListener");
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void startBackgroundTask(Context context, String jobCompCode, String jobCode, String date, DashboardTaskListener mListener) {
        if (this.mListener == null)
            this.mListener = mListener;
        if (!isTaskExecuting) {
            mBackgroundTask = new DashboardTask(context, jobCompCode, jobCode, date, mListener);
            mBackgroundTask.execute();
            isTaskExecuting = true;
        }
    }

    public void cancelBackgroundTask() {
        if (isTaskExecuting) {
            mBackgroundTask.cancel(true);
            isTaskExecuting = false;
        }
    }

    public void updateExecutingStatus(boolean isExecuting) {
        this.isTaskExecuting = isExecuting;
    }
}
