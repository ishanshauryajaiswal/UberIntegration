package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by shaurya on 22/04/18.
 */

public interface JobDataListener {
    public void beforeJobDataTaskStarted(String displayMessage);
    public void onJobDataTaskComplete(String response);
}
