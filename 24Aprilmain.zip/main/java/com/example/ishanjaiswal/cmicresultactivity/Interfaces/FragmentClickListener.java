package com.example.ishanjaiswal.cmicresultactivity.Interfaces;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public interface FragmentClickListener {
    public void retrieveDashboardData(String empOraSeq, String date);
    public void retrieveDashboardData(String jobCompCode, String jobCode, String date);
    public void retrieveCrewMemberData();
    public void retrieveJobData();
    public void onCrewMemberSelected(String crewCode, String jobCode, String jobCompCode, String date, boolean isJobSelected);
    public void retrieveDashboard2Data(String crewCode, String jobCode, String jobCompCode, String date, boolean isJobSelected);
}
