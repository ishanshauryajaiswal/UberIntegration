package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by parneet.singh on 9/26/2016.
 */
public class TotalHours
{
    double standardTime,overTime,doubleOvertime;

    public TotalHours(double standardTime, double overTime, double doubleOvertime)
    {
        this.standardTime = standardTime;
        this.overTime = overTime;
        this.doubleOvertime = doubleOvertime;
    }

    public String getTotalHours()
    {
        String strTotalhours;
        strTotalhours =  standardTime+" ( "+overTime+" )[ "+doubleOvertime+" ] ";
        return strTotalhours;
    }

    public double getDoubleOverTime()
    {
        return doubleOvertime;
    }

    public double getStandardTime()
    {
        return standardTime;
    }

    public double getOverTime()
    {
        return overTime;
    }

    public void setStandardTime(double standardTime) {
        this.standardTime = standardTime;
    }

    public void setDoubleOverTime(double doubleOvertime) {
        this.doubleOvertime = doubleOvertime;
    }

    public void setOverTime(double overTime) {
        this.overTime = overTime;
    }
}
