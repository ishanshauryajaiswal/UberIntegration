package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 4/20/2018.
 */

public class Dashboard {
    String jobAcsCode;
    String jobCompCode;
    String jobCode;
    String pycrCode;
    String pycrName;
    double regHrs, otHrs, dotHrs;
    double prevRegHrs, prevOtHrs, prevDotHrs;

    public String getJobAcsCode() {
        return jobAcsCode;
    }

    public void setJobAcsCode(String jobAcsCode) {
        this.jobAcsCode = jobAcsCode;
    }

    public String getJobCompCode() {
        return jobCompCode;
    }

    public void setJobCompCode(String jobCompCode) {
        this.jobCompCode = jobCompCode;
    }

    public String getJobCode() {
        return jobCode;
    }

    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    public String getPycrCode() {
        return pycrCode;
    }

    public void setPycrCode(String pycrCode) {
        this.pycrCode = pycrCode;
    }

    public String getPycrName() {
        return pycrName;
    }

    public void setPycrName(String pycrName) {
        this.pycrName = pycrName;
    }

    public double getRegHrs() {
        return regHrs;
    }

    public void setRegHrs(double regHrs) {
        this.regHrs = regHrs;
    }

    public double getOtHrs() {
        return otHrs;
    }

    public void setOtHrs(double otHrs) {
        this.otHrs = otHrs;
    }

    public double getDotHrs() {
        return dotHrs;
    }

    public void setDotHrs(double dotHrs) {
        this.dotHrs = dotHrs;
    }

    public double getPrevRegHrs() {
        return prevRegHrs;
    }

    public void setPrevRegHrs(double prevRegHrs) {
        this.prevRegHrs = prevRegHrs;
    }

    public double getPrevOtHrs() {
        return prevOtHrs;
    }

    public void setPrevOtHrs(double prevOtHrs) {
        this.prevOtHrs = prevOtHrs;
    }

    public double getPrevDotHrs() {
        return prevDotHrs;
    }

    public void setPrevDotHrs(double prevDotHrs) {
        this.prevDotHrs = prevDotHrs;
    }
}
