package com.example.ishanjaiswal.cmicresultactivity.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ishan.jaiswal on 2/20/2018.
 */

public class CollectionUtils {
    private CollectionUtils(){
    }

    public static HashMap<String, Integer> dayConverter(){
        HashMap<String , Integer> hashMap = new HashMap<>();
        hashMap.put("Sunday",1);
        hashMap.put("Monday",2);
        hashMap.put("Tuesday",3);
        hashMap.put("Wednesday",4);
        hashMap.put("Thursday",5);
        hashMap.put("Friday",6);
        hashMap.put("Saturday",7);
        return hashMap;
    }

    public static ArrayList<String> getWeek(String day){
        ArrayList<String> list = new ArrayList<>();
        ArrayList<String> week = new ArrayList<>();
        week.add("NULL");
        week.add("Sunday");
        week.add("Monday");
        week.add("Tuesday");
        week.add("Wednesday");
        week.add("Thursday");
        week.add("Friday");
        week.add("Saturday");
        HashMap<String , Integer> hashMap = dayConverter();
        int dayNum = hashMap.get(day).intValue();
        for (int i = dayNum; i<=7; i++)
            list.add(week.get(i));
        for (int i = 1; i<=dayNum; i++)
            list.add(week.get(i));
        return list;
    }
}
