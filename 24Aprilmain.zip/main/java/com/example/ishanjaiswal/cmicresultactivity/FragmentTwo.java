package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard;
import com.example.ishanjaiswal.cmicresultactivity.Model.Dashboard2;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/19/2018.
 */

public class FragmentTwo extends Fragment {
    private RecyclerView rvStatic, rvDynamic;
    private TextView tvRegTotal, tvOtTotal,tvDotTotal;
    private RvDynamicAdapterDashboard2 rvDynamicAdapter;
    private RvStaticAdapterDashboard2 rvStaticAdapter;
    private String mCrewCode, mDate;
    boolean isJobSelected;

    private FragmentClickListener mListener;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException("Activity should implement FragmentClickListener");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_two,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        Bundle b = getArguments();
        mCrewCode = b.getString(getString(R.string.cmic_fragment_extras_crew_code_from_dashboard));
        mDate = b.getString(getString(R.string.cmic_fragment_extras_date_from_dashboard));
        isJobSelected = b.getBoolean(getString(R.string.cmic_fragment_extras_flag_from_dashboard),true);
        mListener.retrieveDashboard2Data(mCrewCode,b.getString("job_code_from_dashboard"),b.getString("job_comp_code_from_dashboard"),mDate,isJobSelected);
    }

    private void initView(View view) {
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(),"fonts/cmic_icons.ttf");
        rvStatic = (RecyclerView)view.findViewById(R.id.rv_static_dashboard2);
        rvDynamic = (RecyclerView)view.findViewById(R.id.rv_dynamic_dashboard2);
        tvRegTotal = (TextView)view.findViewById(R.id.tv_footer_reg_dashboard2);
        tvDotTotal = (TextView)view.findViewById(R.id.tv_footer_ot_dashboard2);
        tvDotTotal = (TextView)view.findViewById(R.id.tv_footer_dot_dashboard2);
        rvStaticAdapter = new RvStaticAdapterDashboard2(new ArrayList<Dashboard2>(),getContext());
        rvDynamicAdapter = new RvDynamicAdapterDashboard2(new ArrayList<Dashboard2>(),getContext());
        rvStatic.setAdapter(rvStaticAdapter);
        rvDynamic.setAdapter(rvDynamicAdapter);
        rvStatic.setLayoutManager(new LinearLayoutManager(getContext()));
        rvDynamic.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    public void setUpDashboard(List<Dashboard2> mList){
        if (mList!=null && mList.size()>0) {
            rvStaticAdapter.setmList(mList);
            rvDynamicAdapter.setmList(mList);
            rvDynamicAdapter.notifyDataSetChanged();
            rvStaticAdapter.notifyDataSetChanged();
        }
        else
            Toast.makeText(getContext(),"Error Occured",Toast.LENGTH_SHORT).show();
    }


    public static FragmentTwo getInstance(Bundle bundle){
        FragmentTwo fragmentTwo = new FragmentTwo();
        fragmentTwo.setArguments(bundle);
        return fragmentTwo;
    }
}
