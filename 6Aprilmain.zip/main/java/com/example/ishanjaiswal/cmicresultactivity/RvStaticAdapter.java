package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 1/30/2018.
 */

public class RvStaticAdapter extends RecyclerView.Adapter<RvStaticAdapter.ViewHolder> {

    private ArrayList<EmployeeDataForCrew> mList;
    private Context mContext;
    CustomClickListener customClickListener;
    private boolean timeInOutMode;


    public void setCustomClickListener(CustomClickListener customClickListener) {
        this.customClickListener = customClickListener;
    }

    public RvStaticAdapter(ArrayList<EmployeeDataForCrew> mList, Context mContext, boolean timeInOutMode) {
        this.mList = mList;
        this.mContext = mContext;
        this.timeInOutMode = timeInOutMode;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout ll = new LinearLayout(mContext);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(dpToPx(540),
                RecyclerView.LayoutParams.WRAP_CONTENT);
        ll.setLayoutParams(layoutParams);
        return new ViewHolder(ll, mContext);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        EmployeeDataForCrew employeeDataForCrew = mList.get(position);
        holder.crewMemberName.setText(employeeDataForCrew.getEmpName());
        holder.crewMemberCode.setText("("+employeeDataForCrew.getTradeCode()+")-"+employeeDataForCrew.getTradeName());
        holder.regValue.setText(employeeDataForCrew.getTotalRtHour() + "");
        holder.otValue.setText(employeeDataForCrew.getTotalOtHour() + "");
        holder.dotValue.setText(employeeDataForCrew.getTotalDotHour() + "");
        if (employeeDataForCrew.getTimeInOutModals() == null)
            holder.totalTime.setText("0.0");
        else
            holder.totalTime.setText(employeeDataForCrew.getTotalTimeInOut() + "");
        if (!timeInOutMode) {
            holder.totalTime.setVisibility(View.GONE);
        }

        holder.linearLayoutCrewMember.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                customClickListener.crewMemberLongClicked(v,position);
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setmList(ArrayList<EmployeeDataForCrew> mList) {
        this.mList = mList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView crewMemberName,crewMemberCode, dotImage, regValue, otValue, dotValue, totalTime;
        LinearLayout linearLayoutRow, linearLayoutCrewMember;
        Context mContext;
        MyListner myListner;
        Typeface tf;
        void setMyListner(MyListner myListner){
            this.myListner = myListner;
        }

        public ViewHolder(View itemView, Context mContext) {
            super(itemView);
            this.mContext = mContext;
            tf = Typeface.createFromAsset(mContext.getAssets(),"fonts/cmic_icons.ttf");
            //linearLayout: Main Linear Layout Containing 2 TextViews and 1 LinearLayout
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(540),
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))));
            LinearLayout linearLayout = (LinearLayout) itemView;
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setLayoutParams(params);
            linearLayout.removeAllViews();

            LinearLayout.LayoutParams tvParams = new TableRow.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))), 1f);
            LinearLayout.LayoutParams crewMemberTvParams = new TableRow.LayoutParams(dpToPx(180),0, 1f);
            LinearLayout.LayoutParams crewMemberParams = new LinearLayout.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))),1f);


            linearLayoutCrewMember = new LinearLayout(mContext);
            linearLayoutCrewMember.setOrientation(LinearLayout.VERTICAL);
            linearLayoutCrewMember.setLayoutParams(crewMemberParams);
            linearLayoutCrewMember.setGravity(Gravity.CENTER);
            linearLayoutCrewMember.setPadding(0, 5, 0, 0);
            linearLayoutCrewMember.removeAllViews();


            crewMemberName = new TextView(mContext);
            crewMemberName.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            crewMemberName.setTextSize(16);
            crewMemberName.setSingleLine(true);
            crewMemberName.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            crewMemberName.setGravity(Gravity.CENTER);
            crewMemberName.setTextColor(Color.BLACK);

            crewMemberCode = new TextView(mContext);
            crewMemberCode.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            crewMemberCode.setSingleLine(true);
            crewMemberCode.setEllipsize(TextUtils.TruncateAt.END);
            crewMemberCode.setGravity(Gravity.CENTER);
            crewMemberCode.setTextColor(Color.BLACK);
            crewMemberCode.setPadding(0, 5, 10, 0);
            crewMemberCode.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);

            dotImage = new TextView(mContext);
            dotImage.setPadding(0, 10, 10, 0);
            dotImage.setText("\uE612");
            dotImage.setTypeface(tf);
            dotImage.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));
            dotImage.setGravity(Gravity.RIGHT);
            dotImage.setGravity(Gravity.BOTTOM);
            dotImage.setTextColor(Color.rgb(23, 128, 251));
            dotImage.setTextSize(20);
            dotImage.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);


            linearLayoutCrewMember.addView(crewMemberName);
            linearLayoutCrewMember.addView(crewMemberCode);
            linearLayoutCrewMember.addView(dotImage);
            linearLayout.addView(linearLayoutCrewMember);

            //linearLayoutRow: Inner Linear Layout Containing 3 TextViews of the 3 Values
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(0,
                    dpToPx(Integer.parseInt(mContext.getResources().getString(R.string.row_cell_height))),1f);
            linearLayoutRow = new LinearLayout(mContext);
            linearLayoutRow.setOrientation(LinearLayout.HORIZONTAL);
            linearLayoutRow.setLayoutParams(rowParams);
            linearLayoutRow.removeAllViews();
            linearLayoutRow.setGravity(1);

            regValue = new TextView(mContext);
            regValue.setLayoutParams(tvParams);
            regValue.setGravity(Gravity.CENTER);
            regValue.setTextColor(Color.BLACK);
            regValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            regValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            otValue = new TextView(mContext);
            otValue.setLayoutParams(tvParams);
            otValue.setGravity(Gravity.CENTER);
            otValue.setTextColor(Color.BLACK);
            otValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            otValue.setBackgroundColor(mContext.getResources().getColor(R.color.colorWhite));

            dotValue = new TextView(mContext);
            dotValue.setLayoutParams(tvParams);
            dotValue.setGravity(Gravity.CENTER);
            dotValue.setTextColor(Color.BLACK);
            dotValue.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            dotValue.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview));

            linearLayoutRow.addView(regValue); linearLayoutRow.addView(otValue); linearLayoutRow.addView(dotValue);
            linearLayout.addView(linearLayoutRow);

            totalTime = new TextView(mContext);
            totalTime.setLayoutParams(tvParams);
            totalTime.setGravity(Gravity.CENTER);
            totalTime.setTextColor(Color.BLACK);
            totalTime.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            totalTime.setBackground(mContext.getResources().getDrawable(R.drawable.style_textview_last));
            linearLayout.addView(totalTime);

        }

        public int dpToPx(int dp) {
            DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
            return Math.round(dp * displayMetrics.density+0.5f);
        }
    }

    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density+0.5f);
    }
}