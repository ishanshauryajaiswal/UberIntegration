package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.TimeSheetDetails;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 3/23/2018.
 */


public class IshanDBHelper extends SQLiteOpenHelper {
    private static IshanDBHelper mInstance;
    private static final String DBName="DATABASE";
    private static final int DBVersion = 1;
    private static IshanDBConstants D = new IshanDBConstants();
    private static final String TAG = IshanDBHelper.class.getSimpleName();

    private static final String CREATE_TABLE_EMPLOYEE_DATA = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_EMPLOYEE_DATA_FOR_CREW + "(" +
            D.EmployeeOraseq_EmployeeDataForCrew + " INTEGER PRIMARY KEY,"+
            D.DeleteFlag_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeNumber_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeName_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeCode_EmployeeDataForCrew + " TEXT,"+
            D.EmployeeTradeName_EmployeeDataForCrew + " TEXT,"+
            D.RowNumber_EmployeeDataForCrew+ " TEXT,"+
            D.PeriodFlag_EmployeeDataForCrew+ " TEXT)";

    private static final String CREATE_TABLE_ACTIVITY_TIME_FOR_CREW = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_ACTIVITY_TIME_FOR_CREW + "(" +
            D.EmployeeOraseq_EmployeeDataForCrew+ " INTEGER,"+
            D.ColoumnNumber_ActivityForTimeSheet+ " INTEGER,"+
            D.rtSeqNumber+ " TEXT,"+
            D.rtHours+ " TEXT,"+
            D.otseqNumber+ " TEXT,"+
            D.otHour+ " TEXT,"+
            D.dotSeqNumber+ " TEXT,"+
            D.dothour+ " TEXT," +
            "PRIMARY KEY("+D.EmployeeOraseq_EmployeeDataForCrew+","+D.ColoumnNumber_ActivityForTimeSheet+ "))";

    private static final String CREATE_TABLE_ACTIVITY_FOR_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_ACTIVITY_FOR_TIMESHEET+"("+
            D.DeleteFlag_ActivityForTimeSheet+ " TEXT,"+
            D.ActivityName_ActivityForTimeSheet+ " TEXT,"+
            D.CategoryCode_ActivityForTimeSheet+ " TEXT,"+
            D.ColoumnNumber_ActivityForTimeSheet+ " INTEGER PRIMARY KEY,"+
            D.JobCode_ActivityForTimeSheet+ " TEXT,"+
            D.PciLineOraseq_ActivityForTimeSheet+ " TEXT,"+
            D.PhaseCode_ActivityForTimeSheet+ " TEXT,"+
            D.SeqNumber_ActivityForTimeSheet+ " TEXT,"+
            D.WbsCode_ActivityForTimeSheet+ " TEXT)";

    private static final String CREATE_TABLE_TIMESHEET = "CREATE TABLE IF NOT EXISTS "+
            D.TABLE_TIMESHEET+"("+
            D.Timesheet_CrewCode+ " TEXT, "+
            D.Timesheet_JobCode+ " TEXT, "+
            D.Timesheet_JobCompCode+ " TEXT, "+
            D.Timesheet_SeqNumber+ " TEXT, "+
            D.Timesheet_WorkDate+ " TEXT PRIMARY KEY, "+
            D.Timesheet_SubmitStatus+ " TEXT, "+
            D.TimesheetState+ " INTEGER)";

    private static final String CREATE_TABLE_CREW_LIST = "CREATE TABLE IF NOT EXISTS  " + D.TABLE_CREW_LIST + "(" + D.CrewList_PycrCode + " TEXT PRIMARY KEY, " + D.CrewList_PycrName + " TEXT, " + D.CrewList_PycrOraseq + " TEXT )";

    private static final String CREATE_TABLE_PROJECT_LIST = "CREATE TABLE IF NOT EXISTS  " + D.TABLE_PROJECT_LIST + "(" + D.ProjectList_Jobcode + " TEXT PRIMARY KEY , " + D.ProjectList_Jobcompcode + " TEXT, " + D.ProjectList_Jobname + " TEXT )";

    private static final String CREATE_TABLE_SELECTED_EMPLOYEES = "CREATE TABLE IF NOT EXISTS " +
            D.TABLE_SELECTED_EMPLOYEES + "(" +
            D.Selected_EmpNumber + " TEXT, " +
            D.Selected_EmpOraseq + " TEXT PRIMARY KEY, " +
            D.Selected_EmpName + " TEXT, " +
            D.Selected_AccessCode + " TEXT, " +
            D.Selected_CompName + " TEXT, " +
            D.Selected_PrnCode + " TEXT, " +
            D.Selected_PrnName + " TEXT, " +
            D.Selected_CompCode +" TEXT, " +
            D.Selected_TrdCode + " TEXT, " +
            D.Selected_TrdName + " TEXT, " +
            D.Selected_UniCode + " TEXT, " +
            D.Selected_UniName + " TEXT)";

    private static final String CREATE_TABLE_ALL_EMPLOYEES = "CREATE TABLE IF NOT EXISTS " +
            D.TABLE_ALL_EMPLOYEES + "(" +
            D.All_EmpNumber + " TEXT, " +
            D.All_EmpOraseq + " TEXT , " +
            D.All_EmpName + " TEXT, " +
            D.All_EmpCrewCode + " TEXT, " +
            D.All_EmpCrewOraseq + " TEXT, " +
            D.All_EmpCrewName +" TEXT, " +
            D.All_TrdCode + " TEXT, " +
            D.All_TrdName + " TEXT, " +
            D.All_PyceOraseq + " TEXT PRIMARY KEY)";


    private IshanDBHelper(Context context) {
        super(context, DBName, null, DBVersion);
    }

    public static synchronized IshanDBHelper getInstance(Context context){
        if (mInstance == null)
            mInstance = new IshanDBHelper(context);
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
            db.execSQL(CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
            db.execSQL(CREATE_TABLE_EMPLOYEE_DATA);
            db.execSQL(CREATE_TABLE_TIMESHEET);
            db.execSQL(CREATE_TABLE_CREW_LIST);
            db.execSQL(CREATE_TABLE_PROJECT_LIST);
            db.execSQL(CREATE_TABLE_SELECTED_EMPLOYEES);
            db.execSQL(CREATE_TABLE_ALL_EMPLOYEES);
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ACTIVITY_FOR_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ACTIVITY_TIME_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_EMPLOYEE_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_CREW_LIST);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_PROJECT_LIST);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_SELECTED_EMPLOYEES);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ALL_EMPLOYEES);
        onCreate(db);
    }

    public void insertEmployeeInDatabase(EmployeeDataForCrew employee){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.EmployeeOraseq_EmployeeDataForCrew, Integer.parseInt(employee.getEmployeeOraseq()));
            values.put(D.DeleteFlag_EmployeeDataForCrew, employee.getDeleteFlag());
            values.put(D.EmployeeName_EmployeeDataForCrew, employee.getEmpName());
            values.put(D.EmployeeNumber_EmployeeDataForCrew, employee.getEmpNo());
            values.put(D.EmployeeTradeCode_EmployeeDataForCrew, employee.getTradeCode());
            values.put(D.EmployeeTradeName_EmployeeDataForCrew, employee.getTradeName());
            values.put(D.PeriodFlag_EmployeeDataForCrew, employee.getPeriodFlag());
            values.put(D.RowNumber_EmployeeDataForCrew, employee.getRowNo());
            int id = (int) db.insertWithOnConflict(D.TABLE_EMPLOYEE_DATA_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_EMPLOYEE_DATA_FOR_CREW,values, D.EmployeeNumber_EmployeeDataForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeNumber_EmployeeDataForCrew)+""});
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public void insertAllEmployeeInDatabase(ArrayList<EmployeeDataForCrew> employeeList){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            for (EmployeeDataForCrew employee : employeeList) {
                ContentValues values = new ContentValues();
                values.put(D.EmployeeOraseq_EmployeeDataForCrew, Integer.parseInt(employee.getEmployeeOraseq()));
                values.put(D.DeleteFlag_EmployeeDataForCrew, employee.getDeleteFlag());
                values.put(D.EmployeeName_EmployeeDataForCrew, employee.getEmpName());
                values.put(D.EmployeeNumber_EmployeeDataForCrew, employee.getEmpNo());
                values.put(D.EmployeeTradeCode_EmployeeDataForCrew, employee.getTradeCode());
                values.put(D.EmployeeTradeName_EmployeeDataForCrew, employee.getTradeName());
                values.put(D.PeriodFlag_EmployeeDataForCrew, employee.getPeriodFlag());
                values.put(D.RowNumber_EmployeeDataForCrew, employee.getRowNo());
                int id = (int) db.insertWithOnConflict(D.TABLE_EMPLOYEE_DATA_FOR_CREW, null, values, SQLiteDatabase.CONFLICT_IGNORE);
                if (id == -1) {
                    db.update(D.TABLE_EMPLOYEE_DATA_FOR_CREW, values, D.EmployeeNumber_EmployeeDataForCrew + "=?", new String[]{values.getAsInteger(D.EmployeeNumber_EmployeeDataForCrew) + ""});
                }
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public void insertActivityTimeForEmployee(int empOraSeq, int columnNo, ActivityTimeForCrew activityTimeForCrew){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.ColoumnNumber_ActivityForTimeSheet,columnNo);
            values.put(D.EmployeeOraSeq_ActivityTimeForCrew, empOraSeq);
            values.put(D.rtSeqNumber, activityTimeForCrew.getStandardTimeSeqNumber());
            values.put(D.rtHours, activityTimeForCrew.getStandardTime());
            values.put(D.otseqNumber, activityTimeForCrew.getOverTimeSeqNumber());
            values.put(D.otHour, activityTimeForCrew.getOverTime());
            values.put(D.dotSeqNumber, activityTimeForCrew.getDoubleOverTimeSeqNumber());
            values.put(D.dothour, activityTimeForCrew.getDoubleOverTime());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_TIME_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_TIME_FOR_CREW,values, D.EmployeeOraSeq_ActivityTimeForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeOraSeq_ActivityTimeForCrew)+""});
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public void insertActivityTimeForAllEmployee(ArrayList<EmployeeDataForCrew> employeeList, ArrayList<SubmittedActivityFromCrewModal> activityFromCrewModals){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            for (EmployeeDataForCrew e : employeeList){
                for (int i=0; i<activityFromCrewModals.size();i++) {
                    ActivityTimeForCrew activityTimeForCrew = e.getTimeSheet().get(i);
                    int colNo = Integer.parseInt(activityFromCrewModals.get(i).getColoumnNo());
                    ContentValues values = new ContentValues();
                    values.put(D.ColoumnNumber_ActivityForTimeSheet,colNo);
                    values.put(D.EmployeeOraSeq_ActivityTimeForCrew, e.getEmployeeOraseq());
                    values.put(D.rtSeqNumber, activityTimeForCrew.getStandardTimeSeqNumber());
                    values.put(D.rtHours, activityTimeForCrew.getStandardTime());
                    values.put(D.otseqNumber, activityTimeForCrew.getOverTimeSeqNumber());
                    values.put(D.otHour, activityTimeForCrew.getOverTime());
                    values.put(D.dotSeqNumber, activityTimeForCrew.getDoubleOverTimeSeqNumber());
                    values.put(D.dothour, activityTimeForCrew.getDoubleOverTime());
                    int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_TIME_FOR_CREW, null, values,SQLiteDatabase.CONFLICT_IGNORE);
                    if (id == -1){
                        db.update(D.TABLE_ACTIVITY_TIME_FOR_CREW,values, D.EmployeeOraSeq_ActivityTimeForCrew+"=?",new String [] {values.getAsInteger(D.EmployeeOraSeq_ActivityTimeForCrew)+""});
                    }
                }
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }


    public void insertActivityForTimesheet(SubmittedActivityFromCrewModal activity) {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.ActivityName_ActivityForTimeSheet, activity.getActivityName());
            values.put(D.CategoryCode_ActivityForTimeSheet, activity.getCatCode());
            values.put(D.ColoumnNumber_ActivityForTimeSheet, Integer.parseInt(activity.getColoumnNo()));
            values.put(D.DeleteFlag_ActivityForTimeSheet, activity.getDeleteFlag());
            values.put(D.JobCode_ActivityForTimeSheet, activity.getjobCode());
            values.put(D.PciLineOraseq_ActivityForTimeSheet, activity.getPciLineOraseq());
            values.put(D.PhaseCode_ActivityForTimeSheet, activity.getPhaseCode());
            values.put(D.SeqNumber_ActivityForTimeSheet, activity.getSeqNo());
            values.put(D.WbsCode_ActivityForTimeSheet, activity.getWbsCode());
            int id = (int) db.insertWithOnConflict(D.TABLE_ACTIVITY_FOR_TIMESHEET, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_ACTIVITY_FOR_TIMESHEET,values, D.ColoumnNumber_ActivityForTimeSheet+"=?",new String [] {values.getAsInteger(D.ColoumnNumber_ActivityForTimeSheet)+""});
            }
        } catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public void insertTimesheetDetailsInDatabase(String crewCode,String jobCode,String jobCompCode,String seqNo,String workDate,String submitStatus,boolean state){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(D.Timesheet_CrewCode, crewCode);
            values.put(D.Timesheet_JobCode, jobCode);
            values.put(D.Timesheet_JobCompCode, jobCompCode);
            values.put(D.Timesheet_SeqNumber, seqNo);
            values.put(D.Timesheet_WorkDate, workDate);
            values.put(D.Timesheet_SubmitStatus, submitStatus);
            if (state)
                values.put(D.TimesheetState, 1);
            else
                values.put(D.TimesheetState, 0);
            int id = (int) db.insertWithOnConflict(D.TABLE_TIMESHEET, null, values,SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1){
                db.update(D.TABLE_TIMESHEET,values, D.Timesheet_WorkDate+"=?",new String [] {values.getAsString(D.Timesheet_WorkDate)});
            }
        }
        catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public ArrayList<EmployeeDataForCrew> getEmployeeDataForCrewFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ArrayList<EmployeeDataForCrew> employeeDataForCrews = new ArrayList<>();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_EMPLOYEE_DATA_FOR_CREW, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    EmployeeDataForCrew e = new EmployeeDataForCrew();
                    e.setEmployeeOraseq(cursor.getString(0));
                    e.setDeleteFlag(cursor.getString(1)+"");
                    e.setEmpNo(cursor.getString(2));
                    e.setEmpName(cursor.getString(3));
                    e.setTradeCode(cursor.getString(4));
                    e.setTradeName(cursor.getString(5));
                    e.setRowNo(cursor.getString(6));
                    e.setPeriodFlag(cursor.getString(7));
                    employeeDataForCrews.add(e);
                    cursor.moveToNext();
                }
            }
            return employeeDataForCrews;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
        return null;
    }

    public ActivityTimeForCrew getActivityTimeForCrewFromDatabase(int empOraSeq, int columnNo){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ActivityTimeForCrew a = new ActivityTimeForCrew();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_TIME_FOR_CREW +
                    " WHERE "+ D.EmployeeOraSeq_ActivityTimeForCrew + " = " + empOraSeq + " AND "
                             + D.ColoumnNumber_ActivityForTimeSheet + " = " + columnNo, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    a.setStandardTimeSeqNumber(cursor.getString(2));
                    a.setStandardTime(Double.parseDouble(cursor.getString(3)));
                    a.setOverTimeSeqNumber(cursor.getString(4));
                    a.setOverTime(Double.parseDouble(cursor.getString(5)));
                    a.setDoubleOverTimeSeqNumber(cursor.getString(6));
                    a.setDoubleOverTime(Double.parseDouble(cursor.getString(7)));
                    cursor.moveToNext();
                }
            }
            return a;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
        return null;
    }

    public ArrayList<SubmittedActivityFromCrewModal> getActivityForTimesheet(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ArrayList<SubmittedActivityFromCrewModal> submittedActivityFromCrewModals = new ArrayList<>();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_ACTIVITY_FOR_TIMESHEET, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    SubmittedActivityFromCrewModal s = new SubmittedActivityFromCrewModal();
                    s.setDeleteFlag(cursor.getString(0));
                    s.setActivityName(cursor.getString(1));
                    s.setCatCode(cursor.getString(2));
                    s.setColoumnNo(cursor.getString(3));
                    s.setjobCode(cursor.getString(4));
                    s.setPciLineOraseq(cursor.getString(5));
                    s.setPhaseCode(cursor.getString(6));
                    s.setSeqNo(cursor.getString(7));
                    s.setWbsCode(cursor.getString(8));
                    submittedActivityFromCrewModals.add(s);
                    cursor.moveToNext();
                }
            }
            return submittedActivityFromCrewModals;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
        return null;
    }

    public TimeSheetDetails getTimesheetDetailsFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            TimeSheetDetails timeSheetDetails = new TimeSheetDetails();
            Cursor cursor = mInstance.getReadableDatabase().rawQuery("SELECT * FROM "+ D.TABLE_TIMESHEET, null);
            if(cursor.moveToFirst()){
                while (!cursor.isAfterLast()){
                    timeSheetDetails.setCrewCode(cursor.getString(0));
                    timeSheetDetails.setJoCode(cursor.getString(1));
                    timeSheetDetails.setJobCompCode(cursor.getString(2));
                    timeSheetDetails.setSeqNo(cursor.getString(3));
                    timeSheetDetails.setWorkDate(cursor.getString(4));
                    timeSheetDetails.setSubmitStatus(cursor.getString(5));
                    if (cursor.getInt(cursor.getColumnIndex(D.TimesheetState)) == 1)
                        timeSheetDetails.setState(true);
                    else
                        timeSheetDetails.setState(false);
                    cursor.moveToNext();
                }
            }
            return timeSheetDetails;
        }
        catch (SQLException e){
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
        return null;
    }

    public void insertTimeSheetInDatabase(CrewTimeSheet crewTimeSheet){
        deleteTimeSheetFromDatabase();
        ArrayList<SubmittedActivityFromCrewModal> activityFromCrewModals = crewTimeSheet.getCrewActivity();
        for (SubmittedActivityFromCrewModal s : activityFromCrewModals)
            this.insertActivityForTimesheet(s);
        ArrayList<EmployeeDataForCrew> employeeDataForCrews = crewTimeSheet.getEmpTimeSheet();
        this.insertAllEmployeeInDatabase(employeeDataForCrews);
        this.insertActivityTimeForAllEmployee(employeeDataForCrews,activityFromCrewModals);
        /*
        for (EmployeeDataForCrew e : employeeDataForCrews){
            for (int i=0; i<activityFromCrewModals.size();i++) {
                int colNo = Integer.parseInt(activityFromCrewModals.get(i).getColoumnNo());
                this.insertActivityTimeForEmployee(Integer.parseInt(e.getEmployeeOraseq()), colNo,e.getTimeSheet().get(i));
            }
        }
        */
        this.insertTimesheetDetailsInDatabase(crewTimeSheet.getCrewCode(), crewTimeSheet.getJobCode(), crewTimeSheet.getJobCompCode(), crewTimeSheet.getSeqNo(), crewTimeSheet.getWorkDate(),"", crewTimeSheet.isEdited());
    }

    public CrewTimeSheet getTimeSheetFromDatabase(){
        CrewTimeSheet crewTimeSheet = new CrewTimeSheet();
        crewTimeSheet.setCrewActivity(this.getActivityForTimesheet());
        ArrayList<EmployeeDataForCrew> employeeDataForCrews;
        employeeDataForCrews = this.getEmployeeDataForCrewFromDatabase();
        crewTimeSheet.setEmpTimeSheet(employeeDataForCrews);
        for (EmployeeDataForCrew e : employeeDataForCrews){
            ArrayList<SubmittedActivityFromCrewModal> activities;
            activities = crewTimeSheet.getCrewActivity();
            ArrayList<ActivityTimeForCrew> activityTimeForCrew = new ArrayList<>();
            for (int i = 0; i < activities.size(); i++){
                ActivityTimeForCrew a = this.getActivityTimeForCrewFromDatabase(Integer.parseInt(e.getEmployeeOraseq()),
                        Integer.parseInt(activities.get(i).getColoumnNo()));
                activityTimeForCrew.add(a);
            }
            e.setTimeSheet(activityTimeForCrew);
        }
        TimeSheetDetails t = this.getTimesheetDetailsFromDatabase();
        crewTimeSheet.setCrewCode(t.getCrewCode());
        crewTimeSheet.setJobCode(t.getJoCode());
        crewTimeSheet.setJobCompCode(t.getJobCompCode());
        crewTimeSheet.setSeqNo(t.getSeqNo());
        crewTimeSheet.setWorkDate(t.getWorkDate());
        crewTimeSheet.setEdited(t.getState());
        if (t.getCrewCode()==null ||t.getCrewCode().equalsIgnoreCase("")|| t.getCrewCode().equalsIgnoreCase("null") ||  t.getCrewCode().isEmpty())
            return null;
        return crewTimeSheet;
    }

    public void deleteTimeSheetFromDatabase(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        db.execSQL("DELETE FROM "+ D.TABLE_TIMESHEET);
        db.execSQL("DELETE FROM "+ D.TABLE_EMPLOYEE_DATA_FOR_CREW);
        db.execSQL("DELETE FROM "+ D.TABLE_ACTIVITY_TIME_FOR_CREW);
        db.execSQL("DELETE FROM "+ D.TABLE_ACTIVITY_FOR_TIMESHEET);
        db.close();
    }

    public boolean isTimeSheetPresent(){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        boolean empty = true;
        Cursor cur = db.rawQuery("SELECT COUNT(*) FROM "+D.TABLE_TIMESHEET, null);
        if (cur != null && cur.moveToFirst()) {
            empty = (cur.getInt (0) == 0);
        }
        cur.close();
        return !empty;
    }

    public void setTimeSheetStateInDatabase(boolean isEdited, String workDate){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            if (isEdited)
                values.put(D.TimesheetState,1);
            else
                values.put(D.TimesheetState,0);
            db.update(D.TABLE_TIMESHEET, values, D.Timesheet_WorkDate+"=?",new String[]{workDate});
        }
        catch (SQLException  e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage());
        }
        finally {
            db.close();
        }
    }
}
