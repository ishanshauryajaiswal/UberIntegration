package com.example.ishanjaiswal.cmicresultactivity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.GetPhaseTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.PciTask;
import com.example.ishanjaiswal.cmicresultactivity.AsyncTask.RetrievingTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Database.DBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanAllEmployeeDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Model.ActivityTimeForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CategoryDetails;
import com.example.ishanjaiswal.cmicresultactivity.Model.CrewTimeSheet;
import com.example.ishanjaiswal.cmicresultactivity.Model.EmployeeDataForCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.JobData;
import com.example.ishanjaiswal.cmicresultactivity.Model.LinkingCrewEmployeeWithCrew;
import com.example.ishanjaiswal.cmicresultactivity.Model.PciModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseWithChild;
import com.example.ishanjaiswal.cmicresultactivity.Model.SubmittedActivityFromCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();
    RecyclerView recyclerViewStatic, recyclerViewDynamic;
    RelativeLayout rv;
    LinearLayout linearLayoutDynamicHeader, linearLayoutDynamicFooter;
    int mTouchedRvTag;
    String selectedCrewCode, selectedProjectCode, selectedProjectName, selectedResponsiblePerson, selectedTradeName, selectedHrtTradeName;
    String workDate, workDay, firstDayOfWeek;
    String selectedOraSew, selectedProjectCompCode;
    ProgressDialog progressDialog;
    CrewTimeSheet mCrewTimeSheet;
    RvStaticAdapter rvStaticAdapter;
    RvDynamicAdapter rvDynamicAdapter;
    Typeface typeface;
    TextView tvBack, tvSheetTitle, tvMode, tvMenu, tvDay, tvDate, tvCalendar, tvCrewname
            , tvResponsiblePerson, tvHrtTradeName, tvTradeName, tvTimeinOut;
    TextView tvFooterReg, tvFooterOt, tvFooterDot, tvFooterInOut;
    private ImageButton btnSubmitTimesheet;
    Button btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven;
    ArrayList<Button> listWeek;
    private  Button btnSelectedJob;
    Calendar cal;
    DatePickerDialog fromDatePickerDialog;
    HashMap<String, String > hashmapDateToButton;
    private boolean isRegularModeSelected, isInOutModeSelected;
    SharedPreferences ishanSharedPreference, defaultSharedPreference;
    SharedPreferences.Editor ishanPreferenceEditor, defaultPreferenceEditor;
    private static final int REQUEST_CODE_PROJECT = 0;
    private static final int REQUEST_CODE_CREW_DETAILS = 1;
    private static final int REQUEST_CODE_CREW_LIST = 2;
    private static final int REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON = 3;
    private int normalTimeFromSettings, overTimeFromSettings;
    private IshanDBHelper mDbInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDbInstance = IshanDBHelper.getInstance(MainActivity.this);
        initViews();
    }

    @Override
    protected void onPostResume(){
        super.onPostResume();
        getValuesFromSharedPreference();
        mCrewTimeSheet = mDbInstance.getTimeSheetFromDatabase();
        if (mDbInstance.isTimeSheetPresent() && mCrewTimeSheet!=null) {
            workDate = mCrewTimeSheet.getWorkDate();
            setUpUIElements(mCrewTimeSheet);
        }
        else {
            setWorkdateToTodaysDate();
            retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
        }
        getValuesFromSharedPreference();
    }

    private void setUpUIElements(CrewTimeSheet crewTimeSheet){
        recyclerViewStatic.clearOnScrollListeners();
        recyclerViewDynamic.clearOnScrollListeners();
        isInoutModeEnabled();
        if (isRegularModeSelected)
            tvMode.setText("A");
        else
            tvMode.setText("R");
        tvMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchRegularAndAdvancedMode();
            }
        });
        mCrewTimeSheet = crewTimeSheet;
        calculateTotalHours(mCrewTimeSheet);
        calculateFooterHours(mCrewTimeSheet);
        rvStaticAdapter = new RvStaticAdapter(mCrewTimeSheet.getEmpTimeSheet(), this, isInOutModeSelected);
        rvStaticAdapter.setCustomClickListener(customClickListener);
        recyclerViewStatic.setAdapter(rvStaticAdapter);
        recyclerViewStatic.setLayoutManager(new LinearLayoutManager(this));
        rvDynamicAdapter = new RvDynamicAdapter(mCrewTimeSheet.getEmpTimeSheet(), this);
        rvDynamicAdapter.setCustomClickListener(customClickListener);
        recyclerViewDynamic.setAdapter(rvDynamicAdapter);
        recyclerViewDynamic.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewStatic.addOnScrollListener(custom_scroll_listner);
        recyclerViewDynamic.addOnScrollListener(custom_scroll_listner);
        recyclerViewStatic.addOnItemTouchListener(custom_item_touch_listner);
        recyclerViewDynamic.addOnItemTouchListener(custom_item_touch_listner);
        setUpDynamicHeaderAndFooter();
        btnSelectedJob.setText(selectedProjectName);
        tvCrewname.setText(mCrewTimeSheet.getCrewCode());
        tvResponsiblePerson.setText(selectedResponsiblePerson);
        tvHrtTradeName.setText(selectedHrtTradeName);
        tvTradeName.setText(selectedTradeName);
        setUpWeekdaysButtons(firstDayOfWeek);
        linkButtonsToDate();
        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenuDialog();
            }
        });
        tvResponsiblePerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                responsiblePersonClicked();
            }
        });
    }

    private void isInoutModeEnabled() {
        if (isInOutModeSelected){
            TextView t = (TextView)findViewById(R.id.headerTime);
            t.setVisibility(View.VISIBLE);
            t = (TextView)findViewById(R.id.tvFooterInOutTotal);
            t.setVisibility(View.VISIBLE);
        }
        else {
            TextView t = (TextView)findViewById(R.id.headerTime);
            t.setVisibility(View.GONE);
            t = (TextView)findViewById(R.id.tvFooterInOutTotal);
            t.setVisibility(View.GONE);
        }
    }


    private void setUpDynamicHeaderAndFooter() {
        linearLayoutDynamicHeader.removeAllViews();
        linearLayoutDynamicFooter.removeAllViews();
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(dpToPx(180),
                dpToPx(Integer.parseInt(getResources().getString(R.string.header_cell_height))));
        LinearLayout.LayoutParams subRowParams = new LinearLayout.LayoutParams(dpToPx(180), 0, 1f);
        LinearLayout.LayoutParams viewDividerParams = new LinearLayout.LayoutParams(dpToPx(180), dpToPx(2));
        LinearLayout.LayoutParams activityNameTvParams = new TableRow.LayoutParams(dpToPx(180), 0, 1f);
        LinearLayout.LayoutParams tvParams = new TableRow.LayoutParams(0, dpToPx(35), 1f);
        int whiteColor = ContextCompat.getColor(MainActivity.this,R.color.colorWhite);
        ArrayList<SubmittedActivityFromCrewModal> activities = mCrewTimeSheet.getCrewActivity();
        ArrayList<Double> footerTotalValues = new ArrayList<>();
        //Setting up Header and Footers for Activities
        for (int i = 0; i < activities.size(); i++) {
            LinearLayout viewDivider = new LinearLayout(this);
            viewDivider.removeAllViews();
            viewDivider.setLayoutParams(viewDividerParams);
            viewDivider.setBackgroundColor(whiteColor);
            LinearLayout dynamicHeader = new LinearLayout(this);
            dynamicHeader.removeAllViews();
            dynamicHeader.setLayoutParams(rowParams);
            dynamicHeader.setOrientation(LinearLayout.VERTICAL);

            TextView activityNameHeading = new TextView(this);
            activityNameHeading.setLayoutParams(activityNameTvParams);
            activityNameHeading.setTextSize(20);
            activityNameHeading.setTextColor(getResources().getColor(R.color.colorWhite));
            activityNameHeading.setText(activities.get(i).getActivityName());
            activityNameHeading.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            activityNameHeading.setGravity(Gravity.CENTER);
            activityNameHeading.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.style_textview_static_header));

            LinearLayout lHeader = new LinearLayout(this);
            lHeader.removeAllViews();
            lHeader.setLayoutParams(subRowParams);
            lHeader.setOrientation(LinearLayout.HORIZONTAL);
            lHeader.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.style_textview_static_header));
            TextView regHeading, otHeading, dotHeading;
            regHeading = new TextView(this);
            regHeading.setLayoutParams(tvParams);
            regHeading.setTextSize(20);
            regHeading.setTextColor(whiteColor);
            regHeading.setText("REG");
            regHeading.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            regHeading.setGravity(Gravity.CENTER);

            otHeading = new TextView(this);
            otHeading.setLayoutParams(tvParams);
            otHeading.setTextSize(20);
            otHeading.setTextColor(whiteColor);
            otHeading.setText("OT");
            otHeading.setGravity(Gravity.CENTER);

            dotHeading = new TextView(this);
            dotHeading.setLayoutParams(tvParams);
            dotHeading.setTextSize(20);
            dotHeading.setTextColor(whiteColor);
            dotHeading.setText("DOT");
            dotHeading.setGravity(Gravity.CENTER);

            lHeader.addView(regHeading);
            lHeader.addView(otHeading);
            lHeader.addView(dotHeading);

            dynamicHeader.addView(activityNameHeading);
            dynamicHeader.addView(viewDivider);
            dynamicHeader.addView(lHeader);

            //adding long press listener to activity heading

            final int finalI1 = i;
            dynamicHeader.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    customClickListener.activityHeaderLongPressed(view, finalI1);
                    return true;
                }
            });
            dynamicHeader.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    customClickListener.activityHeaderClicked(finalI1);
                }
            });


            linearLayoutDynamicHeader.addView(dynamicHeader);
            final int finalI = i;
            double footerRegTotal = 0.0, footerOtTotal = 0.0, footerDotTotal = 0.0;
            for (int row = 0; row < mCrewTimeSheet.getEmpTimeSheet().size(); row++) {
                footerRegTotal = footerRegTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getStandardTime();
                footerOtTotal = footerOtTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getOverTime();
                footerDotTotal = footerDotTotal + mCrewTimeSheet.getEmpTimeSheet().get(row).getTimeSheet().get(i).getDoubleOverTime();
            }
            LinearLayout.LayoutParams footerTvParams = new TableRow.LayoutParams(0, dpToPx(70), 1f);
            LinearLayout lFooter = new LinearLayout(this);
            lFooter.removeAllViews();
            lFooter.setLayoutParams(rowParams);
            lFooter.setOrientation(LinearLayout.HORIZONTAL);
            TextView regTotal, otTotal, dotTotal;
            regTotal = new TextView(this);
            regTotal.setLayoutParams(footerTvParams);
            regTotal.setTextColor(Color.BLACK);
            regTotal.setText(footerRegTotal+"");
            regTotal.setGravity(Gravity.CENTER);

            otTotal = new TextView(this);
            otTotal.setLayoutParams(footerTvParams);
            otTotal.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            otTotal.setTextColor(Color.BLACK);
            otTotal.setText(footerOtTotal+"");
            otTotal.setGravity(Gravity.CENTER);

            dotTotal = new TextView(this);
            dotTotal.setLayoutParams(footerTvParams);
            dotTotal.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            dotTotal.setTextColor(Color.BLACK);
            dotTotal.setText(footerDotTotal+"");
            dotTotal.setGravity(Gravity.CENTER);
            dotTotal.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.style_textview_static_footer));

            lFooter.addView(regTotal);
            lFooter.addView(otTotal);
            lFooter.addView(dotTotal);
            linearLayoutDynamicFooter.addView(lFooter);
        }
    }

    void deleteActivity(View view, final int activityColumn){
        String activityName = mCrewTimeSheet.getCrewActivity().get(activityColumn).getActivityName();
        DeletePopup deletePopup = new DeletePopup(MainActivity.this, R.layout.delete_popup, activityColumn, activityName, new DeletePopupInterface() {
            @Override
            public void deleteValues(int deletePosition) {
                final CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
                    mCrewTimeSheet.getCrewActivity().get(activityColumn).setDeleteFlag("Y");
                    String jsonDeleteTimesheet = creatingSubmitJson.getCrewTimeJSONAsString(mCrewTimeSheet);
                    Log.d("IshanLog JSON Delete TS", jsonDeleteTimesheet);
                    SubmittingTask deleteTask = new SubmittingTask(getApplicationContext(), jsonDeleteTimesheet, new SubmittingTimeSheetInterface() {
                        @Override
                        public void SubmittingTimeSheetInterface(String result) {
                            if (result == null || result.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                                progressDialog.dismiss();
                                makeAlertErrorOccurred();
                            }
                            else {
                                Log.d(TAG, "Delete Activity Successful");
                                RetrieveTimeSheetParser retrieveDeletedTimeSheetParser = new RetrieveTimeSheetParser();
                                mCrewTimeSheet = retrieveDeletedTimeSheetParser.parseCrewTimesheetData(result);
                                setUpUIElements(mCrewTimeSheet);
                                new insertTimesheetInDatabaseTask().execute();
                                progressDialog.dismiss();
                            }
                        }
                        @Override
                        public void BeforeCompleted() {
                            progressDialog = ProgressDialog.show(MainActivity.this, null, "        Deleting Activity...");
                        }
                    });
                    deleteTask.execute();
                }
            @Override
            public void dismiss() {}
            @Override
            public void refreshWebserviceCall(String compCode, String jobCode) {}
            @Override
            public void personWebServiceCall(String employeeOraseq) {}
        });
        deletePopup.show(view);
    }

    private void deleteCrewMember(View view, final int position) {
        final String crewMemberName = mCrewTimeSheet.getEmpTimeSheet().get(position).getEmpName();
        DeletePopup deletePopup = new DeletePopup(MainActivity.this, R.layout.delete_popup, position, crewMemberName, new DeletePopupInterface() {
            @Override
            public void deleteValues(int deletePosition) {
                final CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
                final String empNo = mCrewTimeSheet.getEmpTimeSheet().get(position).getEmpNo();
                mCrewTimeSheet.getEmpTimeSheet().get(position).setDeleteFlag("Y");
                String jsonDelete = creatingSubmitJson.getCrewTimeJSONAsString(mCrewTimeSheet);
                Log.d(TAG, "Deleting Crew Member: Deleting From Timesheet");
                SubmittingTask deleteTask = new SubmittingTask(getApplicationContext(), jsonDelete, new SubmittingTimeSheetInterface() {
                    @Override
                    public void SubmittingTimeSheetInterface(String result) {
                        if (result != null && !result.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                            Log.d(TAG, "Deleting Crew Member: Deleting From Timesheet Successful");
                            RetrieveTimeSheetParser retrieveDeletedTimeSheetParser = new RetrieveTimeSheetParser();
                            mCrewTimeSheet = retrieveDeletedTimeSheetParser.parseCrewTimesheetData(result);
                            new insertTimesheetInDatabaseTask().execute();
                            progressDialog.dismiss();
                            //Fetching Crew Details
                            Log.d(TAG, "Deleting Crew Member: Fetching Crew Details");
                            IshanAllEmployeeDBHelper allEmployeeDBHelper = new IshanAllEmployeeDBHelper(MainActivity.this);
                            String pyceOraSeqofDeletedMember= allEmployeeDBHelper.getPyceOraSeqOfEmployee(empNo);
                            DeleteCrewEmployeeTask deleteCrewEmployeeTask = new DeleteCrewEmployeeTask(
                                    MainActivity.this, pyceOraSeqofDeletedMember, new DeleteCrewEmployeeTask.DeleteCrewEmployeeInterface() {
                                @Override
                                public void preTask() {
                                    progressDialog = ProgressDialog.show(MainActivity.this, null, "      Deleting  Member from Crew");
                                }
                                @Override
                                public void postTask(String response) {
                                    progressDialog.dismiss();
                                    if (response==null || response.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                                        makeAlertErrorOccurred();
                                        Log.d(TAG, "Deleting Crew Member: Deleting From Crew Unsuccessful");
                                        Log.d(TAG, "Deleting Crew Member: Deleting From Crew Response - " + response);
                                    }
                                    else {
                                        Log.d(TAG, "Deleting Crew Member: Deleting From Crew Successful");
                                        Log.d(TAG, "Deleting Crew Member: Deleting From Crew Response - " + response);
                                    }
                                }
                            });
                            deleteCrewEmployeeTask.execute();
                            setUpUIElements(mCrewTimeSheet);
                        } else {
                            progressDialog.dismiss();
                            Log.d(TAG, "Deleting Crew Member: Deleting From Timesheet Unsuccessful");
                            makeAlertErrorOccurred();
                        }
                    }
                    @Override
                    public void BeforeCompleted() {
                        progressDialog = ProgressDialog.show(MainActivity.this, null,"     Deleting Crew Member from Timesheet...");
                    }
                });
                deleteTask.execute();
            }
            @Override
            public void dismiss() {

            }
            @Override
            public void refreshWebserviceCall(String compCode, String jobCode) {

            }
            @Override
            public void personWebServiceCall(String employeeOraseq) {

            }
        });
        deletePopup.show(view);
    }

    private void initViews() {
        changeColor();
        typeface = Typeface.createFromAsset(getAssets(),"fonts/cmic_icons.ttf");
        rv = (RelativeLayout) findViewById(R.id.rltMain);
        recyclerViewStatic = (RecyclerView) findViewById(R.id.rvStatic);
        recyclerViewDynamic = (RecyclerView) findViewById(R.id.rvDynamic);
        linearLayoutDynamicHeader = (LinearLayout) findViewById(R.id.headerDynamic);
        linearLayoutDynamicFooter = (LinearLayout) findViewById(R.id.footerDynamic);
        linearLayoutDynamicHeader.removeAllViews();
        linearLayoutDynamicFooter.removeAllViews();
        recyclerViewStatic.setTag(0);
        recyclerViewDynamic.setTag(1);
        typeface = Typeface.createFromAsset(getAssets(),"fonts/cmic_icons.ttf");
        tvBack = (TextView)findViewById(R.id.back);
        tvSheetTitle = (TextView)findViewById(R.id.daily_crew_sheet_text);
        btnSelectedJob = (Button)findViewById(R.id.btnselectProject);
        btnSubmitTimesheet = (ImageButton)findViewById(R.id.submit);
        tvMenu = (TextView)findViewById(R.id.menu_icon);
        tvMode = (TextView)findViewById(R.id.RegularAdvanceMode);
        tvDay = (TextView)findViewById(R.id.txtDayMiddle);
        tvDate = (TextView)findViewById(R.id.txtDateMiddle);
        tvCalendar = (TextView)findViewById(R.id.selectedDate);
        tvCrewname = (TextView)findViewById(R.id.txtcrewname);
        tvResponsiblePerson = (TextView)findViewById(R.id.txtresponsibleperson);
        tvHrtTradeName = (TextView)findViewById(R.id.txthrttradename);
        tvTradeName = (TextView)findViewById(R.id.txthrtname);
        tvTimeinOut = (TextView)findViewById(R.id.timeinout);
        tvMenu.setTypeface(typeface);
        tvCalendar.setTypeface(typeface);
        tvBack.setTypeface(typeface);
        tvTimeinOut.setTypeface(typeface);
        btnOne = (Button)findViewById(R.id.btnOne);
        btnTwo = (Button)findViewById(R.id.btnTwo);
        btnThree = (Button)findViewById(R.id.btnThree);
        btnFour = (Button)findViewById(R.id.btnFour);
        btnFive = (Button)findViewById(R.id.btnFive);
        btnSix = (Button)findViewById(R.id.btnSix);
        btnSeven = (Button)findViewById(R.id.btnSeven);
        listWeek = new ArrayList<Button>();
        listWeek.add(btnOne);listWeek.add(btnTwo);listWeek.add(btnThree);listWeek.add(btnFour);
        listWeek.add(btnFive);listWeek.add(btnSix);listWeek.add(btnSeven);
        tvCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCrewTimeSheet.isEdited()){
                    unsavedTimesheetPopup();                }
                else {
                    slectDateFromCalendar();
                }
            }
        });
        tvFooterReg = (TextView)findViewById(R.id.tvFooterREGTotal);
        tvFooterOt = (TextView)findViewById(R.id.tvFooterOTTotal);
        tvFooterDot = (TextView)findViewById(R.id.tvFooterDOTTotal);
        tvFooterInOut = (TextView)findViewById(R.id.tvFooterInOutTotal);
        btnSelectedJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCrewTimeSheet.isEdited()){
                    unsavedTimesheetPopup();
                }
                else {
                    Intent intent = new Intent(MainActivity.this, ProjectListActivity.class);
                    intent.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
                    startActivityForResult(intent, REQUEST_CODE_PROJECT);
                }
            }
        });
        tvCrewname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCrewTimeSheet.isEdited()){
                    unsavedTimesheetPopup();                }
                else {
                    Intent intent = new Intent(MainActivity.this, CrewListActivity.class);
                    intent.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
                    intent.putExtra("InsertedNewCrewOraseq", selectedOraSew);
                    startActivityForResult(intent, REQUEST_CODE_CREW_LIST);
                }
            }
        });
        btnSubmitTimesheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitTimeSheet();
            }
        });
    }

    private void calendarOperations() {
        cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE yyyy.MM.dd");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy.MM.dd");
        SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");
        setFirstDayInCalendarInstance();
        int diff = calculateDifference(cal.getFirstDayOfWeek() , cal.get(Calendar.DAY_OF_WEEK));
        String date = sdfDate.format(cal.getTime());
        String day = sdfDay.format(cal.getTime());
        Date todaysDate = (cal.getTime());
        cal.add(Calendar.DAY_OF_WEEK, 1-diff);
        Log.i("dateTag", sdf.format(cal.getTime()));
        for (int i = 2; i <= 7; i++) {
            cal.add(Calendar.DAY_OF_WEEK,1);
            Log.i("dateTag", sdf.format(cal.getTime()));
            int x = cal.getFirstDayOfWeek();
            int y = cal.get(Calendar.DAY_OF_WEEK);
        }
    }
    private void linkButtonsToDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE yyyy.MM.dd");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy.MM.dd");
        SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");
        workDate = mCrewTimeSheet.getWorkDate();
        int year = Integer.parseInt(workDate.split("\\-")[0]);
        int month = Integer.parseInt(workDate.split("\\-")[1]);
        int day = Integer.parseInt(workDate.split("\\-")[2]);
        cal = Calendar.getInstance();
//Month starts from 0-11. so subtract 1
        --month;
        cal.set(year, month, day);
        String dayOfWeek = sdfDay.format(cal.getTime());
        tvDate.setText(workDate);
        tvDay.setText(dayOfWeek);
        setFirstDayInCalendarInstance();
        int diff = calculateDifference(cal.getFirstDayOfWeek() , cal.get(Calendar.DAY_OF_WEEK));
        cal.add(Calendar.DAY_OF_WEEK, 0-diff);
        String date = sdfDate.format(cal.getTime());
        dayOfWeek = sdfDay.format(cal.getTime());
        hashmapDateToButton = new HashMap<>();
        hashmapDateToButton.put(dayOfWeek, date);
        Log.i("dateTag", sdf.format(cal.getTime()));
        for (int i = 2; i <= 7; i++) {
            cal.add(Calendar.DAY_OF_WEEK,1);
            Log.i("dateTag", sdf.format(cal.getTime()));
            date = sdfDate.format(cal.getTime());
            dayOfWeek = sdfDay.format(cal.getTime());
            hashmapDateToButton.put(dayOfWeek, date);
        }
        setUpWeek2();
    }

    public int calculateDifference(int first, int selected){
        int difference = 0;
        while (first!=selected){
            if (first==7) {
                difference++;
                first = 1;
            }
            else {
                difference++;
                first++;
            }
        }
        return difference;
    }

    private void setFirstDayInCalendarInstance() {
        int dayNum = CollectionUtils.dayConverter().get(firstDayOfWeek).intValue();
        switch (dayNum){
            case 1:
                cal.setFirstDayOfWeek(Calendar.SUNDAY);
                break;
            case 2:
                cal.setFirstDayOfWeek(Calendar.MONDAY);
                break;
            case 3:
                cal.setFirstDayOfWeek(Calendar.TUESDAY);
                break;
            case 4:
                cal.setFirstDayOfWeek(Calendar.WEDNESDAY);
                break;
            case 5:
                cal.setFirstDayOfWeek(Calendar.THURSDAY);
                break;
            case 6:
                cal.setFirstDayOfWeek(Calendar.FRIDAY);
                break;
            case 7:
                cal.setFirstDayOfWeek(Calendar.SATURDAY);
                break;
        }
    }

    private void setUpWeekdaysButtons(String firstDay) {
        int i=0;
        ArrayList<String> week = CollectionUtils.getWeek(firstDay);
        for (Button btn : listWeek){
            btn.setText(week.get(i++));
        }
    }

    private void setUpWeek2(){
        workDate = mCrewTimeSheet.getWorkDate();
        StringBuilder tempWorkDate = new StringBuilder(workDate);
        for (int i = 0; i < tempWorkDate.length(); i++)
            if (tempWorkDate.charAt(i) == '-')
                tempWorkDate.setCharAt(i, '.');

        for (final Button btn : listWeek){
            if (hashmapDateToButton.get(String.valueOf(btn.getText())).equalsIgnoreCase(tempWorkDate.toString())){
                btn.setBackgroundColor(Color.parseColor("#ffffff"));
                btn.setTextColor(Color.parseColor("#1780FB"));
            }
            else {
                btn.setBackgroundColor(Color.parseColor("#1780FB"));
                btn.setTextColor(Color.parseColor("#ffffff"));
            }
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCrewTimeSheet.isEdited()){
                        unsavedTimesheetPopup();                    }
                    else {
                        workDate = hashmapDateToButton.get(String.valueOf(btn.getText()));
                        StringBuilder changeWorkDateFormat = new StringBuilder(workDate);
                        for (int i = 0; i < changeWorkDateFormat.length(); i++)
                            if (changeWorkDateFormat.charAt(i) == '.')
                                changeWorkDateFormat.setCharAt(i, '-');
                        workDate = changeWorkDateFormat.toString();
                        retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            if (requestCode == REQUEST_CODE_PROJECT){
                getValuesFromSharedPreference();
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
            else if (requestCode == REQUEST_CODE_CREW_DETAILS){
                /* Ishan Code prior to local Database
                ArrayList<User> addedEmployees = (ArrayList<User>) data.getSerializableExtra(getString(R.string.cmic_intent_extras_added_crew_members));
                ArrayList<ActivityTimeForCrew> a = new ArrayList<ActivityTimeForCrew>();
                for (User crewMember : addedEmployees){
                    a = new ArrayList<ActivityTimeForCrew>();
                    for (int i =0;i<mCrewTimeSheet.getCrewActivity().size(); i++){
                        ActivityTimeForCrew activity = new ActivityTimeForCrew(null,0,null,0,null,0,mCrewTimeSheet.getCrewCode()
                                ,mCrewTimeSheet.getWorkDate(),crewMember.getEmployeeNo());
                        a.add(activity);
                    }
                    EmployeeDataForCrew e = new EmployeeDataForCrew("null",crewMember.getEmployeeNo(), crewMember.getName()
                    ,crewMember.getTradeCode(), crewMember.getTradeName(), mCrewTimeSheet.getEmpTimeSheet().size()+"",
                            a,0,0,0,null,null,null);
                    e.setTimeInOutModals(null);
                    mCrewTimeSheet.getEmpTimeSheet().add(e);
                }
                */
                mCrewTimeSheet = mDbInstance.getTimeSheetFromDatabase();
                setUpUIElements(mCrewTimeSheet);
            }
            else if (requestCode == REQUEST_CODE_CREW_LIST){
                getValuesFromSharedPreference();
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }
            else if (requestCode == REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON){
                getValuesFromSharedPreference();
                setUpUIElements(mCrewTimeSheet);
            }
        }
    }

    private MyListner myListner = new MyListner() {
        @Override
        public void yoNigga(String message) {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        }
    };

    private CustomClickListener customClickListener = new CustomClickListener() {
        @Override
        public void activityHeaderClicked(int position) {
            if (isRegularModeSelected){
                Toast.makeText(MainActivity.this, "Regular Mode Selected", Toast.LENGTH_SHORT).show();
                RegularModePopUp(position);
            }
            else {
                Toast.makeText(MainActivity.this, "Advanced Mode Selected", Toast.LENGTH_SHORT).show();
                AdvancedModePopUp(mCrewTimeSheet.getCrewActivity().get(position).getActivityName(),position);
            }
        }

        @Override
        public void activityHeaderLongPressed(View v, int position) {
            deleteActivity(v, position);
        }

        @Override
        public void rowItemClicked(int listPosition, int activityPosition) {
            TimePopUp(listPosition, activityPosition);
        }

        @Override
        public void crewMemberLongClicked(View v, int position) {
            deleteCrewMember(v,position);
        }
    };

    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = getApplicationContext().getResources().getDisplayMetrics();
        return Math.round(dp * displayMetrics.density + 0.5f);
    }

    private void changeColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorRed));
        }
    }

    private RecyclerView.OnScrollListener custom_scroll_listner = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if ((int) recyclerView.getTag() == mTouchedRvTag) {
                for (int noOfRecyclerView = 0; noOfRecyclerView < 2; noOfRecyclerView++) {
                    if (noOfRecyclerView != (int) recyclerView.getTag()) {
                        RecyclerView tempRecyclerView = (RecyclerView) rv.findViewWithTag(noOfRecyclerView);
                        tempRecyclerView.scrollBy(dx, dy);
                    }
                }
            }
        }
    };

    private RecyclerView.OnItemTouchListener custom_item_touch_listner = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            mTouchedRvTag = (int) rv.getTag();
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    };
    boolean isAsyncTaskRunning = false;
    public void retrieveWebserviceFromCrewCode(String currDate, String crewCode, String projectCode) {
        RetrievingTimeSheet retrieveParser = new RetrievingTimeSheet(this, crewCode, currDate, projectCode, new RetrieveTimeSheetInterface() {
            @Override
            public void RetrieveTimeSheetInterface(String result) {
                isAsyncTaskRunning = false;
                if (result != null && !result.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                    RetrieveTimeSheetParser retrieveTimeSheetParser = new RetrieveTimeSheetParser();
                    mCrewTimeSheet = retrieveTimeSheetParser.parseCrewTimesheetData(result);
                    mCrewTimeSheet.setEdited(false);
                    setUpUIElements(mCrewTimeSheet);
                    new insertTimesheetInDatabaseTask().execute();
                    progressDialog.dismiss();
                } else {
                    progressDialog.dismiss();
                    makeAlertErrorOccurred();
                }
            }
            @Override
            public void BeforeCompletion() {
                isAsyncTaskRunning = true;
                progressDialog = ProgressDialog.show(MainActivity.this, null, "         Retrieving  TimeSheet ...");
            }
        });
        if (!isAsyncTaskRunning)
            retrieveParser.execute();
        else {
            Log.d(TAG,"RetrievingTimeSheet Previous Task Running");
        }
    }

    private String setWorkdateToTodaysDate() {
        cal = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat df1 = new SimpleDateFormat("EEEE");
        workDate = df.format(cal.getTime());
        workDay = df1.format(cal.getTime());
        return workDate;
    }

    private void getValuesFromSharedPreference(){
        ishanSharedPreference = getApplicationContext().getSharedPreferences(getString(R.string.cmic_shared_preference), 0);
        ishanPreferenceEditor = ishanSharedPreference.edit();
        defaultSharedPreference = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        defaultPreferenceEditor = defaultSharedPreference.edit();
        selectedCrewCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_code)
        ,getString(R.string.cmic_shared_preference_no_crew_code));
        selectedProjectCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_code)
        ,getString(R.string.cmic_shared_preference_no_project));
        selectedProjectCompCode = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_comp_code),
                "NOCOMPCODE");
        selectedProjectName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_project_name)
                ,"NOPROJECTNAME");
        selectedResponsiblePerson = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_responsible_person)
                ,"NORESPONSIBLEPERSON");
        if (selectedResponsiblePerson.equalsIgnoreCase("null") || selectedResponsiblePerson.equalsIgnoreCase(""))
            selectedResponsiblePerson = "Not Selected";
        selectedTradeName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_hrt_name)
                ,"NOHRTNAME");
        selectedHrtTradeName = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_hrt_trade_name)
                ,"NOHRTTRADENAME");
        selectedOraSew = ishanSharedPreference.getString(getString(R.string.cmic_shared_preference_crew_ora_seq)
                ,"NOORASEQ");
        isRegularModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_regular_mode),true);
        isInOutModeSelected = defaultSharedPreference.getBoolean(getString(R.string.settings_key_switch_inout_mode),false);
        normalTimeFromSettings = Integer.parseInt(defaultSharedPreference.getString(getString(R.string.settings_key_normal_time),
                getString(R.string.settings_normal_time_default)));
        overTimeFromSettings = Integer.parseInt(defaultSharedPreference.getString(getString(R.string.settings_key_over_time),
                getString(R.string.settings_over_time_default)));
        firstDayOfWeek = defaultSharedPreference.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
        if (mCrewTimeSheet!=null) {
            mCrewTimeSheet.setCrewCode(selectedCrewCode);
            mCrewTimeSheet.setJobCode(selectedProjectCode);
            mCrewTimeSheet.setJobCompCode(selectedProjectCompCode);
        }
    }

    //Dialog datePicker
    private void slectDateFromCalendar() {
        fromDatePickerDialog = new DatePickerDialog(this, R.style.DatePickerDailog, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                int month;
                String  date;
                month = monthOfYear + 01;
                String formattedMonth = "" + month;
                String formattedDayOfMonth = "" + dayOfMonth;
                //newCalendar.set(year, monthOfYear, dayOfMonth);
                if (month < 10) {
                    formattedMonth = "0" + month;
                }
                if (dayOfMonth < 10) {
                    formattedDayOfMonth = "0" + dayOfMonth;
                }
                date = year + "-" + formattedMonth + "-" + formattedDayOfMonth;
                workDate = date;
                retrieveWebserviceFromCrewCode(workDate, selectedCrewCode, selectedProjectCode);
            }

        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        fromDatePickerDialog.show();
    }

    public void calculateTotalHours(CrewTimeSheet crewTimeSheet){
        ArrayList<EmployeeDataForCrew> empTimesheet = crewTimeSheet.getEmpTimeSheet();
        ArrayList<SubmittedActivityFromCrewModal> activityTimeSheet = crewTimeSheet.getCrewActivity();
        if (crewTimeSheet!=null){
            for (int numberOfEmployee = 0; numberOfEmployee < empTimesheet.size(); numberOfEmployee++) {
                double totalREG = 0.0, totalOT = 0.0, totalDOT = 0.0;

                for (int numberOfActivities = 0; numberOfActivities < activityTimeSheet.size(); numberOfActivities++) {

                    totalREG = totalREG + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getStandardTime();
                    totalOT = totalOT + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getOverTime();
                    totalDOT = totalDOT + mCrewTimeSheet.getEmpTimeSheet().get(numberOfEmployee).getTimeSheet().get(numberOfActivities).getDoubleOverTime();
                }
                empTimesheet.get(numberOfEmployee).setTotalRtHour(totalREG);
                empTimesheet.get(numberOfEmployee).setTotalOtHour(totalOT);
                empTimesheet.get(numberOfEmployee).setTotalDotHour(totalDOT);
            }
        }
        else
            Log.d("MAINACTIVITY", "Timesheet is Null");
    }

    private void calculateFooterHours(CrewTimeSheet crewTimeSheet) {
        ArrayList<EmployeeDataForCrew> empTimesheet = crewTimeSheet.getEmpTimeSheet();
        ArrayList<SubmittedActivityFromCrewModal> activityTimeSheet = crewTimeSheet.getCrewActivity();
        if (crewTimeSheet!=null){
            double totalREG = 0.0, totalOT = 0.0, totalDOT = 0.0, totalInOut = 0.0;
            for (int numberOfEmployee = 0; numberOfEmployee < empTimesheet.size(); numberOfEmployee++) {
                totalREG = totalREG + empTimesheet.get(numberOfEmployee).getTotalRtHour();
                totalOT = totalOT + empTimesheet.get(numberOfEmployee).getTotalOtHour();
                totalDOT = totalDOT + empTimesheet.get(numberOfEmployee).getTotalDotHour();
                //totalInOut = totalInOut + Double.parseDouble(totalInOut + empTimesheet.get(numberOfEmployee).getTotalTimeInOut());
            }
            tvFooterReg.setText(totalREG+"");
            tvFooterOt.setText(totalOT+"");
            tvFooterDot.setText(totalDOT+"");
            //tvFooterInOut.setText(totalInOut+"");
        }
        else
            Log.d("MAINACTIVITY", "method calculateFooterHours:  Timesheet is Null");
    }

    private void responsiblePersonClicked(){
        Intent i = new Intent(MainActivity.this, CrewDetailsActivity.class);
        i.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
        i.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), false);
        startActivityForResult(i,REQUEST_CODE_CREW_DETAILS_FOR_RESPONSIBLE_PERSON);
    }

    private void switchRegularAndAdvancedMode(){
        if (isRegularModeSelected){
            isRegularModeSelected = false;
            Log.d(TAG,"Advanced Mode Selected");
            defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_regular_mode),false).commit();
            tvMode.setText("R");
        }
        else {
            isRegularModeSelected = true;
            Log.d(TAG,"Regular Mode Selected");
            defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_regular_mode),true).commit();
            tvMode.setText("A");
        }
    }

    private void submitTimeSheet() {
        CreatingSubmitJson creatingSubmitJson = new CreatingSubmitJson();
        if (mCrewTimeSheet.getSeqNo() == null || mCrewTimeSheet.getSeqNo().equalsIgnoreCase("null") || mCrewTimeSheet.getSeqNo().equals("")) {
            mCrewTimeSheet.setJobCode(selectedProjectCode);
            String crewTimeJson = creatingSubmitJson.getCrewTimeJSONAsString(mCrewTimeSheet);
            SubmittingTask submittingTask = new SubmittingTask(getApplicationContext(), crewTimeJson, submittingTimeSheetInterface);
            submittingTask.execute();
        } else {
            String jsonSubmitWithSeqNo = creatingSubmitJson.getCrewTimeJSONAsString(mCrewTimeSheet);
            SubmittingTask submittingTask = new SubmittingTask(getApplicationContext(), jsonSubmitWithSeqNo, submittingTimeSheetInterface);
            submittingTask.execute();
        }
    }

    private SubmittingTimeSheetInterface submittingTimeSheetInterface= new SubmittingTimeSheetInterface(){
        @Override
        public void SubmittingTimeSheetInterface(String result) {
            if (result != null && !result.equalsIgnoreCase(getString(R.string.internal_server_error))) {
                RetrieveTimeSheetParser retrieveTimeSheetParser = new RetrieveTimeSheetParser();
                mCrewTimeSheet = retrieveTimeSheetParser.parseCrewTimesheetData(result);
                setUpUIElements(mCrewTimeSheet);
                new insertTimesheetInDatabaseTask().execute();
                progressDialog.dismiss();
            }
            else {
                progressDialog.dismiss();
                makeAlertErrorOccurred();
            }
        }
        @Override
        public void BeforeCompleted() {
            progressDialog = ProgressDialog.show(MainActivity.this, null, "         Submitting TimeSheet ...");
        }
    };

//Dialog TimeEntry

private void TimePopUp(final int listPosition, final int activityPosition) {
    final double[] REGTime = new double[1];
    final double[] OTTime = new double[1];
    final double[] DOTTime = new double[1];
    REGTime[0] = mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).getStandardTime();
    OTTime[0] = mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).getOverTime();
    DOTTime[0] = mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).getDoubleOverTime();
    final Dialog timepopup;
    timepopup = new Dialog(MainActivity.this);
    timepopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
    timepopup.setContentView(R.layout.popup);
    TextView cancel = (TextView) timepopup.findViewById(R.id.cancel);
    TextView plusst = (TextView) timepopup.findViewById(R.id.txtplusst);
    TextView plusot = (TextView) timepopup.findViewById(R.id.txtplusot);
    TextView plusdot = (TextView) timepopup.findViewById(R.id.txtplusdot);
    TextView minusst = (TextView) timepopup.findViewById(R.id.txtminusst);
    TextView minusot = (TextView) timepopup.findViewById(R.id.txtminusot);
    TextView minusdot = (TextView) timepopup.findViewById(R.id.txtminusdot);
    Button btnDone = (Button) timepopup.findViewById(R.id.btndone);
    final EditText etst = (EditText) timepopup.findViewById(R.id.etst);
    final EditText etot = (EditText) timepopup.findViewById(R.id.etot);
    final EditText etdot = (EditText) timepopup.findViewById(R.id.etdot);
    etst.setText(String.valueOf(REGTime[0]));
    etot.setText(String.valueOf(OTTime[0]));
    etdot.setText(String.valueOf(DOTTime[0]));
    cancel.setTypeface(typeface);
    plusst.setTypeface(typeface);
    plusot.setTypeface(typeface);
    plusdot.setTypeface(typeface);
    minusst.setTypeface(typeface);
    minusot.setTypeface(typeface);
    minusdot.setTypeface(typeface);
    //   timeInOut.setTypeface(tf);
    plusst.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // double insertedValue = employeeDataForCrewsList.get(row).getTimeSheet().get(pos)
            REGTime[0] = REGTime[0] + 0.5;
            etst.setText(String.valueOf(REGTime[0]));
        }
    });

    plusot.setOnClickListener(new View.OnClickListener() {
        //  double sumOT;
        @Override
        public void onClick(View v) {
            OTTime[0] = OTTime[0] + 0.5;
            etot.setText(String.valueOf(OTTime[0]));
        }
    });

    plusdot.setOnClickListener(new View.OnClickListener() {
        double sumDOT;

        @Override
        public void onClick(View v) {
            DOTTime[0] = DOTTime[0] + 0.5;
            etdot.setText(String.valueOf(DOTTime[0]));

        }
    });

    minusst.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (REGTime[0] > 0) {
                REGTime[0] = REGTime[0] - 0.5;
                etst.setText(String.valueOf(REGTime[0]));
            }

        }
    });
    minusot.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (OTTime[0] > 0) {
                OTTime[0] = OTTime[0] - 0.5;
                etot.setText(String.valueOf(OTTime[0]));
            }
        }
    });
    minusdot.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (DOTTime[0] > 0) {
                DOTTime[0] = DOTTime[0] - 0.5;
                etdot.setText(String.valueOf(DOTTime[0]));
            }
        }
    });
    cancel.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            timepopup.dismiss();
        }
    });

    etst.setOnTouchListener(new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            etst.setFocusable(true);
            etst.setFocusableInTouchMode(true);
            InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
            return false;
        }
    });
    etot.setOnTouchListener(new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            etot.setFocusable(true);
            etot.setFocusableInTouchMode(true);
            InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
            return false;
        }
    });

    etdot.setOnTouchListener(new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            etdot.setFocusable(true);
            etdot.setFocusableInTouchMode(true);
            InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.showSoftInputFromInputMethod(v.getWindowToken(), 0);
            return false;
        }
    });
    btnDone.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            timepopup.dismiss();
            //REGTimePopup = Double.valueOf(etst.getText().toString());
            mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).setStandardTime(REGTime[0]);
            //OTTimePopup = Double.valueOf(etot.getText().toString());
            mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).setOverTime(OTTime[0]);
            //DOTTimePopup = Double.valueOf(etdot.getText().toString());
            mCrewTimeSheet.getEmpTimeSheet().get(listPosition).getTimeSheet().get(activityPosition).setDoubleOverTime(DOTTime[0]);
            mCrewTimeSheet.setEdited(true);
            setUpUIElements(mCrewTimeSheet);
            new insertTimesheetInDatabaseTask().execute();
            /*
            CalculateTotalRowWise(mCrewTimeSheet.getCrewActivity().size());
            CalculateTotalColoumnWise(submittedActivityListFromRetrieveParser);
            footer(CalculateTotalColoumnWise(getSubmittedActivityFromCrewModalArrayList()));

            if (etst.getText().toString().equals("0.0") && etot.getText().toString().equals("0.0") && etdot.getText().toString().equals("0.0")) {
                dataModifiedOrFirstTime = false;
            } else {
                dataModifiedOrFirstTime = true;
            }
            */

        }
    });

    timepopup.show();
}
//Dialog Menu
private void showMenuDialog() {

    final Dialog dialog = new Dialog(MainActivity.this);
    // Include dialog.xml file
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    dialog.setContentView(R.layout.dialog_menu);
    final TextView tvCancel, tvClearData, tvNotifyApprover, tvAddActivity, tvSwitchRegularAdvancedMode
            ,tvAddCrewMember, tvSettingScreen, tvLogout, tvAddNewCrew, tvSwitchInOutMode;
    tvCancel = (TextView) dialog.findViewById(R.id.cancel);
    tvClearData = (TextView) dialog.findViewById(R.id.cleardata);
    tvNotifyApprover = (TextView) dialog.findViewById(R.id.notifyapprover);
    tvAddActivity = (TextView) dialog.findViewById(R.id.addactivity);
    tvSwitchRegularAdvancedMode = (TextView) dialog.findViewById(R.id.switchtoregularmode);
    tvAddCrewMember = (TextView) dialog.findViewById(R.id.addcrewmember);
    tvSettingScreen = (TextView) dialog.findViewById(R.id.txtsettingscreen);
    tvLogout = (TextView) dialog.findViewById(R.id.txtlogout);
    tvAddNewCrew = (TextView) dialog.findViewById(R.id.switchcrew);
    tvSwitchInOutMode = (TextView) dialog.findViewById(R.id.inOutmode);
    if (isRegularModeSelected)
        tvSwitchRegularAdvancedMode.setText("Switch To Advanced Mode");
    else
        tvSwitchRegularAdvancedMode.setText("Switch to Regular Mode");
    if (isInOutModeSelected)
        tvSwitchInOutMode.setText("Switch To TimeSheet Mode");
    else
        tvSwitchInOutMode.setText("Switch To In/Out Mode");

    tvCancel.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.d("Cancel", "clicked");
            dialog.dismiss();
        }
    });


    tvAddActivity.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.dismiss();
            final Dialog dialognewactivity = new Dialog(MainActivity.this);
            dialognewactivity.requestWindowFeature(Window.FEATURE_NO_TITLE); //before
            dialognewactivity.setContentView(R.layout.adding_new_activity);
            TextView txtaddactivityok = (TextView) dialognewactivity.findViewById(R.id.txtaddactivityok);
            TextView txtaddactivitycancel = (TextView) dialognewactivity.findViewById(R.id.txtaddactivitycancel);
            final EditText etActivityName = (EditText) dialognewactivity.findViewById(R.id.etactivityname);


            etActivityName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etActivityName.setFocusable(true);
                    etActivityName.setFocusableInTouchMode(true);
                    InputMethodManager inputMethodManager =
                            (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.toggleSoftInputFromWindow(
                            tvCancel.getApplicationWindowToken(),
                            InputMethodManager.SHOW_FORCED, 0);
                }
            });
            txtaddactivityok.setOnClickListener(new View.OnClickListener() {
                @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                @Override
                public void onClick(View v) {
                    Log.d("ishan", mCrewTimeSheet.toString());
                    String activityName = String.valueOf(etActivityName.getText());
                    ArrayList<SubmittedActivityFromCrewModal> activitiesDataAdd = mCrewTimeSheet.getCrewActivity();
                    SubmittedActivityFromCrewModal lastActivity = activitiesDataAdd.get(activitiesDataAdd.size() - 1);
                    int columnNo = Integer.parseInt(lastActivity.getColoumnNo()) + 1;
                    SubmittedActivityFromCrewModal newActivity = new SubmittedActivityFromCrewModal(""
                            , mCrewTimeSheet.getCrewActivity().size() + "", "", "","Activity "+ activityName, "", "",""
                            , mCrewTimeSheet.getCrewCode(), mCrewTimeSheet.getWorkDate());
                    activitiesDataAdd.add(newActivity);
                    ArrayList<EmployeeDataForCrew> employeeDataAdd = mCrewTimeSheet.getEmpTimeSheet();
                    ActivityTimeForCrew activityTimeForCrew = new ActivityTimeForCrew();
                    activityTimeForCrew.setCrewCode(mCrewTimeSheet.getCrewCode());
                    activityTimeForCrew.setWorkDate(workDate);
                    for (int i = 0; i<employeeDataAdd.size(); i++){
                       mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().add(activityTimeForCrew);
                    }
                    Log.d("ishan", mCrewTimeSheet.toString());
                    dialognewactivity.dismiss();
                    setUpUIElements(mCrewTimeSheet);
                    int a = 10;
                }
            });
            dialognewactivity.show();
            dialog.dismiss();
        }
    });

    tvAddCrewMember.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this, CrewDetailsActivity.class);
            i.putExtra(getString(R.string.cmic_intent_extras_from_timesheet), true);
            i.putExtra(getString(R.string.cmic_intent_extras_show_checkbox), true);
            i.putExtra("InsertedNewCrewOraseq",selectedOraSew);
            i.putExtra(getString(R.string.cmic_intent_extras_timesheet),mCrewTimeSheet);
            startActivityForResult(i,REQUEST_CODE_CREW_DETAILS);
            dialog.dismiss();
        }
    });

    tvSwitchRegularAdvancedMode.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switchRegularAndAdvancedMode();
            dialog.dismiss();
        }
    });

    tvSwitchInOutMode.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (isInOutModeSelected){
                isInOutModeSelected = false;
                defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_inout_mode),isInOutModeSelected);
                setUpUIElements(mCrewTimeSheet);
            }
            else {
                isInOutModeSelected = true;
                defaultPreferenceEditor.putBoolean(getString(R.string.settings_key_switch_inout_mode),isInOutModeSelected);
                setUpUIElements(mCrewTimeSheet);
            }
            dialog.dismiss();
        }
    });

    tvSettingScreen.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intentForSettingActivity = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intentForSettingActivity);
            dialog.dismiss();
        }
    });
    dialog.show();
}

    private void unsavedTimesheetPopup(){
        final Dialog unsavedTimesheetDialog = new Dialog(MainActivity.this);
        unsavedTimesheetDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        unsavedTimesheetDialog.setContentView(R.layout.unsaved_timesheet_popup);
        TextView tvSubmit = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_submit);
        TextView tvDiscard = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_discard);
        TextView tvCancel = (TextView)unsavedTimesheetDialog.findViewById(R.id.unsaved_timesheet_popup_btn_cancel);
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitTimeSheet();
                unsavedTimesheetDialog.dismiss();
            }
        });
        tvDiscard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                retrieveWebserviceFromCrewCode(mCrewTimeSheet.getWorkDate(), mCrewTimeSheet.getCrewCode(), mCrewTimeSheet.getJobCode());
                unsavedTimesheetDialog.dismiss();
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                unsavedTimesheetDialog.dismiss();
            }
        });
        unsavedTimesheetDialog.show();
    }

    private void RegularModePopUp(final int finalI){
        TextWatcher etactivitywatcher = null;
        final Dialog regularModeDialog = new Dialog(MainActivity.this);
        regularModeDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        regularModeDialog.setContentView(R.layout.regularmode_dialog);
        final TextView cancel = (TextView) regularModeDialog.findViewById(R.id.txtcancel);
        TextView txtactivity = (TextView) regularModeDialog.findViewById(R.id.txtactivity);
        final EditText etActivityName = (EditText) regularModeDialog.findViewById(R.id.etactivity);

        if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
            etActivityName.setHint(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
        } else {
            etActivityName.setHint("Activity" + finalI);
        }
        etactivitywatcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    Toast.makeText(MainActivity.this, "blankMessage", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "Message Typed", Toast.LENGTH_SHORT).show();
                }
            }
        };
        //etActivityName.addTextChangedListener(etactivitywatcher);
        etActivityName.requestFocus();
        TextView ok = (TextView) regularModeDialog.findViewById(R.id.txtok);
        TextView batchUpdate = (TextView) regularModeDialog.findViewById(R.id.txtbachupdate);
        if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
            txtactivity.setText(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
        } else {
            txtactivity.setText("Activity" + finalI);
        }

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regularModeDialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regularModeDialog.dismiss();
                mCrewTimeSheet.getCrewActivity().get(finalI).setActivityName(etActivityName.getText().toString());
                mCrewTimeSheet.setEdited(true);
                setUpUIElements(mCrewTimeSheet);
                new insertTimesheetInDatabaseTask().execute();
            }
        });

        batchUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regularModeDialog.dismiss();
                final Dialog BatchUpdateDialog = new Dialog(MainActivity.this);
                BatchUpdateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE); //before
                BatchUpdateDialog.setContentView(R.layout.batchupdate_dialog);
                TextView cancel = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchcancel);
                final TextView ok = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchok);
                TextView txtbatchactivityname = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchactivityname);
                final EditText etbatchactivity = (EditText) BatchUpdateDialog.findViewById(R.id.txtstandardTime);
                etbatchactivity.requestFocus();
                etbatchactivity.setInputType(InputType.TYPE_CLASS_NUMBER);
                TextView txtaActivityName = (TextView) BatchUpdateDialog.findViewById(R.id.txtbatchactivityname);
                if (mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName() != null) {
                    txtbatchactivityname.setText(mCrewTimeSheet.getCrewActivity().get(finalI).getActivityName());
                } else {
                    txtbatchactivityname.setText("Activity" + finalI);
                }
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BatchUpdateDialog.dismiss();
                    }
                });

                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BatchUpdateDialog.dismiss();
                        if (etbatchactivity.getText().toString().equalsIgnoreCase("") || etbatchactivity.getText().toString().equalsIgnoreCase("null")) {
                            BatchUpdateDialog.dismiss();
                        } else {
                            double batchDialogValue = Double.parseDouble(etbatchactivity.getText().toString());
                            Log.d("Ok", "Clicked");
                            for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                                if (batchDialogValue <= normalTimeFromSettings) {
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(batchDialogValue);
                                } else {
                                    double subtractedValue = (Double.valueOf(etbatchactivity.getText().toString())) - normalTimeFromSettings;
                                    if (subtractedValue <= overTimeFromSettings) {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setOverTime(subtractedValue);
                                    } else {
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setOverTime(Double.valueOf(overTimeFromSettings));
                                        mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(finalI).setDoubleOverTime(batchDialogValue - (normalTimeFromSettings + overTimeFromSettings));
                                    }
                                }
                            }
                            mCrewTimeSheet.setEdited(true);
                            setUpUIElements(mCrewTimeSheet);
                            new insertTimesheetInDatabaseTask().execute();
                        }
                    }
                });

                BatchUpdateDialog.show();
            }
        });
        regularModeDialog.show();
    }


    String clickedPhaseCode, clickedProjectCode, clickedCategoryCode, clickedCompCode, clickedJobCode, clickedPciCode;
    String clickedPhaseName, clickedProjectName, clickedCategoryName;
    ArrayList<JobData> jobDataForPopup;
    ActivityJobListAdapter activityJobListAdapter;
    ArrayList<PhaseModal> phaseModals;
    ActivityPhaseListAdapter activityPhaseListAdapter;
    ActivityCategoryListAdapter activityCategoryListAdapter;
    ActivityPciListAdapter activityPciListAdapter;
    ArrayList<PciModal> pciModals = null;
    DBHelper dbHelper;
    public void AdvancedModePopUp(final String ActivityName, final int ActivityClickedPosition) {
        dbHelper = new DBHelper(this);
        final Dialog activityPopup = new Dialog(MainActivity.this);
        activityPopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        activityPopup.setContentView(R.layout.activity_popup);
        TextView normalHours = (TextView) activityPopup.findViewById(R.id.click);
        final TextView tvJob = (TextView) activityPopup.findViewById(R.id.txtjob);
        final TextView tvPhase = (TextView) activityPopup.findViewById(R.id.txtphase);
        final TextView tvCategory = (TextView) activityPopup.findViewById(R.id.txtcategory);
        final TextView tvPciCode = (TextView) activityPopup.findViewById(R.id.txtpci);
        final ListView listview = (ListView) activityPopup.findViewById(R.id.activity_popup_list_view);
        TextView arrowimgjob = (TextView) activityPopup.findViewById(R.id.activity_popup_imageView0);
        TextView arrowimgphase = (TextView) activityPopup.findViewById(R.id.activity_popup_imageView1);
        TextView arrowimgcategory = (TextView) activityPopup.findViewById(R.id.activity_popup_imageView2);
        TextView arrowimgpci = (TextView) activityPopup.findViewById(R.id.activity_popup_imageView3);
        TextView imgcross = (TextView) activityPopup.findViewById(R.id.activity_popup_imgcross);
        TextView imgbtnback = (TextView) activityPopup.findViewById(R.id.activity_popup_back);
        Button btndone = (Button) activityPopup.findViewById(R.id.activity_popup_done);
        //final ListView listview = (ListView) activityPopup.findViewById(R.id.list_view);
        final EditText etsearch = (EditText) activityPopup.findViewById(R.id.ettxtActivity);
        etsearch.setFocusable(false);
        RelativeLayout relativeJob = (RelativeLayout) activityPopup.findViewById(R.id.rljob);
        RelativeLayout relativePhase = (RelativeLayout) activityPopup.findViewById(R.id.rlphase);
        RelativeLayout relativeCategory = (RelativeLayout) activityPopup.findViewById(R.id.rlcategory);
        RelativeLayout relativePci = (RelativeLayout) activityPopup.findViewById(R.id.rlpci);
        final RelativeLayout r1 = (RelativeLayout) activityPopup.findViewById(R.id.activity_popup_relativeLayout1);
        final RelativeLayout r2 = (RelativeLayout) activityPopup.findViewById(R.id.activity_popup_relativeLayout2);
        tvJob.setText(selectedProjectName);
        tvJob.setTextColor(getResources().getColor(R.color.colorBlack));
        arrowimgjob.setTypeface(typeface);
        arrowimgcategory.setTypeface(typeface);
        arrowimgphase.setTypeface(typeface);
        arrowimgpci.setTypeface(typeface);
        imgcross.setTypeface(typeface);
        imgbtnback.setTypeface(typeface);
        clickedJobCode = selectedProjectCode;
        clickedCompCode = selectedProjectCompCode;
        if (mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName().equals("")) {
            etsearch.setHint(ActivityName);
        } else {
            etsearch.setHint(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName());
        }
        etsearch.setTextColor(Color.rgb(169, 169, 169));
        // imgbtnback.setTypeface(tf);
        normalHours.setTypeface(typeface);
        final int[] currentList = {0};
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (currentList[0]) {
                    case 0:
                        final PhaseModal itemAtPosition0 = (PhaseModal) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        clickedPhaseName = itemAtPosition0.getPhaseName();
                        clickedPhaseCode = itemAtPosition0.getPhaseCode();
                        tvPhase.setText(clickedPhaseCode);
                        tvPhase.setTextColor(getResources().getColor(R.color.colorBlack));
                        break;
                    case 1:
                        final CategoryDetails itemAtPosition1 = (CategoryDetails) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        clickedCategoryName = itemAtPosition1.getCategoryName();
                        clickedCategoryCode = itemAtPosition1.getCategoryCode();
                        tvCategory.setText(clickedCategoryCode);
                        tvCategory.setTextColor(getResources().getColor(R.color.colorBlack));
                        break;
                    case 2:
                        final PciModal itemAtPosition2 = (PciModal) parent.getItemAtPosition(position);
                        clickedPciCode = itemAtPosition2.getPciLineOraseq();
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        tvPciCode.setText(itemAtPosition2.getPciCode());
                        tvPciCode.setTextColor(getResources().getColor(R.color.colorBlack));
                        break;
                    case 3:
                        final JobData itemAtPosition3 = (JobData) parent.getItemAtPosition(position);
                        r2.setVisibility(View.INVISIBLE);
                        r1.setVisibility(View.VISIBLE);
                        tvJob.setText(itemAtPosition3.getJobcode());
                        tvJob.setText("");
                        clickedCompCode = itemAtPosition3.getJobcompcode();
                        clickedJobCode = itemAtPosition3.getJobcode();
                        break;
                }
            }
        });

        if (mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName().equals("null") || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName().equals("")) {
            //  etsearch.setHint(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName());
            etsearch.setText("Activity");

            // etsearch.setText("Activity" + ActivityClickedPosition);
            etsearch.setTextColor(Color.rgb(0, 0, 0));
        } else {
            etsearch.setHint(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName());
            // etsearch.setText(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getActivityName());
        }
        if (mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPciLineOraseq() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPciLineOraseq().equalsIgnoreCase("") ||
                mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPciLineOraseq() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPciLineOraseq().equalsIgnoreCase("null")) {
            tvPciCode.setText("Select Pci");
        } else {

            tvPciCode.setText(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPciLineOraseq());
            tvPciCode.setTextColor(Color.BLACK);
        }
        if (mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPhaseName() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPhaseName().equalsIgnoreCase("null") ||
                mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPhaseCode() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPhaseCode().equalsIgnoreCase("null")) {
            tvPhase.setText("Select Phase");
        } else {
            tvPhase.setText(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getPhaseCode());
            tvPhase.setTextColor(Color.BLACK);
        }

        if (mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getCatCode() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getCatCode().equalsIgnoreCase("null") ||
                mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getCategoryName() == null || mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getCategoryName().equalsIgnoreCase("null")) {
            tvCategory.setText("Select Category");

        } else {
            tvCategory.setText(mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).getCatCode());
            tvCategory.setTextColor(Color.BLACK);
        }


        //search Bar AdvancedModePopUp
        etsearch.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                etsearch.setFocusable(true);
                //EditText etsearch = (EditText) activityPopup.findViewById(R.id.ettxtActivity);
                etsearch.requestFocus();
                etsearch.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(etsearch, InputMethodManager.SHOW_FORCED);
                etsearch.setText("");
                return true;
            }
        });

        etsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etsearch.setFocusable(true);
                //EditText etsearch = (EditText) activityPopup.findViewById(R.id.ettxtActivity);
                etsearch.requestFocus();
                etsearch.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(etsearch, InputMethodManager.SHOW_FORCED);

            }
        });

        etsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etsearch.setFocusableInTouchMode(true);
                etsearch.requestFocus();
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(etsearch, InputMethodManager.SHOW_IMPLICIT);

            }
        });
        etsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //Cross button
        imgcross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activityPopup.dismiss();
            }
        });

        //Back button
        imgbtnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.VISIBLE);
                r2.setVisibility(View.INVISIBLE);
            }
        });
        //normal hours for correesponding activity
        normalHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog normalHoursPopup = new Dialog(MainActivity.this);
                normalHoursPopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
                normalHoursPopup.setContentView(R.layout.normal_hours_popup);
                final EditText etsearch = (EditText) normalHoursPopup.findViewById(R.id.ettxtNormalHours);
                TextView activityName = (TextView) normalHoursPopup.findViewById(R.id.activityname);
                TextView normalHoursOk = (TextView) normalHoursPopup.findViewById(R.id.normalhoursok);
                TextView normalHourscancel = (TextView) normalHoursPopup.findViewById(R.id.normalhourscancel);
                etsearch.setFocusable(false);
                etsearch.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        etsearch.setFocusableInTouchMode(true);
                        etsearch.requestFocus();
                        final InputMethodManager inputMethodManager = (InputMethodManager)
                                getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputMethodManager.showSoftInput(etsearch, InputMethodManager.SHOW_IMPLICIT);
                        return false;
                    }
                });
                activityName.setText(ActivityName);
                normalHoursOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        normalHoursPopup.dismiss();

                        Log.d("Ok", "Clicked");
                        for (int i = 0; i < mCrewTimeSheet.getEmpTimeSheet().size(); i++) {
                            if (Double.valueOf(etsearch.getText().toString()) <= 8) {
                                mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setStandardTime(Double.valueOf(etsearch.getText().toString()));
                                mCrewTimeSheet.setEdited(true);
                            } else {
                                double subtractedValue = (Double.valueOf(etsearch.getText().toString())) - normalTimeFromSettings;
                                if (subtractedValue <= 4) {
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setOverTime(subtractedValue);
                                    mCrewTimeSheet.setEdited(true);
                                } else {
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setStandardTime(Double.valueOf(normalTimeFromSettings));
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setOverTime(Double.valueOf(overTimeFromSettings));
                                    mCrewTimeSheet.getEmpTimeSheet().get(i).getTimeSheet().get(ActivityClickedPosition).setDoubleOverTime(Double.valueOf(etsearch.getText().toString()) - (normalTimeFromSettings + overTimeFromSettings));
                                    mCrewTimeSheet.setEdited(true);
                                }
                            }
                            setUpUIElements(mCrewTimeSheet);
                        }
                        if (mCrewTimeSheet.isEdited())
                            new insertTimesheetInDatabaseTask().execute();
                    }
                });
                normalHourscancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        normalHoursPopup.dismiss();
                    }
                });
                normalHoursPopup.show();
            }
        });
        //Ishan Job cannot be changed in this popup for now
        /*
        relativeJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.GONE);
                r2.setVisibility(View.VISIBLE);
                ProjectListTask projectListTask = new ProjectListTask(MainActivity.this, new ProjectListInterface() {
                    @Override
                    public void ResultFromProjectListWebservice(String result) {
                        progressDialog.dismiss();
                        if (result == null) {
                            Toast.makeText(MainActivity.this, "No Project Associated", Toast.LENGTH_SHORT).show();
                        } else {
                            JobDataParser jobDataParser = new JobDataParser();
                            jobDataForPopup = jobDataParser.parseJobData(result);
                            activityJobListAdapter = new ActivityJobListAdapter(MainActivity.this, jobDataForPopup);
                            listview.setAdapter(activityJobListAdapter);
                            currentList[0] = 3;
                        }
                    }
                    @Override
                    public void BeforeCompleted() {
                        progressDialog = ProgressDialog.show(MainActivity.this, null, "         Fetching Projects ...");
                    }
                });
                projectListTask.execute();

                final EditText editTextSearch = (EditText) activityPopup.findViewById(R.id.searchphase);
                editTextSearch.setText("");
                editTextSearch.setFocusable(false);
                editTextSearch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editTextSearch.setFocusableInTouchMode(true);
                        editTextSearch.requestFocus();
                        final InputMethodManager inputMethodManager = (InputMethodManager)
                                getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputMethodManager.showSoftInput(editTextSearch, InputMethodManager.SHOW_IMPLICIT);

                    }
                });
                editTextSearch.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        s = s.toString().toLowerCase();
                        Log.d("svalue", (String) s);
                        final ArrayList<JobData> filteredList = new ArrayList<>();
                        //  ArrayList<PhaseModal>list = new ArrayList<PhaseModal>();
                        final ArrayList<JobData> jobDetails = jobDataForPopup;
                        // JobDBHelper jobDBHelper = new JobDBHelper(ResultActivity.this);
                        // list = jobDBHelper.selectallSelectedJobs();
                        for (int i = 0; i < jobDetails.size(); i++) {
                            final String txtJobName = jobDetails.get(i).getJobname().toLowerCase();
                            final String txtJobCode = jobDetails.get(i).getJobcode().toLowerCase();
                            if (txtJobName.contains(s) || txtJobCode.contains(s)) {
                                filteredList.add(jobDetails.get(i));
                            }
                        }
                        if (activityJobListAdapter == null) {
                            activityJobListAdapter = new ActivityJobListAdapter(MainActivity.this, filteredList);
                            listview.setAdapter(activityJobListAdapter);
                        } else {
                            activityJobListAdapter.setList(filteredList);
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });


            }
        });
        */

        //Relative Layout GetPhaseTask
        relativePhase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setVisibility(View.GONE);
                r2.setVisibility(View.VISIBLE);
                GetPhaseTask phasewebservice = new GetPhaseTask(getApplicationContext(), clickedCompCode, clickedJobCode, new PhaseInterface() {
                    @Override
                    public void onEnd(String response) {
                        Log.d("Result in phase", response);
                        progressDialog.dismiss();
                        PhaseWithChildParser phaseWithChildParser = new PhaseWithChildParser();
                        phaseModals = phaseWithChildParser.parsePhaseJsonData(response);
                        ActivityPhaseListAdapter activityJobListAdapter = new ActivityPhaseListAdapter(MainActivity.this, phaseModals);
                        listview.setAdapter(activityJobListAdapter);
                        currentList[0] = 0;
                        PhaseWithChildParser phaseWithChildParser1 = new PhaseWithChildParser();
                        ArrayList<PhaseWithChild> category = phaseWithChildParser1.parseCategoryJsonData(response);
                        for (int i = 0; i < category.size(); i++) {
                            dbHelper.insertCategoryDetails(category.get(i).getJcatJobCode(), category.get(i).getJcatCode(), category.get(i).getCatName(), category.get(i).getJcatPhsCode());
                        }
                    }
                    @Override
                    public void Dialog() {
                        progressDialog = ProgressDialog.show(MainActivity.this, null, "         Fetching GetPhaseTask List ...");
                    }

                }, new CategoryInterface() {
                    @Override
                    public void onEndCat(String response) {

                    }
                });
                phasewebservice.execute();
                final EditText editTextSearch = (EditText) activityPopup.findViewById(R.id.searchphase);
                editTextSearch.setText("");
                editTextSearch.setFocusable(false);
                editTextSearch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editTextSearch.setFocusableInTouchMode(true);
                        editTextSearch.requestFocus();
                        final InputMethodManager inputMethodManager = (InputMethodManager)
                                getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputMethodManager.showSoftInput(editTextSearch, InputMethodManager.SHOW_IMPLICIT);
                    }
                });
                editTextSearch.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        s = s.toString().toLowerCase();
                        Log.d("svalue", (String) s);
                        final ArrayList<PhaseModal> filteredList = new ArrayList<>();
                        for (int i = 0; i < phaseModals.size(); i++) {
                            final String txtPhaseName = phaseModals.get(i).getPhaseName().toLowerCase();
                            final String txtPhaseCode = phaseModals.get(i).getPhaseCode().toLowerCase();
                            if (txtPhaseName.contains(s) || txtPhaseCode.contains(s)) {
                                filteredList.add(phaseModals.get(i));
                            }
                        }
                        if (activityPhaseListAdapter == null) {
                            activityPhaseListAdapter = new ActivityPhaseListAdapter(MainActivity.this, filteredList);
                            listview.setAdapter(activityPhaseListAdapter);
                        } else {
                            activityPhaseListAdapter.setList(filteredList);
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });
            }
        });

        //RelativeLayout Category
        relativeCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (tvPhase.getText().equals("Select Phase")) {
                    Toast toast = Toast.makeText(getApplicationContext(), "    Please select phase    ", Toast.LENGTH_LONG);
                    View toastView = toast.getView();
                    toastView.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.toast_background));
                    toast.show();
                } else {

                    r1.setVisibility(View.GONE);
                    r2.setVisibility(View.VISIBLE);
                    final ArrayList<CategoryDetails> CategoryDetails = dbHelper.selectCategoryNameOnBasisOfJocCodeAndPhaseCode(selectedProjectCode, clickedPhaseCode);
                    activityCategoryListAdapter = new ActivityCategoryListAdapter(MainActivity.this, CategoryDetails);

                    listview.setAdapter(activityCategoryListAdapter);

                    listview.post(new Runnable() {
                        @Override
                        public void run() {
                            listview.setAdapter(activityCategoryListAdapter);
                        }
                    });
                    currentList[0] = 1;
                    final EditText editTextSearch = (EditText) activityPopup.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
                    editTextSearch.setFocusable(false);
                    editTextSearch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            editTextSearch.setFocusableInTouchMode(true);
                            editTextSearch.requestFocus();
                            final InputMethodManager inputMethodManager = (InputMethodManager)
                                    getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            inputMethodManager.showSoftInput(editTextSearch, InputMethodManager.SHOW_IMPLICIT);
                        }
                    });
//                    final EditText editTextSearch = (EditText) activityPopup.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
                    editTextSearch.setFocusable(false);
                    editTextSearch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            editTextSearch.setFocusableInTouchMode(true);
                            editTextSearch.requestFocus();
                            final InputMethodManager inputMethodManager = (InputMethodManager)
                                    getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            inputMethodManager.showSoftInput(editTextSearch, InputMethodManager.SHOW_IMPLICIT);
                        }
                    });
                    editTextSearch.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            s = s.toString().toLowerCase();
                            Log.d("svalue", (String) s);
                            final ArrayList<CategoryDetails> filteredList = new ArrayList<>();
                            final ArrayList<CategoryDetails> catDetails = CategoryDetails;
                            for (int i = 0; i < catDetails.size(); i++) {
                                final String txtCategoryName = catDetails.get(i).getCategoryName().toLowerCase();
                                final String txtCategoryCode = catDetails.get(i).getCategoryCode().toLowerCase();
                                if (txtCategoryName.contains(s) || txtCategoryCode.contains(s)) {
                                    filteredList.add(catDetails.get(i));
                                }
                            }
                            if (activityCategoryListAdapter == null) {
                                activityCategoryListAdapter = new ActivityCategoryListAdapter(MainActivity.this, filteredList);
                                listview.setAdapter(activityCategoryListAdapter);
                            } else {
                                activityCategoryListAdapter.setList(filteredList);
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                        }
                    });
                }
            }
        });

        relativePci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickedPhaseCode == null || clickedCategoryCode == null) {
                    Toast toast = Toast.makeText(getApplicationContext(), "    Please Select PhaseCode and CategoryCode First  ", Toast.LENGTH_LONG);
                    View toastView = toast.getView();
                    toastView.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.toast_background));
                    toast.show();
                } else {
                    r1.setVisibility(View.GONE);
                    r2.setVisibility(View.VISIBLE);

                    PciTask pciTask = new PciTask(getApplicationContext(), clickedPhaseCode, clickedCategoryCode, selectedProjectCode,
                            clickedCompCode, new PciInterface() {

                        @Override
                        public ArrayList<PciModal> ResultFromPciWebservice(String result) {

                            if (result == null) {
                                Toast.makeText(MainActivity.this, "No Pci Assoiated", Toast.LENGTH_SHORT).show();
                            } else {
                                progressDialog.dismiss();
                                PciParser pciParser = new PciParser();
                                pciModals = pciParser.pciDataParser(result);
                                activityPciListAdapter = new ActivityPciListAdapter(MainActivity.this, pciModals);
                                listview.setAdapter(activityPciListAdapter);
                                currentList[0] = 2;
                            }
                            return pciModals;
                        }

                        @Override
                        public void BeforeCompleted() {
                            progressDialog = ProgressDialog.show(MainActivity.this, null, "         Fetching Pci Data...");
                        }
                    });
                    pciTask.execute();
                    final EditText editTextSearch = (EditText) activityPopup.findViewById(R.id.searchphase);
                    editTextSearch.setText("");
                    editTextSearch.setFocusable(false);
                    editTextSearch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            editTextSearch.setFocusableInTouchMode(true);
                            editTextSearch.requestFocus();
                            final InputMethodManager inputMethodManager = (InputMethodManager)
                                    getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            inputMethodManager.showSoftInput(editTextSearch, InputMethodManager.SHOW_IMPLICIT);
                        }
                    });
                    editTextSearch.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            s = s.toString().toLowerCase();
                            Log.d("svalue", (String) s);
                            final ArrayList<PciModal> filteredList = new ArrayList<>();
                            for (int i = 0; i < pciModals.size(); i++) {
                                final String txtPciName = pciModals.get(i).getPciCode().toLowerCase();
                                final String txtPciCode = pciModals.get(i).getPciName().toLowerCase();
                                if (txtPciName.contains(s) || txtPciCode.contains(s)) {
                                    filteredList.add(pciModals.get(i));
                                }
                            }
                            if (activityPciListAdapter == null) {
                                activityPciListAdapter = new ActivityPciListAdapter(MainActivity.this, filteredList);
                                listview.setAdapter(activityPhaseListAdapter);
                            } else {
                                activityPciListAdapter.setList(filteredList);
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                        }
                    });
                }
            }
        });

        btndone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etsearch.getText().toString().equals("")) {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setActivityName("Activity" + ActivityClickedPosition);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setActivityName(etsearch.getText().toString());
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (selectedProjectName == null || selectedProjectName.equalsIgnoreCase("null") || selectedProjectName.equals("")) {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setJobName("");
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setJobName(selectedProjectName);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (clickedPhaseName == null || clickedPhaseName.equalsIgnoreCase("null") || clickedPhaseName.equals("")) {
                    tvPhase.setText("Select Phase");
                    // mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setPhaseName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setPhaseName(clickedPhaseName);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (clickedCategoryName == null || clickedCategoryName.equalsIgnoreCase("null") || clickedCategoryName.equals("")) {
                    tvCategory.setText("Select Category");
                    // mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setCategoryName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setCategoryName(clickedCategoryName);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }

                if (clickedCategoryCode == null || clickedCategoryCode.equalsIgnoreCase("null") || clickedCategoryCode.equals("")) {
                    tvCategory.setText("Select Category");
                    //mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setCatCode("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setCatCode(clickedCategoryCode);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (clickedPhaseCode == null || clickedPhaseCode.equalsIgnoreCase("null") || clickedPhaseCode.equals("")) {
                    tvPhase.setText("Select Phase");
                    //    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setPhaseCode("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setPhaseCode(clickedPhaseCode);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (ActivityName == null || ActivityName.equalsIgnoreCase("null") || ActivityName.equals("")) {
                    tvPhase.setText("Select Phase");
                    // mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setActivityName("");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setActivityName(ActivityName);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                if (clickedPciCode == null || clickedPciCode.equals("")) {
                    tvPciCode.setText("Select Phase");
                } else {
                    mCrewTimeSheet.getCrewActivity().get(ActivityClickedPosition).setPciLineOraseq(clickedPciCode);
                    mCrewTimeSheet.setEdited(true);
                    new insertTimesheetInDatabaseTask().execute();
                }
                setUpUIElements(mCrewTimeSheet);
                activityPopup.dismiss();
            }
        });
        activityPopup.show();
    }

    private void makeAlertErrorOccurred(){
        final AlertDialog.Builder alertBox = new AlertDialog.Builder(MainActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        alertBox.setMessage("Some Error Occurred. Please Try Again.");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }
    ProgressDialog tempDialog;
    public class insertTimesheetInDatabaseTask extends AsyncTask<Void,Void,Void>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            tempDialog = ProgressDialog.show(MainActivity.this,null,"        Inserting TimeSheet in Database");
        }
        @Override
        protected Void doInBackground(Void... params) {
            mDbInstance.insertTimeSheetInDatabase(mCrewTimeSheet);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            tempDialog.dismiss();
        }
    }
    private insertTimesheetInDatabaseTask insertTimesheetInDatabaseTask = new insertTimesheetInDatabaseTask();

}