package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by parneet.singh on 1/4/2018.
 */

/**
 * Created by parneet.singh on 9/14/2016.
 */
public class PciModal
{
    private String PciCompCode = null;
    private String PciJobCode = null;
    private String PciPhsCode = null;
    private String PciCatCode = null;
    private String PciCode = null;
    private String PciName = null;
    private String PciBudgetAmt = null;
    private String PciLineOraseq = null;


    public PciModal(String PciCompCode,String PciJobCode ,String PciPhsCode, String PciCatCode,
                    String PciCode,String PciName ,String PciBudgetAmt, String PciLineOraseq  )
    {
        this.PciCompCode = PciCompCode;
        this.PciJobCode = PciJobCode;
        this.PciPhsCode = PciPhsCode;
        this.PciCatCode = PciCatCode;
        this.PciCode = PciCode;
        this.PciName = PciName;
        this.PciBudgetAmt = PciBudgetAmt;
        this.PciLineOraseq = PciLineOraseq;
    }

    public String getPciBudgetAmt() {
        return PciBudgetAmt;
    }

    public String getPciCatCode() {
        return PciCatCode;
    }

    public String getPciCode() {
        return PciCode;
    }

    public String getPciCompCode() {
        return PciCompCode;
    }

    public String getPciJobCode() {
        return PciJobCode;
    }

    public String getPciLineOraseq() {
        return PciLineOraseq;
    }

    public String getPciName() {
        return PciName;
    }

    public String getPciPhsCode() {
        return PciPhsCode;
    }

    public void setPciBudgetAmt(String pciBudgetAmt) {
        PciBudgetAmt = pciBudgetAmt;
    }

    public void setPciCatCode(String pciCatCode) {
        PciCatCode = pciCatCode;
    }

    public void setPciCode(String pciCode) {
        PciCode = pciCode;
    }

    public void setPciCompCode(String pciCompCode) {
        PciCompCode = pciCompCode;
    }

    public void setPciJobCode(String pciJobCode) {
        PciJobCode = pciJobCode;
    }

    public void setPciLineOraseq(String pciLineOraseq) {
        PciLineOraseq = pciLineOraseq;
    }

    public void setPciName(String pciName) {
        PciName = pciName;
    }

    public void setPciPhsCode(String pciPhsCode) {
        PciPhsCode = pciPhsCode;
    }
}

