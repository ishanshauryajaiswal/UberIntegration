package com.example.ishanjaiswal.cmicresultactivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

//import com.bugsee.library.Bugsee;
import com.example.ishanjaiswal.cmicresultactivity.Database.IshanDBHelper;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    EditText txtUsername;
    EditText txtPassword;
    Button btnSubmit;
    Button btnOffline;
    ImageButton btnVision;
    ImageView ivSettings;
    String username, password, authEncoded = "";
    ProgressDialog progress;
    SharedPreferences ishanSharedPreferences, defaultSharedPreferences;
    SharedPreferences.Editor ishanSharedPrefeEditor, defaultSharedPrefEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar mTopToolbar = (Toolbar) findViewById(R.id.tb_login);
        setSupportActionBar(mTopToolbar);
        initSharedPreference();
        initViews();
        ifAutoLoginEnabled();
    }

    private void initSharedPreference() {
        defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        defaultSharedPrefEditor = defaultSharedPreferences.edit();
        ishanSharedPreferences = getSharedPreferences(getString(R.string.cmic_shared_preference),MODE_PRIVATE);
        ishanSharedPrefeEditor = ishanSharedPreferences.edit();
    }

    private void ifAutoLoginEnabled(){
        if (defaultSharedPreferences.getBoolean(getString(R.string.settings_key_switch_auto_login),false)){
            username = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_username),"");
            password = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_password),"");
            new AuthenticateTask().execute();
        }
    }

    private void initViews() {
        username = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_username),"");
        txtUsername = (EditText)findViewById(R.id.txtUserName);
        txtUsername.setText(username);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        btnVision = (ImageButton)findViewById(R.id.btnvision);
        btnSubmit = (Button)findViewById(R.id.btnlogin);
        btnOffline = (Button)findViewById(R.id.btnoffline);
        ivSettings = (ImageView)findViewById(R.id.iv_settings_login);
        txtUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                txtUsername.setFocusable(true);
                final InputMethodManager inputMethodManager = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(txtUsername, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                username = txtUsername.getText().toString().trim();
                password = txtPassword.getText().toString().trim();
                new AuthenticateTask().execute();
            }
        });
        btnVision.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                        break;
                    case MotionEvent.ACTION_UP:
                        txtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        break;
                }
                return true;
            }
        });
        btnOffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(LoginActivity.this, "Under Development",Toast.LENGTH_SHORT).show();
            }
        });
        ivSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,SettingsActivity.class));
            }
        });

    }

    public class AuthenticateTask extends AsyncTask<Void, Void, String>
    {

        @Override
        protected void onPreExecute()
        {
            progress=ProgressDialog.show(LoginActivity.this,null,"      Authenticating...");
            super.onPreExecute();

        }
        String auth = "";
        @Override
        protected String doInBackground(Void... params)
        {
            String response="";
            try
            {
                auth = username + ":" + password;
                authEncoded = new String(Base64.encode(auth.getBytes("UTF-8"), Base64.NO_WRAP));
                RequestCall requestCall = new RequestCall(getApplicationContext());
                response = requestCall.requestAuthenticate(getApplicationContext(),authEncoded);
            }
            catch (Exception e)
            {
                return null;
            }
            return response;
        }

        @Override
        protected void onPostExecute(String response)
        {

            super.onPostExecute(response);
            progress.dismiss();
            if (response!=null && !CollectionUtils.reverseHashMapStatusCodes.containsKey(response)) {
                checkPreviousUser();
                ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_username), username);
                ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_password), password);
                ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_authcode), authEncoded);
                ishanSharedPrefeEditor.commit();
                LoginParser loginParser = new LoginParser();
                ArrayList<LoginModal> arrayList = loginParser.parseLoginData(response);
                for (int i = 0; i < arrayList.size(); i++)
                {
                    String hrtTradeName = arrayList.get(i).getHrtTrdName();
                    String hrtName = arrayList.get(i).getHrtFirstName() + arrayList.get(i).getHrtLastName();
                    ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_hrt_trade_name), hrtTradeName);
                    ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_hrt_name), hrtName);
                    ishanSharedPrefeEditor.commit();
                }
                Intent intent = new Intent(LoginActivity.this, CrewListActivity.class);
                startActivity(intent);
            }
            else {
                if (response!=null)
                    makeAlertErrorOccurred(response);
                else
                    makeAlertErrorOccurred("Login Failed");
            }
        }
    }
    @Override
    public void onBackPressed()
    {
        finish();
        super.onBackPressed();
    }


    public void clearLocalStorage(){
        IshanDBHelper dbHelper = IshanDBHelper.getInstance(getApplicationContext());
        dbHelper.deleteLocalDatabase();

        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_crew_code),getString(R.string.cmic_shared_preference_no_crew_code));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_crew_name),getString(R.string.cmic_shared_preference_no_crew_name));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_responsible_person),getString(R.string.cmic_shared_preference_no_responsible_person));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_crew_ora_seq),getString(R.string.cmic_shared_preference_no_crew_oraseq));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_project_name),getString(R.string.cmic_shared_preference_no_project_name));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_project_code),getString(R.string.cmic_shared_preference_no_project_code));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_project_comp_code),getString(R.string.cmic_shared_preference_project_comp_code));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_hrt_name),getString(R.string.cmic_shared_preference_no_hrt_name));
        ishanSharedPrefeEditor.putString(getString(R.string.cmic_shared_preference_hrt_trade_name),getString(R.string.cmic_shared_preference_no_hrt_trade_name));
        ishanSharedPrefeEditor.commit();

    }

    private void checkPreviousUser(){
        defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        defaultSharedPrefEditor = defaultSharedPreferences.edit();
        String previousServer = defaultSharedPreferences.getString(getString(R.string.previous_key_server),null);
        String currentServer = defaultSharedPreferences.getString(getString(R.string.settings_key_server),getString(R.string.settings_server_default));
                //.concat(sp.getString(getString(R.string.settings_key_environment),getString(R.string.settings_environment_default)));
        String previousAuth = ishanSharedPreferences.getString(getString(R.string.cmic_shared_preference_authcode),"");
        if (previousServer==null)
            defaultSharedPrefEditor.putString(getString(R.string.previous_key_server),currentServer).commit();

        else if(!previousServer.equalsIgnoreCase(currentServer)) {
            defaultSharedPrefEditor.putString(getString(R.string.previous_key_server),currentServer).commit();
            clearLocalStorage();
        }
        else if (!authEncoded.equalsIgnoreCase(previousAuth))
            clearLocalStorage();
    }

    private void makeAlertErrorOccurred(String errorMessage){
        final AlertDialog.Builder alertBox = new AlertDialog.Builder(LoginActivity.this);
        alertBox.setTitle("CMiC Mobile Crew Time");
        if (errorMessage!=null)
            alertBox.setMessage(errorMessage);
        else
            alertBox.setMessage("Some Error Occurred");
        alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
            }
        });
        alertBox.show();
    }

        /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.login_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_login:
                startActivity(new Intent(LoginActivity.this,SettingsActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }*/
}