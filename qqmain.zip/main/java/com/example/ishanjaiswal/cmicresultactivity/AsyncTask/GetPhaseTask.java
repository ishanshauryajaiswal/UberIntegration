package com.example.ishanjaiswal.cmicresultactivity.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.CategoryTaskListener;
import com.example.ishanjaiswal.cmicresultactivity.Interfaces.listener.PhaseInterface;
import com.example.ishanjaiswal.cmicresultactivity.RequestCall;


public class GetPhaseTask extends AsyncTask<Void, Void, String> {


    String jobcode, compcode;
    Context context;
    PhaseInterface phaseInterface;
    CategoryTaskListener categoryTaskListener;

    public GetPhaseTask(Context context, String compcode, String jobcode, PhaseInterface phaseInterface, CategoryTaskListener categoryTaskListener) {
        this.context = context;
        this.jobcode = jobcode;
        this.compcode = compcode;
        this.phaseInterface = phaseInterface;
        this.categoryTaskListener = categoryTaskListener;
    }

    public GetPhaseTask(Context context, String authEncode, String compcode, String jobcode) {
        this.context = context;
        this.compcode = compcode;
        this.jobcode = jobcode;
    }

    @Override
    protected void onPreExecute()
    {
        if (!isCancelled())
            phaseInterface.onTaskStarted();
    }

    @Override
    protected String doInBackground(Void... params) {
        String response = null;
        if (!isCancelled()) {
            try {
                RequestCall requestCall = new RequestCall(context);
                response = requestCall.phaseWithChild(context, compcode, jobcode);
                return response;
            } catch (Exception e) {
                return null;
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String response) {

        super.onPostExecute(response);

        if (response == null) {
            if (phaseInterface != null) {
                phaseInterface.onTaskComplete(null);
            }
            if (categoryTaskListener != null) {
                categoryTaskListener.onEndCat(null);
            }
        } else
        {
            phaseInterface.onTaskComplete(response);
            categoryTaskListener.onEndCat(response);
        }
    }
}
