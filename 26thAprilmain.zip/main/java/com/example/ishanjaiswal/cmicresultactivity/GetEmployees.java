package com.example.ishanjaiswal.cmicresultactivity;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;


/**
  Created by parneet.singh on 10/20/2016.
 */
public class GetEmployees extends AsyncTask<Void,Void,String>
{
    private Context context;
    private CrewMemberDataListener employeeListener;
    public GetEmployees(Context context, CrewMemberDataListener employeeListener){
        this.employeeListener=employeeListener;
        this.context=context;
    }

    @Override
    protected void onPreExecute()
    {
       employeeListener.onCrewMemberDataTaskStarted();
    }
    @Override
    protected String doInBackground(Void... params) {
        String response = "";
        try
        {
            RequestCall requestCall = new RequestCall();
            response = requestCall.getAllEmployees(context);
        }
        catch (Exception e)
        {
            Log.d("error1234567", e.toString());
        }
        return response;
    }
    @Override
    protected void onPostExecute(String result)
    {
        employeeListener.onCrewMemberDataTaskCompleted(result);
    }
}
