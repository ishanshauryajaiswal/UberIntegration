package com.example.ishanjaiswal.cmicresultactivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ishanjaiswal.cmicresultactivity.Interfaces.FragmentClickListener;
import com.example.ishanjaiswal.cmicresultactivity.Utils.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * Created by ishan.jaiswal on 4/25/2018.
 */

public class FragmentThree extends Fragment {

    private RelativeLayout rlBack;
    private RecyclerView rvStatic, rvDynamic;
    private TextView tvRegTotal, tvOtTotal,tvDotTotal;
    private TextView tvJob, tvCrew, tvWeek;
    private RvDynamicAdapterDashboard2 rvDynamicAdapter;
    private RvStaticAdapterDashboard2 rvStaticAdapter;
    private String mCrewCode, mDate, firstDayOfWeek;
    private TextView headerViews[];
    private LinearLayout footerViews[];
    private FragmentClickListener mListener;
    private String mJobCode, mJobCompCode;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getValuesFromSharedPreference();
        Bundle bundle = getArguments();
        mDate = bundle.getString(getString(R.string.cmic_fragment_extras_date_from_dashboard));
        mJobCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_code_from_dashboard));
        mJobCompCode = bundle.getString(getString(R.string.cmic_fragment_extras_job_comp_code_from_dashboard));
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_three,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view){
        rlBack = (RelativeLayout)view.findViewById(R.id.rl_heading_dashboard2);
        TextView tvBack = (TextView)view.findViewById(R.id.tv_back_dashboard2);
        tvBack.setText("Back");

        rlBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onBackPressed();
            }
        });
    }
    private void setUpToolbar(){
        int year = Integer.parseInt(mDate.split("\\-")[0]);
        int month = Integer.parseInt(mDate.split("\\-")[1]);
        int day = Integer.parseInt(mDate.split("\\-")[2]);
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day);
        cal.add(Calendar.DAY_OF_WEEK, -6);
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = sdfDate.format(cal.getTime());
        tvWeek.setText(mDate+" TO "+startDate);
    }
    private void setUpHeader(){
        List<String> week = CollectionUtils.getWeek(firstDayOfWeek);
        for (int i=0;i<headerViews.length;i++)
            headerViews[i].setText(week.get(i));
    }
    void getValuesFromSharedPreference(){
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        firstDayOfWeek = defaultSharedPreferences.getString(getString(R.string.settings_key_start_day),getString(R.string.settings_start_day_default));
    }

    public static FragmentThree getInstance(Bundle bundle){
        FragmentThree fragmentThree = new FragmentThree();
        fragmentThree.setArguments(bundle);
        return fragmentThree;
    }
}
