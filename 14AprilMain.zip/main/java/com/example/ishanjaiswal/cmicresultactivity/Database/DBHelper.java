package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.example.ishanjaiswal.cmicresultactivity.Model.AllEmployeesModel;
import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.CategoryDetails;
import com.example.ishanjaiswal.cmicresultactivity.Model.PhaseModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper

{
    SQLiteDatabase db;
    Context context;
    static DatabaseConstants databaseCostants = new DatabaseConstants();
    // private static final String CREATE_TABLE_SelectedJobs = "CREATE TABLE "+databaseCostants.TABLE_SELECTED_JOBS + "(" + databaseCostants.jobcode + " INTEGER,PRIMARY KEY" + databaseCostants.jobcompcode + " INTEGER,"+databaseCostants.jobname+"TEXT )";
    // private static final String CREATE_TABLE_Category = "CREATE TABLE IF NOT EXISTS"+databaseCostants.TABLE_CATEGORY+ "(" + databaseCostants.categoryjobcode + " TEXT FOREIGN KEY REFERENCES "+databaseCostants.TABLE_SELECTED_JOBS+" ("+databaseCostants.jobcode+")," + databaseCostants.categorycode + " INTEGER,"+databaseCostants.categoryname+"TEXT,"+databaseCostants.categoryphasecode+"TEXT FOREIGN KEY REFERENCES"+databaseCostants.TABLE_SELECTED_JOBS+ "("+databaseCostants.phasecode+ ")";
    //   private static final String CREATE_TABLE_Phase = "CREATE TABLE IF NOT EXISTS "+databaseCostants.TABLE_PHASE+"("+databaseCostants.phasecompcode+" TEXT, "+databaseCostants.phasecode + " TEXT, "+databaseCostants.jobcompcode+ " TEXT, "+databaseCostants.jobcode+ " TEXT)";
    private static final String CREATE_TABLE_User = "CREATE TABLE IF NOT EXISTS  " + databaseCostants.TABLE_USER + "(" + databaseCostants.Username + " TEXT PRIMARY KEY," + databaseCostants.Password + " TEXT )";
    private static final String CREATE_TABLE_SelectedJobs = "CREATE TABLE IF NOT EXISTS  " + databaseCostants.TABLE_SELECTED_JOBS + "(" + databaseCostants.jobcode + " TEXT PRIMARY KEY , " + databaseCostants.jobcompcode + " TEXT, " + databaseCostants.jobname + " TEXT )";
    private static final String CREATE_TABLE_Employee = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_EMPLOYEE + "(" + databaseCostants.empname + " TEXT ," + databaseCostants.empcode + " TEXT," + databaseCostants.pkey + " TEXT PRIMARY KEY , " + databaseCostants.empusername + " TEXT)";
    private static final String CREATE_TABLE_Category = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_CATEGORY + "(" + databaseCostants.categoryjobcode + " TEXT ," + databaseCostants.categorycode + " TEXT," + databaseCostants.categoryname + " TEXT," + databaseCostants.categoryphasecode + " TEXT, PRIMARY KEY ( " + databaseCostants.categoryphasecode + " , " + databaseCostants.categorycode + " ) , FOREIGN KEY(" + databaseCostants.categoryphasecode + ") REFERENCES " + databaseCostants.TABLE_PHASE + "(" + databaseCostants.phasecode + "), FOREIGN KEY(" + databaseCostants.categoryjobcode + ") REFERENCES " + databaseCostants.TABLE_SELECTED_JOBS + "(" + databaseCostants.jobcode + "))";
    private static final String CREATE_TABLE_CrewDetails = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_CREW_DETAILS + "(" + databaseCostants.crewname + " TEXT," + databaseCostants.crewcode + " TEXT, " + databaseCostants.creworaseq + " TEXT PRIMARY KEY)";
    private static final String CREATE_TABLE_EMPLOYEE_LINKING_CREW = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_EMPLOYEE_LINKING_CREW + "(" + databaseCostants.pycecreworaseq + " TEXT ," + databaseCostants.pycecrewcode + " TEXT , " + databaseCostants.pycecrewname + " TEXT, " + databaseCostants.pyceemporaseq + " TEXT PRIMARY KEY, " + databaseCostants.pyceempno + " TEXT, " + databaseCostants.pyceoraseq + " TEXT, " + databaseCostants.pyceempname + " TEXT, " + databaseCostants.pycetrdcode +" TEXT, " + databaseCostants.pycetrdname + " TEXT ) ";
    private static final String CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES = "CREATE TABLE IF NOT EXISTS " + databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES + "(" + databaseCostants.pyelEmpNumber + " TEXT, " + databaseCostants.pyelEmpOraseq + " TEXT, " + databaseCostants.pyelEmpName + " TEXT, " + databaseCostants.pyelAccessCode + " TEXT, " + databaseCostants.pyelCompName + " TEXT, " + databaseCostants.pyelPrnCode + " TEXT, " + databaseCostants.pyelPrnName + " TEXT, " + databaseCostants.pyelCompCode +" TEXT, " + databaseCostants.pyelTrdCode + " TEXT, " + databaseCostants.pyelTrdName + " TEXT, " + databaseCostants.pyelUniCode + " TEXT, " + databaseCostants.pyelUniName + " TEXT)";
    private static final String DROP_TABLE_INSERTING_SELECTED_EMPLOYEES= "DROP TABLE IF EXISTS " + databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES;
    private static final String CREATE_TABLE_Phase = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_PHASE + "(" + databaseCostants.phasejobcode + " TEXT, " + databaseCostants.phasecode + " TEXT PRIMARY KEY, " + databaseCostants.phasename + " TEXT, " + databaseCostants.phasecompcode + " TEXT)";
    private static final String DROP_TABLE_PHASE = "DROP TABLE IF EXISTS " + databaseCostants.TABLE_PHASE;
    private static final String DROP_TABLE_CATEGORY = "DROP TABLE IF EXISTS " + databaseCostants.TABLE_CATEGORY;
    private static final String CREATE_TABLE_SubmittedTimeCrew = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.crewcode + " TEXT, " + databaseCostants.seqNumber + " TEXT, " + databaseCostants.workDate + " TEXT, " + databaseCostants.jobcode + " TEXT )";
    private static final String CREATE_TABLE_EmployeeDataForCrew = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_EMPLOYEE_DATA_FOR_CREW + "(" + databaseCostants.employeeNumber + " TEXT , " + databaseCostants.rowNumber + " TEXT, " + databaseCostants.deleteFlag + " TEXT, " + databaseCostants.workDate + " TEXT," + databaseCostants.crewcode + " TEXT, FOREIGN KEY(" + databaseCostants.workDate + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.workDate + "),FOREIGN KEY(" + databaseCostants.crewcode + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.crewcode + "))";
    private static final String CREATE_TABLE_SubmittedActivityFromCrew = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_SUBMITTED_ACTIVITY_FROM_CREW + "(" + databaseCostants.WBSCode + " TEXT, " + databaseCostants.columnNumber + " TEXT, " + databaseCostants.phasecode + " TEXT, " + databaseCostants.seqNumber + " TEXT, " + databaseCostants.activityName + " TEXT, " + databaseCostants.deleteFlag + " TEXT, " + databaseCostants.categorycode + " TEXT, " + databaseCostants.PcilineOraseq + " YEXT, " + databaseCostants.crewcode + " TEXT," + databaseCostants.workDate + " TEXT,FOREIGN KEY(" + databaseCostants.workDate + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.workDate + "),FOREIGN KEY(" + databaseCostants.crewcode + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.crewcode + ") )";
    private static final String CREATE_TABLE_ActivityTimeForCrew = "CREATE TABLE IF NOT EXISTS " + databaseCostants.TABLE_ACTIVITY_TIME_FOR_CREW + "(" + databaseCostants.otseqNumber + " TEXT, " + databaseCostants.dothour + " TEXT, " + databaseCostants.rtSeqNumber + " TEXT, " + databaseCostants.rtHours + " TEXT," + databaseCostants.dotSeqNumber + " TEXT, " + databaseCostants.otHour + " TEXT, " + databaseCostants.crewcode + " TEXT ," + databaseCostants.workDate + " TEXT, " + databaseCostants.employeeNumber + " TEXT, FOREIGN KEY(" + databaseCostants.employeeNumber + ") REFERENCES " + databaseCostants.TABLE_EMPLOYEE_DATA_FOR_CREW + "(" + databaseCostants.employeeNumber + "), FOREIGN KEY(" + databaseCostants.workDate + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.workDate + "),FOREIGN KEY(" + databaseCostants.crewcode + ") REFERENCES " + databaseCostants.TABLE_SUBMITTED_TIME_CREW + "(" + databaseCostants.crewcode + "))";
    private static final String TABLE_CREW_LIST = "CREATE TABLE IF NOT EXISTS  " + databaseCostants.TABLE_CREW_LIST + "(" + databaseCostants.PycrCode + " TEXT , " + databaseCostants.PycrName + " TEXT, " + databaseCostants.PycrOraseq + " TEXT )";



    //Retrieve Timesheet Table

    private static final String TABLE_SUBMITTED_TIMESHEET = "CREATE TABLE IF NOT EXISTS  "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + "(" + DatabaseConstants.CrewCode_SubmittedTimesheet + " TEXT , "
            + DatabaseConstants.JobCode_SubmittedTimesheet + " TEXT, "
            + DatabaseConstants.SeqNo_SubmittedTimesheet + " TEXT, "
            + DatabaseConstants.WorkDate_SubmittedTimesheet + " TEXT , PRIMARY KEY ("
            + DatabaseConstants.CrewCode_SubmittedTimesheet + " , "
            + DatabaseConstants.JobCode_SubmittedTimesheet + " , "
            + DatabaseConstants.WorkDate_SubmittedTimesheet + " ))";


    private static final String TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET = " CREATE TABLE IF NOT EXISTS  "
            + DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET + " ( " + DatabaseConstants.ActivityName_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.CategoryCode_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.ColoumnNumber_SubmittedaActivityForTimeSheet + " INTEGER  PRIMARY KEY AUTOINCREMENT , "
            + DatabaseConstants.CrewCode_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.JobCode_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.PciLineOraseq_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.PhaseCode_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.SeqNumber_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.WbsCode_SubmittedaActivityForTimeSheet + " TEXT , "
            + DatabaseConstants.WorkDate_SubmittedaActivityForTimeSheet +" TEXT , FOREIGN KEY ( "
            + DatabaseConstants.CrewCode_SubmittedaActivityForTimeSheet + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( "
            + DatabaseConstants.CrewCode_SubmittedTimesheet + " ) , FOREIGN KEY ( "
            + DatabaseConstants.JobCode_SubmittedaActivityForTimeSheet + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( "
            + DatabaseConstants.JobCode_SubmittedTimesheet + " ) ,  FOREIGN KEY ( "
            + DatabaseConstants.WorkDate_SubmittedaActivityForTimeSheet + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( "
            + DatabaseConstants.WorkDate_SubmittedTimesheet + " ))";


    private static final String TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW = "CREATE TABLE IF NOT EXISTS  "
            + DatabaseConstants.TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW + "(" + DatabaseConstants.CrewCode_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.EmployeeName_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.EmployeeOraseq_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.EmployeeTradeCode_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.EmployeeTradeName_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.JobCode_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.RowNumber_SubmittedEmployeeDataForCrew + " TEXT , "
            + DatabaseConstants.WorkDate_SubmittedEmployeeDataForCrew + " TEXT , PRIMARY KEY ( "
            + DatabaseConstants.CrewCode_SubmittedTimesheet + " , "
            + DatabaseConstants.JobCode_SubmittedTimesheet + " , "
            + DatabaseConstants.WorkDate_SubmittedTimesheet + " , "
            + DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew + " ) , FOREIGN KEY ( "
            + DatabaseConstants.CrewCode_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.CrewCode_SubmittedTimesheet + " ) , FOREIGN KEY ( "
            + DatabaseConstants.JobCode_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.JobCode_SubmittedTimesheet + " ) ,  FOREIGN KEY ( "
            + DatabaseConstants.WorkDate_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.WorkDate_SubmittedTimesheet + " ))";


    private static final String TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE = "CREATE TABLE IF NOT EXISTS  "
            + DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE + "(" + DatabaseConstants.ActivityName_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.ColoumnNumber_SubmittedActivityTimeForEmployee + " INTEGER PRIMARY KEY AUTOINCREMENT , "
            + DatabaseConstants.Dothours_SubmittedActivityTimeForEmployee + " REAL , "
            + DatabaseConstants.DotSeqNumber_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.EmployeeNumber_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.OtHours_SubmittedActivityTimeForEmployee + " REAL , "
            + DatabaseConstants.OtSeqNumber_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.RtHours_SubmittedActivityTimeForEmployee + " REAL , "
            + DatabaseConstants.RtSeqNumber_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.CrewCode_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.JobCode_SubmittedActivityTimeForEmployee + " TEXT , "
            + DatabaseConstants.WorkDate_SubmittedActivityTimeForEmployee + " TEXT , FOREIGN KEY ( "
            + DatabaseConstants.CrewCode_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.CrewCode_SubmittedEmployeeDataForCrew + " ) , FOREIGN KEY ( "
            + DatabaseConstants.JobCode_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.JobCode_SubmittedEmployeeDataForCrew + " ) , FOREIGN KEY ( "
            + DatabaseConstants.WorkDate_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET + " ( " + DatabaseConstants.WorkDate_SubmittedEmployeeDataForCrew + " ) , FOREIGN KEY ( "
            + DatabaseConstants.EmployeeNumber_SubmittedActivityTimeForEmployee + " ) REFERENCES "
            + DatabaseConstants.TABLE_EMPLOYEE_DATA_FOR_CREW + " ( " + DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew + " ))";



    private static final String TABLE_SUBMITTED_TIME_IN_OUT = "CREATE TABLE IF NOT EXISTS  "
            + DatabaseConstants.TABLE_SUBMITTED_TIME_IN_OUT + "("
            + DatabaseConstants.CrewCode_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.EmployeeNumber_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.InOutIndex_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.IsGlobal_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.JobCode_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.TimeIn_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.TimeOut_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.TotalInOutForEmployee_SubmittedTimeInOut + " TEXT , "
            + DatabaseConstants.EmployeeName_SubmittedEmployeeDataForCrew  + " TEXT , "
            + DatabaseConstants.WorkDate_SubmittedTimeInOut + " TEXT , PRIMARY KEY ( "
            + DatabaseConstants.CrewCode_SubmittedTimesheet + " , "
            + DatabaseConstants.JobCode_SubmittedTimesheet + " , "
            + DatabaseConstants.WorkDate_SubmittedTimesheet + " , "
            + DatabaseConstants.InOutIndex_SubmittedTimeInOut + " ) , FOREIGN KEY ( "
            + DatabaseConstants.EmployeeNumber_SubmittedTimeInOut+ " ) REFERENCES "
            + DatabaseConstants.TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW + " ( " + DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew + " )) ";


    //Dashboard Tables

    public static final String TABLE_DASHBOARD = "CREATE TABLE IF NOT EXISTS "
            + DatabaseConstants.TABLE_DASHBOARD + "("  + databaseCostants.Date + " TEXT , "
            + DatabaseConstants.JobAcsCode + " TEXT , "
            + databaseCostants.JobCompCode + " TEXT , "
            + databaseCostants.dashboardJobCode + " TEXT , "
            + databaseCostants.dashboardPycrCode + " TEXT , "
            + databaseCostants.dashboardPycrName + " TEXT , "
            + databaseCostants.EmpNo + " TEXT , "
            + databaseCostants.EmpTrdCode + " TEXT , "
            + databaseCostants.EmpTrdName + " TEXT , "
            + databaseCostants.EmpFirstName + " TEXT , "
            + databaseCostants.EmpLastName + " TEXT , "
            + databaseCostants.NhHrsTot + " TEXT , "
            + databaseCostants.OtHrsTot + " TEXT , "
            + databaseCostants.DotHrsTot  + " TEXT , "
            + databaseCostants.NhHrs1  + " TEXT , "
            + databaseCostants.OtHrs1  + " TEXT , "
            + databaseCostants.DotHrs1  + " TEXT , "
            + databaseCostants.NhHrs2 + " TEXT , "
            + databaseCostants.OtHrs2 + " TEXT , "
            + databaseCostants.DotHrs2 + " TEXT , "
            + databaseCostants.NhHrs3 +" TEXT , "
            + databaseCostants.OtHrs3 + " TEXT , "
            + databaseCostants.DotHrs3 + " TEXT , "
            + databaseCostants.NhHrs4 + " TEXT , "
            + databaseCostants.OtHrs4 + " TEXT , "
            + databaseCostants.DotHrs4 + " TEXT , "
            + databaseCostants.NhHrs5 + " TEXT , "
            + databaseCostants.OtHrs5 + " TEXT , "
            + databaseCostants.DotHrs5 + " TEXT , "
            + databaseCostants.NhHrs6 + " TEXT , "
            + databaseCostants.OtHrs6 + " TEXT , "
            + databaseCostants.DotHrs6 + " TEXT , "
            + databaseCostants.NhHrs7 + " TEXT , "
            + databaseCostants.OtHrs7 + " TEXT , "
            + databaseCostants.DotHrs7 + " TEXT , "
            + databaseCostants.Total_REG + " TEXT , "
            + databaseCostants.Total_OT + " TEXT , "
            + databaseCostants.Total_DOT + " TEXT , PRIMARY KEY ( "  + databaseCostants.Date + " , " + databaseCostants.dashboardPycrCode + " , " + databaseCostants.EmpNo +" )) ";


    public static final String TABLE_DASHBOARD_CREW_MEMBERS = "CREATE TABLE IF NOT EXISTS "
            + databaseCostants.TABLE_DASHBOARD_CREW_MEMBERS + "("  + databaseCostants.Date + " TEXT , "
            + databaseCostants.JobAcsCode + " TEXT , "
            + databaseCostants.JobCompCode + " TEXT , "
            + databaseCostants.dashboardJobCode + " TEXT , "
            + databaseCostants.dashboardPycrCode + " TEXT , "
            + databaseCostants.dashboardPycrName + " TEXT , "
            + databaseCostants.EmpNo + " TEXT , "
            + databaseCostants.EmpTrdCode + " TEXT , "
            + databaseCostants.EmpTrdName + " TEXT , "
            + databaseCostants.EmpFirstNameDetail + " TEXT , "
            + databaseCostants.EmpLastNameDetail + " TEXT , "
            + databaseCostants.NhHrsTot + " TEXT , "
            + databaseCostants.OtHrsTot + " TEXT , "
            + databaseCostants.DotHrsTot  + " TEXT , "
            + databaseCostants.NhHrs1  + " TEXT , "
            + databaseCostants.OtHrs1  + " TEXT , "
            + databaseCostants.DotHrs1  + " TEXT , "
            + databaseCostants.NhHrs2 + " TEXT , "
            + databaseCostants.OtHrs2 + " TEXT , "
            + databaseCostants.DotHrs2 + " TEXT , "
            + databaseCostants.NhHrs3 +" TEXT , "
            + databaseCostants.OtHrs3 + " TEXT , "
            + databaseCostants.DotHrs3 + " TEXT , "
            + databaseCostants.NhHrs4 + " TEXT , "
            + databaseCostants.OtHrs4 + " TEXT , "
            + databaseCostants.DotHrs4 + " TEXT , "
            + databaseCostants.NhHrs5 + " TEXT , "
            + databaseCostants.OtHrs5 + " TEXT , "
            + databaseCostants.DotHrs5 + " TEXT , "
            + databaseCostants.NhHrs6 + " TEXT , "
            + databaseCostants.OtHrs6 + " TEXT , "
            + databaseCostants.DotHrs6 + " TEXT , "
            + databaseCostants.NhHrs7 + " TEXT , "
            + databaseCostants.OtHrs7 + " TEXT , "
            + databaseCostants.DotHrs7 + " TEXT , "
            + databaseCostants.Total_REG + " TEXT , "
            + databaseCostants.Total_OT + " TEXT , "
            + databaseCostants.Total_DOT + " TEXT , PRIMARY KEY ( "  + databaseCostants.Date + " , " + databaseCostants.dashboardPycrCode + " , " + databaseCostants.EmpNo +" )) ";

    public static final String TABLE_DASHBOARD_CREW_MEMBERS_DETAILS = "CREATE TABLE IF NOT EXISTS "
            + databaseCostants.TABLE_DASHBOARD_CREW_MEMBERS_DETAILS + "("  + databaseCostants.DDSelectedDate + " TEXT , "
            + databaseCostants.DDEmpAcsCode + " TEXT , "
            + databaseCostants.DDEmpNo + " TEXT , "
            + databaseCostants.DDEmpFirstName + " TEXT , "
            + databaseCostants.DDEmpLastName + " TEXT , "
            + databaseCostants.DDTshDataType + " TEXT , "
            + databaseCostants.DDTshWorkCompCode + " TEXT , "
            + databaseCostants.DDTshJobCode + " TEXT , "
            + databaseCostants.DDTshPhase + " TEXT , "
            + databaseCostants.DDTshCategory + " TEXT , "
            + databaseCostants.DDTshDeptCode + " TEXT , "
            + databaseCostants.DDTshGlAccCode + " TEXT , "
            + databaseCostants.DDTshTradeCode + " TEXT , "
            + databaseCostants.DDTshUnionCode  + " TEXT , "
            + databaseCostants.DDTshShiftCode  + " TEXT , "
            + databaseCostants.DDTshJobName  + " TEXT , "
            + databaseCostants.DDTshPhaseName  + " TEXT , "
            + databaseCostants.DDTshCategoryName + " TEXT , "
            + databaseCostants.DDTshDeptName + " TEXT , "
            + databaseCostants.DDTshGlAccName + " TEXT , "
            + databaseCostants.DDTshTradeName + " TEXT , "
            + databaseCostants.DDTshUnionName + " TEXT , "
            + databaseCostants.DDTshShiftName  + " TEXT , "
            + databaseCostants.DDNhHrsTot  + " TEXT , "
            + databaseCostants.DDOtHrsTot  + " TEXT , "
            + databaseCostants.DDDotHrsTot  + " TEXT , "
            + databaseCostants.DDOtherHrsTot + " TEXT , "
            + databaseCostants.DDNhHrs1 + " TEXT , "
            + databaseCostants.DDOtHrs1 + " TEXT , "
            + databaseCostants.DDDotHrs1 + " TEXT , "
            + databaseCostants.DDNhHrs2 + " TEXT , "
            + databaseCostants.DDOtHrs2 + " TEXT , "
            + databaseCostants.DDDotHrs2 + " TEXT , "
            + databaseCostants.DDNhHrs3 +" TEXT , "
            + databaseCostants.DDOtHrs3 + " TEXT , "
            + databaseCostants.DDDotHrs3 + " TEXT , "
            + databaseCostants.DDNhHrs4 + " TEXT , "
            + databaseCostants.DDOtHrs4 + " TEXT , "
            + databaseCostants.DDDotHrs4 + " TEXT , "
            + databaseCostants.DDNhHrs5 + " TEXT , "
            + databaseCostants.DDOtHrs5 + " TEXT , "
            + databaseCostants.DDDotHrs5 + " TEXT , "
            + databaseCostants.DDNhHrs6 + " TEXT , "
            + databaseCostants.DDOtHrs6 + " TEXT , "
            + databaseCostants.DDDotHrs6 + " TEXT , "
            + databaseCostants.DDNhHrs7 + " TEXT , "
            + databaseCostants.DDOtHrs7 + " TEXT , "
            + databaseCostants.DDDotHrs7 + " TEXT , "
            + databaseCostants.DDTotal_REG + " TEXT , "
            + databaseCostants.DDTotal_OT + " TEXT , "
            + databaseCostants.DDTotal_DOT + " TEXT , PRIMARY KEY ( "  + databaseCostants.DDSelectedDate +" , " + databaseCostants.DDEmpNo +" )) ";

    //  public static final String TABLE_DASHBOARD_CREW_MEMBERS_DETAIL = "CREATE TABLE IF NOT EXISTS "+ databaseCostants.TABLE_DASHBOARD_CREW_MEMBERS_DETAILS + "(" + databaseCostants.WeekDetail + " TEXT," + databaseCostants.TshEmpNoDetail + " TEXT," + databaseCostants.TshWorkcompCodeDetail + " TEXT,"+ databaseCostants.TshjobcodeDetail + " TEXT," + databaseCostants.TshPhaseDetail + " TEXT," + databaseCostants.PyCrCodeDetail + " TEXT," + databaseCostants.PyCrNameDetail + " TEXT," + databaseCostants.EmpFirstNameDetail + " TEXT," + databaseCostants.EmpLastNameDetail + " TEXT," + databaseCostants.thisNhHrsDetail + " TEXT," + databaseCostants.thisOtHrsDetail + " TEXT," + databaseCostants.thisDotHrsDetail + " TEXT," + databaseCostants.prevNhHrsDetail + " TEXT,"  + databaseCostants.prevOtHrsDetail  + " TEXT," + databaseCostants.prevDotHrsDetail  + " TEXT,PRIMARY KEY(" + databaseCostants.TshEmpNoDetail + "," + databaseCostants.JobCompCode + "," + databaseCostants.dashboardJobCode + "," + databaseCostants.EmpNo +"))";

    public DBHelper(Context context) {

        super(context, databaseCostants.DATABASE_NAME, null, 1);
        this.context = context;
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(TABLE_DASHBOARD);
            db.execSQL(CREATE_TABLE_User);
            db.execSQL(CREATE_TABLE_SelectedJobs);
            db.execSQL(CREATE_TABLE_Employee);
            db.execSQL(CREATE_TABLE_CrewDetails);
            db.execSQL(CREATE_TABLE_EMPLOYEE_LINKING_CREW);
            db.execSQL(CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES);
            db.execSQL(CREATE_TABLE_Category);
            db.execSQL(CREATE_TABLE_Phase);
            db.execSQL(TABLE_CREW_LIST);
            db.execSQL(TABLE_DASHBOARD_CREW_MEMBERS);
            db.execSQL(TABLE_DASHBOARD_CREW_MEMBERS_DETAILS);
            db.execSQL(CREATE_TABLE_SubmittedTimeCrew);
            db.execSQL(CREATE_TABLE_EmployeeDataForCrew);
            db.execSQL(CREATE_TABLE_SubmittedActivityFromCrew);
            db.execSQL(CREATE_TABLE_ActivityTimeForCrew);

            //Submitted Tables Created
            db.execSQL(TABLE_SUBMITTED_TIMESHEET);
            db.execSQL(TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET);
            db.execSQL(TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW);
            db.execSQL(TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE);
            db.execSQL(TABLE_SUBMITTED_TIME_IN_OUT);
        }
        catch (SQLException e)
        {
            Log.e("sqlException", e.toString());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_SELECTED_JOBS);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_EMPLOYEE);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_CREW_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_EMPLOYEE_LINKING_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_CATEGORY);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_PHASE);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_SUBMITTED_TIME_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_EMPLOYEE_DATA_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_SUBMITTED_ACTIVITY_FROM_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_ACTIVITY_TIME_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_CREW_LIST);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_DASHBOARD_CREW_MEMBERS);
        db.execSQL("DROP TABLE IF EXISTS " + databaseCostants.TABLE_DASHBOARD_CREW_MEMBERS_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SUBMITTED_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET);
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW);
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE);
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseConstants.TABLE_SUBMITTED_TIME_IN_OUT);

        onCreate(db);
    }

//Insert Into Table insertIntoSubmitTimesheet

    public boolean insertIntoSubmitTimesheet(String CrewCode,String JobCode,String SeqNo, String WorkDate)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.CrewCode_SubmittedTimesheet, CrewCode);
            contentValues.put(DatabaseConstants.JobCode_SubmittedTimesheet,JobCode);
            contentValues.put(DatabaseConstants.SeqNo_SubmittedTimesheet, SeqNo);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedTimesheet,WorkDate);
            db.insert(DatabaseConstants.TABLE_SUBMITTED_TIMESHEET, null, contentValues);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }


    public boolean insertIntoSubmittedActivityForTimesheet(String ActivityName,String CategoryCode,String ColoumnNumber,
                                                           String CrewCode,String JobCode,String PciLineOraseq,
                                                           String PhaseCode, String SeqNo,String WbsCode,String WorkDate)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.ActivityName_SubmittedaActivityForTimeSheet, ActivityName);
            contentValues.put(DatabaseConstants.CategoryCode_SubmittedaActivityForTimeSheet, CategoryCode);
            contentValues.put(DatabaseConstants.ColoumnNumber_SubmittedaActivityForTimeSheet, ColoumnNumber);
            contentValues.put(DatabaseConstants.CrewCode_SubmittedaActivityForTimeSheet, CrewCode);
            contentValues.put(DatabaseConstants.JobCode_SubmittedaActivityForTimeSheet, JobCode);
            contentValues.put(DatabaseConstants.PciLineOraseq_SubmittedaActivityForTimeSheet, PciLineOraseq);
            contentValues.put(DatabaseConstants.PhaseCode_SubmittedaActivityForTimeSheet, PhaseCode);
            contentValues.put(DatabaseConstants.SeqNumber_SubmittedaActivityForTimeSheet, SeqNo);
            contentValues.put(DatabaseConstants.WbsCode_SubmittedaActivityForTimeSheet, WbsCode);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedaActivityForTimeSheet, WorkDate);


            db.insert(DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET, null, contentValues);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public boolean insertIntoSubmittedEmployeeDataForCrew(String CrewCode,String EmployeeName,String EmployeeNumber,
                                                          String EmployeeOraseq,String TradeCode,String TradeName,
                                                          String JobCode, String RowNo,String WorkDate)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.CrewCode_SubmittedEmployeeDataForCrew, CrewCode);
            contentValues.put(DatabaseConstants.EmployeeName_SubmittedEmployeeDataForCrew, EmployeeName);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew, EmployeeNumber);
            contentValues.put(DatabaseConstants.EmployeeOraseq_SubmittedEmployeeDataForCrew, EmployeeOraseq);
            contentValues.put(DatabaseConstants.EmployeeTradeCode_SubmittedEmployeeDataForCrew, TradeCode);
            contentValues.put(DatabaseConstants.EmployeeTradeName_SubmittedEmployeeDataForCrew, TradeName);
            contentValues.put(DatabaseConstants.JobCode_SubmittedEmployeeDataForCrew, JobCode);
            contentValues.put(DatabaseConstants.RowNumber_SubmittedEmployeeDataForCrew, RowNo);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedaActivityForTimeSheet, WorkDate);
            db.insert(DatabaseConstants.TABLE_EMPLOYEE_DATA_FOR_CREW, null, contentValues);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public boolean insertIntoSubmittedActivityTimeForEmployee(String ActivityName,String ColoumnNumber,String DoubleHours,
                                                              String DoubleSeqNo,String EmployeeNumber,String OverTimeHours,
                                                              String OverTimeSeqNo, String RtHours,String RtSeqNo)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.ActivityName_SubmittedActivityTimeForEmployee, ActivityName);
            contentValues.put(DatabaseConstants.ColoumnNumber_SubmittedActivityTimeForEmployee, ColoumnNumber);
            contentValues.put(DatabaseConstants.Dothours_SubmittedActivityTimeForEmployee, DoubleHours);
            contentValues.put(DatabaseConstants.DotSeqNumber_SubmittedActivityTimeForEmployee, DoubleSeqNo);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedActivityTimeForEmployee, EmployeeNumber);
            contentValues.put(DatabaseConstants.OtHours_SubmittedActivityTimeForEmployee, OverTimeHours);
            contentValues.put(DatabaseConstants.OtSeqNumber_SubmittedActivityTimeForEmployee, OverTimeSeqNo);
            contentValues.put(DatabaseConstants.RtHours_SubmittedActivityTimeForEmployee, RtHours);
            contentValues.put(DatabaseConstants.RtSeqNumber_SubmittedActivityTimeForEmployee, RtSeqNo);

            db.insert(DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE, null, contentValues);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

/*
    public boolean insertIntoTimeInOut(String ActivityName,String CrewCode,String EmployeeNumber,
                                                              String InOutIndex,String IsGlobal,String JobCode,
                                                              String TimeIn, String TimeOut,String TotalInOutForEmployee,String WorkDate)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.ActivityName_SubmittedTimeInOut, ActivityName);
            contentValues.put(DatabaseConstants.CrewCode_SubmittedTimeInOut, CrewCode);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedTimeInOut, EmployeeNumber);
            contentValues.put(DatabaseConstants.InOutIndex_SubmittedTimeInOut, InOutIndex);
            contentValues.put(DatabaseConstants.IsGlobal_SubmittedTimeInOut, IsGlobal);
            contentValues.put(DatabaseConstants.JobCode_SubmittedTimeInOut, JobCode);
            contentValues.put(DatabaseConstants.TimeIn_SubmittedTimeInOut, TimeIn);
            contentValues.put(DatabaseConstants.TimeOut_SubmittedTimeInOut, TimeOut);
            contentValues.put(DatabaseConstants.TotalInOutForEmployee_SubmittedTimeInOut, TotalInOutForEmployee);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedTimeInOut, WorkDate);

            db.insert(DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE, null, contentValues);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }*/



    public boolean insertUser(String username, String password)
    {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.Username, username);
            contentValues.put(databaseCostants.Password, password);
            db.insert(databaseCostants.TABLE_USER, null, contentValues);

            // Log.d("USERNAME", username);
            // Log.d("PASSWORD", password);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String authenticateUser(String username, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from " + databaseCostants.TABLE_USER + " where " + databaseCostants.Username + " = '" + username + "'", null);
        cursor.moveToFirst();
        String Password = cursor.getString(cursor.getColumnIndex(databaseCostants.Password));
        if (Password == null) {
            Log.d("Data not Exist", "Password");
            return null;

        }
        if (Password.equals(password)) {
            Log.d("Success", password);
            return password;
        }
        return null;
    }

    public void dropTableAllEmployees()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(DROP_TABLE_INSERTING_SELECTED_EMPLOYEES);
    }

    //Inserting The Selected Values Into Table
    public void insertSelectedEmployees(String pyelempNo, String pyelempOraseq, String pyelempName, String pyelAccessCode, String pyelcompName, String pyelPrnCode, String pyelPrnName ,String compCode,String trdCode,String trdName,String uniCode,String uniName)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            // db.execSQL(DROP_TABLE_ALLEMPLOYEES);
            Log.d("table Employee",CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES);
            db.execSQL(CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES);
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.pyelEmpNumber, pyelempNo);
            contentValues.put(databaseCostants.pyelEmpOraseq, pyelempOraseq);
            contentValues.put(databaseCostants.pyelEmpName, pyelempName);
            contentValues.put(databaseCostants.pyelAccessCode, pyelAccessCode);
            contentValues.put(databaseCostants.pyelCompName, pyelcompName);
            contentValues.put(databaseCostants.pyelPrnCode, pyelPrnCode);
            contentValues.put(databaseCostants.pyelPrnName, pyelPrnName);
            contentValues.put(databaseCostants.pyelCompCode,compCode);
            contentValues.put(databaseCostants.pyelTrdCode,trdCode);
            contentValues.put(databaseCostants.pyelTrdName,trdName);
            contentValues.put(databaseCostants.pyelUniCode,uniCode);
            contentValues.put(databaseCostants.pyelUniName,uniName);
            db.insert(databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES, null, contentValues);

            db.close();
            // return true;

        }
        catch (Exception e)
        {
            Log.d("insertingcrewEmployee", e.toString());
            //return false;
        }
    }

    //Selecting the EmployeeData From Table
    public ArrayList<AllEmployeesModel> selectInsertedEmployees()
    {
        AllEmployeesModel selectedemployees;
        ArrayList<AllEmployeesModel> selected = new ArrayList<>();

        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor c = db.rawQuery("Select * from " + databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES, null);
            if(c != null && c.getCount() > 0)
            {
                c.moveToFirst();
                do {
                    String PyelEmpNo = c.getString(0);
                    String PyelEmpOraseq = c.getString(1);
                    String PyelEmpName = c.getString(2);
                    String PyelEmpAccessCode = c.getString(3);
                    String PyelCompName = c.getString(4);
                    String PyelPrnCode = c.getString(5);
                    String PyelPrnName = c.getString(6);
                    String PyelCompCode = c.getString(7);
                    String PyelTrdCode = c.getString(8);
                    String PyelTrdName = c.getString(9);
                    String PyelUnicode = c.getString(10);
                    String PyelUniName = c.getString(11);
                    selectedemployees = new AllEmployeesModel(PyelEmpNo, PyelEmpOraseq, PyelEmpName, PyelEmpAccessCode,PyelCompName,PyelPrnCode,PyelPrnName,PyelCompCode,PyelTrdCode,PyelTrdName,PyelUnicode,PyelUniName);
                    selected.add(selectedemployees);
                    // Log.d("CategoryyName", CatName);
                }
                while (c.moveToNext());
            }
            else
            {
                Log.d("Empty Data","category");

            }
        }
        catch (Exception e)
        {
            Log.d("Exception",e.toString());
        }
        return selected;
    }

    // Inserting The Pre SelectedEmployees for crew
    public void insertCrewEmployee(String pycecreworaseq, String pycecrewcode, String pycecrewname, String pyceemporaseq, String pyceempno, String pyceoraseq, String pyceempname,String pycetrdcode,String pycetrdname)
    {
        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
            // db.execSQL(CREATE_TABLE_EMPLOYEE_LINKING_CREW);
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.pycecreworaseq, pycecreworaseq);
            contentValues.put(databaseCostants.pycecrewcode, pycecrewcode);
            contentValues.put(databaseCostants.pycecrewname, pycecrewname);
            contentValues.put(databaseCostants.pyceemporaseq, pyceemporaseq);
            contentValues.put(databaseCostants.pyceempno, pyceempno);
            contentValues.put(databaseCostants.pyceoraseq, pyceoraseq);
            contentValues.put(databaseCostants.pyceempname, pyceempname);
            contentValues.put(databaseCostants.pycetrdcode, pycetrdcode);
            contentValues.put(databaseCostants.pycetrdname,pycetrdname);
            long insertedcorrectly = db.insert(databaseCostants.TABLE_EMPLOYEE_LINKING_CREW, null, contentValues);
            Log.d("correctly or not", String.valueOf(insertedcorrectly));


            db.close();

        }
        catch (Exception e)
        {
            Log.d("insertingcrewEmployee", e.toString());
        }

    }

    // Selecting the Inserted Employees
    public ArrayList<AttributeValuesForCrewModal> selectAllInsertedEmployees()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        User userList;
        ArrayList<AttributeValuesForCrewModal> preSelectedEmployees = new ArrayList<>();

        try
        {
            Cursor c = db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_EMPLOYEE_LINKING_CREW, null);
            if (c != null && c.getCount() > 0)
            {
                c.moveToFirst();
                do
                {
                    String pyceCrewOraseq = c.getString(0);
                    String pyceCrewCode = c.getString(1);
                    String pyceCrewName = c.getString(2);
                    String pyceEmpOraseq = c.getString(3);
                    String pyceEmpNo = c.getString(4);
                    String pyceOraseq = c.getString(5);
                    String pyceEmpName = c.getString(6);
                    String pyceTrdCode = c.getString(7);
                    String pyceTrdName = c.getString(8);
                    AttributeValuesForCrewModal attributeValuesForCrewModal = new AttributeValuesForCrewModal(pyceCrewOraseq,pyceCrewCode,pyceCrewName,pyceEmpOraseq,pyceEmpNo,pyceOraseq,pyceEmpName,pyceTrdCode,pyceTrdName);
                    preSelectedEmployees.add(attributeValuesForCrewModal);
                    //preSelectedEmployees.add();
                }
                while (c.moveToNext());
                c.close();
                db.close();
            }
        }
        catch (Exception e)
        {
            Log.d("error in selecting", e.toString());
            return null;
        }
        return preSelectedEmployees;
    }
/*    // Selecting the Employees on Basis of Emp Oraseq
    public ArrayList<User> selectAllInsertedEmployeesOnTheBasisOfEmpOraSeq(String[] oraseq) {
        SQLiteDatabase db = this.getWritableDatabase();
        User userList;
        ArrayList<User> selectedCrewDetails = new ArrayList<>();

        try {
            Log.d("EmployeeOraseq", String.valueOf(oraseq));
            for (int i = 0; i < oraseq.length; i++) {
                int j = oraseq.length;
                // Cursor c1 = db.rawQuery("SELECT * FROM "+databaseCostants.TABLE_ALL_EMPLOYEES, null);
                //int s= c1.getCount();
                Cursor c = db.rawQuery("SELECT * FROM " + databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES + " WHERE " + databaseCostants.pyelEmpOraseq + " = '" + oraseq[i] + "'", null);
                int si = c.getCount();
                if (c.moveToFirst()) {
                    String pyelEmpNumber = c.getString(0);
                    String pyelEmpOraseq = c.getString(1);
                    String pyelEmpName = c.getString(2);
                    String pyelAccessCode = c.getString(3);
                    String pyelCompName = c.getString(4);
                    String pyelPrnCode = c.getString(5);
                    String pyelPrnName = c.getString(6);
                    Log.d("Name1", pyelEmpName);
                    //  userList = new User(pyelEmpNumber, pyelEmpName, "Designation", pyelEmpOraseq);
                    // selectedCrewDetails.add(i, pyelEmpName);
                }
                while (c.moveToNext()) ;
                c.close();
            }
            db.close();
        } catch (Exception e) {
            Log.d("error in selecting", e.toString());
            return null;
        }
        return selectedCrewDetails;
    }*/

    //Inserting All the Values In GetPhaseTask Details
    public void insertPhaseDetails(String JhpJobCode, String JhpCode, String JhpName, String JhpCompCode)
    {

        try
        {
            SQLiteDatabase db = this.getWritableDatabase();
           /* db.execSQL(CREATE_TABLE_Category);*/
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.phasejobcode, JhpJobCode);
            Log.d("JhpJobCode PhaseTable", JhpJobCode);
            contentValues.put(databaseCostants.phasecode, JhpCode);
            Log.d("CompCode PhaseTable", JhpCode);
            contentValues.put(databaseCostants.phasename, JhpName);
            Log.d("PhaseNames PhaseTable", JhpName);
            contentValues.put(databaseCostants.phasecompcode, JhpCompCode);
            Log.d("JhpCompCode PhaseTable", JhpCompCode);
            db.insertOrThrow(databaseCostants.TABLE_PHASE, null, contentValues);
            db.close();
        }
        catch (Exception e)
        {
            Log.d("insert phase Details db", e.toString());
        }
    }

    //Inserting All the Values In Category Details
    public void insertCategoryDetails(String JcatJobCode, String JcatCode, String CatName, String JcatPhsCode)
    {

        try {
            Log.d("job Categorytable",JcatJobCode);
            Log.d("phase Categorytable", JcatPhsCode);
            Log.d("category Categorytable",JcatCode);
            Log.d("catname Categorytable", CatName);
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.categoryjobcode, JcatJobCode);
            contentValues.put(databaseCostants.categoryphasecode, JcatPhsCode);
            contentValues.put(databaseCostants.categorycode, JcatCode);
            contentValues.put(databaseCostants.categoryname, CatName);
            long insertedcategory =  db.insert(databaseCostants.TABLE_CATEGORY, null, contentValues);
            Log.d("inserted category", String.valueOf(insertedcategory));
            db.close();
        } catch (Exception e)
        {
            Log.d("insert cat Details db", e.toString());
        }
    }

    // selecting All The Phasename from database
    public ArrayList<PhaseModal> selectPhaseNameOnBasisOfJobCode(String jobCode)
    {
        Log.d("JobCode iN database ",jobCode);
        SQLiteDatabase db = this.getWritableDatabase();

        ArrayList<PhaseModal> phaseList = new ArrayList<>();
        try
        {

            // Cursor c = db.rawQuery(" SELECT * FROM " + databaseCostants.TABLE_PHASE + " WHERE " + databaseCostants.phasejobcode + " = ' " + jobCode+ " '" , null);
            Cursor c = db.query(databaseCostants.TABLE_PHASE,null,databaseCostants.phasejobcode+ " =? ",new String[]{String.valueOf(jobCode)},null,null,null);

            Log.d("value in cursor", String.valueOf(c.getCount()));
            //  if (c != null && c.getCount() > 0)
            // {
            if(c.moveToFirst())
                do
                {
                    String JhpCompCode = c.getString(3);
                    Log.d("name of JhpCompCode", JhpCompCode);
                    String JhpJobCode = c.getString(0);
                    Log.d("name of JhpJobCode", JhpJobCode);
                    String JhpCode = c.getString(1);
                    Log.d("name of JhpCode", JhpCode);
                    String JhpName = c.getString(2);
                    Log.d("name of JhpName", JhpName);
                    PhaseModal phaseModal = new PhaseModal(JhpCompCode,JhpJobCode,JhpCode, JhpName);
                    phaseList.add(phaseModal);
                    // Log.e("phase list size : ", String.valueOf(phaseList.size()));
                }
                while (c.moveToNext());
            //  }

            //    if (c != null)
            c.close();
        }
        catch (Exception e)
        {
            Log.d("error in selecting", e.toString());
        }

        return phaseList;
    }

    // Select categoryName on basis of jobcode and Phasecode
    public ArrayList<CategoryDetails> selectCategoryNameOnBasisOfJocCodeAndPhaseCode(String jobCode, String phaseCode)
    {
        try
        {
            Log.d("Jobcode in database", jobCode);
            Log.d("GetPhaseTsk in Database", phaseCode);
            SQLiteDatabase db = this.getWritableDatabase();
            CategoryDetails categoryDetails;
            ArrayList<CategoryDetails> category = new ArrayList<>();
            // Log.d("qwery category",CREATE_TABLE_Category);
            Cursor c = db.rawQuery(" SELECT * FROM " + databaseCostants.TABLE_CATEGORY + " WHERE " + databaseCostants.categoryjobcode + " = '" + jobCode +"' AND " + databaseCostants.categoryphasecode + " ='" + phaseCode + "' ", null);
            //  String str = " SELECT * FROM " + databaseCostants.TABLE_CATEGORY + " WHERE " + databaseCostants.categoryjobcode + " = '" + jobCode + " ' AND " + databaseCostants.categoryphasecode + " = '" + phaseCode + " ' ";
            // Log.d("QUERY",str);
            if(c != null && c.getCount() > 0)
            {
                c.moveToFirst();
                do {
                    // db.execSQL(CREATE_TABLE_Category);

                    String JcatJobCode = c.getString(0);
                    String JcatCode = c.getString(1);
                    String CatName = c.getString(2);
                    String JcatPhsCode = c.getString(3);
                    // String JcatCompCode = c.getString(4);
                    Log.d("CategoryName", CatName+" "+JcatCode + " " + JcatJobCode + " " + JcatPhsCode);
                    categoryDetails = new CategoryDetails(JcatJobCode, JcatCode, CatName, JcatPhsCode);
                    category.add(categoryDetails);
                }

                while (c.moveToNext());
                c.close();
                db.close();
            }
            else
            {
                Log.d("Empty Data","category");

            }
            return category;
        }
        catch (Exception e)
        {
            Log.e("error 11 :", e.toString());
            return null;
        }

    }

    public void selectAllCategoryDetails()
    {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            Cursor c = db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_CATEGORY, null);
            if (c.moveToFirst()) {
                String categoryJobCode = c.getString(0);
                String categoryCode = c.getString(1);
                String categoryName = c.getString(2);
                String categoryPhaseCode = c.getString(3);
                String PyceEmpNo = c.getString(4);
                String PyceOraseq = c.getString(5);
                String PyceEmpName = c.getString(6);
                Log.d("Name1", categoryName);
            }
            while (c.moveToNext()) ;
            c.close();
            db.close();
        } catch (Exception e) {
            Log.d("error in selecting", e.toString());
        }
    }

    public void insertSubmittedTimeCrew(String crewCode, String seqNumber, String workdate, String jobCode) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.crewcode, crewCode);
            contentValues.put(databaseCostants.seqNumber, seqNumber);
            contentValues.put(databaseCostants.workDate, workdate);
            contentValues.put(databaseCostants.jobcode, jobCode);

            db.insert(databaseCostants.TABLE_SUBMITTED_TIME_CREW, null, contentValues);
            db.close();
            Log.d("submittedTimeCrew :", "inserted");

        } catch (Exception e) {
            Log.e("error", " inserting in SubmittedTimeCrew");
        }
    }

    public void insertEmployeeDataForCrew(String empNumber, String rowNumber, String deleteFlag, String workDate, String crewCode) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.employeeNumber, empNumber);
            contentValues.put(databaseCostants.rowNumber, rowNumber);
            contentValues.put(databaseCostants.deleteFlag, deleteFlag);
            contentValues.put(databaseCostants.workDate, workDate);
            contentValues.put(databaseCostants.crewcode, crewCode);

            db.insert(databaseCostants.TABLE_EMPLOYEE_DATA_FOR_CREW, null, contentValues);
            db.close();
            Log.d("employeeDataForCrew", "inserted");
        } catch (Exception e) {
            Log.e("error", "inserting in EmployeeDataForCrew");
        }
    }

    public void insertSubmittedActivityFromCrew(String WBSCode, String columnNumber, String phaseCode, String seqNumber, String activityName, String deleteFlag, String catCode, String pcilineOraseq, String crewCodw, String workDate) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.WBSCode, WBSCode);
            contentValues.put(databaseCostants.columnNumber, columnNumber);
            contentValues.put(databaseCostants.phasecode, phaseCode);
            contentValues.put(databaseCostants.seqNumber, seqNumber);
            contentValues.put(databaseCostants.activityName, activityName);
            contentValues.put(databaseCostants.deleteFlag, deleteFlag);
            contentValues.put(databaseCostants.categorycode, catCode);
            contentValues.put(databaseCostants.PcilineOraseq, pcilineOraseq);
            contentValues.put(databaseCostants.crewcode, crewCodw);
            contentValues.put(databaseCostants.workDate, workDate);

            db.insert(databaseCostants.TABLE_SUBMITTED_ACTIVITY_FROM_CREW, null, contentValues);
            db.close();
            Log.d("SubmitedActivityFrmCrew", "inserted");
        } catch (Exception e) {
            Log.e("erroe", "inserting in SubmittedActivityFromCrew");
        }
    }

    public void insertActivityTimeForCrew(String otseqNumbr, String dotHour, String rtSeqNumber, String rtHours, String dotSeqNumber, String otHour, String crewCode, String workdate, String empNumber) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.otseqNumber, otseqNumbr);
            contentValues.put(databaseCostants.dothour, dotHour);
            contentValues.put(databaseCostants.rtSeqNumber, rtSeqNumber);
            contentValues.put(databaseCostants.rtHours, rtHours);
            contentValues.put(databaseCostants.dotSeqNumber, dotSeqNumber);
            contentValues.put(databaseCostants.otHour, otHour);
            contentValues.put(databaseCostants.crewcode, crewCode);
            contentValues.put(databaseCostants.workDate, workdate);
            contentValues.put(databaseCostants.employeeNumber, empNumber);

            db.insert(databaseCostants.TABLE_ACTIVITY_TIME_FOR_CREW, null, contentValues);
            db.close();
            Log.d("ActivityTimeForCrew", "inserted");

        } catch (Exception e) {
            Log.e("error", "inserting in ActivityTimeForCrew");
        }
    }

    public void selectAllInsertedCrewemployee()
    {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            Cursor c = db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_EMPLOYEE_LINKING_CREW, null);
            if (c.moveToFirst()) {
                String PyceCrewOraseq = c.getString(0);
                String PyceCrewCode = c.getString(1);
                String PyceCrewName = c.getString(2);
                String PyceEmpOraseq = c.getString(3);
                String PyceEmpNo = c.getString(4);
                String PyceOraseq = c.getString(5);
                String PyceEmpName = c.getString(6);
                Log.d("Name1", PyceCrewName);
            }
            while (c.moveToNext()) ;
            c.close();
            db.close();
        } catch (Exception e) {
            Log.d("error in selecting", e.toString());
        }
    }

    //Selecting All the Employees
    public ArrayList<User> selectAllEmployeeName() {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<User> userList = new ArrayList<>();
        try {

            Cursor c = db.rawQuery("SELECT * FROM " + databaseCostants.TABLE_PHASE, null);
            int c2 = c.getCount();
            if (c.moveToFirst()) {
                do {

                    String pyelEmpNumber = c.getString(0);
                    String pyelEmpOraseq = c.getString(1);
                    String pyelEmpName = c.getString(2);
                    String pyelAccessCode = c.getString(3);
                    String pyelCompName = c.getString(4);
                    String pyelPrnCode = c.getString(5);
                    String pyelPrnName = c.getString(6);
                    // User user = new User(pyelEmpNumber, pyelEmpName, "Designation", pyelEmpOraseq);
                    //  userList.add(user);
                }
                while (c.moveToNext());
            }
            c.close();
            db.close();
        } catch (Exception e) {
            Log.d("error in selecting", e.toString());
        }
        return userList;
    }

    public ArrayList<String> selectAllInsertedCrewemployeeOnBasisOfEmpNo(ArrayList<String> empNumber) {

        System.out.println("db emp lkis " + empNumber);
        if (empNumber != null && !empNumber.isEmpty()) {
            ArrayList<String> empNameList = new ArrayList<>();
            SQLiteDatabase db = this.getWritableDatabase();
//            try
//            {
            Log.d("in try", "try");
            for (int i = 0; i < empNumber.size(); i++) {
                Cursor c = db.rawQuery("SELECT " + databaseCostants.pyceempname + " FROM " + databaseCostants.TABLE_EMPLOYEE_LINKING_CREW + " WHERE " + databaseCostants.pyceempno + " = \"" + empNumber.get(i) + "\"", null);
                if (c.moveToFirst()) {
                    empNameList.add(i, c.getString(0));
                }
                while (c.moveToNext()) ;
                c.close();
            }

            db.close();
//            }
//            catch (Exception e)
//            {
//                Log.d("error in selecting", e.toString());
//            }
            Log.d("databasevalues", String.valueOf(empNameList));
            return empNameList;
        } else {
            Log.d("in if", "else");
            return null;
        }


    }

    public boolean insertSelectedCrewList(String crewCode, String crewName, String  crewOraseq)
    {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(databaseCostants.pycecrewcode, crewCode);
            contentValues.put(databaseCostants.pycecrewname, crewName);
            contentValues.put(databaseCostants.pycecreworaseq, crewOraseq);
            db.insert(databaseCostants.TABLE_CREW_LIST, null, contentValues);

            //  Log.d("JOB_NAME", jobName);
            // Log.d("JOB_COMPCODE", jobCompCode);
            /// Log.d("JOB_Code", jobCode);

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, databaseCostants.TABLE_USER);
        return numRows;
    }

    public ArrayList<String> getAllCotacts()
    {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + databaseCostants.TABLE_USER, null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(databaseCostants.Password)));
            res.moveToNext();
        }
        return array_list;
    }


    public void InsertIntoSubmittedTimeSheet(String CrewCode, String JobCode, String SeqNumber, String WorkDate)
    {

        try {
            Log.d("categoryjob code",CrewCode);
            Log.d("categoryphase code", JobCode);
            Log.d("category cat code",SeqNumber);
            Log.d("categorycatname", WorkDate);
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.CrewCode_SubmittedTimesheet, CrewCode);
            contentValues.put(DatabaseConstants.JobCode_SubmittedTimesheet, JobCode);
            contentValues.put(DatabaseConstants.SeqNo_SubmittedTimesheet, SeqNumber);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedTimesheet, WorkDate);
            long InsertedSubmittedTimeSheet =  db.insert(DatabaseConstants.TABLE_SUBMITTED_TIMESHEET, null, contentValues);
            Log.d("dbSubmittedTimeSheet", String.valueOf(InsertedSubmittedTimeSheet));
            db.close();
        }
        catch (Exception e)
        {
            Log.d("dbSubmittedTimeSheet", e.toString());
        }
    }
    public void InsertIntoSubmittedActivityForTimesheet(String ActivityName, String CategoryCode, Integer ColoumnNumber, String CrewCode ,String JobCode ,String PciLineOraseq , String PhaseCode , String SeqNumber , String WbsCode ,String WorkDate)
    {

        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(DatabaseConstants.ActivityName_SubmittedaActivityForTimeSheet, ActivityName);
            contentValues.put(DatabaseConstants.CategoryCode_SubmittedaActivityForTimeSheet, CategoryCode);
            contentValues.put(DatabaseConstants.ColoumnNumber_SubmittedaActivityForTimeSheet, ColoumnNumber);
            contentValues.put(DatabaseConstants.CrewCode_SubmittedaActivityForTimeSheet, CrewCode);
            contentValues.put(DatabaseConstants.JobCode_SubmittedaActivityForTimeSheet, JobCode);
            contentValues.put(DatabaseConstants.PciLineOraseq_SubmittedaActivityForTimeSheet, PciLineOraseq);
            contentValues.put(DatabaseConstants.PhaseCode_SubmittedaActivityForTimeSheet, PhaseCode);
            contentValues.put(DatabaseConstants.SeqNumber_SubmittedaActivityForTimeSheet, SeqNumber);
            contentValues.put(DatabaseConstants.WbsCode_SubmittedaActivityForTimeSheet, WbsCode);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedaActivityForTimeSheet, WorkDate);

            long InsertedSubmittedActivityForTimeSheet =  db.insert(DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_FOR_TIMESHEET, null, contentValues);
            Log.d("ActivityForTimeSheet", String.valueOf(InsertedSubmittedActivityForTimeSheet));
            db.close();
        }
        catch (Exception e)
        {
            Log.d("ActivityForTimeSheet", e.toString());
        }
    }

    public void InsertIntoSubmittedEmployeeDataForCrew(String CrewCode, String EmployeeName, String EmployeeNumber, String EmployeeOraseq ,String EmployeeTradeCode ,String EmployeeTradeName , String JobCode , String RowNumber , String WorkDate )
    {

        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.CrewCode_SubmittedEmployeeDataForCrew, CrewCode);
            contentValues.put(DatabaseConstants.EmployeeName_SubmittedEmployeeDataForCrew, EmployeeName);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedEmployeeDataForCrew, EmployeeNumber);
            contentValues.put(DatabaseConstants.EmployeeOraseq_SubmittedEmployeeDataForCrew, EmployeeOraseq);
            contentValues.put(DatabaseConstants.EmployeeTradeCode_SubmittedEmployeeDataForCrew, EmployeeTradeCode);
            contentValues.put(DatabaseConstants.EmployeeTradeName_SubmittedEmployeeDataForCrew, EmployeeTradeName);
            contentValues.put(DatabaseConstants.JobCode_SubmittedEmployeeDataForCrew, JobCode);
            contentValues.put(DatabaseConstants.RowNumber_SubmittedEmployeeDataForCrew, RowNumber);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedEmployeeDataForCrew, WorkDate);
            long InsertedSubmittedEmployeeDataForCrew =  db.insert(DatabaseConstants.TABLE_SUBMITTED_EMPLOYEE_DATA_FOR_CREW, null, contentValues);
            Log.d("dbEmployeeDataForCrew", String.valueOf(InsertedSubmittedEmployeeDataForCrew));
            db.close();
        }
        catch (Exception e)
        {
            Log.d("dbEmployeeDataForCrew", e.toString());
        }
    }

    public void InsertIntoSubmittedActivityTimeForEmployee(String ActivityName, String ColoumnNumber, double DotHour ,String DotSeqNumber ,String EmployeeNumber , double OtHour , String OtSeqNumber , double RtHour ,String RtSeqNumber)
    {

        try {
            Log.d("ActivityName",ActivityName);
            Log.d("ColoumnNumber",ColoumnNumber);
            Log.d("DotHour", String.valueOf(DotHour));
            Log.d("DotSeqNumber",DotSeqNumber);
            Log.d("EmployeeNumber",EmployeeNumber);
            Log.d("OtHour", String.valueOf(OtHour));
            Log.d("OtSeqNumber", OtSeqNumber);
            Log.d("RtHour", String.valueOf(RtHour));
            Log.d("RtSeqNumber",RtSeqNumber);
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.ActivityName_SubmittedaActivityForTimeSheet, ActivityName);
            contentValues.put(DatabaseConstants.ColoumnNumber_SubmittedActivityTimeForEmployee, ColoumnNumber);
            contentValues.put(DatabaseConstants.Dothours_SubmittedActivityTimeForEmployee, DotHour);
            contentValues.put(DatabaseConstants.DotSeqNumber_SubmittedActivityTimeForEmployee, DotSeqNumber);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedActivityTimeForEmployee, EmployeeNumber);
            contentValues.put(DatabaseConstants.OtHours_SubmittedActivityTimeForEmployee, OtHour);
            contentValues.put(DatabaseConstants.OtSeqNumber_SubmittedActivityTimeForEmployee, OtSeqNumber);
            contentValues.put(DatabaseConstants.RtHours_SubmittedActivityTimeForEmployee, RtHour);
            contentValues.put(DatabaseConstants.RtSeqNumber_SubmittedActivityTimeForEmployee, RtSeqNumber);
            long InsertedSubmittedActivityTimeForEmployee =  db.insert(DatabaseConstants.TABLE_SUBMITTED_ACTIVITY_TIME_FOR_EMPLOYEE, null, contentValues);
            Log.d("dbActivityForTimeSheet", String.valueOf(InsertedSubmittedActivityTimeForEmployee));
            db.close();
        }
        catch (Exception e)
        {
            Log.d("dbActivityForTimeSheet", e.toString());
        }
    }
    public void InsertIntoSubmittedTimeInOut(String CrewCode, String EmployeeNumber ,String InOutIndex , Boolean IsGlobal , String JobCode , String TimeIn ,String TimeOut,Float TotalInOutForEmployee,String WorkDate)
    {

        try {
        /*    Log.d("ActivityName",ActivityName);
            Log.d("ColoumnNumber",CrewCode);
            Log.d("EmployeeNumber", EmployeeNumber);
            Log.d("InOutIndex",InOutIndex);
            Log.d("IsGlobal",IsGlobal);
            Log.d("JobCode",JobCode);
            Log.d("TimeIn", TimeIn);
            Log.d("TimeOut",TimeOut);
            Log.d("TotalInOutForEmployee",TotalInOutForEmployee);*/
            // Log.d("WorkDate",WorkDate);
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseConstants.CrewCode_SubmittedTimeInOut, CrewCode);
            contentValues.put(DatabaseConstants.EmployeeNumber_SubmittedTimeInOut, EmployeeNumber);
            contentValues.put(DatabaseConstants.InOutIndex_SubmittedTimeInOut, InOutIndex);
            contentValues.put(DatabaseConstants.IsGlobal_SubmittedTimeInOut, IsGlobal);
            contentValues.put(DatabaseConstants.JobCode_SubmittedTimeInOut, JobCode);
            contentValues.put(DatabaseConstants.TimeIn_SubmittedTimeInOut, TimeIn);
            contentValues.put(DatabaseConstants.TimeOut_SubmittedTimeInOut, TimeOut);
            contentValues.put(DatabaseConstants.TotalInOutForEmployee_SubmittedTimeInOut, TotalInOutForEmployee);
            contentValues.put(DatabaseConstants.WorkDate_SubmittedTimeInOut, WorkDate);
            long InsertedSubmittedTimeInOut =  db.insert(DatabaseConstants.TABLE_SUBMITTED_TIME_IN_OUT, null, contentValues);
            Log.d("dbTimeInOut", String.valueOf(InsertedSubmittedTimeInOut));
            db.close();
        }
        catch (Exception e)
        {
            Log.d("dbTimeInOut", e.toString());
        }
    }




    public void clear_Data()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete  from "+databaseCostants.TABLE_USER);
        db.execSQL("delete  from "+databaseCostants.TABLE_CREW_LIST);
        db.execSQL("delete  from "+databaseCostants.TABLE_SELECTED_JOBS);
        db.execSQL("delete  from "+databaseCostants.TABLE_EMPLOYEE);
        db.execSQL("delete  from "+databaseCostants.TABLE_CATEGORY);
        db.execSQL("delete  from "+databaseCostants.TABLE_CREW_DETAILS);
        db.execSQL("delete  from "+databaseCostants.TABLE_EMPLOYEE_LINKING_CREW);
        db.execSQL("delete  from "+databaseCostants.CREATE_TABLE_INSERTING_SELECTED_EMPLOYEES);
        db.execSQL("delete  from "+databaseCostants.TABLE_PHASE);
        db.execSQL("delete  from "+databaseCostants.TABLE_SUBMITTED_TIME_CREW);
        db.execSQL("delete  from "+databaseCostants.TABLE_EMPLOYEE_DATA_FOR_CREW);
        db.execSQL("delete  from "+databaseCostants.TABLE_SUBMITTED_ACTIVITY_FROM_CREW);
        db.execSQL("delete  from "+databaseCostants.TABLE_ACTIVITY_TIME_FOR_CREW);

    }
}
