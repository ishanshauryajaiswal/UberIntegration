package com.example.ishanjaiswal.cmicresultactivity;

public class WebConstants {

    public static final String baseURL = " http://v10xsandboxmobile.cmic360.com:7004/cmicprod";

    public static final String jobDataEndPoint = "eTimeData/jersey/etime/EtimeJob/select?";

}
