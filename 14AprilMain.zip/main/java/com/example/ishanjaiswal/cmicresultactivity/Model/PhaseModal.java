package com.example.ishanjaiswal.cmicresultactivity.Model;

/**
 * Created by ishan.jaiswal on 2/6/2018.
 */

public class PhaseModal
{
    private String phaseCode;
    private String phaseName = null;
    private String phasejobCode = null;
    private String phasecompCode = null;

    public PhaseModal(String phasecompCode,String phasejobCode ,String phaseCode, String phaseName ) {
        this.phaseCode = phaseCode;
        this.phaseName = phaseName;
        this.phasejobCode = phasejobCode;
        this.phasecompCode = phasecompCode;
    }
    public PhaseModal(String phaseName ) {
        this.phaseCode = phaseCode;
        this.phaseName = phaseName;
        this.phasejobCode = phasejobCode;
        this.phasecompCode = phasecompCode;
    }
    //getters
    public String getPhaseCode()
    {
        return  phaseCode;
    }

    public String getPhaseName()
    {
        return  phaseName;
    }

    public String getphaseJobCode()
    {
        return  phasejobCode;
    }

    public String getphaseCompCode()
    {
        return  phasecompCode;
    }

    //setters
    public void setPhaseCode(String phaseCode)
    {
        this.phaseCode=phaseCode;
    }
    public void setPhaseName(String phaseName)
    {
        this.phaseName=phaseName;
    }
    public void setJobCode(String jobCode)
    {
        this.phasejobCode=jobCode;
    }
    public void setCompCode(String compCode)
    {
        this.phasecompCode=compCode;
    }
}
