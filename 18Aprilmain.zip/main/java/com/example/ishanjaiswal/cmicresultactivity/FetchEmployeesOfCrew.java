package com.example.ishanjaiswal.cmicresultactivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

/**
 * Created by ishan.jaiswal on 2/7/2018.
 */

public class FetchEmployeesOfCrew extends AsyncTask<Void,Void,String> {
    private Context context;
    private String crewCode;
    ProgressDialog progressdialog;
    private FetchEmployeesOfCrewInterface fetchEmployeesOfCrewInterface;
    public FetchEmployeesOfCrew(Context context, String crewCode, FetchEmployeesOfCrewInterface fetchEmployeesOfCrewInterface){
        this.context = context;
        this.crewCode = crewCode;
        this.context = context;
        progressdialog = new ProgressDialog(context);
        this.fetchEmployeesOfCrewInterface = fetchEmployeesOfCrewInterface;
    }
    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        fetchEmployeesOfCrewInterface.preTask();
    }
    @Override
    protected String doInBackground(Void... params)
    {
        String response = "";
        RequestCall requestCall = new RequestCall();
        response = requestCall.fetchCrewEmployee(context, crewCode);
        return response;
    }
    @Override
    protected void onPostExecute(String response)
    {
        progressdialog.dismiss();
        fetchEmployeesOfCrewInterface.postTask(response);
    }
}
