package com.example.ishanjaiswal.cmicresultactivity.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.example.ishanjaiswal.cmicresultactivity.Model.AttributeValuesForCrewModal;
import com.example.ishanjaiswal.cmicresultactivity.Model.User;

import java.util.ArrayList;

/**
 * Created by ishan.jaiswal on 3/29/2018.
 */

public class IshanAllEmployeeDBHelper {
    private static final String TAG = IshanAllEmployeeDBHelper.class.getSimpleName();
    private static IshanDBConstants D = new IshanDBConstants();
    IshanDBHelper mInstance;
    public IshanAllEmployeeDBHelper(Context context)
    {
        mInstance = IshanDBHelper.getInstance(context);
    }

    public void insertAllEmployeeInDatabase(ArrayList<AttributeValuesForCrewModal> list)
    {
        SQLiteDatabase db = mInstance.getWritableDatabase();
        try {
            for (AttributeValuesForCrewModal employee : list) {
                ContentValues values = new ContentValues();
                values.put(D.All_PyceOraseq, employee.getPyceOraseq());
                values.put(D.All_EmpCrewCode, employee.getPyceCrewCode());
                values.put(D.All_EmpCrewName, employee.getPyceCrewName());
                values.put(D.All_EmpCrewOraseq, employee.getPyceCrewOraseq());
                values.put(D.All_EmpName, employee.getPyceEmpName());
                values.put(D.All_EmpNumber, employee.getPyceEmpNo());
                values.put(D.All_EmpOraseq, employee.getPyceEmpOraseq());
                values.put(D.All_TrdCode, employee.getPyceTrdCode());
                values.put(D.All_TrdName, employee.getPyceTrdName());
                int id = (int) db.insertWithOnConflict(D.TABLE_ALL_EMPLOYEES, null, values, SQLiteDatabase.CONFLICT_IGNORE);
                if (id == -1)
                    db.update(D.TABLE_ALL_EMPLOYEES, values, D.All_EmpNumber + "=?", new String[]{employee.getPyceEmpNo() + ""});
            }
        }
        catch(SQLiteException e) {
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        }
        catch(Exception e){
                Log.d(TAG, "Error While Inserting Project: " + e.getMessage());
        }
        finally {
            db.close();
        }
    }

    public String  getPyceOraSeqOfEmployee(String employeeNumber){
        SQLiteDatabase db = mInstance.getWritableDatabase();
        String pyceOraSeq="";
        try {
            Cursor cur = db.rawQuery("SELECT * FROM " + D.TABLE_ALL_EMPLOYEES + " WHERE "+ D.All_EmpNumber+ " = '" + employeeNumber + "'" , null);
            if (cur.moveToFirst())
                pyceOraSeq = cur.getString(cur.getColumnIndex(D.All_PyceOraseq));
            cur.close();
        }
        catch (SQLiteException e)
        {
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        catch (Exception e){
            Log.d(TAG, "Error While Fetching Employee: "+e.getMessage());
        }
        finally {
            db.close();
        }
        return pyceOraSeq;
    }

}
